# 1.0.0.19 — steady wrist and broad tip travel

This patch uses the requested broad tip arc around a mostly steady wrist. It retains the existing acceleration envelope, contact clock, cadence matching and 50% swing pace setting. The learning model, human demonstrations, 250,000 timestamp budget, camera controls, invisible body, three models and score-submission protections are unchanged. It targets the dedicated `1.40.8 (3)` AI instance.

## Confirmed findings

The supplied version 18 game trace contains angular motion almost entirely along the blade: at song times 24.3825, 24.4865 and 25.152 seconds, the axial fraction is over 99.8%. Rotating about that axis twists the handle without sweeping the tip. The controlled swing generator previously used the entire angular-velocity vector as its swing axis. Contact fitting also allowed a contact distance of 10% of blade length, and active grip holding applied only to dense passages.

An overlapping handoff copied the preceding plan's evaluator but omitted that plan's already-carried prefix. A new plan could therefore replace actual outgoing motion with its future seed path. An offline failed-contact candidate also reproduced an out-of-reach grip entering the inverse reach projection, which amplified position derivatives enormously. These are reproducible code defects; the decimated game trace does not establish that either is the sole cause of its reported 310 m/s maximum.

The real game log reports planning slices up to 176 ms despite a sub-millisecond budget. Speed-feasibility checks constructed discarded pose objects, active grip playback reconstructed discarded rotations, and the final planner measured scoring arcs whose result was unused whenever an owned envelope or burst already supplied the boundaries. Their unnecessary work is confirmed; the exact contribution to the live stall is not isolated by the existing log.

## Changes

- Derive the scored swing axis from angular motion perpendicular to the blade. Preserve the fitted controller roll, but do not extrapolate axial twist as the scoring sweep. If that transverse motion cannot cut the arrow, use its valid blade/cut plane. No arbitrary frame jitter, extra smoothing, new speed limit or neutral reset was added.
- Keep the wrist grip through active slow and fast swings when the next reachable contact permits it. Reserve early continuous repositioning for wide jumps. Prefer the longer blade contact lever; keep shorter reachable alternatives to avoid sacrificing attainable cuts.
- Flatten the actual carried evaluator ranges during overlapping replans, including wrist and frozen teacher ownership, without retaining chains of old plan objects.
- Keep failed contact fallbacks inside the invertible reach domain; project future preparation/release anchors before inverting them. Refine existing speed checks only near a short reach edge's speed boundary instead of clamping displayed movement.
- Use exact allocation-free angular-speed probes, exact grip-only curve sampling, and omit unused final scoring probes. Retain scoring measurements wherever they actually choose a protected boundary.

Changed source: `ReplayMotor.cs`, `ConstrainedReplayTrajectory.cs`, `TrajectoryMath.cs`, `ReachTransition.cs`, `BoundedWristBridge.cs`, `ContinuousWristBurst.cs`. `Plugin.cs` changes only the build identifier.

## Verification

The DLL compiles against the installed Beat Saber 1.40.8 assemblies. The full offline suite passes, including 9,961 new pivot/handoff/allocation assertions, native scoring-rule comparisons, all 32 Harmony targets, 1,826 native planner follow-through assertions, learning limits, ownership/memory checks, menus and unranked policies. These checks do not execute Unity gameplay.

Eight eligible human recordings exercise 1,337 plans, 5,915 nominal contacts and 666,649 sampled poses. They have no unmarked contact/direction failures, no unreachable published contacts, and no blade-angle violations beyond floating-point roundoff. There are 282 explicitly limited contact proxy misses and two limited direction differences, versus 288 and three in version 18. Maximum sampled grip speed is 17.4603 m/s. Maximum quaternion-derivative discrepancy is 0.004349 rad/s and linear discrepancy is 0.007974 m/s. Maximum angular speed is 180 rad/s, the existing feasibility bound; that bound is not a claim of normal human pace.

In a paired 109-plan comparison, planning allocations fell from 1,400,638,352 to 1,030,196,480 bytes (26.4%), and mean planning time from 17.49 to 12.74 ms. Warm incremental peak slices were 1.5762 and 1.3845 ms. A separate 100,000-probe test allocates 40 bytes for exact speed-only checks versus 32,000,000 bytes for full poses. These are offline measurements on .NET Framework, not verified Unity frame-time improvements; some allocation and garbage collection remain.

The 46.23-second 100 Bills Expert chart proxy has one limited nominal miss and zero nominal direction failures. Its approximate first-collision sweep worsens: 103 good / 40 direction errors versus version 18's 119 / 24. It uses approximate NJS and collision geometry and does not execute native cut detection. This remains a timing/accuracy risk, rather than proof of in-game results. The custom chart from the latest game log was not reproduced as native gameplay.

The configured 140-degree vertical range cannot guarantee both a straight 100-degree preparation and 60-degree follow-through on every note. The motor retains the allowed arc and necessary reachable repositioning. Actual accuracy, score, appearance and live lag require in-game validation. **No Unity gameplay or VR testing was performed for this release.**
