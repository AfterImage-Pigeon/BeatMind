# 1.0.0.24 — return strokes between repeated arrows

The user reported a full saber turn when two downslashes occur in succession. No new video was supplied for this report. The behavior was reproduced offline using the shipped v23 movement code: 18 of 108 two-downslash fixtures, across both hands, note heights and spacings, continued around the swing circle. Their largest net blade winding was 323.70 degrees between hits.

## Confirmed cause

The first swing's release and the second swing's preparation sometimes required an upward recovery of more than 180 degrees. `ConnectWrists` used a principal quaternion logarithm to select the shortest endpoint rotation. That chose the equivalent shorter downward route, combining the release, recovery and next approach into almost a full forward turn. Quaternion signs and normalization were valid; more smoothing would retain the wrong route.

## Changes

`ConstrainedReplayTrajectory.cs` selects the reverse recovery branch for compatible repeated arrows when the principal branch continues in the cutting direction. The existing recovery timing feasibility check now measures that actual branch. It retains one immutable recovery on the adjacent contacts so a replan after the first note has disappeared continues the same curve.

`TrajectoryMath.cs` allows the analytic rotation curve to retain a selected branch. Its middle subdivision preserves the same branch instead of taking another shortest quaternion logarithm. Both endpoint angular velocity and acceleration remain exact. The immutable recovery clears previous link references and does not retain a chain of old plans.

`Plugin.cs` records build 1.0.0.24. There are no other runtime source changes relative to v23. The new regression is `Tests/RepeatedCutRegression.cs`, registered in `Tests/Run.ps1`.

Contact selection, note times, contact speeds, learning, replay source files, unranked protections, head/body simulation, fast-stream pivots and collection policy are unchanged.

## Verification

- The game-referenced DLL compiles and the full offline suite passes.
- The 108 two-downslash fixtures now have zero full turns. Maximum net blade winding is 76.09 degrees, representing the change in target height rather than a full revolution.
- All 216 compared contact states have identical time, grip position, quaternion components and angular velocity to v23. Maximum component difference is zero.
- 931,880 focused assertions cover repeated down/up/diagonal arrows, both hands, nonzero grip/blade offsets, all three note heights, six spacings, direction/contact accuracy, rotation/acceleration continuity and replanning. Replanning the reproduced return differs by at most 9.81e-18 radians.
- The existing 57,488 fast-stream assertions and 24,960 original v14 parity assertions pass. All 32 native hooks resolve; 1,826 shipped planner follow-through assertions pass.
- The eight-recording proxy check passes 1,337 plans, 5,915 contact checks and 666,649 samples, retaining zero unmarked contact misses, zero wrong-direction contacts and zero unreachable contacts. The earlier map proxy retains its v23 results: 453 contacts, zero wrong-direction cuts, zero near-contact reversals, 13 limited contacts.

These checks exercise the actual motion mathematics offline and load game assemblies for binding checks. They do not execute Unity collisions or establish in-game/VR accuracy. Previously documented difficult-contact and memory-safety-pause limitations remain; this patch does not claim to remove all misses or lag.
