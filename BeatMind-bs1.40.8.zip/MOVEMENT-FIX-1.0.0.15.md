# BeatMind Human Beta 1.0.0.15

This update keeps the smooth acceleration from 1.0.0.14 and improves scored blade travel, follow-through and temporary memory use. F6 now offers AI head and mouse camera views during live FPFC play as well as replay watching. No Unity/VR gameplay was executed for this release.

## Confirmed causes

- The installed game scores the change in the blade's direction: 100° before contact for 70 points and 60° after contact for 30 points, with swing-plane weighting and a 400 ms observation window. Rolling around the blade axis or translating an upright blade does not earn that angular travel. Chain/arc endpoints have different scoring rules.
- Short dense fallback strokes used 80°/48° arcs. Recovery could trim them further. Recorded poses marked as human could still translate through a cut with almost no wrist travel.
- The provided Oct 2 desktop recording and corresponding native replay contain real pre-contact slowdowns. At replay song time 15.7235 s, a 4-point cut's wrist speed fell from about 233 to 15.8°/s before contact. At 24.5536 s, a 0-point cut had almost stationary wrist rotation and rapidly declining translation. Several 111–114 point cuts continued accelerating into contact. These are replay song times, not the desktop recording's UI timestamps.
- The old plan carry ignored cuts occurring before their scheduled contact and capped continuation at 100 ms. A hit could interrupt an unfinished release.
- Protecting larger arcs exposed a quaternion winding issue: after more than 180° of combined scored travel, a shortest return could continue forward to complete a 360°. A mixed recorded/generated transition could also discard its preparation marker behind a later midpoint marker.
- Optional markers 1.4–1.97 ms before a real contact caused the contact itself to be silently omitted. Wider contact jets could also make a safety repair discard previously reachable cuts. Inner reach-barrier engagement was incorrectly treated as an actual reach violation during an already safe spherical repair.

## Changes

The planner measures blade travel rather than trusting a human-source flag. Qualified full-scoring human arcs retain their recorded motion. Undersized normal-note arcs receive 115–117° preparation and 75° release when cadence allows, using the same continuous acceleration/deceleration envelope. Its peak is at planned contact. Genuine chain/arc scoring types avoid unnecessary angular repairs.

Repeated strokes recover on the rotational branch implied by their history, reversing instead of completing an extra turn. Preparation stays local to the next cut; openings and breaks retain their recorded gestures. Wrist joins are checked before publication, and real contact knots have priority over optional markers.

Native early cuts and queued plan handoffs retain the exact published release until completion, bounded by the next required contact. If expanded arcs cannot fit safely, contact repair retries the original fitted wrist jets at the same contact position, rotation and time. Physical reach is checked against the resulting hand radius. Replaced routes lose their old swing clocks so a subsequent plan cannot resurrect a discarded envelope.

The memory change caches immutable source events and builds target events once per selection. Aligned paths use two endpoint metadata knots while continuing to evaluate the full original recording and clock; all 129 demonstration points remain. Startup acknowledges the exact source snapshot it loaded, avoiding an unchanged duplicate model decode while detecting files arriving during import.

In FPFC, F6 switches between AI head and mouse views during Play & learn, Play learned or replay watching. Mouse looks; WASD/QE moves the free view; Shift speeds it up. The switch affects rendering only. Signed pitch initialization prevents a slightly tilted head from becoming an 85° free-camera tilt. F8 still restores manual gameplay. Pause and disposal restore camera state.

## Verification

- Full offline suite passed, including 61,275 scoring/motion assertions, 66,594 acceleration assertions, 5,952 reach-repair/route-ownership assertions, 1,108 release-continuation assertions, 1,826 checks of the compiled planner publication path, installed-native scoring comparisons, learning-cap checks, menus and all 32 Harmony hook targets.
- The same capped model and 100 Bills Expert fixture retain 145 planned contacts with zero nominal misses or wrong directions. Moving-cube proxies improved from 133 to 141 good crossings and from 11 to 2 direction errors. These are offline proxies, not an in-game accuracy result.
- Eight real recordings, 1,337 plans and 5,915 evaluated contacts: limited contact misses decreased from 243 to 191; direction differences decreased from 10 to 5. Both versions have zero unmarked contact misses and zero unreachable contacts. The new trajectory retains analytic derivatives. The sampled certification bound is 125 rad/s; a same-map continuous polynomial peak of 125.20 rad/s is a 0.16% between-probe overshoot, not a hard speed-clamp guarantee.
- The near-shoulder regression fails with the old barrier criterion and passes with actual-radius validation. The mixed preparation regression reproduces the omitted-marker defect when its ownership fix is removed.
- Current-source 80-second playback allocation decreased from 937,945,072 to 551,990,168 bytes (41.15%). Output hash `0B91D60870737C5D`, 12 choices and 24 searches are identical. This measures transient allocation in the offline graph audit, not total game RAM or live FPS.
- Prepared/cropped event parity passed 8,149,656 bitwise checks across 33,792 cases. Startup tests use the current Plugin/importer and verify one unchanged model load instead of two, including arrivals during loading. A standalone model decode allocates approximately 363.6 MB transiently; one unnecessary decode is avoided.

Very tight repeated patterns can still need less angular travel to preserve contact and bounded motion. The fixed-registration native oracle is not a dynamic cube collision and does not prove live cut scores. No promise of 100+ on every note, perfect accuracy or absence of all future bugs is made.

The installed 499,875-pose model, source replays, learned timing/strokes and settings are unchanged. The 500,000-pose budget, invisible articulated rig, three AI models, unranked gameplay, leaderboard blocking and existing controls remain.
