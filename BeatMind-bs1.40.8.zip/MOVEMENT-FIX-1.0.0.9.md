# SaberMind movement fix 1.0.0.9

## Confirmed cause

The fallback motion graph selected an entire human sequence using a soft posture/context score, then played it on its original clock. It did not use the already stored note anchors to align that sequence's swings with the current chart. Dense, irregular and diagonal human phrases therefore produced additional swings between the regular notes in 100Bills Expert. The contact motor then corrected those unrelated trajectories to reach the current notes.

The excessive rotation is already present at the graph's output, before body constraints and the final saber transform. Source 160 contains 6.4 notes per second with stacks and diagonal cuts; the affected chart section uses regular down/up alternation. Its stored blade travel is approximately 9.14/13.06 radians for left/right; dense interpolation gives 9.15/13.08 radians. Quaternion interpolation adds almost none of that travel. This is a source-selection and temporal-context mismatch, rather than evidence of a quaternion normalization or sign-flip failure.

The live build 1.0.0.8 log records 51 good cuts, 49 bad cuts and 5 misses, including 47 wrong-direction cuts. All 900 saved regular trace rows have matching requested/actual grip positions, zero wrist tracking/projection error and zero reach error to the saved precision. The native override sets the transform directly; native Saber.ManualUpdate reads blade endpoints without rewriting the transform. These observations do not establish the absence of later third-party parent-transform changes.

## Recording inspection

The supplied recording is 7.117 seconds at approximately 119.85 FPS. The inspected samples show the broad orange loop and purple overhead motion at 1.30–1.78 seconds, continued looping at 2.02–2.82, an orange arc at 4.10–4.20 followed by the purple arc at 4.22–4.43, and purple notes passing the saber at 5.24–5.60. These are clip-relative times. The recording and CSV do not share an explicit synchronization marker, so no individual clip frame is claimed to identify a particular internal note ID or target update.

## Changes

- HumanEventAlignment.cs matches ordered, simultaneous hand/cut events and crops continuous source intervals between neighboring events. It does not pick independent poses. A monotone C2 source clock aligns the matching recorded events to the chart, including the velocity/acceleration chain rule for head and both hands.
- HumanMotionGraph.cs uses those event matches during selection and playback. It excludes unrelated internal swings, skips a successor window's already played prefix, and evaluates the actual cropped/retimed boundary state. Source clocks and handoffs that leave the training motion range are rejected during selection; no displayed rotation is clamped and no extra global smoothing or hardcoded swing was added. Handoffs finish before the next matched cut. Missing matches produce a brief connected settle while the existing contact motor continues handling notes.
- HumanMotion.cs exposes the existing boundary metric for the actual retimed states. Training, cached demonstrations and learned timing/stroke data remain intact.
- ReplayMotor.cs, TrajectoryMath.cs and SaberTrace.cs retain frozen diagnostic teacher stages and record teacher, reach-adapted, planned, commanded and final transform rotations, blade endpoints and grip offsets. These diagnostic fields do not select or alter motion.
- Plugin.cs identifies build 1.0.0.9 correctly. Focused event/sequence regression coverage was added; older synthetic fixtures now include their note anchors and consistent timestamps/derivatives.

There are no new HUD, gameplay, multiplayer or quality-of-life features. The three models, once-only openings/breaks, invisible rig, F8, saved learning and unranked submission blocking remain.

## Verification

The same-map comparison uses the actual 437-note 100Bills Expert chart, the installed learned model, configured body proportions, and 32.35 seconds at 240 Hz. It extracts chart metadata from an existing replay; that below-threshold replay's poses are not used for training or imitation. Blade geometry and moving-note collision volumes are offline approximations.

| Measured offline quantity | 1.0.0.8 | 1.0.0.9 |
| --- | ---: | ---: |
| Raw wrist travel more than 250 ms from that hand's notes, both hands combined | 288.72 rad | 65.53 rad |
| Planned blade-contact proxy misses | 8 | 7 |
| Incorrect direction at planned anchors | 5 | 0 |
| Good first swept-collision proxies | 53 | 99 |
| Wrong-direction first swept-collision proxies | 48 | 3 |
| Wrong-hand first swept-collision proxies | 3 | 0 |
| Maximum angular derivative error away from plan boundaries | 6.44e-7 rad/s | 5.80e-7 rad/s |

The approximately 77% reduction is between-note rotation, not a claim that all human wrist rotation is suppressed. Human demonstration coverage remains approximately 93.5% of sampled hand frames. A second validation checks eight qualifying full human recordings: 1,337 plans, 5,915 contact proxies and 666,649 samples. Its contact outcomes match 1.0.0.8, including 888 proxy misses in 893 stability-limited contacts, zero unmarked misses and zero unreachable contacts. Those misses were not hidden or interpreted as a perfect score.

All offline policy, movement, event-clock, sequence overlap, quaternion-sign, opening/break, cut-speed, native-contact, dot-pattern, replay, results/restart and menu/hook checks pass. The 32 native hooks resolve against the installed assemblies. No Unity gameplay or VR playthrough was executed. Three wrong-direction proxies and seven contact proxies remain in the same-map approximation; an in-game retest is required to establish actual accuracy, timing and rendered appearance. Later transform interference also remains unverified in-game.
