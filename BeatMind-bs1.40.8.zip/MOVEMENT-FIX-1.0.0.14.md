# 1.0.0.14 — preparation, acceleration and bounded learning

For the dedicated Beat Saber 1.40.8 (3) instance. No Unity gameplay or VR test was performed.

## Confirmed movement cause and correction

The idle-source fallback recomputed its preparation window from the remaining time on every replan. A contact already committed to an ongoing swing could receive a new, very short zero-speed approach. In a reproduced slow downswing, refreshing 20 ms before contact increased peak angular acceleration from 16,188 to 695,218 degrees/s² and peak speed from 1,275 to 2,713 degrees/s. This explains abrupt acceleration without requiring a quaternion normalization or smoothing change.

Fallback strokes now carry immutable preparation, peak and release timestamps with their committed contact. One analytic rotational curve supplies orientation, angular velocity and angular acceleration. It builds speed progressively, peaks shortly before contact and decelerates through follow-through. Late refreshes continue the existing curve. In the same 20 ms refresh, the original and refreshed angular velocities are identical; peak approach speed stays approximately 1,280 degrees/s, with the fitted contact speed still exactly 1,275 degrees/s.

Slow fallback preparation uses the cut axis and fitted blade direction to raise the saber nearly upright for a downswing. The regression raises the blade tip more than 0.85 m above the note center while retaining its hand pivot and exact fitted contact. Dense patterns receive shorter cadence-dependent preparation; repeated directions reserve recovery time under the existing physical speed bound. This does not promise gentle recovery for every extremely dense pattern. Valid recorded human cuts keep their measured motion instead of receiving a replacement fallback envelope.

## Learning and memory

The hard learning budget is 500,000 synchronized timestamps. Keeping complete 129-point head/left/right excerpts yields at most 3,875 excerpts, or 499,875 timestamps. Sampling distributes the budget across all eligible recordings and phases, preserves source ordering and all per-excerpt derivatives, and prevents old cluster weights from bypassing the limit. The checkpoint fingerprint and validation reject the old unlimited model. Existing source replays and raw per-recording caches are preserved. All eligible recordings remain available in the exact-map index.

Fitting materializes only this bounded selection once, preserving the same fitting order, held-out recording split and idle checks on each epoch. It avoids repeatedly deserializing the uncapped cache library during optimization. Retained exact-run tracking is limited to 500,000 frames in total; a single larger recording falls back to pattern motion rather than being truncated.

The actual AI log reported out-of-memory during paused pre-song graph training. Offline replay of that allocation path discarded hundreds of MB of temporary state without retaining it. Inspection of the installed game's `DisableGCWhileEnabled` component shows that gameplay can disable managed collection. The exact GC mode at the crash was not recorded, so this is a supported contributing mechanism, not a conclusively reproduced in-game crash cause.

AI sessions now enable automatic collection before pre-song training and during playback, then restore the prior policy on exit or takeover. They do not force collection every frame. Frozen contact-plan snapshots retain the relevant time range rather than the entire prepared song. Background exact-run decoding is serialized and superseded requests are discarded.

## Offline verification

- Compiled against the installed 1.40.8 (3) game and mod libraries.
- 66,066 preparation, acceleration and committed-envelope assertions passed across both hands, eight cut directions and multiple cadences.
- Existing recorded-speed, compact-pivot, swept-contact, opening/break, continuous replay, incremental planning, learning policy and unranked controls passed.
- 3,984 learning-budget assertions include whole-excerpt preservation, legacy checkpoint invalidation and byte-for-byte fitting equivalence after bounded materialization.
- 538 planning-memory checks and eight collection-policy ownership checks passed.
- All 32 native Harmony targets resolved. These checks do not execute Unity gameplay.

The local validation report accompanies the package. Offline contact and collision proxies cannot establish actual cut scores, live frame times, visual realism or crash freedom. An in-game run is still required for those results.
