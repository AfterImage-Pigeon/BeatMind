using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;
using SaberMind;
class RealMotionValidation
{
    static double[] Vector(MotionVector v){return new[]{v.X,v.Y,v.Z};}
    static int Main(string[] args)
    {
        try
        {
            var model=HumanMotionTraining.Read<HumanMotionModel>(Path.Combine(args[0],"HumanMotionModel.json.gz"));
            if(!model.Valid())throw new Exception("Invalid fitted model.");
            int plans=0,cuts=0,wrong=0,unlimitedWrong=0,unreachable=0,misses=0,limited=0,unlimitedMisses=0,samples=0;double gripSpeed=0,angularSpeed=0,reachError=0,derivativeError=0,linearDerivativeError=0,accelerationDerivativeError=0,planMs=0,maxPlanMs=0;
            var reports=new List<object>();var missingContacts=new List<object>();
            var peaks=new List<object>();
            var reachCases=new List<object>();
            var directionCases=new List<object>();double contactAngularSpeed=0;
            for(int run=0;run<8;run++)
            {
                var recording=model.Recordings[run*(model.Recordings.Count-1)/7];var raw=HumanReplayLibrary.Read(recording.Path);HumanMotionTraining.RequireEligible(raw,recording.Path);
                var tape=HumanTape.FromReplay(raw,recording.Identity);var graph=new HumanMotionGraph(model,tape.Notes,new HumanRunHandle{Tape=tape},2);graph.Sample(Math.Max(0,tape.Times[0]),0);
                int runCuts=0;double runMaxSpeed=0;
                for(int hand=0;hand<2;hand++)
                {MotionPhrase previous=null;for(double now=Math.Max(.30,tape.Notes[0].Time-.8);now<tape.Notes[tape.Notes.Length-1].Time+1;now+=1.5)
                {
                    double end=now+3.1,shownEnd=Math.Min(now+1.5,tape.Notes[tape.Notes.Length-1].Time+1);int color=hand;
                    var g=new PhraseGeometry{Bottom=new MotionVector(),Top=new MotionVector(0,0,1),Grip=new MotionVector(),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=color,ScoredHumanSwings=args.Length>2 && args[2]=="hybrid",StableFastGrip=args.Length>2 && (args[2]=="production" || args[2]=="pivot"),SwingSpeedScale=args.Length>2 && (args[2]=="production" || args[2]=="speed") ? 1.5 : 1};
                    g.ShoulderAt=delegate(double t){return graph.Sample(t,0).Grip+new MotionVector(color==0 ? -.21 : .21,-.23,.025);};g.Shoulder=g.ShoulderAt(now);
                    g.OtherHandAt=delegate(double t){return graph.Sample(t,2-color).Grip;};
                    var notes=new List<PhraseNote>();
                    for(int i=0;i<tape.Notes.Length;i++)
                    {
                        var n=tape.Notes[i];if(n.Hand!=hand || n.Time<=now+.015 || n.Time>=end-.05)continue;
                        MotionVector direction=HumanContext.Direction(n.Direction);
                        if(n.Direction==8)
                        {direction=n.ObservedCutDirection;direction.Z=0;direction=direction.Unit;if(direction.Length<.5){var human=graph.Sample(n.Time,color+1);MotionVector velocity=human.Velocity+MotionVector.Cross(human.AngularVelocity,human.Rotation.Rotate(g.Top));velocity.Z=0;direction=velocity.Unit;}if(direction.Length<.5)direction=new MotionVector(0,-1,0);}
                        double gap=.3;for(int j=i+1;j<tape.Notes.Length;j++)if(tape.Notes[j].Hand==hand){gap=tape.Notes[j].Time-n.Time;break;}
                        if(notes.Count>0 && n.Time-notes[notes.Count-1].Time<.012)
                        {var list=new List<MotionVector>(notes[notes.Count-1].OtherCenters);var linked=raw.Notes[n.Id];list.Add(new MotionVector((n.Lane-1.5)*.6,.85+n.Layer*.6,0));notes[notes.Count-1].OtherCenters=list.ToArray();continue;}
                        var eventNote=raw.Notes[n.Id];MotionVector observed=new MotionVector((n.Lane-1.5)*.6,.85+n.Layer*.6,0);
                        if(!eventNote.Good)continue;
                        notes.Add(new PhraseNote{Id=i,ScoringType=eventNote.ScoringType,Time=n.Time,Center=observed,Direction=direction,Forward=g.Forward,Spacing=Math.Max(.035,gap),LocalNps=1/Math.Max(.035,gap)*2,Committed=previous==null ? null : previous.Contact(i)});
                    }
                    if(notes.Count==0)continue;
                    var seed=previous==null ? ConstrainedReplayTrajectory.Project(graph.Sample(now,color+1),g) : previous.Sample(now);seed.Time=now;
                    var timer=Stopwatch.StartNew();var phrase=ReplayMotor.Build(seed,notes,g,delegate(double t){return graph.Sample(t,color+1);},9,3.1);timer.Stop();plans++;planMs+=timer.Elapsed.TotalMilliseconds;maxPlanMs=Math.Max(maxPlanMs,timer.Elapsed.TotalMilliseconds);
                    foreach(var n in notes)
                    {
                        if(n.Time>shownEnd)continue;
                        if(phrase.Contact(n.Id)==null)
                        {
                            var knots=new List<object>();foreach(var k in phrase.Knots)knots.Add(new{k.Time,k.Id,k.SwingStart,k.SwingEnd});
                            missingContacts.Add(new{run,hand,now,n.Id,n.Time,n.Spacing,knots});continue;
                        }
                        var contact=phrase.Sample(n.Time);cuts++;runCuts++;
                        double miss=CutSafety.BladeDistance(contact,n.Center,g);if(phrase.Contact(n.Id).LimitedContact)limited++;if(miss>.025){misses++;if(!phrase.Contact(n.Id).LimitedContact)unlimitedMisses++;}
                        MotionVector tipVelocity=contact.Velocity+MotionVector.Cross(contact.AngularVelocity,contact.Rotation.Rotate(g.Top));
                        contactAngularSpeed=Math.Max(contactAngularSpeed,contact.AngularVelocity.Length);
                        if(MotionVector.Dot(tipVelocity,n.Direction)<=1){wrong++;if(!phrase.Contact(n.Id).LimitedContact)unlimitedWrong++;var knot=phrase.Contact(n.Id);directionCases.Add(new{run,hand,planningTime=now,id=n.Id,time=n.Time,n.ScoringType,n.LocalNps,limited=knot.LimitedContact,repairStage=contact.RepairStage,repairs=phrase.StabilityFallbacks,wristScale=knot.WristSpeedScale,tipDirection=MotionVector.Dot(tipVelocity,n.Direction),direction=Vector(n.Direction),gripVelocity=Vector(contact.Velocity),angularVelocity=Vector(contact.AngularVelocity),blade=Vector(contact.Rotation.Rotate(g.Top)),knotVelocity=Vector(knot.Velocity),knotAngularVelocity=Vector(knot.AngularVelocity),sourceVelocity=Vector(knot.WristSource==null ? new MotionVector() : knot.WristSource.Velocity)});}
                        if((contact.Grip-g.ShoulderAt(n.Time)).Length>g.Reach+.015)
                        {unreachable++;if(reachCases.Count<12)reachCases.Add(new{source=recording.Identity,time=n.Time,center=new[]{n.Center.X,n.Center.Y,n.Center.Z},grip=new[]{contact.Grip.X,contact.Grip.Y,contact.Grip.Z},shoulder=new[]{g.ShoulderAt(n.Time).X,g.ShoulderAt(n.Time).Y,g.ShoulderAt(n.Time).Z},cubeDistance=(n.Center-g.ShoulderAt(n.Time)).Length,registration=tape.RegistrationError,scale=tape.CaptureScale});}
                    }
                    for(double t=now+.003;t<shownEnd-.001;t+=.003)
                    {
                        var s=phrase.Sample(t);samples++;if(!HumanMotionModel.Finite(s.Grip.X) || Math.Abs(s.Rotation.Length-1)>.001)throw new Exception("Nonfinite / invalid quaternion.");
                        if(s.Velocity.Length>gripSpeed)
                        {
                            int k=0;while(k+1<phrase.Knots.Count && phrase.Knots[k+1].Time<t)k++;var a=phrase.Knots[k];var b=phrase.Knots[Math.Min(k+1,phrase.Knots.Count-1)];
                            var measured=graph.Sample(t,color+1);
                            peaks.Add(new{source=recording.Identity,time=t,speed=s.Velocity.Length,repairStage=s.RepairStage,repairCount=phrase.StabilityFallbacks,sourceSpeed=measured.Velocity.Length,sourceAngular=measured.AngularVelocity.Length,from=a.Time,to=b.Time,fromId=a.Id,toId=b.Id,gap=b.Time-a.Time,positionDelta=(b.Grip-a.Grip).Length,rotationDelta=MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length,headSpeed=graph.Sample(t,0).Velocity.Length,shoulderSpeed=(g.ShoulderAt(t+.002)-g.ShoulderAt(t-.002)).Length/.004,endingHumanSpeed=graph.Sample(b.Time,color+1).Velocity.Length,startingHumanSpeed=graph.Sample(a.Time,color+1).Velocity.Length,endingHumanAcceleration=graph.Sample(b.Time,color+1).Acceleration.Length,startingHumanAcceleration=graph.Sample(a.Time,color+1).Acceleration.Length,endingDesiredSpeed=b.Velocity.Length,startingDesiredSpeed=a.Velocity.Length,fromCenter=new[]{a.TargetCenter.X,a.TargetCenter.Y,a.TargetCenter.Z},toCenter=new[]{b.TargetCenter.X,b.TargetCenter.Y,b.TargetCenter.Z},fromGrip=new[]{a.Grip.X,a.Grip.Y,a.Grip.Z},toGrip=new[]{b.Grip.X,b.Grip.Y,b.Grip.Z},blade=new[]{a.Rotation.Rotate(g.Top).X,a.Rotation.Rotate(g.Top).Y,a.Rotation.Rotate(g.Top).Z},fromType=a.Id<0 ? -99 : raw.Notes[tape.Notes[a.Id].Id].ScoringType,toType=b.Id<0 ? -99 : raw.Notes[tape.Notes[b.Id].Id].ScoringType});if(peaks.Count>20)peaks.RemoveAt(0);
                        }
                        gripSpeed=Math.Max(gripSpeed,s.Velocity.Length);runMaxSpeed=Math.Max(runMaxSpeed,s.Velocity.Length);angularSpeed=Math.Max(angularSpeed,s.AngularVelocity.Length);reachError=Math.Max(reachError,(s.Grip-g.ShoulderAt(t)).Length-g.Reach);
                        if(samples%11==0)
                        {double e=.000001;var a=phrase.Sample(t-e);var b=phrase.Sample(t+e);derivativeError=Math.Max(derivativeError,(MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length);linearDerivativeError=Math.Max(linearDerivativeError,((b.Grip-a.Grip)/(2*e)-s.Velocity).Length);accelerationDerivativeError=Math.Max(accelerationDerivativeError,((b.Velocity-a.Velocity)/(2*e)-s.Acceleration).Length);}
                    }
                    previous=phrase;
                }
                } reports.Add(new{source=recording.Identity,accuracy=recording.Accuracy,cuts=runCuts,maximumGripSpeed=runMaxSpeed});
            }
            var report=new{recordings=model.Files,eligibleSources=model.Recordings.Count,phrases=model.Cuts,prototypes=model.Examples.Count,points=HumanMotionModel.Points,parameters=model.Examples.Count*129*HumanMotionModel.TotalChannels,optimizer=model.OptimizerVersion,phases=model.PhaseCounts,contextWeight=model.ContextWeight,boundaryWeight=model.BoundaryWeight,heldOutExamples=model.ValidationExamples,conditionedError=model.ContextValidationError,genericError=model.MeanValidationError,plans,cuts,proxyContactMisses=misses,stabilityLimitedContactPlans=limited,unlimitedContactMisses=unlimitedMisses,proxyDirectionDifferences=wrong,unlimitedDirectionDifferences=unlimitedWrong,unreachableContacts=unreachable,samples,maximumGripSpeed=gripSpeed,maximumAngularSpeed=angularSpeed,maximumContactAngularSpeed=contactAngularSpeed,maximumReachOvershoot=reachError,maximumAngularDerivativeError=derivativeError,maximumLinearDerivativeError=linearDerivativeError,maximumAccelerationDerivativeError=accelerationDerivativeError,meanPlanMilliseconds=planMs/Math.Max(1,plans),maximumPlanMilliseconds=maxPlanMs,actualSources=reports,peaks,reachCases,directionCases};
            File.WriteAllText(args[1],JsonConvert.SerializeObject(report,Formatting.Indented));Console.WriteLine(JsonConvert.SerializeObject(report));
            File.WriteAllText(args[1]+".missing.json",JsonConvert.SerializeObject(missingContacts,Formatting.Indented));
            // The requested speed variant scales a connected hand/wrist jet
            // by 1.5. Compare its linear peak to the same normalized baseline
            // budget (18 * 1.5), rather than rejecting the requested increase.
            double speedScale=args.Length>2 && (args[2]=="production" || args[2]=="speed") ? 1.5 : 1;
            if(missingContacts.Count>0 || unlimitedMisses>0 || unlimitedWrong>0 || unreachable>0 || reachError>.06 || gripSpeed>18*speedScale || angularSpeed>200 || contactAngularSpeed>200 || derivativeError>.05 || linearDerivativeError>.08)throw new Exception("Actual recording regression guard failed; see report.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}

