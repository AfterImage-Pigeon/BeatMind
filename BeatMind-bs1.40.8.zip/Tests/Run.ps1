param([string]$GamePath='C:\Users\comma\BSManager\BSInstances\1.40.8 (3)')
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$testDirectory=Join-Path ([IO.Path]::GetTempPath()) ('BeatMind-whole-body-tests-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testDirectory | Out-Null
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$json=Join-Path $GamePath 'Libs\Newtonsoft.Json.dll'
Copy-Item -LiteralPath $json -Destination $testDirectory
function Run-Checks([string]$Name,[string[]]$SourceNames,[string[]]$TestNames,[string[]]$Arguments) {
    $exe=Join-Path $testDirectory ($Name+'.exe')
    $sources=@($SourceNames | ForEach-Object {Join-Path "$project\Source" $_})
    $sources+=@($TestNames | ForEach-Object {Join-Path $PSScriptRoot $_})
    & $compiler /nologo /optimize+ /target:exe "/out:$exe" "/reference:$json" @sources
    if($LASTEXITCODE -ne 0){throw "$Name compilation failed."}
    & $exe @Arguments
    if($LASTEXITCODE -ne 0){throw "$Name failed."}
}
Run-Checks 'PolicyTests' @('Learning.cs','Models.cs','RotationDynamics.cs','MotionContinuity.cs','MemoryStore.cs') @('PolicyTests.cs') @((Join-Path $testDirectory 'memory'))
Run-Checks 'PreparationPolicyTests' @('Learning.cs','Models.cs','PreparationCache.cs','MemoryStore.cs') @('PreparationPolicyTests.cs') @((Join-Path $testDirectory 'preparation-memory'))
Run-Checks 'ContactScheduleTests' @('CutSchedule.cs','PreparationSignature.cs') @('ContactScheduleTests.cs') @()
$motionSources=@('Learning.cs','Models.cs','TrajectoryMath.cs','BladeSwingScoring.cs','SwingContinuation.cs','HumanMotion.cs','HumanMotionTraining.cs','HumanReplay.cs','HumanMotionGraph.cs','HumanEventAlignment.cs','ReplayMotor.cs','ReplayPlanJob.cs','ConstrainedReplayTrajectory.cs','ReachTransition.cs','ReplayRegistration.cs','ReplayFileAccess.cs','ContactGeometry.cs','ReplayWristClock.cs','SteadySwingEnvelope.cs','WristMotionLimits.cs','BoundedWristBridge.cs','ContinuousWristBurst.cs','ReplayWristRoll.cs')
Run-Checks 'LearningOptimizationTests' $motionSources @('LearningOptimizationTests.cs') @((Join-Path $PSScriptRoot 'LearningFitGolden.json'))
Run-Checks 'PreparationContactTests' ($motionSources+@('PreparationContact.cs')) @('PreparationContactTests.cs') @()
Run-Checks 'WholeBodyTests' $motionSources @('Legacy14\WholeBodyTests.cs') @((Join-Path $testDirectory 'whole-body'))
Run-Checks 'OpeningRegressionTests' $motionSources @('Legacy14\OpeningRegressionTests.cs') @()
Run-Checks 'EventAlignmentTests' $motionSources @('EventAlignmentTests.cs') @()
Run-Checks 'FreshCaptureRegression' $motionSources @('FreshCaptureRegression.cs') @()
Run-Checks 'MovementStabilityTests' $motionSources @('Legacy14\MovementStabilityTests.cs') @()
Run-Checks 'PivotWristTests' $motionSources @('Legacy14\PivotWristTests.cs') @()
Run-Checks 'IdleStrokeTests' $motionSources @('Legacy14\IdleStrokeTests.cs') @()
Run-Checks 'IdleCollisionTests' $motionSources @('Legacy14\IdleCollisionTests.cs') @((Join-Path $testDirectory 'idle-collisions.json'))
Run-Checks 'PreswingAccelerationTests' $motionSources @('Legacy14\PreswingAccelerationTests.cs') @()
Run-Checks 'V14MovementParityTests' $motionSources @('V14MovementParityTests.cs') @((Join-Path $PSScriptRoot 'V14MovementGolden.json'))
Run-Checks 'V14FasterSwingTests' $motionSources @('V14FasterSwingTests.cs') @()
Run-Checks 'HybridSwingTests' $motionSources @('HybridSwingTests.cs') @()
Run-Checks 'FastStreamRegression' $motionSources @('FastStreamRegression.cs') @()
Run-Checks 'RepeatedCutRegression' $motionSources @('RepeatedCutRegression.cs') @()
Run-Checks 'ReplayPlaybackTests' $motionSources @('Legacy14\ReplayPlaybackTests.cs') @()
Run-Checks 'PlaybackPerformanceTests' $motionSources @('PlaybackPerformanceTests.cs') @((Join-Path $testDirectory 'bounded-streaming'))
Run-Checks 'PlanningMemoryTests' $motionSources @('PlanningMemoryTests.cs') @()
Run-Checks 'AiCollectionScopeTests' @('AiCollectionScope.cs') @('AiCollectionScopeTests.cs') @()
Run-Checks 'FrameStallTraceTests' @('FrameStallTrace.cs') @('FrameStallTraceTests.cs') @()
Run-Checks 'LearningCapTests' $motionSources @('LearningCapTests.cs') @((Join-Path $testDirectory 'learning-cap'))
Run-Checks 'NativeContactTests' $motionSources @('NativeContactTests.cs') @()
Run-Checks 'MultiplayerTests' @('Learning.cs','Models.cs','MultiplayerPolicy.cs','MultiplayerGestures.cs') @('MultiplayerTests.cs') @()
Run-Checks 'ResultsTests' @('ResultsText.cs','AutoRestartPolicy.cs') @('ResultsTests.cs') @()
Run-Checks 'ReplayTests' @('Learning.cs','Models.cs','BreakTiming.cs','ReplayStore.cs') @('ReplayTests.cs') @((Join-Path $testDirectory 'replays'))
Run-Checks 'PatternTests' @('PatternFlow.cs') @('PatternTests.cs') @()
& "$PSScriptRoot\CheckBindings.ps1" -GamePath $GamePath
$targets=Join-Path $testDirectory 'HarmonyTargets.exe'
Copy-Item -LiteralPath "$GamePath\Libs\0Harmony.dll" -Destination $testDirectory
& $compiler /nologo /target:exe "/out:$targets" "/reference:$GamePath\Libs\0Harmony.dll" "$PSScriptRoot\HarmonyTargets.cs"
if($LASTEXITCODE -ne 0){throw 'Harmony target regression compilation failed.'}
& $targets $GamePath "$project\Plugins\BeatMindHumanBeta.dll"
if($LASTEXITCODE -ne 0){throw 'Native Harmony target resolution failed.'}
$follow=Join-Path $testDirectory 'PlannerFollowthroughNativeTests.exe'
& $compiler /nologo /target:exe "/out:$follow" "/reference:$project\Plugins\BeatMindHumanBeta.dll" "$PSScriptRoot\PlannerFollowthroughNativeTests.cs"
if($LASTEXITCODE -ne 0){throw 'Planner follow-through regression compilation failed.'}
& $follow $GamePath "$project\Plugins\BeatMindHumanBeta.dll"
if($LASTEXITCODE -ne 0){throw 'Shipped planner follow-through regression failed.'}
$schedule=Join-Path $testDirectory 'ContactScheduleNativeTests.exe'
& $compiler /nologo /target:exe "/out:$schedule" "/reference:$project\Plugins\BeatMindHumanBeta.dll" "$PSScriptRoot\ContactScheduleNativeTests.cs"
if($LASTEXITCODE -ne 0){throw 'Native contact schedule regression compilation failed.'}
& $schedule $GamePath "$project\Plugins\BeatMindHumanBeta.dll"
if($LASTEXITCODE -ne 0){throw 'Native contact schedule regression failed.'}
Write-Output "Test artifacts: $testDirectory"
