using System;
using System.Collections.Generic;
using SaberMind;
class EventAlignmentTests
{
    static int checks;
    static void Check(bool valid,string message){checks++;if(!valid)throw new Exception(message);}
    static HumanMotionExample Example(params HumanAnchor[] anchors)
    {
        var e=new HumanMotionExample{Duration=1.25,Recording="ordered-human",Anchors=anchors,Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36]};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {
            double t=e.Duration*p/128,f=.8+j*.1;
            var s=new PhraseState{Time=t,Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.5+.015*Math.Sin(f*t),.28),Velocity=new MotionVector(0,.015*f*Math.Cos(f*t),0),Acceleration=new MotionVector(0,-.015*f*f*Math.Sin(f*t),0),Rotation=MotionRotation.Exp(new MotionVector(.3*Math.Sin(f*t),0,0)),AngularVelocity=new MotionVector(.3*f*Math.Cos(f*t),0,0),AngularAcceleration=new MotionVector(-.3*f*f*Math.Sin(f*t),0,0)};
            if(p%2==0)s.Rotation=s.Rotation*-1;
            HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
        }
        return e;
    }
    static HumanAnchor A(double time,int hand,int direction){return new HumanAnchor{Phase=time/1.25,Hand=hand,Direction=direction};}
    static HumanChartNote N(double time,int hand,int direction){return new HumanChartNote{Time=time,Hand=hand,Direction=direction};}
    static void NoUnmatchedSwing()
    {
        var e=Example(A(.2,0,1),A(.35,1,1),A(.5,0,0));var tape=HumanTape.FromExample(e);
        var match=HumanEventAlignment.Match(e,tape,new[]{N(.4,0,1),N(.6,1,0)},0,1,0);
        Check(match!=null && match.MatchedEvents==1,"incompatible intervening cut was accepted as the current pattern");
        Check(match.SourceEnd<.35,"cropped source leaked its unrelated second swing");
        Check(Math.Abs(match.Clock.Sample(.4).Grip.X-.2)<1e-8,"human cut phase was not aligned to the real note");
    }
    static void PrefixAndOverlap()
    {
        var e=Example(A(.9,0,1),A(1.1,1,0));var tape=HumanTape.FromExample(e);
        var match=HumanEventAlignment.Match(e,tape,new[]{N(.02,0,1)},0,.15,0);
        Check(match!=null && match.SourceStart>=.879999,"long source preparation was compressed into a 20ms lead");
        for(int p=0;p<100;p++)Check(match.Clock.Sample(.15*p/100).Velocity.X<2,"one-event crop compressed the long source prefix");
        var sequence=Example(A(.2,0,1),A(.6,1,0),A(.9,0,0));
        var next=HumanEventAlignment.Match(sequence,HumanTape.FromExample(sequence),new[]{N(2.2,1,0),N(2.5,0,0)},2,2.8,.3);
        Check(next!=null && next.SourceStart>=.3 && next.MatchedEvents==2,"overlapping predecessor content was played again");
    }
    static void ContinuousClock()
    {
        var random=new Random(7);
        for(int run=0;run<30;run++)
        {
            double sourceA=.2,sourceB=.4+random.NextDouble()*.2,sourceC=.8+random.NextDouble()*.2;
            var e=Example(A(sourceA,0,1),A(sourceB,1,0),A(sourceC,0,0));var tape=HumanTape.FromExample(e);
            double a=2.1,b=a+.08+random.NextDouble()*.5,c=b+.08+random.NextDouble()*.5;
            var match=HumanEventAlignment.Match(e,tape,new[]{N(a,0,1),N(b,1,0),N(c,0,0)},2,c+.2,0);
            Check(match!=null && match.MatchedEvents==3,"compatible ordered events were lost");
            foreach(var knot in match.Clock.Knots)
            {
                if(knot.Time==2 || knot.Time==match.DestinationEnd)continue;
                const double epsilon=1e-7;var l=match.Clock.Sample(knot.Time-epsilon);var r=match.Clock.Sample(knot.Time+epsilon);
                Check((l.Velocity-r.Velocity).Length<.001 && (l.Acceleration-r.Acceleration).Length<.01,"source clock lost C2 continuity at a cut");
            }
            for(int p=1;p<180;p++)
            {
                double t=2+(match.DestinationEnd-2)*p/180;var clock=match.Clock.Sample(t);
                Check(clock.Velocity.X>0,"source clock reversed or repeated poses");
                for(int joint=0;joint<3;joint++)
                {
                    var state=match.Sample(tape,t,joint);const double epsilon=1e-7;
                    var l=match.Sample(tape,t-epsilon,joint);var r=match.Sample(tape,t+epsilon,joint);
                    Check(Math.Abs(state.Rotation.Length-1)<1e-9,"signed replay quaternions were not normalized");
                    Check((MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*epsilon)-state.AngularVelocity).Length<.0001,"retiming discarded wrist angular motion");
                    Check(((r.Grip-l.Grip)/(2*epsilon)-state.Velocity).Length<.0001,"retiming discarded hand velocity");
                }
            }
        }
    }
    static void IncompatibleClockIsRejected()
    {
        var e=Example(A(.2,0,1),A(1,1,0));
        // A physical 20rad/s source is acceptable to training, but a 20x
        // event clock is incompatible. Selection rejects it instead of
        // clamping the resulting displayed wrist or altering cut speed.
        for(int p=0;p<129;p++)for(int j=1;j<3;j++)
        {double t=1.25*p/128;var s=new PhraseState{Rotation=MotionRotation.Exp(new MotionVector(20*t,0,0)),AngularVelocity=new MotionVector(20,0,0),Grip=new MotionVector(j==1 ? -.3 : .3,1.5,.28)};HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);}
        var tape=HumanTape.FromExample(e);var match=HumanEventAlignment.Match(e,tape,new[]{N(.2,0,1),N(.24,1,0)},0,.35,0);
        Check(match!=null && !match.PreservesTrainingDomain(tape),"an inference clock amplified a valid human recording outside its trained motion range");
    }
    static void OverlappingSequenceHandoff()
    {
        var first=Example(A(.2,0,1),A(1.1,1,0));first.Sequence=0;first.StartTime=0;
        var next=Example(A(.1,1,0),A(.4,0,0));next.Sequence=1;next.StartTime=1;
        var model=new HumanMotionModel{Files=1,OptimizerVersion=4};model.Examples.Add(first);model.Examples.Add(next);
        var graph=new HumanMotionGraph(model,new[]{N(.4,0,1),N(1.1,1,0),N(1.4,0,0)},null,2);graph.BeginFrame(0);graph.Sample(0,0);
        var actual=graph.Sample(1.4,1);var expected=HumanTape.FromExample(next).Sample(.4,1);
        Check(actual.HumanSource==1,"compatible successor sequence was not used");
        Check(MotionRotation.Log(actual.Rotation*expected.Rotation.Inverse).Length<1e-7 && (actual.Grip-expected.Grip).Length<1e-7,"overlapping training prefix was replayed instead of the next real cut");
        for(double t=1.25001;t<1.399;t+=.003)
        {const double epsilon=1e-5;var state=graph.Sample(t,1);var l=graph.Sample(t-epsilon,1);var r=graph.Sample(t+epsilon,1);double error=(MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*epsilon)-state.AngularVelocity).Length;Check(error<.0001,"sequence handoff introduced wrist lag or snapping at "+t+"; error="+error);}
    }
    static int Main()
    {
        try{NoUnmatchedSwing();PrefixAndOverlap();ContinuousClock();IncompatibleClockIsRejected();OverlappingSequenceHandoff();Console.WriteLine(checks+" event alignment / continuous replay / no extra swing assertions passed.");return 0;}
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
