using System;
using System.Collections.Generic;
using System.Reflection;
using SaberMind;
class RepeatedCutRegression
{
    static int checks;
    static void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
    static PhraseState Teacher(double t,int hand)
    {return new PhraseState{Time=t,HumanSource=6,HumanGripWeight=.8,HumanWristWeight=.8,Grip=new MotionVector(hand==0 ? -.35 : .35,1.57,.18),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};}
    static void Jets(MotionPhrase path,double t)
    {
        const double e=1e-7;var a=path.Sample(t-e);var b=path.Sample(t+e);var s=path.Sample(t);
        Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.08,"Repeated-cut return has a rotation discontinuity at "+t);
        double error=((b.AngularVelocity-a.AngularVelocity)/(2*e)-s.AngularAcceleration).Length;
        Check(error<.2,"Repeated-cut return has an acceleration discontinuity at "+t+": "+error);
    }
    static int Main()
    {
        try
        {
            foreach(int hand in new[]{0,1})foreach(bool offset in new[]{false,true})foreach(int arrow in new[]{0,1,4,5,6,7})foreach(double gap in new[]{.1,.15,.2,.3,.5,.7})foreach(int low in new[]{0,1,2})foreach(int high in new[]{0,1,2})
            {
                var g=new PhraseGeometry{ScoredHumanSwings=true,StableFastGrip=true,Top=new MotionVector(0,0,1),Bottom=offset ? new MotionVector(.008,0,.025) : new MotionVector(),Grip=offset ? new MotionVector(.006,-.002,-.045) : new MotionVector(),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.99,0),Reach=.646,MinimumReach=.149,Forward=new MotionVector(0,0,1),Color=hand};
                Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand);};var direction=HumanContext.Direction(arrow);var notes=new List<PhraseNote>();
                for(int i=0;i<2;i++)notes.Add(new PhraseNote{Id=i,Time=.65+i*gap,Center=new MotionVector(hand==0 ? -.3 : .3,1.0764+(i==0 ? low : high)*.55,.88),Direction=direction,Forward=g.Forward,Spacing=gap,LocalNps=2/gap});
                var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,2.7);
                foreach(var n in notes)
                {
                    var c=path.Contact(n.Id);Check(c!=null && !c.LimitedContact,"Repeated-cut contact was discarded");var s=path.Sample(n.Time);
                    Check(CutSafety.BladeDistance(s,n.Center,g)<.025,"Repeated-cut recovery lost contact position");
                    Check(MotionVector.Dot(s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Grip)),direction)>1.5,"Return changed the actual cut direction");
                    Check(c.Time==n.Time && c.AngularVelocity.Length>=CutSafety.StrokeFor(n).Speed*.969,"Return weakened or retimed the scored contact");Jets(path,n.Time);
                }
                // Accumulate actual tip-plane motion; a quaternion endpoint
                // comparison alone cannot detect a full turn back to itself.
                var blade=path.Sample(notes[0].Time).Rotation.Rotate(g.Top-g.Bottom);double previous=Math.Atan2(-MotionVector.Dot(blade,direction),MotionVector.Dot(blade,g.Forward)),winding=0;
                for(double t=notes[0].Time+.001;t<=notes[1].Time+.000001;t+=.001)
                {
                    var s=path.Sample(t);blade=s.Rotation.Rotate(g.Top-g.Bottom);double angle=Math.Atan2(-MotionVector.Dot(blade,direction),MotionVector.Dot(blade,g.Forward)),delta=angle-previous;
                    while(delta>Math.PI)delta-=2*Math.PI;while(delta<-Math.PI)delta+=2*Math.PI;winding+=delta;previous=angle;
                    Check(s.AngularVelocity.Length<180,"Repeated-cut recovery became an excessive speed spike");
                }
                Check(Math.Abs(winding)<Math.PI,"Repeated arrows still wind around a full circle: "+winding+" arrow="+arrow+" gap="+gap+" layers="+low+","+high);
                var first=path.Contact(0);var last=path.Contact(1);var owned=last.IncomingWrist;
                if(owned==null || !owned.IsRecovery)continue;
                Jets(path,owned.Start);Jets(path,owned.End);Jets(path,owned.Start+.015);Jets(path,owned.End-.015);
                var from=(PhraseState)typeof(ContactWristLink).GetField("from",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(owned);
                var to=(PhraseState)typeof(ContactWristLink).GetField("to",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(owned);
                Check(from.IncomingWrist==null && from.OutgoingWrist==null && to.IncomingWrist==null && to.OutgoingWrist==null,"Recovery retains a chain of previous plans");
                foreach(double phase in new[]{.0,.35,.75})
                {
                    double now=owned.Start+(owned.End-owned.Start)*phase;notes[1].Committed=last;var seed=path.Sample(now);seed.Id=-1;
                    var next=ReplayMotor.Build(seed,new[]{notes[1]},g,teacher,9,2);
                    Check(object.ReferenceEquals(next.Contact(1).IncomingWrist,owned),"Replan replaced the active return stroke");
                    for(double t=now+.0001;t<last.SwingEnd;t+=.002)
                    {var a=path.Sample(t);var b=next.Sample(t);Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-7 && (a.AngularVelocity-b.AngularVelocity).Length<1e-5,"Replan changes a visible repeated-cut return");}
                }
            }
            Console.WriteLine(checks+" repeated-arrow return / no full turns / cut jets / replan ownership assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
