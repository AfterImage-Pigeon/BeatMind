using System;
using SaberMind;

class ReachRepairScoringTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main()
    {
        try
        {
            foreach(int color in new[]{0,1})
            {
                var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(color==0 ? -.2 : .2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=color};
                Func<double,PhraseState> teacher=delegate(double t)
                {
                    const double sigma=.008;double x=t-.744,angle=1.6*Math.Exp(-x*x/(sigma*sigma));
                    return new PhraseState{Time=t,Grip=g.Shoulder+new MotionVector(0,.121,0),HumanWristWeight=1,
                        Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),AngularVelocity=new MotionVector(-2*x/(sigma*sigma)*angle,0,0),
                        AngularAcceleration=new MotionVector((-2/(sigma*sigma)+4*x*x/(sigma*sigma*sigma*sigma))*angle,0,0)};
                };
                var note=new PhraseNote{Id=1446,Time=1,Center=g.Shoulder+new MotionVector(0,.121,.6),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=1,LocalNps=2};
                var seed=ConstrainedReplayTrajectory.Project(teacher(0),g);
                var path=ReplayMotor.Build(seed,new[]{note},g,teacher,9,2);
                Check(path.StabilityFallbacks>0,"near-shoulder source did not exercise the local repair");
                Check(path.Contact(note.Id)!=null && !path.Contact(note.Id).LimitedContact,"safe inner-barrier detour discarded the scored contact");
                var cut=path.Sample(note.Time);
                Check(cut.RepairStage>0,"unsafe pulse did not replace the contact's approach/release route");
                Check(CutSafety.BladeDistance(cut,note.Center,g)<.001,"reach repair lost the fitted note contact");
                Check(MotionVector.Dot(cut.Velocity+MotionVector.Cross(cut.AngularVelocity,cut.Rotation.Rotate(g.Top)),note.Direction)>1.5,"reach repair lost cut direction/speed");
                Check(double.IsNaN(path.Contact(note.Id).SwingStart),"replaced contact route retained a stale generated swing clock");
                for(double t=.01;t<1.99;t+=.002)
                {
                    var s=path.Sample(t);double radius=(s.Grip-g.Shoulder).Length;
                    Check(radius>=g.MinimumReach-1e-8 && radius<=g.Reach+1e-8,"accepted detour violated physical reach");
                    Check(s.Velocity.Length<=18.001 && s.AngularVelocity.Length<=125.001,"accepted detour exceeded unchanged speed bounds");
                    const double e=1e-6;var a=path.Sample(t-e);var b=path.Sample(t+e);
                    Check(((b.Grip-a.Grip)/(2*e)-s.Velocity).Length<.01,"reach detour snapped or published incorrect velocity");
                }
            }
            Console.WriteLine(checks+" inner-barrier contact repair / route ownership assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
