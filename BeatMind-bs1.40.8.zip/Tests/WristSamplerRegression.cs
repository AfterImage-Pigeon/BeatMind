using System;
using System.Collections.Generic;
using SaberMind;
class WristSamplerRegression
{
    static int checks;
    static void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
    static bool Equal(double a,double b){return BitConverter.DoubleToInt64Bits(a)==BitConverter.DoubleToInt64Bits(b);}
    static void Compare(PhraseState a,PhraseState b,string why)
    {
        Check(Equal(a.Time,b.Time),why+" changed time");
        Check(Equal(a.Rotation.X,b.Rotation.X) && Equal(a.Rotation.Y,b.Rotation.Y) && Equal(a.Rotation.Z,b.Rotation.Z) && Equal(a.Rotation.W,b.Rotation.W),why+" changed quaternion bits");
        Check(Equal(a.AngularVelocity.X,b.AngularVelocity.X) && Equal(a.AngularVelocity.Y,b.AngularVelocity.Y) && Equal(a.AngularVelocity.Z,b.AngularVelocity.Z),why+" changed angular velocity bits");
        Check(Equal(a.AngularAcceleration.X,b.AngularAcceleration.X) && Equal(a.AngularAcceleration.Y,b.AngularAcceleration.Y) && Equal(a.AngularAcceleration.Z,b.AngularAcceleration.Z),why+" changed angular acceleration bits");
    }
    static PhraseState Pose(double t)
    {
        return new PhraseState{Time=t,Grip=new MotionVector(-.3+.02*Math.Sin(t*4),1.2+.01*Math.Cos(t*6),.28),Velocity=new MotionVector(.08*Math.Cos(t*4),-.06*Math.Sin(t*6),0),Acceleration=new MotionVector(-.32*Math.Sin(t*4),-.36*Math.Cos(t*6),0),
            Rotation=MotionRotation.Exp(new MotionVector(.35*Math.Sin(t*8),0,0)),AngularVelocity=new MotionVector(2.8*Math.Cos(t*8),0,0),AngularAcceleration=new MotionVector(-22.4*Math.Sin(t*8),0,0),HumanSource=0,HumanGripWeight=1,HumanWristWeight=1};
    }
    static void Curves()
    {
        for(int i=0;i<32;i++)
        {
            var a=Pose(i*.031);var b=Pose(a.Time+.015+i*.019);
            foreach(bool wristJoin in new[]{false,true})
            {
                var edge=new MotionTransition(a,b,wristJoin,.015);
                for(int k=-2;k<=102;k++)
                {double t=a.Time+(b.Time-a.Time)*k/100;Compare(edge.Sample(t),edge.SampleWrist(t),"transition");}
            }
        }
        int calls=0;var g=new PhraseGeometry{Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.15,ShoulderAt=delegate(double t){calls++;return new MotionVector(-.15,1.47,.025);}};
        var left=Pose(0);var right=Pose(.3);right.Grip=new MotionVector(-.05,1.2,.28);
        var reach=new ReachTransition(left,right,g,true);
        for(int k=0;k<=200;k++)
        {
            double t=k*.3/200;var full=reach.Sample(t);calls=0;var wrist=reach.SampleWrist(t);Compare(full,wrist,"spherical reach");Check(calls==0,"wrist sampler evaluated moving shoulder");
        }
    }
    static void Phrases()
    {
        foreach(bool human in new[]{false,true})foreach(double scale in new[]{1.0,1.5})foreach(bool stable in new[]{false,true})
        {
            Func<double,PhraseState> teacher=delegate(double t){var s=Pose(t);if(!human)s.HumanGripWeight=s.HumanWristWeight=0;return s;};
            var g=new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1),Shoulder=new MotionVector(-.15,1.47,.025),Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1),StableFastGrip=stable,SwingSpeedScale=scale};
            var notes=new List<PhraseNote>();
            for(int i=0;i<14;i++)notes.Add(new PhraseNote{Id=i,Time=.25+i*.15,Center=new MotionVector(-.3,1.10+i%2*.12,.825),Direction=new MotionVector(0,i%2==0 ? -1 : 1,0),Forward=g.Forward,Spacing=.15,LocalNps=10});
            var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,2.7);
            for(int k=-2;k<=650;k++)
            {
                double t=k/240.0;var full=path.Sample(t);var wrist=path.SampleWrist(t);Compare(full,wrist,"published phrase");
                wrist.Rotation=MotionRotation.Identity;wrist.AngularVelocity=new MotionVector(999,999,999);wrist.AngularAcceleration=new MotionVector(999,999,999);
                Compare(full,path.Sample(t),"wrist result mutation");
            }
            double carry=.82;var next=ReplayMotor.Build(path.Sample(carry),notes,g,teacher,9,2.7);next.CarryFrom(path,carry,carry+.12);
            for(int k=0;k<=80;k++){double t=carry-.02+k*.002;Compare(next.Sample(t),next.SampleWrist(t),"carried phrase");}
        }
        var plain=new MotionPhrase();plain.Knots.Add(Pose(0));plain.Knots.Add(Pose(.2));plain.Knots.Add(Pose(.4));
        foreach(double t in new[]{.5,.1,.2,.3,.4,0.0,-.1,.21,.2,.19})Compare(plain.Sample(t),plain.SampleWrist(t),"plain phrase cursor");
    }
    static int Main()
    {
        try{Curves();Phrases();Console.WriteLine(checks+" exact angular sampler / ownership / reach assertions passed.");return 0;}
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
