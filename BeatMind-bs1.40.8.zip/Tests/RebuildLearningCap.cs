using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SaberMind;

// Offline preparation only: all generated files go to a fresh workspace stage.
// Game replay paths stay original so startup fingerprints and provenance match.
class RebuildLearningCap
{
    static string Snapshot(string path)
    {return File.Exists(path) ? HumanMotionTraining.Digest(File.ReadAllText(path)) : null;}
    static string Evidence(HumanMotionExample e)
    {return JsonConvert.SerializeObject(new{e.Phase,e.StartTime,e.Duration,e.Score,e.Recording,e.Sequence,e.Context,e.Curve,e.Kinematics,e.Anchors});}
    static int Main(string[] args)
    {
        try
        {
            if(args.Length!=2)throw new ArgumentException("Usage: RebuildLearningCap <read-only-game-directory> <new-workspace-cache-directory>");
            string game=Path.GetFullPath(args[0]),stage=Path.GetFullPath(args[1]);
            string gamePrefix=game.TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
            if(stage.Equals(game,StringComparison.OrdinalIgnoreCase) || stage.StartsWith(gamePrefix,StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Offline cache must be outside the game directory.");
            if(Directory.Exists(stage))throw new ArgumentException("Choose a fresh offline cache directory.");
            string data=Path.Combine(game,"UserData","AIPlayAndLearn"),oldCache=Path.Combine(data,"HumanMotionCache");
            string settings=Path.Combine(data,"Settings.json"),state=Path.Combine(data,"BotReplayWindows.json");
            string settingsSnapshot=Snapshot(settings),stateSnapshot=Snapshot(state),backupSnapshot=Snapshot(state+".bak");
            bool automatic=File.Exists(settings) ? (bool?)JObject.Parse(File.ReadAllText(settings))["AutoLearnOwnReplays"] ?? true : true;
            var collector=new AutomaticReplays(Path.Combine(data,"HumanReplays"),Path.Combine(game,"UserData","BeatLeader","Replays"),state);
            string[] paths=collector.Collect(automatic,DateTime.UtcNow);string sourceRevision=AutomaticReplays.SourceRevision(paths);
            string revision=(string)typeof(HumanMotionTraining).GetField("Revision",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
            var sourceKeys=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);int copied=0;long copiedBytes=0;
            Directory.CreateDirectory(stage);var timer=Stopwatch.StartNew();
            foreach(string path in paths)
            {
                long length,ticks;ReplayFileAccess.Metadata(path,out length,out ticks);
                string key=HumanMotionTraining.Digest(Path.GetFileName(path)+"|"+length+"|"+ticks+"|"+revision);sourceKeys[path]=key;
                string source=Path.Combine(oldCache,key+".json.gz");
                if(File.Exists(source)){File.Copy(source,Path.Combine(stage,key+".json.gz"));copied++;copiedBytes+=new FileInfo(source).Length;}
            }
            HumanMotionModel previous=null;string oldModel=Path.Combine(oldCache,"HumanMotionModel.json.gz");
            if(File.Exists(oldModel)){previous=HumanMotionTraining.Read<HumanMotionModel>(oldModel);File.Copy(oldModel,Path.Combine(stage,"HumanMotionModel.json.gz"));}
            Console.WriteLine("Staged "+copied+" existing extraction caches for "+paths.Length+" startup sources. Original replays and game cache remain untouched.");
            int warmModels=0,updates=0;var warnings=new List<string>();
            var model=HumanMotionTraining.LoadFiles(paths,stage,delegate(string s){if(++updates%100==0 || !s.StartsWith("Reading"))Console.WriteLine(s);},delegate(string s){warnings.Add(s);},null,
                delegate(HumanMotionModel m){warmModels++;if(!m.Valid() || m.LearningPoseSamples>HumanMotionTraining.MaximumLearningPoseSamples)throw new InvalidDataException("Offline rebuild exposed an old or over-budget warm model.");});
            if(!model.Valid())throw new InvalidDataException("Offline capped model failed its persisted contract.");
            if(previous!=null && !previous.Valid() && warmModels!=0)throw new InvalidDataException("Legacy warm model escaped before rebuilding.");
            if(sourceRevision!=AutomaticReplays.SourceRevision(paths) || sourceRevision!=AutomaticReplays.SourceRevision(collector.Collect(automatic,DateTime.UtcNow)))throw new IOException("Replay source snapshot changed during rebuilding; rerun while the game is closed.");
            if(settingsSnapshot!=Snapshot(settings) || stateSnapshot!=Snapshot(state) || backupSnapshot!=Snapshot(state+".bak"))throw new IOException("Source settings or replay provenance changed during rebuilding.");
            var identities=new Dictionary<string,HumanRecording>();foreach(var recording in model.Recordings)identities[recording.Identity]=recording;
            int priorIncluded=0,priorPreserved=0;if(previous!=null)foreach(var r in previous.Recordings)
            {
                if(!sourceKeys.ContainsKey(r.Path))continue;priorIncluded++;HumanRecording retained;
                if(!identities.TryGetValue(r.Identity,out retained) || retained.Accuracy!=r.Accuracy || retained.Frames!=r.Frames || retained.Notes!=r.Notes)throw new InvalidDataException("Smaller budget removed or changed an eligible replay source index.");priorPreserved++;
            }
            // Prototypes remain exact, complete source excerpts, including note
            // anchor timing/score and the synchronized pose/derivative arrays.
            var byRecording=new Dictionary<string,List<HumanMotionExample>>();foreach(var e in model.Examples)
            {List<HumanMotionExample> bank;if(!byRecording.TryGetValue(e.Recording,out bank)){bank=new List<HumanMotionExample>();byRecording.Add(e.Recording,bank);}bank.Add(e);}
            int verified=0;foreach(var entry in byRecording)
            {
                var r=identities[entry.Key];var source=HumanMotionTraining.Read<HumanMotionFile>(Path.Combine(stage,sourceKeys[r.Path]+".json.gz"));
                foreach(var e in entry.Value){HumanMotionExample original=source.Examples.Find(delegate(HumanMotionExample x){return x.Sequence==e.Sequence;});if(original==null || Evidence(e)!=Evidence(original))throw new InvalidDataException("Fitting changed measured motion, derivatives or learned note/stroke data.");verified++;}
            }
            int ready=0;var warm=HumanMotionTraining.LoadFiles(paths,stage,null,null,null,delegate(HumanMotionModel m){ready++;});
            if(ready!=1 || !warm.Valid() || warm.Fingerprint!=model.Fingerprint || warm.TrainingFingerprint!=model.TrainingFingerprint || warm.CachedFiles!=paths.Length)throw new InvalidDataException("Prepared cache was not accepted immediately on warm startup.");
            var report=new{maximumPoseSamples=HumanMotionTraining.MaximumLearningPoseSamples,learningBudgetVersion=model.LearningBudgetVersion,retainedPoseSamples=model.LearningPoseSamples,intactExcerpts=model.Cuts,availableSequences=model.AvailableSequences,
                inspected=paths.Length,eligibleSources=model.Files,rejected=model.Rejected,duplicates=model.Duplicates,prototypes=model.Examples.Count,verifiedIntactSourcePrototypes=verified,
                priorPoseSamples=previous==null ? 0 : previous.LearningPoseSamples,priorBudgetVersion=previous==null ? 0 : previous.LearningBudgetVersion,priorIncludedEligibleSources=priorIncluded,priorPreservedEligibleSources=priorPreserved,
                heldOutExamples=model.ValidationExamples,contextualError=model.ContextValidationError,genericError=model.MeanValidationError,phases=model.PhaseCounts,
                stagedExtractionCaches=copied,stagedBytes=copiedBytes,legacyWarmCallbacks=warmModels,warmCacheCallbacks=ready,sourceSnapshotUnchanged=true,elapsedSeconds=timer.Elapsed.TotalSeconds,peakMemoryMB=Process.GetCurrentProcess().PeakWorkingSet64/1048576.0,
                model.Fingerprint,model.TrainingFingerprint,preparedModelPath=Path.Combine(stage,"HumanMotionModel.json.gz")};
            File.WriteAllText(Path.Combine(stage,"LearningCapMigrationReport.json"),JsonConvert.SerializeObject(report,Formatting.Indented));
            File.WriteAllLines(Path.Combine(stage,"LearningCapMigrationWarnings.txt"),warnings.ToArray());
            Console.WriteLine(JsonConvert.SerializeObject(report));return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
