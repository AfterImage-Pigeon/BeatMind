using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using SaberMind;
class IdleCollisionTests
{
    static bool Box(MotionVector a,MotionVector b,MotionVector c)
    {
        a-=c;b-=c;double[] p={a.X,a.Y,a.Z},d={b.X-a.X,b.Y-a.Y,b.Z-a.Z};double lo=0,hi=1;
        for(int k=0;k<3;k++){if(Math.Abs(d[k])<1e-9){if(Math.Abs(p[k])>.15)return false;}else{double x=(-.15-p[k])/d[k],y=(.15-p[k])/d[k];lo=Math.Max(lo,Math.Min(x,y));hi=Math.Min(hi,Math.Max(x,y));if(lo>hi)return false;}}return true;
    }
    static int Main(string[] args)
    {
        try
        {
            var output=new List<object>();int contacts=0,slow=0,wrong=0;
            foreach(int hand in new[]{0,1})foreach(int direction in new[]{0,1,2,3,4,5,6,7})foreach(double njs in new[]{10.0,12.0,16.0})
            {
                double x=hand==0 ? -.3529 : .3529;
                var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};
                Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(x,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};};
                var n=new PhraseNote{Id=0,Time=.5,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(direction),Forward=g.Forward,Spacing=1.14,LocalNps=1};
                var path=ReplayMotor.Build(teacher(0),new[]{n},g,teacher,9,1);
                const double dt=1.0/240;bool hit=false;var prior=path.Sample(n.Time-.15);
                for(double t=n.Time-.15+dt;t<n.Time+.10;t+=dt)
                {
                    var s=path.Sample(t);var center=n.Center+g.Forward*((n.Time-t)*njs);bool touch=false;
                    MotionVector a=s.Grip+s.Rotation.Rotate(g.Bottom),b=s.Grip+s.Rotation.Rotate(g.Top),pa=prior.Grip+prior.Rotation.Rotate(g.Bottom),pb=prior.Grip+prior.Rotation.Rotate(g.Top);
                    for(int k=0;k<=4;k++){double u=k/4.0;if(Box(pa*(1-u)+a*u,pb*(1-u)+b*u,center)){touch=true;break;}}
                    if(touch){var velocity=(b-pb)/dt;velocity.Z=0;double speed=velocity.Length,cosine=MotionVector.Dot(velocity.Unit,n.Direction);contacts++;if(speed<1.5)slow++;if(cosine<.5)wrong++;output.Add(new{hand,direction,njs,offset=t-n.Time,speed,cosine});hit=true;break;}
                    prior=s;
                }
                if(!hit)output.Add(new{hand,direction,njs,miss=true});
            }
            var summary=new{cases=48,contacts,slow,wrong,cuts=output};string json=JsonConvert.SerializeObject(summary,Formatting.Indented);System.IO.File.WriteAllText(args[0],json);if(contacts!=48 || slow!=0 || wrong!=0)throw new Exception("Idle-source swept contact regression: contacts="+contacts+", slow="+slow+", wrong="+wrong);Console.WriteLine("48 idle-source swept-contact assertions passed.");return 0;
        }catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}

