using System;
using System.Collections.Generic;
using System.Reflection;
using SaberMind;
class FastStreamRegression
{
    static int checks;
    static void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
    static PhraseGeometry Geometry(int hand,bool offset)
    {return new PhraseGeometry{ScoredHumanSwings=true,StableFastGrip=true,Top=new MotionVector(0,0,1),Bottom=offset ? new MotionVector(.008,0,.025) : new MotionVector(),Grip=offset ? new MotionVector(.006,-.002,-.045) : new MotionVector(),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.99,0),Forward=new MotionVector(0,0,1),Reach=.646,MinimumReach=.149,Color=hand};}
    static PhraseState Teacher(double t,int hand)
    {
        // An unrelated demonstration moves its whole hand. Its derivatives
        // stay internally consistent; the cut constraints must not treat this
        // translation as a second target layered over the wrist's fast stream.
        double phase=14*t;return new PhraseState{Time=t,HumanSource=6,HumanGripWeight=.8,HumanWristWeight=.8,Grip=new MotionVector(hand==0 ? -.35 : .35,1.57+.16*Math.Sin(phase),.18),Velocity=new MotionVector(0,2.24*Math.Cos(phase),0),Acceleration=new MotionVector(0,-31.36*Math.Sin(phase),0),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};
    }
    static PhraseNote Note(int hand,int id,double t,double gap,bool twoLayers)
    {return new PhraseNote{Id=id,Time=t,Center=new MotionVector(hand==0 ? -.3 : .3,twoLayers && id%2==1 ? 2.1764 : 1.0764,.88),Direction=HumanContext.Direction(id%2==0 ? 1 : 0),Forward=new MotionVector(0,0,1),Spacing=gap,LocalNps=2/gap};}
    static void Jets(MotionPhrase path,double t)
    {
        const double e=1e-6;var a=path.Sample(t-e);var b=path.Sample(t+e);var s=path.Sample(t);
        Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.08,"Rotation jumps or disagrees with its angular velocity at "+t);
        Check(((b.Grip-a.Grip)/(2*e)-s.Velocity).Length<.03,"Grip jumps or disagrees with its velocity at "+t);
    }
    static int Main()
    {
        try
        {
            HalfTurnRoll();
            foreach(int hand in new[]{0,1})foreach(bool offset in new[]{false,true})foreach(bool twoLayers in new[]{false,true})foreach(double gap in new[]{.04411764705882353,.0661764705882353,.1})foreach(int arrow in new[]{1,2,4,5})
            {
                var g=Geometry(hand,offset);Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand);};var notes=new List<PhraseNote>();
                for(int i=0;i<14;i++){var n=Note(hand,i,.65+i*gap,gap,twoLayers);n.Direction=HumanContext.Direction(i%2==0 ? arrow : arrow==1 ? 0 : arrow==2 ? 3 : arrow==4 ? 7 : 6);notes.Add(n);}
                var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,2.7);
                double minZ=1,maxGrip=0;
                foreach(var n in notes)
                {
                    var c=path.Contact(n.Id);Check(c!=null,"Dense contact disappeared");Check(!c.LimitedContact,"A feasible compact-pivot stream was discarded");var s=path.Sample(n.Time);
                    Check(CutSafety.BladeDistance(s,n.Center,g)<.025,"Contact fitting lost the note");
                    var top=s.Rotation.Rotate(g.Top-g.Grip);var v=s.Velocity+MotionVector.Cross(s.AngularVelocity,top);
                    Check(MotionVector.Dot(v,n.Direction)>1.5,"Wrong cut direction at exact contact");
                    Check(MotionVector.Dot(s.Rotation.Rotate((g.Top-g.Bottom).Unit),g.Forward)>.08,"Contact blade points away from the incoming note field");
                    if(n.Id>0 && n.Id<13)Check(c.IncomingWrist!=null && c.OutgoingWrist!=null,"Close cuts did not share a connected wrist path");
                    Jets(path,n.Time);
                }
                for(double t=notes[1].Time+.001;t<notes[12].Time;t+=1.0/240)
                {
                    var s=path.Sample(t);double z=s.Rotation.Rotate((g.Top-g.Bottom).Unit).Z;minZ=Math.Min(minZ,z);maxGrip=Math.Max(maxGrip,s.Velocity.Length);
                    Check(s.AngularVelocity.Length<180,"A dense recovery whips around the grip");Check((s.Grip-g.Shoulder).Length<g.Reach+.001,"Compact pivot violates reach");
                }
                Check(maxGrip<2,"Unrelated replay bob is translating the whole saber through the stream: "+maxGrip);
                Check(minZ>-.2,"A compact fast stream points its tip back toward the player: "+minZ+" hand="+hand+" offset="+offset+" twoLayers="+twoLayers+" gap="+gap+" arrow="+arrow);
                // Replanning inside a shared stroke keeps the same incoming
                // curve and contact jet, rather than restarting a preparation.
                int first=5;double now=notes[first].Time-gap*.25;var future=new List<PhraseNote>();
                for(int i=first;i<notes.Count;i++){notes[i].Committed=path.Contact(notes[i].Id);future.Add(notes[i]);}
                var seed=path.Sample(now);seed.Id=-1;var next=ReplayMotor.Build(seed,future,g,teacher,9,2);
                Check(object.ReferenceEquals(path.Contact(first).IncomingWrist,next.Contact(first).IncomingWrist),"Replan replaced the ongoing shared stroke");
                for(double t=now+1e-5;t<notes[first+1].Time;t+=.001)
                {Check(MotionRotation.Log(path.Sample(t).Rotation*next.Sample(t).Rotation.Inverse).Length<1e-6,"Replan snaps an ongoing fast wrist");}
                var link=path.Contact(first).OutgoingWrist;
                var from=(PhraseState)typeof(ContactWristLink).GetField("from",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(link);
                var to=(PhraseState)typeof(ContactWristLink).GetField("to",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(link);
                Check(from.IncomingWrist==null && from.OutgoingWrist==null && to.IncomingWrist==null && to.OutgoingWrist==null,"A wrist link retains the whole prior song");
            }
            Console.WriteLine(checks+" fast-stream pivot / directed contacts / connected rotation / replan / ownership assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void HalfTurnRoll()
    {
        var blade=new MotionVector(0,0,1);var axis=new MotionVector(1,0,.1).Unit;
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,HumanSource=7,Rotation=MotionRotation.Exp(axis*(36*(t-1))),AngularVelocity=axis*36};};
        var contact=new PhraseState{Time=1,SwingStart=.75,SwingEnd=1.25};
        var old=ReplayWristRoll.Capture(teacher,contact,blade);var corrected=ReplayWristRoll.Capture(teacher,contact,blade,true);
        Check(old!=null && corrected!=null,"Half-turn roll fixture lost measured wrist motion");
        var sign=ReplayWristRoll.Capture(delegate(double t){var s=teacher(t);s.Rotation=s.Rotation*-1;return s;},contact,blade,true);
        double oldPeak=0,visible=0;
        for(int i=0;i<=500;i++)
        {
            double t=.75+.001*i;var original=new PhraseState{Time=t};var s=original.Copy();corrected.Apply(s);var faulty=original.Copy();old.Apply(faulty);oldPeak=Math.Max(oldPeak,faulty.AngularVelocity.Length);
            Check(s.AngularVelocity.Length<30,"Measured half-turn swing became an artificial roll spin");
            Check((s.Rotation.Rotate(blade)-blade).Length<1e-10,"Axial roll changed the scored tip arc");visible=Math.Max(visible,MotionRotation.Log(s.Rotation).Length);
            var signed=original.Copy();sign.Apply(signed);Check(MotionRotation.Log(signed.Rotation*s.Rotation.Inverse).Length<1e-10,"Quaternion sign changed integrated wrist roll");
            const double e=1e-6;var a=new PhraseState{Time=t-e};var b=new PhraseState{Time=t+e};corrected.Apply(a);corrected.Apply(b);
            Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.001,"Continuous roll velocity does not match the transform");
            Check(((b.AngularVelocity-a.AngularVelocity)/(2*e)-s.AngularAcceleration).Length<.01,"Continuous roll acceleration does not match its velocity");
        }
        Check(oldPeak>60,"Fixture did not reproduce the swing/twist half-turn amplification: "+oldPeak);Check(visible>.1,"Correction removed legitimate measured wrist roll");
        foreach(double t in new[]{.75,1.0,1.25}){var s=new PhraseState{Time=t};corrected.Apply(s);Check(MotionRotation.Log(s.Rotation).Length<1e-10 && s.AngularVelocity.Length<1e-10 && s.AngularAcceleration.Length<1e-10,"Roll changed a contact or boundary jet");}
        Check(ReplayWristRoll.Capture(delegate(double t){var s=teacher(t);s.HumanSource=t<1 ? 7 : 8;return s;},contact,blade,true)==null,"Integrated roll mixed source sequences");
    }
}
