using System;
namespace SaberMind {
    internal sealed class LegacyPhraseCurve
    {
        private readonly double start,duration;
        internal double Start {get{return start;}}
        internal double End {get{return start+duration;}}
        private readonly MotionVector[] p,v,acc,r,rd,rdd;
        private readonly MotionRotation initial;
        private readonly double humanGrip,humanWrist;
        private readonly int source;
        internal LegacyPhraseCurve(PhraseState a,PhraseState b)
        {
            humanGrip=Math.Min(a.HumanGripWeight,b.HumanGripWeight);humanWrist=Math.Min(a.HumanWristWeight,b.HumanWristWeight);source=b.HumanSource;
            start=a.Time;duration=Math.Max(1e-8,b.Time-a.Time);initial=a.Rotation.Unit;
            p=Controls(a.Grip,a.Velocity,a.Acceleration,b.Grip,b.Velocity,b.Acceleration,duration);
            v=Derivative(p,duration);acc=Derivative(v,duration);p=Power(p);v=Power(v);acc=Power(acc);
            MotionVector end=MotionRotation.Log(b.Rotation*initial.Inverse);
            MotionVector endVelocity=InverseJacobian(end,b.AngularVelocity);
            MotionVector endAcceleration=InverseJacobian(end,b.AngularAcceleration-JacobianDerivative(end,endVelocity,endVelocity));
            r=Controls(new MotionVector(),a.AngularVelocity,a.AngularAcceleration,end,endVelocity,endAcceleration,duration);
            rd=Derivative(r,duration);rdd=Derivative(rd,duration);r=Power(r);rd=Power(rd);rdd=Power(rdd);
        }
        internal PhraseState Sample(double now)
        {return Sample(now,false);}
        internal PhraseState Sample(double now,bool wristOnly)
        {
            double t=MotionPhrase.Clamp((now-start)/duration,0,1);
            MotionVector angle=Blend(r,t),velocity=Blend(rd,t),acceleration=Blend(rdd,t);
            return new PhraseState{Time=now,Grip=wristOnly ? new MotionVector() : Blend(p,t),Velocity=wristOnly ? new MotionVector() : Blend(v,t),Acceleration=wristOnly ? new MotionVector() : Blend(acc,t),Rotation=(MotionRotation.Exp(angle)*initial).Unit,
                AngularVelocity=Jacobian(angle,velocity),AngularAcceleration=Jacobian(angle,acceleration)+JacobianDerivative(angle,velocity,velocity),
                HumanGripWeight=humanGrip,HumanWristWeight=humanWrist,HumanSource=source};
        }
        private static MotionVector Jacobian(MotionVector r,MotionVector v)
        {
            double t=r.Length,a,b;
            if(t<.001){double s=t*t;a=.5-s/24+s*s/720;b=1.0/6-s/120+s*s/5040;}
            else{a=(1-Math.Cos(t))/(t*t);b=(t-Math.Sin(t))/(t*t*t);}
            return v+MotionVector.Cross(r,v)*a+MotionVector.Cross(r,MotionVector.Cross(r,v))*b;
        }
        private static MotionVector InverseJacobian(MotionVector r,MotionVector v)
        {
            double t=r.Length,c=t<.001 ? 1.0/12+t*t/720 : (1-.5*t/Math.Tan(t*.5))/(t*t);
            return v-MotionVector.Cross(r,v)*.5+MotionVector.Cross(r,MotionVector.Cross(r,v))*c;
        }
        private static MotionVector JacobianDerivative(MotionVector r,MotionVector rate,MotionVector v)
        {
            double t=r.Length,a,b,da,db,dot=MotionVector.Dot(r,rate);
            if(t<.001){double s=t*t;a=.5-s/24+s*s/720;b=1.0/6-s/120+s*s/5040;da=dot*(-1.0/12+s/180);db=dot*(-1.0/60+s/1260);}
            else{double t2=t*t;a=(1-Math.Cos(t))/t2;b=(t-Math.Sin(t))/(t2*t);da=dot*(t*Math.Sin(t)-2*(1-Math.Cos(t)))/(t2*t2);db=dot*(t*(1-Math.Cos(t))-3*(t-Math.Sin(t)))/(t2*t2*t);}
            MotionVector cross=MotionVector.Cross(r,v);
            return cross*da+MotionVector.Cross(rate,v)*a+MotionVector.Cross(r,cross)*db+
                (MotionVector.Cross(rate,cross)+MotionVector.Cross(r,MotionVector.Cross(rate,v)))*b;
        }
        private static MotionVector[] Controls(MotionVector a,MotionVector av,MotionVector aa,MotionVector b,MotionVector bv,MotionVector ba,double d)
        {return new[]{a,a+av*(d/5),a+av*(2*d/5)+aa*(d*d/20),b-bv*(2*d/5)+ba*(d*d/20),b-bv*(d/5),b};}
        private static MotionVector[] Derivative(MotionVector[] a,double d)
        {int n=a.Length-1;var v=new MotionVector[n];for(int i=0;i<n;i++)v[i]=(a[i+1]-a[i])*(n/d);return v;}
        private static readonly int[][] Binomial={new[]{1},new[]{1,1},new[]{1,2,1},new[]{1,3,3,1},new[]{1,4,6,4,1},new[]{1,5,10,10,5,1}};
        private static MotionVector[] Power(MotionVector[] a)
        {int n=a.Length-1;var result=new MotionVector[a.Length];for(int i=0;i<=n;i++)for(int j=0;j<=i;j++)result[i]+=a[j]*(Binomial[n][i]*Binomial[i][j]*((i-j)%2==0 ? 1 : -1));return result;}
        private static MotionVector Blend(MotionVector[] a,double t)
        {MotionVector value=a[a.Length-1];for(int i=a.Length-2;i>=0;i--)value=value*t+a[i];return value;}
    }
}