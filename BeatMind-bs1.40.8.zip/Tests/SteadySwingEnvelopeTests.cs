using System;
using SaberMind;

class SteadySwingEnvelopeTests
{
    static int checks;static double maximumWError,maximumAlphaError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static void Near(double actual,double expected,double tolerance,string message)
    {Check(Math.Abs(actual-expected)<=tolerance,message+": actual="+actual+" expected="+expected);}
    static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    static double Angle(SteadySwingEnvelope envelope,double time)
    {double angle,rate,acceleration;envelope.Sample(time,out angle,out rate,out acceleration);return angle;}
    static MotionRotation Rotation(SteadySwingEnvelope envelope,double time,MotionVector axis,MotionRotation contact)
    {return MotionRotation.Exp(axis*Angle(envelope,time))*contact;}

    static void TravelAndPlateau()
    {
        var envelope=new SteadySwingEnvelope(.7,1,1.25,12);double angle,rate,acceleration;
        Near(SteadySwingEnvelope.TravelFraction,1-SteadySwingEnvelope.RampFraction/2,1e-15,"travel fraction does not match ramp integral");
        foreach(double time in new[]{-.1,.7})
        {envelope.Sample(time,out angle,out rate,out acceleration);Near(angle,-12*.30*.91,1e-14,"preparation travel");Check(rate==0 && acceleration==0,"preparation endpoint is not stationary");}
        foreach(double time in new[]{1.25,2.0})
        {envelope.Sample(time,out angle,out rate,out acceleration);Near(angle,12*.25*.91,1e-14,"release travel");Check(rate==0 && acceleration==0,"release endpoint is not stationary");}
        for(int i=0;i<=120;i++)
        {
            double time=1-.060+i*.001;envelope.Sample(time,out angle,out rate,out acceleration);
            Near(angle,12*(time-1),1e-14,"contact plateau angle");Check(rate==12 && acceleration==0,"wrist slowed in the +/-60 ms contact plateau");
        }
        // Integrating the returned velocity independently must reproduce the
        // analytic angles on both sides, including the stationary endpoints.
        foreach(bool preparation in new[]{false,true})
        {
            double start=preparation ? envelope.Start : envelope.Hit,end=preparation ? envelope.Hit : envelope.End;
            const int count=2000;double integral=0,step=(end-start)/count;
            for(int i=0;i<=count;i++)
            {envelope.Sample(start+step*i,out angle,out rate,out acceleration);integral+=(i==0 || i==count ? 1 : i%2==0 ? 2 : 4)*rate;}
            integral*=step/3;
            Near(integral,envelope.Speed*(end-start)*.91,2e-10,"velocity integral drifted from exact travel");
            Near(Angle(envelope,end)-Angle(envelope,start),integral,2e-10,"angle is not the integrated velocity");
        }
    }

    static void AnalyticJets(double before,double after,double speed)
    {
        const double hit=2;var envelope=new SteadySwingEnvelope(hit-before,hit,hit+after,speed);
        var axis=new MotionVector(.3,-.7,.2).Unit;var contact=MotionRotation.Exp(new MotionVector(.2,.4,-.1));
        double epsilon=Math.Min(before,after)*1e-6,previous=double.NegativeInfinity;
        for(int i=0;i<=500;i++)
        {
            double time=envelope.Start+(envelope.End-envelope.Start)*i/500,angle,rate,acceleration;
            envelope.Sample(time,out angle,out rate,out acceleration);
            Check(Finite(angle) && Finite(rate) && Finite(acceleration),"envelope contains a nonfinite jet");
            Check(rate>=-1e-10 && rate<=speed+1e-10,"envelope rate left its steady-speed bounds");
            Check(angle>=previous-1e-11,"scalar swing reversed");previous=angle;
            Check(time<=hit ? angle<=1e-12 : angle>=-1e-12,"angle lost its contact-relative sign");
            double leftAngle,leftRate,leftAlpha,rightAngle,rightRate,rightAlpha;
            envelope.Sample(time-epsilon,out leftAngle,out leftRate,out leftAlpha);
            envelope.Sample(time+epsilon,out rightAngle,out rightRate,out rightAlpha);
            double wError=(MotionRotation.Log(Rotation(envelope,time+epsilon,axis,contact)*Rotation(envelope,time-epsilon,axis,contact).Inverse)/(2*epsilon)-axis*rate).Length;
            double alphaError=((axis*rightRate-axis*leftRate)/(2*epsilon)-axis*acceleration).Length;
            maximumWError=Math.Max(maximumWError,wError);maximumAlphaError=Math.Max(maximumAlphaError,alphaError);
            Check(wError<2e-5,"rotation and analytic angular velocity disagree at "+time);
            Check(alphaError<Math.Max(1e-5,speed/Math.Min(before,after)*1e-5),"analytic angular acceleration disagrees with angular velocity at "+time);
        }
        Near(MotionRotation.Log(Rotation(envelope,hit,axis,contact)*contact.Inverse).Length,0,1e-12,"analytic envelope moved the contact quaternion");
        foreach(double boundary in new[]{envelope.Start,envelope.Start+before*.18,hit,envelope.End-after*.18,envelope.End})
        {
            double centerAngle,centerRate,centerAlpha;envelope.Sample(boundary,out centerAngle,out centerRate,out centerAlpha);
            Check(centerAlpha==0,"C2 boundary acceleration is nonzero");
            double leftAngle,leftRate,leftAlpha,rightAngle,rightRate,rightAlpha;
            envelope.Sample(boundary-epsilon,out leftAngle,out leftRate,out leftAlpha);
            envelope.Sample(boundary+epsilon,out rightAngle,out rightRate,out rightAlpha);
            Check(Finite(leftAlpha) && Finite(rightAlpha),"C2 boundary has a nonfinite acceleration");
            Check(Math.Abs(rightRate-leftRate)<Math.Max(1e-9,speed*1e-7),"C2 boundary rate jumps");
            double halfLeftAngle,halfLeftRate,halfLeftAlpha,halfRightAngle,halfRightRate,halfRightAlpha;
            envelope.Sample(boundary-epsilon*.5,out halfLeftAngle,out halfLeftRate,out halfLeftAlpha);
            envelope.Sample(boundary+epsilon*.5,out halfRightAngle,out halfRightRate,out halfRightAlpha);
            Check(Math.Abs(halfRightAlpha-halfLeftAlpha)<=Math.Abs(rightAlpha-leftAlpha)*.31+1e-8,"C2 boundary acceleration jump does not converge to zero");
        }
    }

    static void UniformTimeScale()
    {
        var source=new SteadySwingEnvelope(.61,1,1.27,9);const double scale=1.5;
        var fast=new SteadySwingEnvelope(1+(.61-1)/scale,1,1+(1.27-1)/scale,9*scale);
        for(int i=0;i<=500;i++)
        {
            double time=source.Start+(source.End-source.Start)*i/500,angle,rate,acceleration,fastAngle,fastRate,fastAcceleration;
            source.Sample(time,out angle,out rate,out acceleration);fast.Sample(1+(time-1)/scale,out fastAngle,out fastRate,out fastAcceleration);
            Near(fastAngle,angle,1e-12,"uniform speed scaling changed angular travel");
            Near(fastRate,rate*scale,2e-11,"uniform speed scaling lost the analytic velocity scale");
            Near(fastAcceleration,acceleration*scale*scale,5e-9,"uniform speed scaling lost the analytic acceleration scale");
        }
    }

    static void Cadence()
    {
        const double travel=100*Math.PI/180,hit=.5;double previousSpeed=0;
        foreach(double available in new[]{.30,.20,.125,.083333333333,.05,.025})
        {
            double speed=travel/(available*SteadySwingEnvelope.TravelFraction);
            var envelope=new SteadySwingEnvelope(hit-available,hit,hit+available,speed);double angle,rate,acceleration;
            Near(-Angle(envelope,envelope.Start),travel,1e-12,"denser cadence lost preparation travel");
            Near(Angle(envelope,envelope.End),travel,1e-12,"denser cadence lost release travel");
            envelope.Sample(hit,out angle,out rate,out acceleration);
            Check(angle==0 && rate==speed && acceleration==0,"denser cadence moved or slowed the contact");
            Check(speed>previousSpeed,"denser notes did not increase steady swing pace");previousSpeed=speed;
        }
    }

    static int Main()
    {
        try
        {
            TravelAndPlateau();UniformTimeScale();Cadence();
            AnalyticJets(.30,.25,12);AnalyticJets(.08,.05,40);AnalyticJets(.014,.012,180);
            Console.WriteLine(checks+" steady swing travel / contact plateau / C2 angular jets / cadence assertions passed; maximum quaternion velocity/acceleration derivative errors="+maximumWError+"/"+maximumAlphaError);return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
