using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using SaberMind;
class FreshCaptureRegression
{
    static int checks;
    static void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
    static string Pose(PhraseState s)
    {
        var values=new[]{s.Time,s.Id,s.LimitedContact ? 1.0 : 0,s.MinimumReachAdjusted ? 1.0 : 0,s.HumanSource,s.RepairStage,s.HumanGripWeight,s.HumanWristWeight,s.SwingStart,s.SwingPeak,s.SwingEnd,s.ScoringReleaseEnd,
            s.Grip.X,s.Grip.Y,s.Grip.Z,s.Velocity.X,s.Velocity.Y,s.Velocity.Z,s.Acceleration.X,s.Acceleration.Y,s.Acceleration.Z,s.Rotation.X,s.Rotation.Y,s.Rotation.Z,s.Rotation.W,s.AngularVelocity.X,s.AngularVelocity.Y,s.AngularVelocity.Z,s.AngularAcceleration.X,s.AngularAcceleration.Y,s.AngularAcceleration.Z,s.TargetCenter.X,s.TargetCenter.Y,s.TargetCenter.Z,s.TargetDirection.X,s.TargetDirection.Y,s.TargetDirection.Z};
        return JsonConvert.SerializeObject(Array.ConvertAll(values,delegate(double x){return BitConverter.DoubleToInt64Bits(x);}));
    }
    static HumanMotionModel Model(bool phases)
    {
        var model=new HumanMotionModel();
        foreach(HumanPhase phase in Enum.GetValues(typeof(HumanPhase)))
        {
            if(!phases && phase!=HumanPhase.Playing)continue;
            var e=new HumanMotionExample{Phase=phase,Duration=1.25,Recording="fresh-pose fixture "+phase,Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=phase==HumanPhase.Playing ? new[]{new HumanAnchor{Hand=0,Direction=1,Phase=.4},new HumanAnchor{Hand=1,Direction=0,Phase=.8}} : new HumanAnchor[0]};
            for(int p=0;p<129;p++)for(int j=0;j<3;j++)
            {
                double t=p*1.25/128;
                var s=new PhraseState{Time=t,Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.2+j*.1+.01*t,.25),Velocity=new MotionVector(0,.01,0),Rotation=MotionRotation.Exp(new MotionVector(.2*t,0,0)),AngularVelocity=new MotionVector(.2,0,0)};
                HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
            }
            model.Examples.Add(e);
        }
        return model;
    }
    static HumanChartNote[] Chart()
    {
        var notes=new List<HumanChartNote>();
        foreach(double begin in new[]{1.0,8.0})for(int i=0;i<4;i++)notes.Add(new HumanChartNote{Id=notes.Count,Time=begin+i*.5,Hand=i%2,Direction=i%2==0 ? 1 : 0});
        return notes.ToArray();
    }
    static void Owned(HumanMotionGraph graph,double start,double end,string label)
    {
        var capture=graph.Capture(start,end);
        for(double t=start;t<=end;t+=.031)for(int j=0;j<3;j++)
        {
            var a=capture(t,j);var b=capture(t,j);string expected=Pose(b),expectedGraph=Pose(graph.Sample(t,j));
            Check(!Object.ReferenceEquals(a,b),label+" reused a captured pose object");
            Check(Pose(a)==expected,label+" repeated sample changed before mutation");
            a.Time=-4321;a.Grip=new MotionVector(91,92,93);a.Velocity=new MotionVector(81,82,83);a.Acceleration=new MotionVector(71,72,73);a.Rotation=MotionRotation.Identity;a.AngularVelocity=new MotionVector(61,62,63);a.AngularAcceleration=new MotionVector(51,52,53);a.Id=123;a.HumanSource=456;a.HumanGripWeight=a.HumanWristWeight=9;
            Check(Pose(b)==expected,label+" result mutation changed an earlier returned pose");
            Check(Pose(capture(t,j))==expected,label+" result mutation changed the frozen source");
            Check(Pose(graph.Sample(t,j))==expectedGraph,label+" result mutation changed graph playback");
        }
    }
    static int Main()
    {
        try
        {
            var chart=Chart();
            Owned(new HumanMotionGraph(null,chart,null,2),-2,18,"rest");
            Owned(new HumanMotionGraph(Model(false),chart,null,2),-2,18,"missing-phase hold");
            var learned=new HumanMotionGraph(Model(true),chart,null,2);
            Owned(learned,-2,18,"learned paths and joins");
            Check(learned.Choices>0,"fixture did not exercise recorded graph paths");
            Owned(learned,110,118,"settled ending");
            var e=Model(true).Examples[0];var tape=HumanTape.FromExample(e);
            var exactTape=new HumanTape(e.Curve,tape.Times,new[]{new HumanChartNote{Time=.3,Hand=0,Direction=1},new HumanChartNote{Time=.8,Hand=1,Direction=0}},"exact fixture",.99,e.Kinematics);
            var exactChart=exactTape.Notes;var exact=new HumanMotionGraph(Model(true),exactChart,new HumanRunHandle{Tape=exactTape},2);
            Owned(exact,-.3,2,"exact recording");Check(exact.ExactMap,"exact fixture was not adopted");
            var handle=new HumanRunHandle();var adopting=new HumanMotionGraph(Model(true),exactChart,handle,2);adopting.BeginFrame(0);adopting.Sample(0,0);handle.Tape=exactTape;adopting.BeginFrame(.45);
            Owned(adopting,-.1,1.3,"exact adoption transition");Check(adopting.ExactMap,"delayed exact fixture was not adopted");
            Console.WriteLine(checks+" fresh capture ownership assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
