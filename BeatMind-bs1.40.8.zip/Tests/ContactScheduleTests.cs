using System;
using System.Globalization;
using System.Threading;
using SaberMind;

class ContactScheduleTests
{
    static int checks;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static void Near(double a,double b,string message){Check(Math.Abs(a-b)<1e-10,message);}
    static string Signature()
    {return new PreparationSignature().Add("map-v26").Add(0).Add(-45).Add(90).Add(180).Add(1.1f).Add(76.8526).Add(true).Digest();}
    static int Main()
    {
        try
        {
            double[] raw={.035,-.035};double[] times={76.8526,76.91725};int[] hands={1,1};
            Check(times[1]+raw[1]<times[0]+raw[0],"fixture must reproduce live reversed up/down contacts");
            Check(times[1]+raw[1]-(times[0]+raw[0])<.012,"fixture must reproduce the old planner's incorrect merge");
            var hit=CutSchedule.Resolve(times,hands,raw);
            Check(hit[1]>hit[0]+.012,"separate arrows lost their ordered contact times");
            Check(hit[1]-hit[0]>=(times[1]-times[0])*.5-1e-10,"ordered pair left insufficient wrist transition time");
            Check(!CutSchedule.MergeContact(times[1],times[0],hit[1],hit[0]),"projected arrows merged");
            Check(!CutSchedule.MergeContact(times[1],times[0],times[1]+raw[1],times[0]+raw[0]),"negative learned gap merged");
            Near(raw[0],.035,"requested evidence changed");Near(raw[1],-.035,"requested evidence changed");
            var stack=CutSchedule.Resolve(new[]{1.0,1.0,1.0,1.1},new[]{0,0,0,0},new[]{-.035,0,.035,-.02});
            Near(stack[0],stack[1],"stack split");Near(stack[0],stack[2],"stack split");Near(stack[0],1,"stack median");
            Check(CutSchedule.MergeContact(1,1,stack[1],stack[0]),"true stack not combined");
            Check(!CutSchedule.MergeContact(1.005,1,1.005,1),"nearby normal arrows merged");
            Check(CutSchedule.MergeContact(1.005,1,1.005,1,true),"explicit continuous chain lost existing merge");
            Check(!CutSchedule.MergeContact(1.005,1,.999,1,true),"chain allowed reversed clock");
            var isolated=CutSchedule.Resolve(new[]{1.0,2.0},new[]{0,0},new[]{.035,-.035});
            Near(isolated[0],1.035,"safe timing changed");Near(isolated[1],1.965,"safe timing changed");
            var both=CutSchedule.Resolve(new[]{1.0,1.001},new[]{0,1},new[]{.035,-.035});
            Near(both[0],1.035,"other hand constrained safe timing");Near(both[1],.966,"other hand constrained safe timing");
            for(int size=2;size<=90;size++)
            {
                var ts=new double[size];var cs=new int[size];var os=new double[size];
                for(int i=0;i<size;i++){ts[i]=i*.005;cs[i]=i%2;os[i]=i%4<2 ? .035 : -.035;}
                var result=CutSchedule.Resolve(ts,cs,os);
                for(int i=2;i<size;i++)Check(result[i]>result[i-2],"dense same-hand order reversed");
            }
            var shuffled=CutSchedule.Resolve(new[]{2.0,1.0,1.0},new[]{0,0,0},new[]{-.02,.02,.035});
            Near(shuffled[1],shuffled[2],"unsorted stack split");Check(shuffled[0]>shuffled[1],"unsorted input reversed output identity");
            CultureInfo old=Thread.CurrentThread.CurrentCulture;
            try
            {
                Thread.CurrentThread.CurrentCulture=CultureInfo.GetCultureInfo("en-US");string a=Signature();
                Thread.CurrentThread.CurrentCulture=CultureInfo.GetCultureInfo("fr-FR");Check(a==Signature(),"preparation fingerprint changed with locale");
                Check(a.Length==64,"invalid digest");
                Check(new PreparationSignature().Add(45).Digest()!=new PreparationSignature().Add(46).Digest(),"integer rotation omitted");
                Check(new PreparationSignature().Add(1.1f).Digest()!=new PreparationSignature().Add(1.2f).Digest(),"floating value omitted");
                Check(new PreparationSignature().Add("a:b").Add("c").Digest()!=new PreparationSignature().Add("a").Add("b:c").Digest(),"signature delimiter collision");
            }
            finally{Thread.CurrentThread.CurrentCulture=old;}
            Console.WriteLine(checks+" learned contact ordering / stack / integer preparation fingerprint assertions passed");return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
