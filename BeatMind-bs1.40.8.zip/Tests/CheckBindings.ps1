param([string]$GamePath = 'C:\Users\comma\BSManager\BSInstances\1.40.8')
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
Add-Type -Path "$GamePath\Libs\Mono.Cecil.dll"
$main = [Mono.Cecil.ModuleDefinition]::ReadModule("$GamePath\Beat Saber_Data\Managed\Main.dll")
$modules = @($main)
foreach ($name in @('BGNetCore','Networking','PlatformUserModel','GameplayCore','DataModels')) {
    $modules += [Mono.Cecil.ModuleDefinition]::ReadModule("$GamePath\Beat Saber_Data\Managed\$name.dll")
}
$gameTypes = @($modules | ForEach-Object { $_.Types })
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
foreach ($directory in @("$GamePath\Libs","$GamePath\Plugins","$GamePath\Beat Saber_Data\Managed")) { $resolver.AddSearchDirectory($directory) }
$reader = New-Object Mono.Cecil.ReaderParameters
$reader.AssemblyResolver = $resolver
$plugin = [Mono.Cecil.ModuleDefinition]::ReadModule("$project\Plugins\BeatMindHumanBeta.dll",$reader)
$count = 0
foreach ($type in $plugin.Types) {
    $patch = $type.CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'HarmonyLib.HarmonyPatch' }
    if (!$patch) { continue }
    $typeName = $patch.ConstructorArguments[0].Value.FullName
    $methodName = if ($patch.ConstructorArguments[1].Type.FullName -eq 'HarmonyLib.MethodType') { '.ctor' } else { $patch.ConstructorArguments[1].Value }
    $targetType = $gameTypes | Where-Object { $_.FullName -eq $typeName }
    $methods = @($targetType.Methods | Where-Object { $_.Name -eq $methodName })
    if ($patch.ConstructorArguments.Count -gt 2) {
        $wanted = @($patch.ConstructorArguments[2].Value | ForEach-Object { $_.Value.FullName }) -join ','
        $methods = @($methods | Where-Object { (@($_.Parameters | ForEach-Object {$_.ParameterType.FullName}) -join ',') -eq $wanted })
    } elseif ($methodName -eq '.ctor') {
        # Match Harmony, which treats omitted constructor arguments as empty.
        $methods = @($methods | Where-Object { $_.Parameters.Count -eq 0 })
    }
    if ($methods.Count -ne 1) { throw "Patch target ambiguous/missing: $typeName.$methodName" }
    foreach ($hook in $type.Methods | Where-Object { $_.Name -in @('Prefix','Postfix') }) {
        foreach ($parameter in $hook.Parameters) {
            if ($parameter.Name -in @('__instance','__result')) { continue }
            if ($parameter.Name.StartsWith('___')) {
                $name = $parameter.Name.Substring(3)
                $field = $targetType.Fields | Where-Object { $_.Name -eq $name }
                if (!$field -or $field.FieldType.FullName -ne $parameter.ParameterType.FullName) { throw "Invalid injected field $name" }
            } elseif (!($methods[0].Parameters | Where-Object { $_.Name -eq $parameter.Name })) {
                throw "Missing parameter $($parameter.Name) in $typeName.$methodName"
            }
        }
    }
    $count++
}
if ($count -ne 32) { throw "Expected 32 game hooks, found $count" }
if (!(($main.Types | Where-Object FullName -eq 'AudioTimeSyncController').Methods | Where-Object Name -eq 'Pause')) { throw 'Pre-song audio hold is unavailable' }
if (!(($main.Types | Where-Object FullName -eq 'ResultsViewController').Methods | Where-Object Name -eq 'RestartButtonPressed')) { throw 'Results restart action is unavailable' }
$startPatch = $plugin.Types | Where-Object FullName -eq 'SaberMind.BeginPatch'
if (!($startPatch.Methods | Where-Object { $_.Name -eq 'Postfix' -and $_.Parameters[0].ParameterType.FullName -eq 'System.Collections.IEnumerator&' })) { throw 'Pre-song coroutine wrapper is missing' }
"PASS: $count game hook targets and named arguments"
$source = (Get-ChildItem "$project\Source" -Filter '*.cs' | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw }) -join "`n"
$reflected = [regex]::Matches($source, 'AccessTools\.Field\(typeof\((\w+)\),\s*"([^"]+)"\)')
foreach ($match in $reflected) {
    $type = $gameTypes | Where-Object { $_.Name -eq $match.Groups[1].Value }
    if (!($type.Fields | Where-Object { $_.Name -eq $match.Groups[2].Value })) { throw "Missing reflected game field: $($match.Value)" }
}
$player = $main.Types | Where-Object { $_.Name -eq 'PlayerTransforms' }
foreach ($name in @('_headWorldRot','_headPseudoLocalPos','_headPseudoLocalRot','_headPseudoLocalZOnlyPos','_leftHandPseudoLocalPos','_leftHandPseudoLocalRot','_rightHandPseudoLocalPos','_rightHandPseudoLocalRot')) {
    if (!($player.Fields | Where-Object { $_.Name -eq $name })) { throw "Missing pose field $name" }
}
"PASS: private note, player, saber and menu field bindings"
foreach ($menuName in @('Menu.bsml','MultiplayerMenu.bsml')) {
$hostName = if ($menuName -eq 'Menu.bsml') { 'SaberMind.PlayMenu' } else { 'SaberMind.MultiplayerOptions' }
$hostType = $plugin.Types | Where-Object FullName -eq $hostName
$values = @{}
$actions = @{}
$components = @{}
foreach ($member in @($hostType.Properties) + @($hostType.Methods) + @($hostType.Fields)) {
    foreach ($attribute in $member.CustomAttributes) {
        if ($attribute.AttributeType.FullName -eq 'BeatSaberMarkupLanguage.Attributes.UIValue') { $values[$attribute.ConstructorArguments[0].Value] = $true }
        if ($attribute.AttributeType.FullName -eq 'BeatSaberMarkupLanguage.Attributes.UIAction') { $actions[$attribute.ConstructorArguments[0].Value] = $true }
        if ($attribute.AttributeType.FullName -eq 'BeatSaberMarkupLanguage.Attributes.UIComponent') { $components[$attribute.ConstructorArguments[0].Value] = $true }
    }
}
[xml]$menu = Get-Content "$project\Source\$menuName" -Raw
foreach ($node in $menu.SelectNodes('//*')) {
    foreach ($attribute in $node.Attributes) {
        $binding = $null
        if ($attribute.Name -in @('value','choices')) { $binding = $attribute.Value }
        if ($attribute.Name -eq 'text' -and $attribute.Value.StartsWith('~')) { $binding = $attribute.Value.Substring(1) }
        if ($binding -and !$values.ContainsKey($binding)) { throw "Missing menu binding $binding on $hostName" }
        if ($attribute.Name -eq 'on-click' -and !$actions.ContainsKey($attribute.Value)) { throw "Missing menu action $($attribute.Value) on $hostName" }
    }
}
foreach ($id in $components.Keys) { if (!$menu.SelectSingleNode("//*[@id='$id']")) { throw "Missing component $id in $menuName" } }
if (!$actions.ContainsKey('#post-parse')) { throw "Missing layout callback on $hostName" }
}
$update = ($plugin.Types | Where-Object FullName -eq 'SaberMind.PlayMenu').Methods | Where-Object Name -eq 'Update'
$tabCalls = @($update.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.FullName -match 'GameplaySetup::AddTab' })
if ($tabCalls.Count -ne 2 -or $tabCalls[0].Previous.OpCode.Name -ne 'ldc.i4.1' -or $tabCalls[1].Previous.OpCode.Name -ne 'ldc.i4.2') { throw 'Learning and 1v1 must have separate Solo/Online registrations.' }
'PASS: separate Solo learning and Online 1v1 tabs; each menu has its own complete host bindings'
$manifest = Get-Content "$project\Source\manifest.json" -Raw | ConvertFrom-Json
if ($manifest.version -ne '1.0.0' -or $manifest.gameVersion -ne '1.40.8') { throw 'Manifest version mismatch' }
if ($plugin.Assembly.Name.Version.ToString() -ne '1.0.0.0') { throw 'Assembly version mismatch' }
foreach ($resource in @('SaberMind.Menu.bsml','SaberMind.MultiplayerMenu.bsml','SaberMind.manifest.json')) {
    if (!($plugin.Resources | Where-Object { $_.Name -eq $resource })) { throw "Missing embedded resource $resource" }
}
'PASS: menu XML, data bindings, manifest, assembly version and resources'
$signature=($plugin.Types | Where-Object FullName -eq 'SaberMind.PreSongTrainer').Methods | Where-Object Name -eq 'Signature'
$integerCalls=@($signature.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.FullName -match 'System.Int32::ToString' })
if($integerCalls.Count -ne 0){throw 'Preparation signature directly formats integers instead of using typed invariant serialization'}
$typedCalls=@($signature.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.FullName -match 'PreparationSignature::Add\(System.Int32\)' })
if($typedCalls.Count -lt 6){throw 'Preparation fingerprint no longer covers typed map rotation and wall integer inputs'}
foreach($class in @('SaberMind.MovementPlanner','SaberMind.SaberTrace')) {
    $hitCalls=@(($plugin.Types | Where-Object FullName -eq $class).Methods | ForEach-Object {if($_.HasBody){$_.Body.Instructions}} | Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.FullName -match 'TrackedNote::get_HitTime'})
    if($hitCalls.Count -lt 1){throw "Missing scheduled-contact clock in $class"}
}
'PASS: typed native preparation fingerprint and scheduled movement/trace contacts'
$plugin.Dispose(); foreach ($module in $modules) { $module.Dispose() }; $resolver.Dispose()
'Static checks only; these do not execute Unity or establish VR rendering/cut accuracy.'



