using System;
using System.IO;
using SaberMind;

internal static class PolicyTests
{
    private static int assertions;
    private static void Check(bool value, string label)
    {
        assertions++;
        if (!value) throw new Exception("FAILED: " + label);
        Console.WriteLine("PASS: " + label);
    }
    private static int Main(string[] args)
    {
        try { return Run(args); }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }
    private static int Run(string[] args)
    {
        NoteMemory note = new NoteMemory();
        Check(Policy.Choose(note, true) == 0, "new notes use the baseline stroke");
        Policy.Observe(note, 0, 0);
        Check(Policy.Choose(note, true) == 1, "a missed note explores a different stroke on replay");
        Check(Policy.Choose(note, false) == 0, "watch mode does not explore");
        Policy.Observe(note, 1, 1);
        Check(Policy.Choose(note, false) == 1, "watch mode picks the successful learned stroke");
        Policy.Observe(note, 1, .96);
        Check(Policy.Choose(note, true) == 1, "reliable clean strokes are retained during training");
        Policy.Observe(note, 1, 0);
        Check(Policy.Choose(note, true) == 2, "learning resumes after a previously strong stroke degrades");
        for (int i = 2; i < Policy.Variants.Length; i++) Policy.Observe(note, i, .1);
        Check(Policy.Choose(note, true) == 1, "exploration returns to the best known stroke after trying alternatives");
        NoteMemory corrupted = new NoteMemory { Trials = null, Rewards = new double[] { double.NaN } };
        Check(Policy.Choose(corrupted, true) == 0, "damaged policy arrays are normalized");
        bool rejected = false;
        try { Policy.Observe(note, 0, double.NaN); } catch (ArgumentOutOfRangeException) { rejected = true; }
        Check(rejected, "non-finite feedback is rejected");
        MemoryStore store = new MemoryStore(args[0]);
        LevelMemory first = store.Load("custom_level_example|Standard|Expert");
        first.Notes["12.5:1:1:0:0:0"] = note;
        first.Attempts = 3;
        store.Save(first);
        LevelMemory loaded = store.Load(first.Identity);
        Check(loaded.Attempts == 3 && Policy.Choose(loaded.Get("12.5:1:1:0:0:0"), false) == 1,
            "learning and best stroke survive disk round-trip");
        Check(store.Load("custom_level_example|Standard|Easy").Notes.Count == 0,
            "different difficulties have independent learning");
        Check(store.Load("custom_level_other|Standard|Expert").Notes.Count == 0,
            "different songs have independent learning");
        first.Attempts = 4;
        store.Save(first);
        Check(store.Load(first.Identity).Attempts == 4 && File.Exists(store.FileFor(first.Identity) + ".bak"),
            "atomic replacement retains a backup of earlier learning");
        File.WriteAllText(store.FileFor("bad-json"), "{broken");
        rejected = false;
        try { store.Load("bad-json"); } catch { rejected = true; }
        Check(rejected, "corrupt learning is not silently overwritten");
        Check(Path.GetDirectoryName(store.FileFor("../../outside")) == args[0],
            "map identifiers cannot escape the learning directory");
        Check(FlowPath.DenseArcScale(.1f)<.7f && FlowPath.DenseArcScale(.35f)==1,
            "dense contacts get compact arcs and isolated cuts keep full arcs");
        Check(ModelProfile.All.Length == 3 && ModelProfile.All[0].Dimensions == 0 && ModelProfile.All[2].Dimensions == 12,
            "three models expose genuinely different learned parameter sets");
        for (int model = 0; model < ModelProfile.All.Length; model++)
        {
            ModelProfile profile = ModelProfile.All[model];
            BehaviorMemory behavior = new BehaviorMemory();
            if (profile.Dimensions == 0)
            {
                Check(BehaviorOptimizer.Choose(behavior, profile, true, "stream").Axis == -1,
                    "Rapid performs no extra behavior optimization"); continue;
            }
            for (int trial = 0; trial < profile.Dimensions * 3; trial++)
            {
                BehaviorChoice choice = BehaviorOptimizer.Choose(behavior, profile, true, "stream");
                // Low values cut badly, baseline is acceptable, high values win.
                double reward = choice.Option == 2 ? 1 : (choice.Option == 1 ? .75 : .2);
                BehaviorOptimizer.Observe(behavior, profile, choice, reward, 1);
            }
            bool allExplored = true, allBest = true;
            BehaviorChoice learned = BehaviorOptimizer.Choose(behavior, profile, false, "stream");
            for (int d = 0; d < profile.Dimensions; d++)
            {
                for (int c = 0; c < 3; c++) allExplored &= behavior.Trials[d][c] == 1;
                allBest &= learned.Values[d] == 1;
            }
            Check(allExplored && allBest && learned.Axis == -1, profile.Name + " explores every active axis and reuses measured winners");
            int visits = behavior.Visits;
            BehaviorOptimizer.Choose(behavior, profile, false, "stream");
            Check(behavior.Visits == visits, profile.Name + " Play learned never explores or changes trial counts");
        }
        BehaviorMemory motionData = new BehaviorMemory(); ModelProfile human = ModelProfile.All[2];
        BehaviorChoice experiment = BehaviorOptimizer.Choose(motionData, human, true, "cross");
        BehaviorOptimizer.Observe(motionData, human, experiment, 0, 1);
        Check(motionData.Rewards[0][1] == 0, "perfect motion never rewards a missed cut");
        BehaviorMemory smooth = new BehaviorMemory(), rough = new BehaviorMemory();
        BehaviorChoice smoothChoice = BehaviorOptimizer.Choose(smooth, human, true, "stream");
        BehaviorChoice roughChoice = BehaviorOptimizer.Choose(rough, human, true, "stream");
        BehaviorOptimizer.Observe(smooth, human, smoothChoice, .95, 1);
        BehaviorOptimizer.Observe(rough, human, roughChoice, .95, 0);
        Check(smooth.Rewards[0][1] == rough.Rewards[0][1], "equally accurate cuts have equal rewards regardless of visible movement quality");
        ModelMemory independent = first.ForModel("Human Simulation");
        NoteMemory copied = independent.Note("legacy", note, true); int oldTrials = note.Trials[1];
        Policy.Observe(copied, 1, 1);
        Check(note.Trials[1] == oldTrials && copied.Trials[1] == oldTrials + 1, "new models retain legacy stroke evidence without overwriting it");
        independent.Behaviors["stream"] = smooth;
        Check(first.ForModel("Rapid").Timing.Count == 0 && first.ForModel("Rapid").Behaviors.Count == 0, "models have isolated learning");
        Check(independent.Prediction().Contains("Predicted Score: N/A"), "predictions remain N/A without measured completed runs");
        independent.Record(new MeasuredRun { Score = 850, RawScore = 850, Maximum = 1000, Completed = false });
        independent.Record(new MeasuredRun { Score = 1200, RawScore = 1200, Maximum = 1000, Completed = true });
        Check(independent.Runs.Count == 0, "incomplete and impossible scores cannot produce predictions");
        independent.Record(new MeasuredRun { Score = 720, RawScore = 900, Maximum = 1000, Good = 8, Missed = 1, Bad = 1, Completed = true });
        Check(independent.Runs[0].Accuracy == 90 && independent.Prediction().Contains("Predicted Score: 720")
            && independent.Prediction().Contains("Estimated BeatLeader PP: N/A") && independent.Prediction().Contains("Estimated ScoreSaber PP: N/A"),
            "accuracy uses measured raw score/max, score uses actual modifiers, and PP stays unavailable");
        independent.Pretrained["burst"] = new PretrainedPlan { X=.04f,Y=-.02f,Confidence=.64f,Validations=1,Variant=3 };
        store.Save(first); ModelMemory savedModel = store.Load(first.Identity).ForModel("Human Simulation");
        Check(savedModel.Runs.Count == 1 && savedModel.Behaviors["stream"].Visits == 1 && savedModel.Timing["legacy"].Trials[1] == copied.Trials[1],
            "model behavior, legacy timing clones and measured results all persist");
        Check(savedModel.Pretrained["burst"].Variant==3 && savedModel.Pretrained["burst"].Validations==1
            && savedModel.Timing["legacy"].Trials[1]==copied.Trials[1] && savedModel.Runs.Count==1,
            "offline plans persist separately without fabricating cut trials or measured runs");
        LevelMemory shared=store.Load("SaberMind|general-v1");
        BehaviorMemory sharedPattern=shared.ForModel("Natural").Behavior("blue:down:up:2:1:1",true);
        BehaviorChoice sharedChoice=BehaviorOptimizer.Choose(sharedPattern,ModelProfile.All[1],true,"pattern");
        BehaviorOptimizer.Observe(sharedPattern,ModelProfile.All[1],sharedChoice,.8,.9);
        store.Save(shared);
        Check(store.Load("SaberMind|general-v1").ForModel("Natural").Behaviors["blue:down:up:2:1:1"].Visits==1
            && store.Load(first.Identity).ForModel("Human Simulation").Behaviors["stream"].Visits==1,
            "measured general pattern skills persist independently from map-specific learning");
        BodySettings invalidBody = new BodySettings { Height = float.NaN, UpperArm = 10, Forearm = -1, Model = "missing",ReadinessThreshold=9 };
        invalidBody.Normalize();
        Check(invalidBody.Height == 1.72f && invalidBody.UpperArm == .40f && invalidBody.Forearm == .20f && invalidBody.Model == "Natural"
            && invalidBody.ReadinessThreshold==.95f,
            "non-finite and impossible body proportions are bounded");
        double reach = JointGeometry.Distance(.31, .36, 168), folded = JointGeometry.Distance(.31,.36,25);
        Check(reach < .67 && reach > .66 && folded > .05 && folded < .16,
            "arm reach respects both bent and extended elbow limits");
        Check(RotationDynamics.ContinuousReferenceStep(3,1f/120,540)
            && !RotationDynamics.ContinuousReferenceStep(50,1f/120,540),
            "arm target impulses are not differentiated into impossible feed-forward");
        MotionAxis physical = new MotionAxis();
        bool bounded = true, finite = true;
        double peakJerk = 0;
        for (int i=0;i<6000;i++)
        {
            double oldAcceleration=physical.Acceleration, oldVelocity=physical.Velocity;
            double goal=i<2000 ? 100 : (i<4000 ? -100 : 0);
            MotionContinuity.Step(ref physical,goal,0,.001,40,800,8000,180000);
            peakJerk=Math.Max(peakJerk,Math.Abs(physical.Acceleration-oldAcceleration)/.001);
            bounded &= Math.Abs(physical.Acceleration)<=8000.0001 && peakJerk<=180000.001;
            bounded &= Math.Abs(physical.Velocity-oldVelocity)<=8.0001;
            finite &= !double.IsNaN(physical.Position) && !double.IsInfinity(physical.Position);
        }
        Check(bounded && finite && Math.Abs(physical.Position)<.01,
            "physical motor respects acceleration and jerk limits through target reversals and settles");
        physical=new MotionAxis { Velocity=600,Acceleration=2000 };
        MotionContinuity.Step(ref physical,-100,-600,.003,40,800,8000,180000);
        Check(physical.Velocity>600 && physical.Acceleration>0,
            "a reversal retains outgoing acceleration until bounded jerk can reverse it");
        bool boundedBend=true;
        for (int i=-1000;i<=1000;i++)
        {
            double bend=MotionContinuity.Bend(i*.05);
            boundedBend &= bend>=12 && bend<=156 && !double.IsNaN(bend);
        }
        Check(boundedBend && Math.Abs(MotionContinuity.Bend(MotionContinuity.BendCoordinate(80))-80)<.00001,
            "elbow flexion stays bounded without a discontinuous joint-angle clamp");
        Console.WriteLine(assertions + " assertions passed.");
        return 0;
    }
}
