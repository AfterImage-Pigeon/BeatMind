using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using SaberMind;
using UnityEngine;
class NativeRuleRegression
{
    static int checks;
    static string game;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main(string[] args)
    {
        game=args[0];
        AppDomain.CurrentDomain.AssemblyResolve+=delegate(object sender,ResolveEventArgs e)
        {
            string name=new AssemblyName(e.Name).Name+".dll";
            foreach(string dir in new[]{Path.Combine(game,"Beat Saber_Data","Managed"),Path.Combine(game,"Libs")})
            {string path=Path.Combine(dir,name);if(File.Exists(path))return Assembly.LoadFrom(path);}
            return null;
        };
        try{return Run();}catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static int Run()
    {
        var geometry=new PhraseGeometry{Top=new MotionVector(0,0,1)};
        foreach(double speed in new[]{.5,1,2,4,6})
        {
            Func<double,PhraseState> straight=delegate(double t){return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector((t-.6)*speed,0,0))};};
            var arc=BladeSwingScoring.Measure(straight,geometry,.6,120);
            double native=Before(straight,geometry,.6,1.0/120);
            double beforeTolerance=speed*(1.0/120)*180/Math.PI/100+.0005;
            Check(Math.Abs(Math.Min(1,arc.BeforeDegrees/100)-native)<beforeTolerance,"pure blade scorer disagrees with installed native before rating at speed "+speed+" pure="+arc.BeforeDegrees/100+" native="+native);
            var note=new PhraseNote{Time=.6,Center=new MotionVector(),Forward=new MotionVector(0,0,1),Direction=new MotionVector(0,-1,0)};
            var rating=NativeSwingAngleOracle.Evaluate(straight,geometry,note,.575,1.0/120,0);
            Check(rating.NotePlaneWasCut,"native scoring plane was never crossed");
            double afterTolerance=speed*(1.0/120)*180/Math.PI/60+.0005;
            Check(Math.Abs(Math.Min(1,arc.AfterDegrees/60)-rating.After)<afterTolerance,"pure blade scorer disagrees with installed native after rating at speed "+speed+" pure="+arc.AfterDegrees/60+" native="+rating.After);
        }
        Func<double,PhraseState> roll=delegate(double t){return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector(0,0,t*20))};};
        Check(Before(roll,geometry,.6,1.0/120)<1e-6,"installed native game counted blade roll");
        Func<double,PhraseState> reversal=delegate(double t){return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector((t<=.58 ? t-.58 : .58-t)*6,0,0))};};
        var reverse=BladeSwingScoring.Measure(reversal,geometry,.6,120);
        double nativeReverse=Before(reversal,geometry,.6,1.0/120);
        Check(Math.Abs(Math.Min(1,reverse.BeforeDegrees/100)-nativeReverse)<.001,"pure native direction reset disagrees with installed game");
        Check(nativeReverse<.10,"installed native before count crossed a plane reversal");
        Console.WriteLine(checks+" installed-native formula / blade-roll / plane-reversal comparisons passed");return 0;
    }
    static double Before(Func<double,PhraseState> sample,PhraseGeometry g,double contact,double step)
    {
        var data=new SaberMovementData();
        for(int i=0;i<=64;i++)
        {
            double t=contact-(64-i)*step;var s=sample(t);
            var top=s.Grip+s.Rotation.Rotate(g.Top-g.Grip);var bottom=s.Grip+s.Rotation.Rotate(g.Bottom-g.Grip);
            data.AddNewData(new Vector3((float)top.X,(float)top.Y,(float)top.Z),new Vector3((float)bottom.X,(float)bottom.Y,(float)bottom.Z),(float)t);
        }
        return data.ComputeSwingRating();
    }
}
