param(
    [string]$GamePath='C:\Users\comma\BSManager\BSInstances\1.40.8 (3)',
    [string]$WorkDirectory
)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$workspace=Split-Path -Parent (Split-Path -Parent $project)
if(-not $WorkDirectory){$WorkDirectory=Join-Path $workspace ('work\learning-cap-v17-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss'))}
$workPath=[IO.Path]::GetFullPath($WorkDirectory)
$workspacePrefix=[IO.Path]::GetFullPath($workspace).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
if(-not $workPath.StartsWith($workspacePrefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Offline rebuild output must stay inside this workspace.'}
$gamePrefix=[IO.Path]::GetFullPath($GamePath).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
if($workPath.StartsWith($gamePrefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Offline rebuild output must be outside the game directory.'}
if(Get-Process -Name 'Beat Saber' -ErrorAction SilentlyContinue){throw 'Close Beat Saber before preparing a consistent replay/cache snapshot.'}
if(Test-Path -LiteralPath $workPath){throw 'Choose a fresh WorkDirectory so previous rebuild evidence is preserved.'}
New-Item -ItemType Directory -Path $workPath | Out-Null
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$json=Join-Path $GamePath 'Libs\Newtonsoft.Json.dll'
Copy-Item -LiteralPath $json -Destination $workPath
$sourceNames=@('Learning.cs','Models.cs','TrajectoryMath.cs','BladeSwingScoring.cs','SwingContinuation.cs','HumanMotion.cs','HumanMotionTraining.cs','HumanReplay.cs','HumanMotionGraph.cs','HumanEventAlignment.cs','ReplayMotor.cs','ReplayPlanJob.cs','ConstrainedReplayTrajectory.cs','ReachTransition.cs','ReplayRegistration.cs','ReplayFileAccess.cs','ContactGeometry.cs','ReplayWristClock.cs','SteadySwingEnvelope.cs','WristMotionLimits.cs','BoundedWristBridge.cs','ContinuousWristBurst.cs','AutomaticReplays.cs')
$sources=@($sourceNames | ForEach-Object {Join-Path "$project\Source" $_})
$exe=Join-Path $workPath 'RebuildLearningCap.exe'
& $compiler /nologo /optimize+ /target:exe "/out:$exe" "/reference:$json" @sources "$PSScriptRoot\RebuildLearningCap.cs"
if($LASTEXITCODE -ne 0){throw 'Offline learning-cap rebuild compilation failed.'}
$stage=Join-Path $workPath 'HumanMotionCache'
& $exe $GamePath $stage | Tee-Object -FilePath (Join-Path $workPath 'rebuild.log')
if($LASTEXITCODE -ne 0){throw 'Offline learning-cap migration failed; see rebuild.log.'}
Write-Output "Prepared capped cache: $stage"
Write-Output "Migration evidence: $stage\LearningCapMigrationReport.json"
