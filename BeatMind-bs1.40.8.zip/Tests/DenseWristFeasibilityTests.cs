using System;
using System.Collections.Generic;
using SaberMind;

class DenseWristFeasibilityTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseGeometry Geometry()
    {return new PhraseGeometry{Top=new MotionVector(0,0,1),Forward=new MotionVector(0,0,1),Shoulder=new MotionVector(-.25,1.58,0),Reach=.69,MinimumReach=.12,Color=0,ControlledWrist=true,StableFastGrip=true,SwingSpeedScale=1.5};}
    static void DotDirection()
    {
        var g=Geometry();var human=new PhraseState{Time=.5,Grip=new MotionVector(-.25,1.25,.20),Rotation=MotionRotation.Exp(new MotionVector(-Math.PI/2,0,0)),AngularVelocity=new MotionVector(0,0,20),HumanWristWeight=1,HumanGripWeight=1};
        var note=new PhraseNote{Id=1,Time=.5,AnyDirection=true,ScoringType=1,Center=human.Grip+human.Rotation.Rotate(g.Top)*.70,Direction=new MotionVector(0,1,0),Forward=g.Forward,Spacing=.2,LocalNps=8};
        int tested;var fitted=ReplayMotor.FitContact(human,note,g,null,9,out tested);
        Check(MotionRotation.Log(fitted.Rotation*human.Rotation.Inverse).Length<1e-7,"dot fitting forced an unnecessary arrow orientation");
        Check((fitted.AngularVelocity-human.AngularVelocity).Length<1e-7,"valid measured dot wrist motion was replaced by the preferred arrow");
        Func<double,PhraseState> teacher=delegate(double t){var s=human.Copy();s.Time=t;return s;};var seed=teacher(0);
        var plan=ReplayMotor.Build(seed,new List<PhraseNote>{note},g,teacher,9,1.1);
        var contact=plan.SampleWrist(note.Time);
        Check(MotionVector.Dot(contact.AngularVelocity.Unit,human.AngularVelocity.Unit)>.999999,"dot swing preparation replaced the actual human swing axis");
        Check(CutSafety.BladeDistance(plan.Sample(note.Time),note.Center,g)<.025,"dot fix lost reachable contact");
        for(int i=0;i<=600;i++)
        {double t=i/600.0;var s=plan.SampleWrist(t);Check(WristMotionLimits.Contains(s.Rotation,g),"dot swing exceeded configured blade range");Check(s.AngularVelocity.Length<=180.000001,"dot curve requires impossible recovery speed");}
    }
    static void ShortTransition()
    {
        // Anonymized 14 ms arrow/dot transition from the reproduced failure.
        var g=Geometry();var previous=new PhraseState{Time=25.270666122436523,Grip=new MotionVector(-.7282681411606027,1.1046138538784032,.132865358092006),Rotation=new MotionRotation(-.6969336258643258,-.2876991816553784,-.13809583591748537,.6422166629079945),TargetDirection=new MotionVector(.7071067811865475,-.7071067811865475,0)};
        var human=new PhraseState{Time=25.284666061401367,Grip=previous.Grip,Rotation=new MotionRotation(-.11973747799253318,.4444160725952578,-.6650366794780374,.5881186153590283),AngularVelocity=new MotionVector(126.76290433811488,69.10803758445532,-107.49532652627948),HumanWristWeight=1,HumanGripWeight=1};
        var note=new PhraseNote{Id=2,Time=human.Time,AnyDirection=true,ScoringType=1,Center=new MotionVector(-.3,.85,0),Direction=new MotionVector(.44988677445860237,-.8930856006941521,0),Forward=g.Forward,Spacing=.035,LocalNps=28};
        var origin=previous.Copy();origin.AngularVelocity=origin.AngularAcceleration=new MotionVector();var wanted=human.Copy();wanted.AngularVelocity=wanted.AngularAcceleration=new MotionVector();
        var oldRoute=new BoundedWristBridge(origin,wanted,g);double oldPeak=0;for(int i=0;i<=64;i++)oldPeak=Math.Max(oldPeak,oldRoute.Sample(origin.Time+(wanted.Time-origin.Time)*i/64).AngularVelocity.Length);
        Check(oldPeak>200,"fixture no longer reproduces the incompatible target transition");
        int tested;var fitted=ReplayMotor.FitContact(human,note,g,previous,9,out tested);var goal=fitted.Copy();goal.AngularVelocity=goal.AngularAcceleration=new MotionVector();
        var route=new BoundedWristBridge(origin,goal,g);Check(route.Safe,"fallback goal has no bounded wrist route");
        for(int i=0;i<=256;i++)Check(route.Sample(origin.Time+(goal.Time-origin.Time)*i/256).AngularVelocity.Length<=180.000001,"contact fallback still requires an impossible short recovery");
        if(!CutSafety.ContactFits(ConstrainedReplayTrajectory.Project(fitted,g),note.Center,g,.025))Check(fitted.LimitedContact,"infeasible contact was falsely declared valid");
    }
    static void LimitHandoff()
    {
        var g=Geometry();var envelope=new SteadySwingEnvelope(2.88,3,3.12,20);var axis=new MotionVector(-1,0,0);
        var contact=MotionRotation.Exp(axis*(100*Math.PI/180-20*.12*SteadySwingEnvelope.TravelFraction));
        Func<double,PhraseState> outgoing=delegate(double t){double angle,rate,acceleration;envelope.Sample(t,out angle,out rate,out acceleration);return new PhraseState{Time=t,Rotation=MotionRotation.Exp(axis*angle)*contact,AngularVelocity=axis*rate,AngularAcceleration=axis*acceleration};};
        var a=outgoing(3.118);var b=new PhraseState{Time=3.42,Rotation=MotionRotation.Exp(axis*(60*Math.PI/180))};
        var curve=ConstrainedReplayTrajectory.Handoff(a,b,g,outgoing);var begin=curve(a.Time);var finish=curve(b.Time);
        Check(MotionRotation.Log(begin.Rotation*a.Rotation.Inverse).Length<1e-8 && (begin.AngularVelocity-a.AngularVelocity).Length<1e-7 && (begin.AngularAcceleration-a.AngularAcceleration).Length<1e-5,"near-limit handoff changed the outgoing wrist jet");
        Check(MotionRotation.Log(finish.Rotation*b.Rotation.Inverse).Length<1e-8 && finish.AngularVelocity.Length<1e-7,"near-limit handoff lost the incoming endpoint");
        for(int i=0;i<=1200;i++)
        {
            double t=a.Time+(b.Time-a.Time)*i/1200;var s=curve(t);Check(WristMotionLimits.Contains(s.Rotation,g),"frozen near-limit handoff escaped range");
            if(i>0 && i<1200){const double h=1e-7;var before=curve(t-h);var after=curve(t+h);var velocity=MotionRotation.Log(after.Rotation*before.Rotation.Inverse)/(2*h);Check((velocity-s.AngularVelocity).Length<.002,"handoff introduced a rotational snap or inaccurate derivative");}
        }
    }
    static int Main()
    {try{DotDirection();ShortTransition();LimitHandoff();Console.WriteLine(checks+" dot direction / dense wrist feasibility assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
