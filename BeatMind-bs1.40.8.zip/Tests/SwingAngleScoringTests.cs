using System;
using System.Collections.Generic;
using SaberMind;

class SwingAngleScoringTests
{
    static int checks;
    static void Check(bool condition,string message)
    {checks++;if(!condition)throw new Exception(message);}
    static string Context(int hand,int arrow,double spacing,int id)
    {return " hand="+hand+" arrow="+arrow+" spacing="+spacing+" id="+id;}
    static PhraseGeometry Geometry(int hand)
    {return new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};}
    static Func<double,PhraseState> StationaryHuman(int hand)
    {
        return delegate(double time){return new PhraseState{Time=time,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118,.2794),
            Rotation=MotionRotation.Exp(new MotionVector(.55,0,0)),HumanSource=12,HumanGripWeight=1,HumanWristWeight=1};};
    }
    static PhraseNote Note(int hand,int id,double time,int arrow,double spacing)
    {return new PhraseNote{Id=id,Time=time,ScoringType=1,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(arrow),Forward=new MotionVector(0,0,1),Spacing=spacing,LocalNps=1/spacing};}
    static double Travel(MotionPhrase path,PhraseGeometry geometry,double start,double end)
    {
        const int samples=180;double angle=0;var old=path.Sample(start).Rotation.Rotate(geometry.Top-geometry.Bottom).Unit;
        for(int i=1;i<=samples;i++)
        {var current=path.Sample(start+(end-start)*i/samples).Rotation.Rotate(geometry.Top-geometry.Bottom).Unit;
            angle+=Math.Acos(MotionPhrase.Clamp(MotionVector.Dot(old,current),-1,1))*180/Math.PI;old=current;}
        return angle;
    }
    static double SignedTurn(MotionPhrase path,double start,double end,MotionVector axis)
    {
        const int samples=300;double angle=0;var old=path.Sample(start).Rotation;
        for(int i=1;i<=samples;i++)
        {var current=path.Sample(start+(end-start)*i/samples).Rotation;angle+=MotionVector.Dot(MotionRotation.Log(current*old.Inverse),axis);old=current;}
        return angle;
    }
    static void Pattern(int hand,int arrow,double spacing,bool alternating)
    {
        var opposite=new[]{1,0,3,2,7,6,5,4};var teacher=StationaryHuman(hand);var geometry=Geometry(hand);var notes=new List<PhraseNote>();
        for(int i=0;i<3;i++)notes.Add(Note(hand,i,.5+i*spacing,alternating && i%2==1 ? opposite[arrow] : arrow,spacing));
        var path=ReplayMotor.Build(teacher(0),notes,geometry,teacher,9,3.4);
        foreach(var note in notes)
        {
            string context=Context(hand,arrow,spacing,note.Id)+(alternating ? " alternating" : " repeated");var contact=path.Contact(note.Id);
            Check(contact!=null && HumanMotionModel.Finite(contact.SwingStart) && HumanMotionModel.Finite(contact.SwingEnd),"a weighted static source was mistaken for a scored swing"+context);
            var arc=BladeSwingScoring.Measure(path.Sample,geometry,note.Time);
            Check(arc.BeforeFull && arc.AfterFull,"final blade path did not earn required 100/60 angle ratings: "+arc.BeforeDegrees+"/"+arc.AfterDegrees+context);
            double before=Travel(path,geometry,contact.SwingStart,note.Time),after=Travel(path,geometry,note.Time,contact.SwingEnd);
            Check(before>=114.9 && before<=117.1,"repair deleted or inflated its 115-117 degree preparation: "+before+context);
            Check(after>=74.9 && after<=75.1,"repair deleted or inflated its 75 degree follow-through: "+after+context);
            Check(contact.SwingPeak==note.Time,"repair peaked before the constrained contact"+context);
            Check(contact.ScoringReleaseEnd>=contact.SwingEnd-1e-10,"contact handoff failed to reserve complete release"+context);
            var hit=path.Sample(note.Time);
            Check(CutSafety.BladeDistance(hit,note.Center,geometry)<.025,"larger scored swing lost an otherwise reachable contact"+context);
            Check(MotionVector.Dot(hit.Velocity+MotionVector.Cross(hit.AngularVelocity,hit.Rotation.Rotate(geometry.Top)),note.Direction)>1.5,"scored repair moved against the arrow or lost cut speed"+context);
            double prior=0;
            for(int i=0;i<=60;i++)
            {
                var state=path.Sample(contact.SwingStart+(note.Time-contact.SwingStart)*i/60);
                Check(state.AngularVelocity.Length+1e-7>=prior,"pre-contact speed stopped increasing"+context);
                Check(MotionVector.Dot(state.AngularAcceleration,hit.AngularVelocity)>=-1e-6,"pre-contact acceleration reversed"+context);prior=state.AngularVelocity.Length;
            }
            prior=hit.AngularVelocity.Length;
            for(int i=0;i<=60;i++)
            {
                var state=path.Sample(note.Time+(contact.SwingEnd-note.Time)*i/60);
                Check(state.AngularVelocity.Length<=prior+1e-7,"release accelerated instead of slowing"+context);
                Check(MotionVector.Dot(state.AngularAcceleration,hit.AngularVelocity)<=1e-6,"release deceleration reversed"+context);prior=state.AngularVelocity.Length;
            }
            Check(prior<1e-7,"release ended with a nonzero wrist velocity"+context);
        }
        if(!alternating)
            for(int i=0;i+1<notes.Count;i++)
            {
                var a=path.Contact(notes[i].Id);var b=path.Contact(notes[i+1].Id);var axis=(a.AngularVelocity.Unit+b.AngularVelocity.Unit).Unit;
                Check(MotionVector.Dot(a.AngularVelocity.Unit,b.AngularVelocity.Unit)>.95,"repeat fixture did not retain a consistent swing plane");
                double recovery=SignedTurn(path,a.SwingEnd,b.SwingStart,axis);
                Check(recovery<-Math.PI,"repeated >180 degree overswing recovered by completing an unwanted forward 360: "+recovery+Context(hand,arrow,spacing,i));
                double cycle=SignedTurn(path,a.Time,b.Time,axis);
                double expected=MotionVector.Dot(MotionRotation.Log(b.Rotation*a.Rotation.Inverse),axis);
                Check(Math.Abs(cycle-expected)<.005,"one repeated swing added a whole extra turn: "+cycle+" expected "+expected+Context(hand,arrow,spacing,i));
            }
    }
    static void ScoringRules()
    {
        var geometry=new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1)};
        var roll=BladeSwingScoring.Measure(delegate(double t){return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector(0,0,30*t))};},geometry,1);
        Check(roll.BeforeDegrees<.005 && roll.AfterDegrees<.005,"axial saber roll counted as blade swing angle");
        var slide=BladeSwingScoring.Measure(delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(0,20*t,0)};},geometry,1);
        Check(slide.BeforeDegrees<.005 && slide.AfterDegrees<.005,"fast translating saber counted as scored angular travel");
        var known=BladeSwingScoring.Measure(delegate(double t){return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector(6*t,0,0))};},geometry,1);
        Check(known.BeforeFull && known.AfterFull,"a real fixed-pivot blade arc did not earn swing-angle ratings");
        Check(BladeSwingScoring.NormalWeight(75)==1 && BladeSwingScoring.NormalWeight(90)==0 && Math.Abs(BladeSwingScoring.NormalWeight(82.5)-.5)<1e-12,"native 75-90 degree plane weighting changed");
        var before=new[]{false,true,true,false,true,false,false,false,false};
        var after=new[]{false,true,false,true,false,false,false,false,false};
        for(int type=0;type<=8;type++)
        {Check(BladeSwingScoring.RequiresBefore(type)==before[type],"wrong native before-angle scoring type "+type);Check(BladeSwingScoring.RequiresAfter(type)==after[type],"wrong native after-angle scoring type "+type);}
        Check(BladeSwingScoring.RequiresBefore(3-2) && BladeSwingScoring.RequiresAfter(3-2),"ordinary BSOR prefix 3 must decode to native Normal 1");
    }
    static void PreserveMeasuredHuman(int hand)
    {
        var geometry=new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.47,.025),Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1),Color=hand};
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(hand==0 ? -.3 : .3,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(2*Math.Sin(8*t),0,0)),AngularVelocity=new MotionVector(16*Math.Cos(8*t),0,0),AngularAcceleration=new MotionVector(-128*Math.Sin(8*t),0,0),HumanSource=3,HumanGripWeight=1,HumanWristWeight=1};};
        var notes=new List<PhraseNote>();
        foreach(double time in new[]{.8,1.2})
        {
            var arc=BladeSwingScoring.Measure(teacher,geometry,time);Check(arc.BeforeFull && arc.AfterFull,"qualified human fixture lacks full native scoring arcs");
            var s=teacher(time);var direction=MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(geometry.Top));direction.Z=0;
            notes.Add(new PhraseNote{Id=notes.Count,Time=time,Center=s.Grip+s.Rotation.Rotate(new MotionVector(0,0,.9)),Direction=direction.Unit,Forward=geometry.Forward,Spacing=.4,LocalNps=4});
        }
        var path=ReplayMotor.Build(teacher(0),notes,geometry,teacher,9,1.6);
        foreach(var note in notes)
        {
            Check(double.IsNaN(path.Contact(note.Id).SwingStart),"qualified human swing was replaced by a generated envelope");
            var score=BladeSwingScoring.Measure(teacher,geometry,note.Time);
            for(double t=score.Start;t<=score.End;t+=.001)
            {var actual=path.Sample(t);var source=teacher(t);Check(MotionRotation.Log(actual.Rotation*source.Rotation.Inverse).Length<1e-7,"valid human scored arc was rewritten");Check((actual.AngularVelocity-source.AngularVelocity).Length<1e-6,"valid human speed waveform was rewritten");Check((actual.Grip-source.Grip).Length<1e-7,"valid human grip arc was rewritten");}
        }
    }
    static void InfinitesimalRotation()
    {
        var axis=new MotionVector(.2,-.7,.5).Unit;
        foreach(double size in new[]{1e-14,1e-12,1e-10,1e-9,1e-8})
        {var vector=axis*size;var rotation=MotionRotation.Exp(vector);var decoded=MotionRotation.Log(rotation);Check(decoded.Length>size*.999999,"SO(3) exp/log discarded a real infinitesimal turn");Check((decoded-vector).Length<size*1e-9,"infinitesimal SO(3) round trip lost rotation");Check((MotionRotation.Log(rotation*-1)-vector).Length<size*1e-9,"quaternion sign changed infinitesimal motion");}
        var tiny=new MotionVector(8e-10,0,0);Check(MotionRotation.Log(MotionRotation.Exp(tiny)).X>7.999999e-10,"visible finite-difference rotation has a dead zone");
    }
    static double Smooth(double u){return u*u*u*(10+u*(-15+6*u));}
    static double Slope(double u){return 30*u*u*(1-u)*(1-u);}
    static double Rise(double u){return u*u*u*u*(2.5+u*(-3+u));}
    static void MixedMeasuredAndGenerated(int hand)
    {
        const double first=.8,second=1.085,speed=26,up=.17,down=.095;
        var geometry=Geometry(hand);
        Func<double,PhraseState> teacher=delegate(double time)
        {
            double u,angle,rate,acceleration;
            if(time<first)
            {u=MotionPhrase.Clamp((time-(first-up))/up,0,1);angle=.55+speed*up*(Rise(u)-.5);rate=speed*Smooth(u);acceleration=speed*Slope(u)/up;}
            else
            {u=MotionPhrase.Clamp((time-first)/down,0,1);angle=.55+speed*down*(u-Rise(u));rate=speed*(1-Smooth(u));acceleration=-speed*Slope(u)/down;}
            return new PhraseState{Time=time,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),
                AngularVelocity=new MotionVector(rate,0,0),AngularAcceleration=new MotionVector(acceleration,0,0),HumanSource=14,HumanGripWeight=1,HumanWristWeight=1};
        };
        var firstScore=BladeSwingScoring.Measure(teacher,geometry,first);
        var secondScore=BladeSwingScoring.Measure(teacher,geometry,second);
        Check(firstScore.BeforeFull && firstScore.AfterFull,"mixed boundary fixture's first demonstration lacks a full-scored swing");
        Check(!secondScore.BeforeFull || !secondScore.AfterFull,"mixed boundary fixture's second demonstration already contains a full-scored swing");
        var initial=teacher(first);var center=initial.Grip+initial.Rotation.Rotate(geometry.Top*.82);
        var notes=new[]{new PhraseNote{Id=0,Time=first,Center=center,Direction=HumanContext.Direction(1),Forward=geometry.Forward,Spacing=.285,LocalNps=1/.285},
            new PhraseNote{Id=1,Time=second,Center=center,Direction=HumanContext.Direction(0),Forward=geometry.Forward,Spacing=.285,LocalNps=1/.285}};
        var path=ReplayMotor.Build(teacher(.3),notes,geometry,teacher,9,1.6);
        var measured=path.Contact(0);var repaired=path.Contact(1);
        Check(double.IsNaN(measured.SwingStart),"mixed boundary replaced an already qualified human stroke");
        Check(HumanMotionModel.Finite(repaired.SwingStart),"mixed boundary did not repair the following static source");
        Check(second-repaired.SwingStart>.16 && second-repaired.SwingStart<.23,"mixed fixture no longer exercises the long generated preparation");
        Check(repaired.SwingStart<(first+second)*.5-.002,"mixed fixture does not reproduce preparation before the old midpoint turnaround");
        bool hasPreparation=false;
        foreach(var knot in path.Knots)if(Math.Abs(knot.Time-repaired.SwingStart)<1e-12)hasPreparation=true;
        Check(hasPreparation,"legacy midpoint turnaround silently rejected the generated preparation knot");
        const double epsilon=1e-8;
        var before=path.Sample(repaired.SwingStart-epsilon);var at=path.Sample(repaired.SwingStart);var after=path.Sample(repaired.SwingStart+epsilon);
        Check(MotionRotation.Log(after.Rotation*before.Rotation.Inverse).Length<1e-7,"mixed source-to-generated preparation snapped in orientation");
        Check((after.AngularVelocity-before.AngularVelocity).Length<1e-5,"mixed preparation changed angular velocity instantly");
        Check((after.AngularAcceleration-before.AngularAcceleration).Length<.01,"mixed preparation changed angular acceleration instantly");
        Check((MotionRotation.Log(after.Rotation*before.Rotation.Inverse)/(2*epsilon)-at.AngularVelocity).Length<1e-5,"mixed preparation's visible rotation disagrees with its angular velocity");
        foreach(var note in notes)
        {Check(CutSafety.BladeDistance(path.Sample(note.Time),note.Center,geometry)<.025,"mixed boundary lost a reachable constrained contact");Check(!path.Contact(note.Id).LimitedContact,"mixed boundary discarded a reachable constrained contact");}
        for(double time=first-.06;time<=repaired.SwingEnd+.04;time+=.0001)
            Check(path.Sample(time).AngularVelocity.Length<=125.001,"mixed boundary introduced an impossible wrist join");
    }
    static int Main()
    {
        try
        {ScoringRules();InfinitesimalRotation();foreach(int hand in new[]{0,1}){PreserveMeasuredHuman(hand);MixedMeasuredAndGenerated(hand);foreach(int arrow in new[]{0,1,2,3,4,5,6,7})foreach(double spacing in new[]{.30,.125}){Pattern(hand,arrow,spacing,false);Pattern(hand,arrow,spacing,true);}}Console.WriteLine(checks+" blade scoring / full arcs / replay preservation / no extra rotation assertions passed.");return 0;}
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
