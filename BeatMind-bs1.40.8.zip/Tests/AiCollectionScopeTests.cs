using System;
// Test the mode lease's ownership and lifecycle without starting Unity or
// invoking its native collection bindings. The mod build checks the real API.
namespace UnityEngine.Scripting
{
    public static class GarbageCollector
    {
        public enum Mode{Disabled,Enabled,Manual}public static Mode GCMode{get;set;}
        public static bool isIncremental;
        public static int Calls,Remaining;public static ulong Budget;
        public static bool CollectIncremental(ulong nanoseconds){Calls++;Budget=nanoseconds;return Remaining-- >0;}
    }
}
namespace SaberMind
{
    internal static class Plugin
    {internal sealed class Logger{internal void Info(string message){}}internal static readonly Logger Log=new Logger();}
}
class AiCollectionScopeTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main(){try{Run();Console.WriteLine(checks+" AI collection ownership assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static void Run()
    {
        var disabled=UnityEngine.Scripting.GarbageCollector.Mode.Disabled;var enabled=UnityEngine.Scripting.GarbageCollector.Mode.Enabled;var manual=UnityEngine.Scripting.GarbageCollector.Mode.Manual;
        UnityEngine.Scripting.GarbageCollector.GCMode=disabled;var scope=new SaberMind.AiCollectionScope();Check(UnityEngine.Scripting.GarbageCollector.GCMode==enabled,"AI allocations remained under disabled gameplay collection");scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"stop did not restore the original gameplay policy");UnityEngine.Scripting.GarbageCollector.GCMode=manual;scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual,"repeated disposal overwrote a later policy");
        UnityEngine.Scripting.GarbageCollector.GCMode=enabled;scope=new SaberMind.AiCollectionScope();UnityEngine.Scripting.GarbageCollector.GCMode=disabled;scope.EnsureEnabled();Check(UnityEngine.Scripting.GarbageCollector.GCMode==enabled,"late scene OnEnable disabled collection throughout pre-song training");scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"late scene policy was not restored");
        UnityEngine.Scripting.GarbageCollector.GCMode=disabled;scope=new SaberMind.AiCollectionScope();UnityEngine.Scripting.GarbageCollector.GCMode=manual;scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual,"AI disposal overwrote an independent policy change");
        UnityEngine.Scripting.GarbageCollector.GCMode=enabled;scope=new SaberMind.AiCollectionScope();scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==enabled,"an already collecting session changed the game's original policy");
        UnityEngine.Scripting.GarbageCollector.GCMode=manual;try{using(new SaberMind.AiCollectionScope()){throw new InvalidOperationException("cancelled training");}}catch(InvalidOperationException){}Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual,"exception cleanup leaked the AI collection setting");
        var gc=typeof(UnityEngine.Scripting.GarbageCollector);
        UnityEngine.Scripting.GarbageCollector.isIncremental=true;UnityEngine.Scripting.GarbageCollector.Calls=0;UnityEngine.Scripting.GarbageCollector.Remaining=2;
        UnityEngine.Scripting.GarbageCollector.GCMode=disabled;scope=new SaberMind.AiCollectionScope();scope.Tick(1,0,true);
        Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual,"supported playback did not own budgeted collection");
        Check(UnityEngine.Scripting.GarbageCollector.Calls==1 && UnityEngine.Scripting.GarbageCollector.Budget==500000,"playback used an unlimited full collection");
        scope.Tick(1,0,true);Check(UnityEngine.Scripting.GarbageCollector.Calls==1,"multiple saber updates collected twice in the same frame");
        scope.Tick(2,.004,true);scope.Tick(3,.008,true);Check(UnityEngine.Scripting.GarbageCollector.Calls==3,"incomplete collection was abandoned");
        scope.Tick(4,.012,true);Check(UnityEngine.Scripting.GarbageCollector.Calls==3,"stable heap started another collection on every frame");
        scope.Tick(5,3,true);Check(UnityEngine.Scripting.GarbageCollector.Calls==4,"low allocation playback never collected again");
        scope.Tick(6,3.004,false);Check(UnityEngine.Scripting.GarbageCollector.GCMode==enabled,"paused learning kept playback's manual policy");
        scope.Tick(7,3.008,true);Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual,"resume lost incremental playback collection");scope.Dispose();
        Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"incremental lease did not restore vanilla policy");
        UnityEngine.Scripting.GarbageCollector.isIncremental=false;UnityEngine.Scripting.GarbageCollector.GCMode=disabled;scope=new SaberMind.AiCollectionScope();int before=UnityEngine.Scripting.GarbageCollector.Calls;scope.Tick(8,4,true);
        Check(UnityEngine.Scripting.GarbageCollector.GCMode==manual && UnityEngine.Scripting.GarbageCollector.Calls==before,"unsupported player kept automatic stalls or called an unavailable incremental collector");scope.Dispose();
        Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"unsupported fallback did not restore vanilla");
        UnityEngine.Scripting.GarbageCollector.isIncremental=true;UnityEngine.Scripting.GarbageCollector.GCMode=enabled;scope=new SaberMind.AiCollectionScope();scope.Tick(9,5,true);UnityEngine.Scripting.GarbageCollector.GCMode=disabled;scope.Dispose();
        Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"incremental disposal overwrote a later owner's policy");
        UnityEngine.Scripting.GarbageCollector.isIncremental=false;UnityEngine.Scripting.GarbageCollector.GCMode=disabled;
        long heap=100L*1048576;int full=0;
        scope=new SaberMind.AiCollectionScope(delegate{return heap;},delegate{full++;heap=100L*1048576;});
        scope.PreparePlayback();Check(full==1,"pre-song did not release training temporaries");
        Check(scope.PlaybackFullCollections==0 && scope.PeakPlaybackCollectionMilliseconds==0,"Pre-song collection was attributed to playback");
        scope.Tick(10,0,true);heap+=16L*1048576;scope.Tick(11,.01,true);
        Check(full==1,"ordinary heap growth collected inside active notes");
        scope.Tick(12,.02,true,true);Check(full==1,"note-free break caused the reproduced full-GC hitch");
        heap+=16L*1048576;scope.Tick(13,.03,true,true);Check(full==1,"break forced a full collection");
        scope.Tick(14,2.03,true,true);Check(full==1,"old two-second timer still forces playback stalls");
        heap+=129L*1048576;scope.Tick(15,2.54,true);Check(full==1 && !scope.NeedsStoppedCollection,"ordinary growth forced an emergency pause");
        heap+=513L*1048576;scope.Tick(15,2.54,true);Check(full==1 && !scope.NeedsStoppedCollection,"two hand updates sampled heap twice in one frame");
        scope.Tick(16,3.05,true);Check(full==1 && scope.NeedsStoppedCollection,"bounded memory guard was lost");
        bool blocked=false;try{scope.CollectWithStoppedClock(false);}catch(InvalidOperationException){blocked=true;}
        Check(blocked && full==1,"memory guard collected with a running song clock");
        scope.CollectWithStoppedClock(true);Check(full==2 && !scope.NeedsStoppedCollection && scope.StoppedMaintenanceCollections==1,"stopped-clock maintenance failed");
        Check(scope.PlaybackFullCollections==0,"full collection ran during unpaused playback");
        scope.Tick(17,3.1,false);Check(UnityEngine.Scripting.GarbageCollector.GCMode==enabled,"pause retained unsupported manual playback mode");
        scope.Tick(18,3.2,true);heap+=16L*1048576;scope.Tick(19,3.8,true);scope.Tick(20,4,false);
        Check(full==3,"real user pause did not release deferred garbage");
        scope.Dispose();Check(UnityEngine.Scripting.GarbageCollector.GCMode==disabled,"bounded fallback lost the original collection owner");
    }
}
