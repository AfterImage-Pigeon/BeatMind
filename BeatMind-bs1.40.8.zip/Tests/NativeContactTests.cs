using System;
using SaberMind;
class NativeContactTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main()
    {
        try
        {
            var proxy=new MotionVector(.3,.85,.4);var native=new MotionVector(.3,.973,.852);var down=new MotionVector(0,-1,0);
            var start=new MotionVector(.3,.85,10.4);var end=new MotionVector(.3,.85,-9.6);
            var nominal=ContactGeometry.JumpCenter(start,end,.5,8,0,0);
            var early=ContactGeometry.JumpCenter(start,end,.5,8,-.02,0);
            var late=ContactGeometry.JumpCenter(start,end,.5,8,.02,0);
            Check((nominal-new MotionVector(.3,1.85,.4)).Length<1e-12,"nominal native parabolic jump midpoint changed");
            Check(Math.Abs(early.Z-.8)<1e-12 && Math.Abs(late.Z)<1e-12,"native learned timing offsets aimed 40 cm away from the cube");
            Check(Math.Abs(early.Y-late.Y)<1e-12 && late.Y<nominal.Y,"native jump gravity was not evaluated at contact time");
            var flip=ContactGeometry.JumpCenter(new MotionVector(-.3,0,1),new MotionVector(.3,0,-1),.5,0,0,0);
            Check(Math.Abs(flip.X-.3)<1e-12,"flip note aimed between lanes at contact");
            var exit=ContactGeometry.JumpCenter(start,end,.5,0,.4,.5);
            Check(Math.Abs(exit.Z-(-7.6-.108))<1e-12,"native late jump end-distance offset was ignored");
            var contact=new PhraseState{Time=1.02,TargetCenter=proxy,TargetDirection=down};
            Check(!ContactGeometry.NeedsRefit(contact,1.02,proxy,down,.2),"unchanged contact refit repeatedly");
            Check(ContactGeometry.NeedsRefit(contact,1.02,native,down,.2),"spawned native jump geometry kept the stale proxy contact");
            contact.TargetCenter=native;
            Check(!ContactGeometry.NeedsRefit(contact,1.02,native,down,.2),"published native contact refit every frame");
            Check(!ContactGeometry.NeedsRefit(contact,1.02,native+new MotionVector(.01,0,0),down,.2),"visual animation noise changed committed geometry");
            Check(ContactGeometry.NeedsRefit(contact,1.02,native,new MotionVector(1,0,0),.2),"early cut-direction change was ignored");
            Check(!ContactGeometry.NeedsRefit(contact,1.02,proxy,new MotionVector(1,0,0),.9),"late controller animation changed the scoring stroke");
            Check(ContactGeometry.NeedsRefit(contact,1.03,native,down,.9),"changed learned timing was ignored");
            Check(!ContactGeometry.NeedsRefit(null,1.02,native,down,.2),"absent contact was treated as geometry mutation");
            contact.LimitedContact=true;
            Check(ContactGeometry.NeedsRefit(contact,1.02,native,down,.2),"limited approximate contact could not be retried with native geometry");
            Check(!ContactGeometry.Changed(contact,1.02,native,down,.2),"unchanged limited contact triggered replanning every frame");
            Check(!ContactGeometry.NeedsRefit(contact,1.02,native,down,.9),"limited contact forced last-second repeated refits");
            Check(Math.Abs(MotionSampling.Delta(1.1,1,.02)-.1)<1e-12,"frame hitch corrupted measured song derivatives");
            Check(Math.Abs(MotionSampling.Delta(1.015,1,.01)-.015)<1e-12,"song-speed modifier used Unity frame delta");
            Check(Math.Abs(MotionSampling.Delta(1,double.NaN,.007)-.007)<1e-12,"first sample discarded valid native song delta");
            Check(Math.Abs(MotionSampling.Delta(1,1,.007)-.007)<1e-12,"same song timestamp divided by zero");
            Check(MotionSampling.Delta(1,2,double.NaN)>0,"rewind or invalid fallback produced an invalid derivative interval");
            Console.WriteLine(checks+" native contact and song-clock assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
