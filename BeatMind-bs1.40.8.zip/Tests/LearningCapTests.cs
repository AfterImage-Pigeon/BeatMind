using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using SaberMind;
class LearningCapTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main(string[] args)
    {try{Run(args[0]);Console.WriteLine(checks+" intact-sequence learning-cap assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static HumanMotionExample Example(string id,int sequence)
    {
        var e=new HumanMotionExample{Count=100,Phase=(HumanPhase)(sequence%5),Duration=1.25,StartTime=sequence*2,Sequence=sequence,Recording=id,Score=.95,Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new[]{new HumanAnchor{Phase=.375,Score=110,Hand=sequence%2,Lane=sequence%4,Layer=sequence%3,Direction=sequence%9}}};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {double t=1.25*p/128;var s=new PhraseState{Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.2+j*.1+.01*t,.25),Velocity=new MotionVector(0,.01,0),Rotation=MotionRotation.Exp(new MotionVector(.2*t,0,0)),AngularVelocity=new MotionVector(.2,0,0)};HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);}
        return e;
    }
    static HumanMotionFile Source(string id,int count)
    {
        var f=new HumanMotionFile{Key=id,ReplayIdentity=id,Recording=new HumanRecording{Identity=id,Path=id+".bsor",Hash="hash",Difficulty="Expert",Mode="Standard",Accuracy=.95,Frames=100,Notes=2}};
        for(int i=0;i<count;i++){var e=Example(id,i);f.Examples.Add(e);f.Cuts+=e.Count;f.PhaseCounts[(int)e.Phase]+=e.Count;}return f;
    }
    static string Selection(IList<HumanMotionTraining.CachedSource> files)
    {var entries=new List<string>();foreach(var f in files)entries.Add(string.Join(",",f.Selected.ConvertAll(delegate(int n){return n.ToString();}).ToArray()));return string.Join("|",entries.ToArray());}
    static void Run(string root)
    {
        Directory.CreateDirectory(root);var files=new List<HumanMotionTraining.CachedSource>();var template=Source("source",40);
        for(int i=0;i<100;i++)files.Add(HumanMotionTraining.IndexSource("unused",template,i));
        var model=new HumanMotionModel{AvailableSequences=400000};HumanMotionTraining.ApplyLearningBudget(files,model);
        Check(HumanMotionTraining.MaximumLearningPoseSamples==250000 && model.Cuts==1937 && model.LearningPoseSamples==249873,"250k cap did not select the largest whole 129-timestamp budget");
        int selected=0,min=int.MaxValue,max=0;foreach(var f in files){selected+=f.Selected.Count;min=Math.Min(min,f.Selected.Count);max=Math.Max(max,f.Selected.Count);int prior=-1;foreach(int index in f.Selected){Check(index>prior,"selected excerpts lost source temporal ordering");prior=index;}}
        Check(selected==1937 && max-min<=1,"cap biased the input toward the first recordings");foreach(int count in model.PhaseCounts)Check(count>0,"balanced budget discarded an entire motion phase");
        string first=Selection(files);HumanMotionTraining.ApplyLearningBudget(files,model);Check(first==Selection(files),"budget changed between fitting epochs");
        var many=new List<HumanMotionTraining.CachedSource>();var single=Source("one",1);for(int i=0;i<5000;i++)many.Add(HumanMotionTraining.IndexSource("unused",single,i));
        HumanMotionTraining.ApplyLearningBudget(many,new HumanMotionModel());Check(many[0].Selected.Count==1 && many[4997].Selected.Count==1 && many[4999].Selected.Count==0,"partly fitting round was not distributed across the library");
        // Exercise real cache loading and legacy checkpoint invalidation, while
        // source files remain unopened because their excerpt caches are valid.
        string cache=Path.Combine(root,"cache");Directory.CreateDirectory(cache);string revision=(string)typeof(HumanMotionTraining).GetField("Revision",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
        var paths=new string[7];var hashes=new string[7];
        for(int i=0;i<paths.Length;i++)
        {
            paths[i]=Path.Combine(root,"human-"+i+".bsor");File.WriteAllText(paths[i],"source replay preserved");long size,ticks;ReplayFileAccess.Metadata(paths[i],out size,out ticks);
            string key=HumanMotionTraining.Digest(Path.GetFileName(paths[i])+"|"+size+"|"+ticks+"|"+revision);var f=Source("identity-"+i,8);f.Key=key;f.Recording.Path=paths[i];HumanMotionTraining.Write(Path.Combine(cache,key+".json.gz"),f);hashes[i]=HumanMotionTraining.Digest(File.ReadAllText(paths[i]));
        }
        var loaded=HumanMotionTraining.LoadFiles(paths,cache,null,null);Check(loaded.Valid(),"bounded source fit was not valid");
        Check(loaded.Recordings.Count==7 && loaded.Files==7,"cap removed eligible exact-map source indexes");
        Check(loaded.Cuts==56 && loaded.LearningPoseSamples==56*129 && loaded.AvailableSequences==5600,"old exemplar cluster weights bypassed the selected pose budget");
        long weight=0;foreach(var e in loaded.Examples)weight+=e.Count;Check(weight==56,"optimizer retained weight from unselected raw demonstrations");
        int ready=0;var warm=HumanMotionTraining.LoadFiles(paths,cache,null,null,null,delegate(HumanMotionModel m){ready++;Check(m.Valid(),"warm startup exposed an invalid model");});Check(ready==1 && warm.Valid() && warm.TrainingFingerprint==loaded.TrainingFingerprint,"bounded warm cache was not reused");
        string checkpoint=Path.Combine(cache,"HumanMotionModel.json.gz");
        // Both the primary and its recovery backup can still contain an old
        // 500k fit. Even a matching fingerprint must never expose that fit to
        // gameplay through cachedReady before the smaller-budget refit ends.
        var legacy=JsonConvert.DeserializeObject<HumanMotionModel>(JsonConvert.SerializeObject(loaded));legacy.LearningBudgetVersion=1;legacy.Cuts=3875;legacy.LearningPoseSamples=499875;
        legacy.Examples[0].Count+=3875-56;legacy.PhaseCounts[(int)legacy.Examples[0].Phase]+=3875-56;
        Check(!legacy.Valid(),"old 500k checkpoint passed the smaller budget contract");
        HumanMotionTraining.Write(checkpoint,legacy);HumanMotionTraining.Write(checkpoint+".bak",legacy);ready=0;
        var rebuilt=HumanMotionTraining.LoadFiles(paths,cache,null,null,null,delegate(HumanMotionModel m){ready++;});
        Check(ready==0 && rebuilt.Valid() && rebuilt.LearningBudgetVersion==HumanMotionTraining.LearningBudgetVersion && rebuilt.LearningPoseSamples==56*129,"old primary/backup fit escaped through warm startup or was returned without a bounded refit");
        var smallLegacy=JsonConvert.DeserializeObject<HumanMotionModel>(JsonConvert.SerializeObject(rebuilt));smallLegacy.LearningBudgetVersion=1;Check(!smallLegacy.Valid(),"old budget version was accepted merely because its count fit the new cap");
        smallLegacy.LearningBudgetVersion=0;Check(!smallLegacy.Valid(),"legacy unlimited checkpoint passed the new budget contract");
        for(int i=0;i<paths.Length;i++)Check(hashes[i]==HumanMotionTraining.Digest(File.ReadAllText(paths[i])),"learning cap changed an original replay file");
        var oversizedContract=JsonConvert.DeserializeObject<HumanMotionModel>(JsonConvert.SerializeObject(legacy));oversizedContract.LearningBudgetVersion=HumanMotionTraining.LearningBudgetVersion;Check(!oversizedContract.Valid(),"500k fit accepted after only relabeling its budget version");
        rebuilt.LearningPoseSamples=250001;Check(!rebuilt.Valid(),"over-budget checkpoint accepted");rebuilt.LearningPoseSamples=56*129;rebuilt.Examples[0].Count++;Check(!rebuilt.Valid(),"hidden source weight accepted");
        string weighted=Path.Combine(root,"weighted.json.gz");var oversized=Source("weighted",40);HumanMotionTraining.Write(weighted,oversized);bool blocked=false;
        try{foreach(var e in HumanMotionTraining.Examples(new[]{new HumanMotionTraining.CachedSource{Path=weighted,Key=oversized.Key,Identity=oversized.ReplayIdentity}},null,null)){} }catch(InvalidDataException){blocked=true;}
        Check(blocked,"direct weighted enumeration bypassed the 250k pose cap");
        // Selection must keep every pose and derivative in each excerpt intact.
        var selectedSource=HumanMotionTraining.IndexSource(weighted,oversized,0);HumanMotionTraining.ApplyLearningBudget(new[]{selectedSource},new HumanMotionModel());
        foreach(var e in HumanMotionTraining.Examples(new[]{selectedSource},null,null))
        {var original=oversized.Examples[e.Sequence];Check(e.Count==1 && e.Curve.Length==129*21 && e.Kinematics.Length==129*36,"selection chopped or reweighted a continuous excerpt");Check(JsonConvert.SerializeObject(e.Curve)==JsonConvert.SerializeObject(original.Curve) && JsonConvert.SerializeObject(e.Kinematics)==JsonConvert.SerializeObject(original.Kinematics),"selection changed measured motion or derivatives");Check(e.StartTime==original.StartTime && e.Duration==original.Duration && e.Score==original.Score && e.Recording==original.Recording && JsonConvert.SerializeObject(e.Anchors)==JsonConvert.SerializeObject(original.Anchors),"selection changed learned note timing, source accuracy or stroke data");}
        int waits=0;var retained=HumanMotionTraining.MaterializeSelected(new[]{selectedSource},delegate{waits++;});
        long bytes=0;foreach(var e in retained)bytes+=((long)e.Curve.Length+e.Kinematics.Length)*sizeof(float);
        Check(retained.Count==40 && bytes<=HumanMotionTraining.MaximumLearningPoseSamples*HumanMotionModel.TotalChannels*sizeof(float),"materialization retained uncapped source arrays");
        var fit=typeof(HumanMotionTraining).GetMethod("Fit",BindingFlags.Static|BindingFlags.NonPublic);
        var reference=fit.Invoke(null,new object[]{HumanMotionTraining.Examples(new[]{selectedSource},null,null),null});
        var reused=fit.Invoke(null,new object[]{HumanMotionTraining.RepeatSelected(retained,null,delegate{waits++;}),null});
        Check(JsonConvert.SerializeObject(reference)==JsonConvert.SerializeObject(reused),"materializing bounded excerpts changed fitting order or learned parameters");
        Check(waits>=retained.Count*10,"materialized fitting epochs lost gameplay idle checks");
    }
}
