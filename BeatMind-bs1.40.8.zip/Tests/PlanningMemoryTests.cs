using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using SaberMind;
class PlanningMemoryTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static HumanMotionExample Example()
    {
        var e=new HumanMotionExample{Duration=1.25,Recording="ordered human recording",Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new[]{new HumanAnchor{Hand=0,Direction=1,Phase=.4}}};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {double t=p*1.25/128;var s=new PhraseState{Time=t,Grip=new MotionVector(j==0?0:j==1?-.3:.3,1.2+j*.1+.01*t,.25),Velocity=new MotionVector(0,.01,0),Rotation=MotionRotation.Exp(new MotionVector(.2*t,0,0)),AngularVelocity=new MotionVector(.2,0,0)};HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);}return e;
    }
    static HumanMotionGraph Graph()
    {
        var model=new HumanMotionModel();var e=Example();model.Examples.Add(e);model.Examples.Add(new HumanMotionExample{Phase=HumanPhase.Opening,Duration=e.Duration,Recording=e.Recording,Context=e.Context,Curve=e.Curve,Kinematics=e.Kinematics,Anchors=new HumanAnchor[0]});
        var chart=new HumanChartNote[240];for(int i=0;i<chart.Length;i++)chart[i]=new HumanChartNote{Time=1+i*.5,Hand=0,Direction=1};return new HumanMotionGraph(model,chart,null,2);
    }
    static int Main(){try{ScopedCapture();HistoricalRoutes();ExactCacheLimit();Console.WriteLine(checks+" bounded planning memory assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static void ScopedCapture()
    {
        var graph=Graph();for(double t=0;t<=119;t+=1)graph.PrepareUntil(t);
        var capture=graph.Capture(108,111);for(double t=108;t<=111;t+=.017)for(int j=0;j<3;j++)
        {var a=graph.Sample(t,j);var b=capture(t,j);Check((a.Grip-b.Grip).Length<1e-10 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-10 && (a.Velocity-b.Velocity).Length<1e-9 && (a.AngularVelocity-b.AngularVelocity).Length<1e-9,"scoped capture changed temporal motion or derivatives");}
        var target=capture.Target;int spanCount=0;foreach(var f in target.GetType().GetFields(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance))
        {var list=f.GetValue(target) as IList;if(list==null || list.Count==0)continue;var first=list[0];if(first!=null && first.GetType().Name=="Span")spanCount=list.Count;}
        Check(spanCount>0 && spanCount<32,"a short contact plan retained the complete prepared song's spans");
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static MotionPhrase BuildHistory(out WeakReference[] references)
    {
        references=new WeakReference[240];MotionPhrase current=null;var g=new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1),Shoulder=new MotionVector(-.15,1.47,.025),Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1)};
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(-.3,1.3,.3),Rotation=MotionRotation.Exp(new MotionVector(.2,0,0))};};
        for(int i=0;i<references.Length;i++)
        {double now=i*.04;var seed=current==null ? teacher(now) : current.Sample(now);seed.Time=now;var next=ReplayMotor.Build(seed,new List<PhraseNote>(),g,teacher,9,.9);if(current!=null)next.CarryFrom(current,now,now+.025);current=next;references[i]=new WeakReference(current);}
        return current;
    }
    static void HistoricalRoutes()
    {
        WeakReference[] history;var current=BuildHistory(out history);
        // One collection after the whole workload checks strong-reference
        // retention. The workload itself never forces a collection per plan.
        GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();int retained=0;foreach(var r in history)if(r.IsAlive)retained++;
        Check(retained<=2,"the current evaluator retained old MotionPhrase objects across successive replans");Check(current.Sample(9.57).Grip.Length>0,"retention check discarded the live route");GC.KeepAlive(current);
    }
    static void ExactCacheLimit()
    {
        var type=typeof(HumanReplayPreparation);var flags=BindingFlags.Static|BindingFlags.NonPublic;
        var runs=(Dictionary<string,HumanRunHandle>)type.GetField("runs",flags).GetValue(null);var order=(Queue<string>)type.GetField("order",flags).GetValue(null);runs.Clear();order.Clear();
        int recordingPoints=HumanMotionTraining.MaximumLearningPoseSamples*3/5;
        for(int i=0;i<3;i++){string key="run"+i;var tape=new HumanTape(new float[0],new double[recordingPoints],new HumanChartNote[0],key,.99);runs[key]=new HumanRunHandle{Tape=tape};order.Enqueue(key);}
        type.GetMethod("TrimRetainedRuns",flags).Invoke(null,new object[]{"run2"});long poses=0;foreach(var h in runs.Values)poses+=h.Tape.Times.Length;
        Check(poses<=HumanMotionTraining.MaximumLearningPoseSamples,"exact-run cache exceeded the shared current pose budget");Check(runs.Count==1 && runs.ContainsKey("run2") && runs["run2"].Tape.Times.Length==recordingPoints,"cache trimming chopped or removed the newest whole recording");runs.Clear();order.Clear();
        var exact=new HumanRunHandle{Tape=new HumanTape(new float[0],new double[HumanMotionTraining.MaximumLearningPoseSamples],new HumanChartNote[0],"at-budget",.99)};runs["at-budget"]=exact;order.Enqueue("at-budget");
        type.GetMethod("TrimRetainedRuns",flags).Invoke(null,new object[]{"at-budget"});Check(exact.Tape!=null && exact.Tape.Times.Length==HumanMotionTraining.MaximumLearningPoseSamples,"exactly budget-sized recording was trimmed");runs.Clear();order.Clear();
        var huge=new HumanRunHandle{Tape=new HumanTape(new float[0],new double[HumanMotionTraining.MaximumLearningPoseSamples+1],new HumanChartNote[0],"oversize",.99)};runs["oversize"]=huge;order.Enqueue("oversize");
        type.GetMethod("TrimRetainedRuns",flags).Invoke(null,new object[]{"oversize"});
        Check(huge.Tape==null,"one oversized recording bypassed the retained tracking budget");Check(huge.Status.Contains("budget"),"oversized source did not expose its pattern-motion fallback");runs.Clear();order.Clear();
    }
}
