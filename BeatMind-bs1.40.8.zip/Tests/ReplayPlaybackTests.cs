using System;
using System.Collections.Generic;
using SaberMind;
class ReplayPlaybackTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseGeometry Geometry(int color)
    {return new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1),Shoulder=new MotionVector(color==0 ? -.15 : .15,1.47,.025),Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1),Color=color};}
    static int Main()
    {
        try
        {
            foreach(int color in new[]{0,1})foreach(int arrow in new[]{0,1,2,3,4,5,6,7})foreach(double nps in new[]{1.0,8.0,18.0})MeasuredSpeed(color,arrow,nps);
            foreach(int color in new[]{0,1}){MeasuredWindow(color);DenseRepair(color);Sliced(color);}
            Console.WriteLine(checks+" replay speed / dense repair / incremental planning assertions passed.");return 0;
        }catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void MeasuredSpeed(int color,int arrow,double nps)
    {
        var g=Geometry(color);var grip=new MotionVector(color==0 ? -.3 : .3,1.3,.25);var center=grip+new MotionVector(0,-.21,.575);
        var rotation=MotionRotation.FromTo(new MotionVector(0,0,1),(center-grip).Unit,new MotionVector(1,0,0));
        var direction=HumanContext.Direction(arrow);var blade=rotation.Rotate(new MotionVector(0,0,1));var angular=MotionVector.Cross(blade,direction).Unit*7+blade*3.1;
        var human=new PhraseState{Time=1,Grip=grip,Rotation=rotation,AngularVelocity=angular,AngularAcceleration=new MotionVector(330,-17,11),Velocity=new MotionVector(.03,.015,.02),Acceleration=new MotionVector(85,3,4),HumanSource=2,HumanGripWeight=1,HumanWristWeight=1};
        var note=new PhraseNote{Id=0,Time=1,Center=center,Direction=direction,Forward=g.Forward,Spacing=.5,LocalNps=nps};int count;
        var fit=ReplayMotor.FitContact(human,note,g,null,9,out count);var transport=fit.Rotation*human.Rotation.Inverse;
        Check((fit.AngularVelocity-transport.Rotate(angular)).Length<1e-7,"valid human wrist speed/roll was replaced by generated NPS speed");
        Check((fit.AngularAcceleration-transport.Rotate(human.AngularAcceleration)).Length<1e-7,"measured angular acceleration was replaced");
        Check((fit.Velocity-human.Velocity).Length<1e-7 && (fit.Acceleration-human.Acceleration).Length<1e-7,"valid recorded hand kinematics were scaled/clamped");
        Check((fit.Grip-grip).Length<1e-7,"speed replication moved a reachable human grip");
        Check(CutSafety.BladeDistance(fit,center,g)<1e-7,"measured-speed contact lost the note");
    }
    static Func<double,PhraseState> Teacher(int color)
    {
        return delegate(double t)
        {
            double angle=2*Math.Sin(8*t);
            return new PhraseState{Time=t,Grip=new MotionVector(color==0 ? -.3 : .3,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),AngularVelocity=new MotionVector(16*Math.Cos(8*t),0,0),AngularAcceleration=new MotionVector(-128*Math.Sin(8*t),0,0),HumanSource=1,HumanGripWeight=1,HumanWristWeight=1};
        };
    }
    static void MeasuredWindow(int color)
    {
        var g=Geometry(color);var teacher=Teacher(color);var notes=new List<PhraseNote>();
        foreach(double time in new[]{.8,1.2})
        {var score=BladeSwingScoring.Measure(teacher,g,time);Check(score.BeforeFull && score.AfterFull,"recorded preservation fixture must earn both native swing-angle ratings");var s=teacher(time);var speed=MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top));speed.Z=0;notes.Add(new PhraseNote{Id=notes.Count,Time=time,Center=s.Grip+s.Rotation.Rotate(new MotionVector(0,0,.90)),Direction=speed.Unit,Forward=g.Forward,Spacing=.4,LocalNps=4});}
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.6);
        foreach(var note in notes)for(double t=note.Time-.065;t<=note.Time+.065;t+=.002)
        {var s=path.Sample(t);var h=teacher(t);Check(MotionRotation.Log(s.Rotation*h.Rotation.Inverse).Length<1e-7,"valid recorded scored-window orientation changed");Check((s.AngularVelocity-h.AngularVelocity).Length<1e-6,"recorded swing speed waveform changed");Check((s.Grip-h.Grip).Length<1e-7,"recorded saber positioning changed");}
    }
    static void DenseRepair(int color)
    {
        var g=Geometry(color);double x=color==0 ? -.3 : .3;
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(x,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};};
        var notes=new[]{new PhraseNote{Id=0,Time=.8,Center=new MotionVector(x,1.09,.825),Direction=new MotionVector(0,1,0),Forward=g.Forward,Spacing=.1,LocalNps=18},new PhraseNote{Id=1,Time=.805,Center=new MotionVector(-x*3,1.69,.825),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=.1,LocalNps=18},new PhraseNote{Id=2,Time=1.2,Center=new MotionVector(x,1.09,.825),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=.1,LocalNps=18}};
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.8);int kept=0;
        foreach(var n in notes){var c=path.Contact(n.Id);if(c!=null && !c.LimitedContact && CutSafety.BladeDistance(path.Sample(n.Time),n.Center,g)<.025)kept++;}
        Check(path.StabilityFallbacks>0,"dense fixture did not exercise an unsafe transition");
        Check(kept>=2,"one unsafe dense transition discarded the otherwise feasible cuts");
        for(double t=.001;t<1.79;t+=.001){var s=path.Sample(t);Check(s.Velocity.Length<=18.001 && s.AngularVelocity.Length<=125.001,"partial dense repair introduced an unsafe trajectory");}
    }
    static void Sliced(int color)
    {
        var g=Geometry(color);var teacher=Teacher(color);var notes=new List<PhraseNote>();
        for(int i=0;i<40;i++){double time=.3+i*.065;var s=teacher(time);var v=MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top));v.Z=0;notes.Add(new PhraseNote{Id=i,Time=time,Center=s.Grip+s.Rotation.Rotate(new MotionVector(0,0,.9)),Direction=v.Length>.1 ? v.Unit : new MotionVector(0,-1,0),Forward=g.Forward,Spacing=.065,LocalNps=18});}
        var sync=ReplayMotor.Build(teacher(0),notes,g,teacher,9,3.1);
        var job=ReplayMotor.BeginBuild(teacher(0),notes,g,teacher,9,3.1);int frames=0;
        while(!job.Advance(.05)){frames++;Check(frames<1000,"incremental planning stalled on a dense stream");}
        Check(frames>1,"incremental planning still blocked in one monolithic call");
        var sliced=job.Result;Check(sync.Knots.Count==sliced.Knots.Count,"slicing changed planned contacts");
        for(double t=.001;t<3.0;t+=.002){var a=sync.Sample(t);var b=sliced.Sample(t);Check((a.Grip-b.Grip).Length<1e-12 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8,"slicing changed the computed motion");Check((a.AngularVelocity-b.AngularVelocity).Length<1e-10,"slicing altered recorded swing speed");}
        Console.WriteLine("Dense plan slices="+job.Slices+", total ms="+job.TotalMilliseconds.ToString("0.00")+", peak slice ms="+job.PeakSliceMilliseconds.ToString("0.00"));job.Dispose();
    }
}
