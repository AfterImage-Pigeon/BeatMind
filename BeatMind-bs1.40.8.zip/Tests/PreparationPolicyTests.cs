using System;
using System.Collections.Generic;
using SaberMind;

class PreparationPolicyTests
{
    static int checks;
    static void Check(bool value,string label){checks++;if(!value)throw new Exception(label);}
    static int Main(string[] args)
    {
        try
        {
            var note=new NoteMemory();Policy.Observe(note,0,.93);Policy.Observe(note,0,.93);
            Check(Policy.Choose(note,true,.95)==1,"93% strokes must continue learning toward 95%");
            Check(Policy.Choose(note,true,.90)==0,"a stroke meeting a lower chosen goal must remain stable");
            Check(!Policy.ReuseReplayStroke(note,0,.95),"old whole-run choices may not freeze below-target strokes");
            Check(Policy.ReuseReplayStroke(new NoteMemory(),0,.95),"a best replay may warm-start an unmeasured stroke");
            Policy.Observe(note,1,.96);Policy.Observe(note,1,.96);
            Check(Policy.Choose(note,true,.95)==1 && Policy.ReuseReplayStroke(note,1,.95),"measured target-reaching cuts are retained");
            Policy.Observe(note,2,1);Policy.Observe(note,2,1);
            Check(!Policy.ReuseReplayStroke(note,1,.95) && Policy.ReuseReplayStroke(note,2,.95),"better newer evidence beats an older successful choice");
            Check(Policy.Choose(note,false,.99)==2,"watch mode retains measured winners without exploring");
            foreach(var profile in ModelProfile.All)
            {
                Check(profile.MotionWeight==0,"a model still rewards aesthetic quality");
                if(profile.Dimensions==0)continue;
                var m=new BehaviorMemory();var choice=BehaviorOptimizer.Choose(m,profile,true,"test");
                BehaviorOptimizer.Observe(m,profile,choice,.99,0);
                BehaviorOptimizer.Observe(m,profile,choice,.95,1);
                Check(Math.Abs(m.Rewards[0][1]-1.94)<1e-12,"a faster accurate cut was discounted for style");
                BehaviorOptimizer.Observe(m,profile,choice,0,1);
                Check(m.Trials[0][1]==3 && Math.Abs(m.Rewards[0][1]-1.94)<1e-12,"a pretty miss received reward");
                BehaviorOptimizer.Observe(m,profile,choice,.97,double.NaN);
                Check(m.Trials[0][1]==4 && Math.Abs(m.Rewards[0][1]-2.91)<1e-12,"irrelevant style feedback rejected real score evidence");
                BehaviorOptimizer.Observe(m,profile,choice,double.PositiveInfinity,1);
                Check(m.Trials[0][1]==4,"nonfinite score counted as a real observation");
            }
            var p=new PretrainedPlan{PreparationSignature="verified-inputs",MotionVersion=2,Validations=2,Confidence=.95f,Variant=0,Z=.035f};
            var plans=new List<PretrainedPlan>{p};
            Check(PreparationCache.Reusable(plans,"verified-inputs",.72),"unchanged completed geometric practice did not cache");
            foreach(string changed in new[]{"new-chart","new-model","new-human-library","different-body","new-wall","new-stroke","new-plan","new-runtime"})
                Check(!PreparationCache.Reusable(plans,changed,.72),"changed trajectory inputs skipped validation");
            p.PreparationSignature=null;Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"legacy plans without provenance were reused");p.PreparationSignature="verified-inputs";
            p.Validations=0;Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"unfinished practice was reused");p.Validations=2;
            p.MotionVersion=1;Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"a legacy movement plan was reused");p.MotionVersion=2;
            p.Confidence=.50f;Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"weak cached geometry skipped practice");
            p.Confidence=float.NaN;Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"invalid cached confidence skipped practice");p.Confidence=.95f;
            plans.Add(new PretrainedPlan{PreparationSignature="verified-inputs",MotionVersion=2,Validations=1,Confidence=.10f,Variant=0});
            Check(!PreparationCache.Reusable(plans,"verified-inputs",.72),"a poor note was hidden by section averaging");plans.RemoveAt(1);
            var store=new MemoryStore(args[0]);var memory=store.Load("original-map");var model=memory.ForModel("Natural");
            model.Pretrained["cut"]=p;model.Timing["cut"]=note;
            var legacy=new BehaviorMemory();BehaviorOptimizer.Observe(legacy,ModelProfile.All[1],BehaviorOptimizer.Choose(legacy,ModelProfile.All[1],true,"cut"),.81,1);model.Behaviors["cut"]=legacy;
            string prior=Newtonsoft.Json.JsonConvert.SerializeObject(model.Timing);string oldControls=Newtonsoft.Json.JsonConvert.SerializeObject(model.Behaviors);
            store.Save(memory);var saved=store.Load(memory.Identity).ForModel("Natural");
            Check(PreparationCache.Reusable(new[]{saved.Pretrained["cut"]},"verified-inputs",.72),"verified preparation did not survive disk round-trip");
            Check(Newtonsoft.Json.JsonConvert.SerializeObject(saved.Timing)==prior && Newtonsoft.Json.JsonConvert.SerializeObject(saved.Behaviors)==oldControls,"caching altered real timing trials or old control evidence");
            Check(saved.Runs.Count==0 && saved.Prediction().Contains("Predicted Score: N/A"),"geometric practice fabricated measured scores");
            Console.WriteLine(checks+" score-only / goal-aware learning / validated preparation cache assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
