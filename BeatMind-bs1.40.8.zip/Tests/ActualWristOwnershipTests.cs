using System;
using System.Collections.Generic;
using SaberMind;

class ActualWristOwnershipTests
{
    const double Radians=Math.PI/180;
    static int checks;
    static double maximumMetadataRotationError,maximumMetadataVelocityError,maximumMetadataAccelerationError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static PhraseGeometry Geometry(int hand,int body,double scale)
    {
        var frame=MotionRotation.Exp(new MotionVector(0,(body==0 ? 0 : 67)*Radians,0));
        return new PhraseGeometry{Top=new MotionVector(0,0,1),Forward=frame.Rotate(new MotionVector(0,0,1)),
            Shoulder=frame.Rotate(new MotionVector(hand==0 ? -.14 : .14,1.58,-.10)),Color=hand,Reach=.90,MinimumReach=.10,
            ControlledWrist=true,StableFastGrip=true,SwingSpeedScale=scale};
    }
    static Func<double,PhraseState> Teacher(int hand,int body)
    {
        var frame=MotionRotation.Exp(new MotionVector(0,(body==0 ? 0 : 67)*Radians,0));
        var grip=frame.Rotate(new MotionVector(hand==0 ? -.30 : .30,1.30,.22));
        var axis=frame.Rotate(new MotionVector(-1,0,0));
        return delegate(double time){return new PhraseState{Time=time,Grip=grip,
            Rotation=frame*MotionRotation.Exp(new MotionVector(-(25*Radians+2*(time-.5)),0,0)),
            AngularVelocity=axis*2,HumanSource=12,HumanGripWeight=1,HumanWristWeight=1};};
    }
    static List<PhraseNote> Notes(PhraseGeometry g,Func<double,PhraseState> teacher,int count)
    {
        var human=teacher(.5);var center=human.Grip+human.Rotation.Rotate(g.Top-g.Grip)*.67;
        var up=new MotionVector(0,1,0);var result=new List<PhraseNote>();
        for(int i=0;i<count;i++)result.Add(new PhraseNote{Id=i,Time=.5+.20*i,Spacing=.20,LocalNps=5,ScoringType=1,
            Center=center,Direction=up,Forward=g.Forward});
        return result;
    }
    static PhraseState Envelope(PhraseState contact,double time)
    {
        double angle,rate,acceleration;var curve=new SteadySwingEnvelope(contact.SwingStart,contact.Time,contact.SwingEnd,contact.AngularVelocity.Length);
        curve.Sample(time,out angle,out rate,out acceleration);var axis=contact.AngularVelocity.Unit;
        return new PhraseState{Time=time,Rotation=MotionRotation.Exp(axis*angle)*contact.Rotation,AngularVelocity=axis*rate,AngularAcceleration=axis*acceleration};
    }
    static void Metadata(MotionPhrase path,PhraseGeometry g,string context)
    {
        foreach(var contact in path.Knots)
        {
            if(contact.Id<0)continue;
            Check(contact.SteadyWristMotion,context+": generated envelope ownership lost");
            Check(contact.WristSpeedScale==g.SwingSpeedScale,context+": actual pace ownership lost");
            Check(contact.WristSource==null,context+": actual-time envelope retained legacy clock restoration ownership");
            Check(contact.SwingStart<contact.Time && contact.Time<contact.SwingEnd,context+": envelope times invalid");
            for(int i=0;i<=120;i++)
            {
                double time=contact.SwingStart+(contact.SwingEnd-contact.SwingStart)*i/120;
                var expected=Envelope(contact,time);var actual=path.SampleWrist(time);
                double q=MotionRotation.Log(actual.Rotation*expected.Rotation.Inverse).Length,w=(actual.AngularVelocity-expected.AngularVelocity).Length,a=(actual.AngularAcceleration-expected.AngularAcceleration).Length;
                maximumMetadataRotationError=Math.Max(maximumMetadataRotationError,q);maximumMetadataVelocityError=Math.Max(maximumMetadataVelocityError,w);maximumMetadataAccelerationError=Math.Max(maximumMetadataAccelerationError,a);
                Check(q<1e-7,context+": retimed endpoint metadata reconstructs a different wrist curve at "+time+" q="+q);
                Check(w<1e-6,context+": metadata wrist pace disagrees with actual curve at "+time+" w="+w);
                Check(a<.001,context+": metadata angular acceleration disagrees with actual curve at "+time+" a="+a);
                Check(WristMotionLimits.Contains(actual.Rotation,g),context+": published owned stroke violates angle limits");
            }
        }
    }
    static void SinglePace(int hand,int body)
    {
        var teacher=Teacher(hand,body);var normalGeometry=Geometry(hand,body,1);var fastGeometry=Geometry(hand,body,1.5);
        var normal=ReplayMotor.Build(teacher(0),Notes(normalGeometry,teacher,1),normalGeometry,teacher,9,1.1);
        var fast=ReplayMotor.Build(teacher(0),Notes(fastGeometry,teacher,1),fastGeometry,teacher,9,1.1);
        Check(Math.Abs(fast.Contact(0).AngularVelocity.Length/normal.Contact(0).AngularVelocity.Length-1.5)<1e-8,"single requested speed scale was applied more than once");
        Check(MotionRotation.Log(fast.Contact(0).Rotation*normal.Contact(0).Rotation.Inverse).Length<1e-8,"speed setting changed contact orientation");
        Metadata(fast,fastGeometry,"single actual pace hand="+hand+" body="+body);
    }
    static void EarlyCommitted(int hand,int body)
    {
        var teacher=Teacher(hand,body);var g=Geometry(hand,body,1.5);var notes=Notes(g,teacher,2);
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.1);Metadata(path,g,"initial pair");
        var original=new[]{path.Contact(0).Copy(),path.Contact(1).Copy()};
        foreach(double time in new[]{.05,.10,.15})
        {
            foreach(var note in notes)note.Committed=path.Contact(note.Id);
            var previous=path;g.PreviousWristAt=previous.SampleWrist;
            var seed=previous.Sample(time);seed.Id=-1;seed.Time=time;
            path=ReplayMotor.Build(seed,notes,g,teacher,9,1.1-time);Metadata(path,g,"early committed hand="+hand+" body="+body+" at="+time);
            foreach(var before in original)
            {
                var after=path.Contact(before.Id);
                Check(MotionRotation.Log(after.Rotation*before.Rotation.Inverse).Length<1e-8,"early replan changed owned contact orientation");
                Check((after.AngularVelocity-before.AngularVelocity).Length<1e-6,"early replan multiplied owned wrist speed");
                Check((after.AngularAcceleration-before.AngularAcceleration).Length<.001,"early replan changed owned contact acceleration");
                Check(Math.Abs(after.SwingStart-before.SwingStart)<1e-8 && Math.Abs(after.SwingEnd-before.SwingEnd)<1e-8,"early replan changed actual envelope window");
            }
        }
    }
    static void NonAffineClockCounterexample()
    {
        var axis=new MotionVector(-1,0,0);var right=new PhraseState{Id=1,Time=.914,Rotation=MotionRotation.Exp(new MotionVector(30*Radians,0,0)),AngularVelocity=axis*20,SwingStart=.906,SwingPeak=.914,SwingEnd=.98,SteadyWristMotion=true};
        var left=new PhraseState{Id=0,Time=.900,AngularVelocity=axis*20,SwingStart=.85,SwingPeak=.9,SwingEnd=.96,SteadyWristMotion=true};
        var clock=new ReplayWristClock(.8,1.2,new[]{left,right},1.5);
        var raw=new SteadySwingEnvelope(right.SwingStart,right.Time,right.SwingEnd,right.AngularVelocity.Length);
        var reconstructed=right.Copy();reconstructed.SwingStart=clock.Unmap(right.SwingStart);reconstructed.SwingEnd=clock.Unmap(right.SwingEnd);reconstructed.AngularVelocity*=1.5;
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Forward=new MotionVector(0,0,1)};
        Check(Math.Abs(reconstructed.SwingStart-(right.Time-(right.Time-right.SwingStart)/1.5))>1e-4,"counterexample did not exercise a non-affine clock");
        bool recreatedLeavesBounds=false;
        for(int i=0;i<=200;i++)
        {
            double time=reconstructed.SwingStart+(right.Time-reconstructed.SwingStart)*i/200,source,rate,acceleration,angle,w,a;
            clock.Map(time,out source,out rate,out acceleration);raw.Sample(source,out angle,out w,out a);
            Check(WristMotionLimits.Contains(MotionRotation.Exp(axis*angle)*right.Rotation,g),"actual retimed source should remain bounded");
            if(!WristMotionLimits.Contains(Envelope(reconstructed,time).Rotation,g))recreatedLeavesBounds=true;
        }
        Check(recreatedLeavesBounds,"non-affine endpoint reconstruction failed to expose the old bounds regression");
        // Actual-time metadata with one pace retains the same permitted travel.
        var actual=right.Copy();actual.AngularVelocity*=1.5;actual.SwingStart=right.Time-(right.Time-right.SwingStart)/1.5;actual.SwingEnd=right.Time+(right.SwingEnd-right.Time)/1.5;
        for(int i=0;i<=200;i++)Check(WristMotionLimits.Contains(Envelope(actual,actual.SwingStart+(actual.SwingEnd-actual.SwingStart)*i/200).Rotation,g),"one actual-time envelope must remain bounded");
    }
    static int Main()
    {
        try
        {
            NonAffineClockCounterexample();
            foreach(int hand in new[]{0,1})foreach(int body in new[]{0,1}){SinglePace(hand,body);EarlyCommitted(hand,body);}
            Console.WriteLine(checks+" actual wrist ownership assertions passed; metadata q="+maximumMetadataRotationError+" w="+maximumMetadataVelocityError+" alpha="+maximumMetadataAccelerationError);return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
