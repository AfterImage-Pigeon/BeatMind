using System;
using SaberMind;
class WristMotionLimitsTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static double Radians(double degrees){return degrees*Math.PI/180;}
    static MotionVector Up=new MotionVector(0,1,0);
    static PhraseGeometry Geometry(int hand,double yaw,bool offset)
    {var f=MotionRotation.Exp(Up*Radians(yaw)).Rotate(new MotionVector(0,0,1));return new PhraseGeometry{Color=hand,Forward=f+Up*.6,Bottom=offset ? new MotionVector(-.13,.07,.10) : new MotionVector(0,0,.12),Top=offset ? new MotionVector(.12,.18,1.05) : new MotionVector(0,0,1.1)};}
    static MotionVector Forward(PhraseGeometry g){return new MotionVector(g.Forward.X,0,g.Forward.Z).Unit;}
    static MotionVector Right(PhraseGeometry g){return MotionVector.Cross(Up,Forward(g)).Unit;}
    static MotionVector Blade(PhraseGeometry g){return (g.Top-g.Bottom).Unit;}
    static MotionVector Direction(PhraseGeometry g,double pitch,double side)
    {pitch=Radians(pitch);side=Radians(side);return Forward(g)*(Math.Cos(side)*Math.Cos(pitch))+Right(g)*Math.Sin(side)+Up*(Math.Cos(side)*Math.Sin(pitch));}
    static MotionRotation Pose(PhraseGeometry g,double pitch,double side,double roll)
    {var facing=MotionRotation.FromTo(Blade(g),Forward(g),Right(g));return (MotionRotation.Exp(-Right(g)*Radians(pitch))*MotionRotation.Exp(Up*Radians(side))*facing*MotionRotation.Exp(Blade(g)*Radians(roll))).Unit;}
    static void AngleCases(PhraseGeometry g)
    {
        foreach(double pitch in new[]{-40.0,0,89.9,90,90.1,100})foreach(double side in new[]{-45.0,0,45})foreach(double roll in new[]{0.0,37,-73})
        {
            var q=Pose(g,pitch,side,roll);double p,s;WristMotionLimits.Angles(q,g,out p,out s);
            Check(Math.Abs(p-Radians(pitch))<1e-10 && Math.Abs(s-Radians(side))<1e-10,"body-frame angle chart changed above overhead, under blade offsets or roll");
            Check(WristMotionLimits.Contains(q,g),"valid requested endpoint was rejected");
            var fitted=WristMotionLimits.Fit(q,g);Check(MotionRotation.Log(fitted*q.Inverse).Length<1e-10,"fitting altered an already legal wrist pose");
            var negative=WristMotionLimits.Fit(q*-1,g);Check(MotionRotation.Log(negative*fitted.Inverse).Length<1e-10,"quaternion sign changed the fitted physical pose");
        }
        foreach(var angles in new[]{new[]{-40.01,0.0},new[]{100.01,0.0},new[]{0.0,-45.01},new[]{0.0,45.01}})Check(!WristMotionLimits.Contains(Pose(g,angles[0],angles[1],0),g),"out-of-range blade accepted");
        var upper=Pose(g,100,0,0);Check(MotionVector.Dot(upper.Rotate(Blade(g)),Forward(g))<0,"100-degree test did not actually cross above forward");
    }
    static void NearestFit(PhraseGeometry g)
    {
        foreach(double pitch in new[]{-179.0,-150,-140,-90,-40.1,100.1,160,179})foreach(double side in new[]{-70.0,0,20,70})
        {
            var q=Pose(g,pitch,side,31);var fitted=WristMotionLimits.Fit(q,g);var original=q.Rotate(Blade(g));var actual=fitted.Rotate(Blade(g));
            Check(WristMotionLimits.Contains(fitted,g),"nearest fitted wrist escaped the actual angle bounds");
            double quality=MotionVector.Dot(original,actual);
            // Independent dense spherical search bounds the nearest-direction
            // requirement, including corners and periodic pitch alternatives.
            for(int p=-40;p<=100;p+=2)for(int s=-45;s<=45;s+=2)
                Check(quality+2e-10>=MotionVector.Dot(original,Direction(g,p,s)),"fitted orientation was farther than a legal spherical candidate");
            var unrolled=Pose(g,pitch,side,0);var fittedUnrolled=WristMotionLimits.Fit(unrolled,g);
            Check((MotionRotation.Log(fitted*fittedUnrolled.Inverse)-actual*Radians(31)).Length<1e-9,"fitting added or lost blade roll");
            var qNegative=WristMotionLimits.Fit(q*-1,g);Check(MotionRotation.Log(qNegative*fitted.Inverse).Length<1e-10,"sign choice changed nearest-fit branch");
        }
        var a=WristMotionLimits.Fit(Pose(g,179.99,0,0),g);var b=WristMotionLimits.Fit(Pose(g,-179.99,0,0),g);
        Check(MotionRotation.Log(a*b.Inverse).Length<1e-8,"periodic pitch wrap jumped across the 140-degree envelope");
        var margin=Radians(5);var inset=WristMotionLimits.Fit(Pose(g,100,45,12),g,margin);double pitchInset,sideInset;WristMotionLimits.Angles(inset,g,out pitchInset,out sideInset);
        Check(pitchInset<=Radians(95)+1e-10 && pitchInset>=Radians(-35)-1e-10 && Math.Abs(sideInset)<=Radians(40)+1e-10 && WristMotionLimits.Contains(inset,g,margin),"positive margin did not inset both limits");
    }
    static void Travel(PhraseGeometry g)
    {
        var q=Pose(g,0,0,23);var pitchAxis=-Right(g);
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,pitchAxis,Radians(360),g)-Radians(100))<1e-9,"full circle skipped first upper-pitch exit");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,pitchAxis,Radians(-360),g)-Radians(-40))<1e-9,"negative arc skipped first lower-pitch exit");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,Up,Radians(180),g)-Radians(45))<1e-9,"positive side travel escaped upper inclination");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,Up,Radians(-180),g)-Radians(-45))<1e-9,"negative side travel escaped lower inclination");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,pitchAxis,Radians(20),g)-Radians(20))<1e-12,"legal requested travel was shortened");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,q.Rotate(Blade(g)),Math.PI*5,g)-Math.PI*5)<1e-12,"blade-axis roll acquired a pitch/side restriction");
        Check(WristMotionLimits.SafeTravel(Pose(g,100,0,0),pitchAxis,1,g)==0,"outward arc began beyond an exact boundary");
        Check(WristMotionLimits.SafeTravel(Pose(g,101,0,0),pitchAxis,-1,g)==0,"arc planner accepted an initially illegal pose");
        Check(Math.Abs(WristMotionLimits.SafeTravel(Pose(g,100,0,0),Up,Math.PI*4,g)-Math.PI*4)<1e-9,"legal tangent touch was treated as an exit");
        Check(Math.Abs(WristMotionLimits.SafeTravel(q,pitchAxis,Math.PI,g,Radians(5))-Radians(95))<1e-9,"travel ignored an inset pitch margin");
        // A 0.06-degree side excursion at 2.4 degrees re-enters before a
        // one-degree probe would notice it. The first exit must still win.
        double radius=Math.Sin(Radians(45))+1e-7,peak=Radians(2.4);var near=Right(g)*(radius*Math.Cos(peak))+Up*Math.Sqrt(1-radius*radius)+Forward(g)*(radius*Math.Sin(peak));
        var narrow=MotionRotation.FromTo(Blade(g),near,Right(g));double expected=peak-Math.Acos(Math.Sin(Radians(45))/radius);
        double safe=WristMotionLimits.SafeTravel(narrow,Up,Radians(5),g);
        Check(Math.Abs(safe-expected)<1e-8,"narrow exit/re-entry skipped the earliest actual blade bound");
        Check(!WristMotionLimits.Contains(MotionRotation.Exp(Up*(safe+1e-4))*narrow,g),"narrow first-exit fixture never left the limits");
        var random=new Random(9381+g.Color);
        for(int trial=0;trial<100;trial++)
        {
            var start=Pose(g,-30+random.NextDouble()*120,-35+random.NextDouble()*70,random.NextDouble()*100);
            var axis=new MotionVector(random.NextDouble()*2-1,random.NextDouble()*2-1,random.NextDouble()*2-1).Unit;double wanted=(trial%2==0 ? 1 : -1)*(Math.PI*.5+random.NextDouble()*Math.PI*2);
            double retained=WristMotionLimits.SafeTravel(start,axis,wanted,g);Check(retained*wanted>=0 && Math.Abs(retained)<=Math.Abs(wanted)+1e-10,"safe travel changed direction or exceeded request");
            for(int p=0;p<=240;p++)
            {var probe=MotionRotation.Exp(axis*(retained*p/240))*start;double pitch,side;WristMotionLimits.Angles(probe,g,out pitch,out side);Check(WristMotionLimits.Contains(probe,g),"returned arc crossed a bound before its endpoint: trial="+trial+" point="+p+" retained="+retained+" pitch="+pitch+" side="+side+" hand="+g.Color);}
            if(Math.Abs(retained)<Math.Abs(wanted)-1e-5)Check(!WristMotionLimits.Contains(MotionRotation.Exp(axis*(retained+Math.Sign(wanted)*1e-5))*start,g),"reported exit was not the maximal first safe arc");
        }
    }
    static int Main()
    {
        try
        {
            for(int hand=0;hand<2;hand++)foreach(double yaw in new[]{0.0,37,-123})foreach(bool offset in new[]{false,true})
            {var g=Geometry(hand,yaw,offset);AngleCases(g);NearestFit(g);Travel(g);}
            bool rejected=false;try{WristMotionLimits.Contains(MotionRotation.Identity,Geometry(0,0,false),-.01);}catch(ArgumentOutOfRangeException){rejected=true;}Check(rejected,"negative margin silently expanded requested bounds");
            Console.WriteLine(checks+" planned wrist-angle / closest-fit / first-exit assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
