using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using SaberMind;
class V14MovementParityTests
{
    static PhraseGeometry Geometry(int hand)
    {return new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};}
    static PhraseState Teacher(double t,int hand,bool human)
    {
        double x=human ? .55+.22*Math.Sin(5*t) : .55;
        return new PhraseState{Time=t,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(x,0,0)),
            AngularVelocity=new MotionVector(human ? 1.1*Math.Cos(5*t) : 0,0,0),AngularAcceleration=new MotionVector(human ? -5.5*Math.Sin(5*t) : 0,0,0),HumanGripWeight=human ? .8 : 0,HumanWristWeight=human ? .8 : 0};
    }
    static double[] Snapshot(PhraseState s)
    {return new[]{s.Time,s.Grip.X,s.Grip.Y,s.Grip.Z,s.Velocity.X,s.Velocity.Y,s.Velocity.Z,s.Acceleration.X,s.Acceleration.Y,s.Acceleration.Z,s.Rotation.X,s.Rotation.Y,s.Rotation.Z,s.Rotation.W,s.AngularVelocity.X,s.AngularVelocity.Y,s.AngularVelocity.Z,s.AngularAcceleration.X,s.AngularAcceleration.Y,s.AngularAcceleration.Z};}
    static List<double[]> Generate()
    {
        var rows=new List<double[]>();
        foreach(int hand in new[]{0,1})foreach(bool human in new[]{false,true})foreach(double spacing in new[]{.75,.3,.125})
        {
            var g=Geometry(hand);Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand,human);};var notes=new List<PhraseNote>();
            for(int i=0;i<3;i++)notes.Add(new PhraseNote{Id=i,Time=.5+i*spacing,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(i%2==0 ? 1 : 0),Forward=new MotionVector(0,0,1),Spacing=spacing,LocalNps=spacing<.2 ? 8 : spacing<.5 ? 4 : 1});
            var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,3.4);
            for(int i=0;i<=100;i++)rows.Add(Snapshot(path.Sample((.56+2*spacing)*i/100)));
            foreach(var n in notes)rows.Add(Snapshot(path.Contact(n.Id)));
        }
        return rows;
    }
    static int Main(string[] args)
    {
        try
        {
            var rows=Generate();
            if(args.Length>1 && args[1]=="write"){File.WriteAllText(args[0],JsonConvert.SerializeObject(rows));Console.WriteLine("Wrote "+rows.Count+" original 1.0.0.14 sampled motion states.");return 0;}
            var expected=JsonConvert.DeserializeObject<List<double[]>>(File.ReadAllText(args[0]));
            if(rows.Count!=expected.Count)throw new Exception("Baseline fixture size changed.");int assertions=0;double max=0;
            for(int i=0;i<rows.Count;i++)for(int j=0;j<rows[i].Length;j++)
            {double e=Math.Abs(rows[i][j]-expected[i][j]);max=Math.Max(max,e);assertions++;if(e>1e-6 || double.IsNaN(e))throw new Exception("Original v14 motion changed at state="+i+" component="+j+" error="+e);}
            Console.WriteLine(assertions+" original v14 motion parity assertions passed; maximum numerical difference="+max.ToString("G4")+".");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
