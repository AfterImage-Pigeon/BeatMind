using System;
using System.Collections.Generic;
using SaberMind;
class PreswingAccelerationTests
{
    static int checks;
    static void Check(bool value,string message){checks++;if(!value)throw new Exception(message);}
    static PhraseGeometry Geometry(int hand)
    {return new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};}
    static Func<double,PhraseState> Teacher(int hand)
    {return delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};};}
    static PhraseNote Note(int hand,int id,double time,int arrow,double spacing)
    {return new PhraseNote{Id=id,Time=time,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(arrow),Forward=new MotionVector(0,0,1),Spacing=spacing,LocalNps=spacing<.2 ? 8 : spacing<.5 ? 4 : 1};}
    static int Main()
    {try{foreach(int hand in new[]{0,1}){SlowDown(hand);foreach(int arrow in new[]{0,1,2,3,4,5,6,7})foreach(double spacing in new[]{1.14,.30,.125,.06})Pattern(hand,arrow,spacing);}Console.WriteLine(checks+" high preparation / progressive acceleration / committed-envelope assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static void SlowDown(int hand)
    {
        var teacher=Teacher(hand);var g=Geometry(hand);var n=Note(hand,0,.5,1,1.14);var notes=new[]{n};
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.5);var c=path.Contact(0);
        Check(c.SwingStart<n.Time-.15,"slow down swing still prepares only just above the note");
        var raised=path.Sample(c.SwingStart);var top=raised.Grip+raised.Rotation.Rotate(g.Top);
        Check(top.Y>n.Center.Y+.85 && raised.Rotation.Rotate(g.Top).Y>.97,"slow down swing did not bring the blade nearly upright above the note");
        var cut=path.Sample(n.Time);
        Check((cut.Grip-teacher(n.Time).Grip).Length<1e-7,"larger preparation moved the whole saber to the note");
        Check(CutSafety.BladeDistance(cut,n.Center,g)<1e-7,"larger preparation lost the fitted note");
        double speed=CutSafety.StrokeFor(n).Speed;
        Check(Math.Abs(cut.AngularVelocity.Length-speed)<1e-7,"larger preparation changed contact swing speed");
        double peak=path.Sample(c.SwingPeak).AngularVelocity.Length;
        Check(c.SwingPeak<n.Time && peak>=speed && peak<speed*1.025,"pre-hit apex changed contact speed or added a large speed spike");
        double prior=0;
        for(int i=0;i<=120;i++)
        {double t=c.SwingStart+(c.SwingPeak-c.SwingStart)*i/120;var s=path.Sample(t);Check(s.AngularVelocity.Length+1e-8>=prior,"approach speed reversed or restarted");Check(s.AngularAcceleration.Length<speed*12,"slow approach accelerated too abruptly");prior=s.AngularVelocity.Length;}
        Check(path.Sample(c.SwingStart+(c.SwingPeak-c.SwingStart)*.25).AngularVelocity.Length<speed*.12,"approach starts at almost full swing speed");
        prior=peak;
        for(int i=0;i<=120;i++)
        {double t=c.SwingPeak+(c.SwingEnd-c.SwingPeak)*i/120;var s=path.Sample(t);Check(s.AngularVelocity.Length<=prior+1e-8,"release speed rose instead of slowing smoothly");prior=s.AngularVelocity.Length;}
        Check(prior<1e-7,"follow-through did not finish its deceleration");
        foreach(double remaining in new[]{.20,.08,.04,.02,.01,.006})
        {
            var seed=path.Sample(n.Time-remaining);seed.Id=-1;n.Committed=c;
            var refreshed=ReplayMotor.Build(seed,notes,g,teacher,9,1.5);var committed=refreshed.Contact(0);
            Check(committed.SwingStart==c.SwingStart && committed.SwingPeak==c.SwingPeak && committed.SwingEnd==c.SwingEnd,"late refresh replaced the original swing clock");
            for(double t=seed.Time+.000001;t<c.SwingEnd;t+=.0008)
            {var a=path.Sample(t);var b=refreshed.Sample(t);Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8,"late refresh snapped or replaced the ongoing swing");Check((a.AngularVelocity-b.AngularVelocity).Length<1e-7 && (a.AngularAcceleration-b.AngularAcceleration).Length<1e-6,"late refresh restarted acceleration or created a new speed peak");}
        }
        n.Committed=null;
    }
    static void Pattern(int hand,int arrow,double spacing)
    {
        var teacher=Teacher(hand);var g=Geometry(hand);var notes=new List<PhraseNote>();
        for(int i=0;i<3;i++)notes.Add(Note(hand,i,.5+i*spacing,arrow,spacing));
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,3.4);
        foreach(var note in notes)
        {
            var c=path.Contact(note.Id);var s=path.Sample(note.Time);
            Check(CutSafety.BladeDistance(s,note.Center,g)<.025,"cadence adjustment lost an otherwise reachable note: hand="+hand+" arrow="+arrow+" spacing="+spacing+" id="+note.Id+" distance="+CutSafety.BladeDistance(s,note.Center,g)+" repairs="+path.StabilityFallbacks);
            Check(MotionVector.Dot(s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top)),note.Direction)>1.5,"cadence adjustment changed cut direction or speed");
            if(!HumanMotionModel.Finite(c.SwingStart))continue;
            foreach(double boundary in new[]{c.SwingStart,c.SwingPeak,note.Time,c.SwingEnd})
            {if(boundary<=.001)continue;const double e=1e-7;var a=path.Sample(boundary-e);var b=path.Sample(boundary+e);var m=path.Sample(boundary);Check(MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length<.0001,"stroke boundary snapped");Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-m.AngularVelocity).Length<.003,"visible wrist motion disagrees with planned acceleration");}
        }
        for(double t=.001;t<notes[notes.Count-1].Time+.06;t+=.003)
        {var s=path.Sample(t);Check(s.AngularVelocity.Length<125.01,"larger swing introduced impossible wrist speed");Check((s.Grip-g.Shoulder).Length<=g.Reach+.001,"larger swing exceeded arm reach");}
    }
}
