using System;
using SaberMind;

class OpeningRegressionTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main()
    {
        try{OneGesturePerRegion();NaturalSpeedAndEarlyCrop();ExactAdoptionUsesPlaybackClock();FirstLookAheadIsOrderIndependent();MissingGestureDoesNotBorrowOrBlock();PastConstraintProbesCannotRewritePublishedPlans();ReadinessCannotChangeSourceDuringAPlan();CapturedTeachersSurviveSourceRevision();CapturedEndingSettlesAllJoints();DistinctBreaksNeverRecycleGestures();Console.WriteLine(checks+" opening/break and playback-clock assertions passed.");return 0;}
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static HumanChartNote[] Chart()
    {return new[]{new HumanChartNote{Time=8,Hand=0,Direction=1},new HumanChartNote{Time=8.5,Hand=1,Direction=0},new HumanChartNote{Time=15,Hand=0,Direction=1},new HumanChartNote{Time=15.5,Hand=1,Direction=0},new HumanChartNote{Time=22,Hand=0,Direction=1},new HumanChartNote{Time=22.5,Hand=1,Direction=0}};}
    static HumanMotionExample Example(HumanPhase phase,double offset)
    {
        var e=new HumanMotionExample{Phase=phase,Duration=1.25,Sequence=(int)phase,Recording="gesture-fixture",Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=phase==HumanPhase.Playing ? new[]{new HumanAnchor{Phase=.52,Hand=0,Direction=1},new HumanAnchor{Phase=.92,Hand=1,Direction=0}} : new HumanAnchor[0]};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {
            double t=e.Duration*p/128,velocity=phase==HumanPhase.Playing ? .005 : .04;
            var s=new PhraseState{Time=t,Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.25+offset+velocity*t,.28),Velocity=new MotionVector(0,velocity,0),Rotation=MotionRotation.Exp(new MotionVector(.05+velocity*t,0,0)),AngularVelocity=new MotionVector(velocity,0,0)};
            HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
        }
        return e;
    }
    static HumanMotionModel Model()
    {
        var m=new HumanMotionModel{Files=1,OptimizerVersion=4,ContextWeight=1,BoundaryWeight=.1};
        for(int p=0;p<5;p++)m.Examples.Add(Example((HumanPhase)p,p*.025));return m;
    }
    static void Same(PhraseState a,PhraseState b,string message)
    {Check((a.Grip-b.Grip).Length<1e-7 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-7 && (a.Velocity-b.Velocity).Length<1e-7 && (a.AngularVelocity-b.AngularVelocity).Length<1e-7,message);}
    static void OneGesturePerRegion()
    {
        var graph=new HumanMotionGraph(Model(),Chart(),null,2);graph.BeginFrame(0);var first=graph.Sample(.25,1);graph.Sample(6,2);
        Check(graph.Choices==1,"opening selected several gestures before the first note");
        for(double t=2;t<7.3;t+=.07)for(int j=0;j<3;j++)
        {var s=graph.Sample(t,j);Check(s.Velocity.Length<1e-8 && s.AngularVelocity.Length<1e-8,"opening restarted or kept waving after its captured gesture");}
        Same(first,graph.Sample(.25,1),"look-ahead rewrote the opening motion");
        graph.Sample(8,1);Check(graph.Phase(8)==HumanPhase.Playing,"opening phase overlaps the first note");
        // The first preparation ends before contact: the playing source is
        // already active at the first note, rather than an opening crossfade.
        var playing=HumanTape.FromExample(Model().Examples[0]).Sample(.65,1);
        Check(Math.Abs(graph.Sample(8,1).Grip.Y-playing.Grip.Y)<1e-7,"opening transition was still active at the first cut");
        var before=graph.Sample(9,1);int chosen=graph.Choices;graph.Sample(14,2);
        Check(graph.Choices==chosen,"one break selected another gesture after the first one");
        for(double t=11;t<14.2;t+=.11)
        {var s=graph.Sample(t,1);Check(s.Velocity.Length<1e-8 && s.AngularVelocity.Length<1e-8,"break gesture repeated instead of settling");}
        graph.Sample(30,2);int later=graph.Choices;Same(before,graph.Sample(9,1),"past break preview recreated a different gesture");Same(first,graph.Sample(.25,1),"past opening preview recreated a different gesture");Check(graph.Choices==later,"preview/reordered sampling reselected a completed gesture");
    }
    static void NaturalSpeedAndEarlyCrop()
    {
        var m=Model();var graph=new HumanMotionGraph(m,Chart(),null,2);graph.BeginFrame(0);
        var s=graph.Sample(.30,1);var source=HumanTape.FromExample(m.Examples[1]).Sample(.30,1);
        Same(s,source,"opening did not play at its recorded speed");
        Same(graph.Sample(8.2,1),HumanTape.FromExample(m.Examples[0]).Sample(.85,1),"playing compressed a 1.25-second source into one second");
        var shortChart=new[]{new HumanChartNote{Time=.90,Hand=0,Direction=1},new HumanChartNote{Time=1.2,Hand=1,Direction=0}};
        var cropped=new HumanMotionGraph(m,shortChart,null,2);cropped.BeginFrame(0);
        Same(cropped.Sample(.08,1),HumanTape.FromExample(m.Examples[1]).Sample(.08,1),"short opening squeezed the whole gesture before an early note");
        cropped.Sample(.9,1);Check(cropped.Choices==2,"short opening repeated before playing began");
    }
    static HumanTape Tape(HumanChartNote[] chart)
    {
        var times=new double[2001];var poses=new float[times.Length*21];
        for(int i=0;i<times.Length;i++)for(int j=0;j<3;j++)
        {double t=times[i]=i*.02;HumanTape.Put(poses,i*21+j*7,new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.2+.02*t,.3),MotionRotation.Exp(new MotionVector(.08*t,0,0)));}
        return new HumanTape(poses,times,chart,"exact-fixture",.97);
    }
    static void ExactAdoptionUsesPlaybackClock()
    {
        var chart=Chart();var handle=new HumanRunHandle();var graph=new HumanMotionGraph(Model(),chart,handle,2);graph.BeginFrame(0);graph.Sample(0,0);graph.Sample(3.4,2);
        var before=graph.Sample(.1,1);handle.Tape=Tape(chart);graph.BeginFrame(.1);
        graph.Sample(3.4,2);Same(before,graph.Sample(.1,1),"future contact request moved the adoption boundary and froze current motion");
        Check((graph.Sample(.20,1).Grip-before.Grip).Length>.0001,"exact adoption froze the entire current hand interval");
        for(int j=0;j<3;j++)Same(graph.Sample(.35,j),handle.Tape.Sample(.35,j),"all joints did not share the same playback adoption clock");
        double h=1e-7;for(int j=0;j<3;j++)
        {var a=graph.Sample(.34-h,j);var b=graph.Sample(.34+h,j);Check((a.Velocity-b.Velocity).Length<1e-4 && (a.AngularVelocity-b.AngularVelocity).Length<1e-4,"exact adoption discarded outgoing momentum");}
    }
    static void FirstLookAheadIsOrderIndependent()
    {
        var chart=Chart();var a=new HumanMotionGraph(Model(),chart,null,2);var b=new HumanMotionGraph(Model(),chart,null,2);
        a.Sample(.1,1);a.Sample(5,2);b.Sample(5,2);Same(a.Sample(.1,1),b.Sample(.1,1),"first future sample started the opening at a future time");
        var tape=Tape(chart);var exact=new HumanMotionGraph(Model(),chart,new HumanRunHandle{Tape=tape},2);exact.Sample(3.4,2);
        for(int j=0;j<3;j++)Same(exact.Sample(.1,j),tape.Sample(.1,j),"ready exact replay froze when the first request was look-ahead");
    }
    static void MissingGestureDoesNotBorrowOrBlock()
    {
        var m=new HumanMotionModel{Files=1,OptimizerVersion=4};m.Examples.Add(Example(HumanPhase.Playing,0));
        var graph=new HumanMotionGraph(m,Chart(),null,2);graph.BeginFrame(0);
        var idle=graph.Sample(.25,1);Check(idle.HumanSource<0,"missing opening borrowed a gameplay gesture");
        Check(graph.Sample(8,1).HumanSource==0,"missing opening prevented later playing motion from being generated");
        var before=graph.Sample(10,1);graph.Sample(20,2);Same(before,graph.Sample(10,1),"missing break restarted or changed on a future preview");
        Check(graph.Sample(15,1).HumanSource==0,"missing break blocked the next playing region");
    }
    static void PastConstraintProbesCannotRewritePublishedPlans()
    {
        var graph=new HumanMotionGraph(Model(),Chart(),null,2);graph.BeginFrame(0);
        Func<double,PhraseState> teacher=delegate(double t){return graph.Sample(t,1);};
        var geometry=new PhraseGeometry{Bottom=new MotionVector(0,0,0),Top=new MotionVector(0,0,1),Grip=new MotionVector(),Reach=1,MinimumReach=.1,Forward=new MotionVector(0,0,1),ShoulderAt=delegate(double t){return graph.Sample(t,0).Grip+new MotionVector(-.15,-.23,0);}};
        var path=ReplayMotor.Build(teacher(0),new PhraseNote[0],geometry,teacher,9,3);
        var planned=new PhraseState[61];var raw=new PhraseState[183];
        for(int i=0;i<61;i++){double t=i*.05;planned[i]=path.Sample(t);for(int j=0;j<3;j++)raw[i*3+j]=graph.Sample(t,j);}
        int choices=graph.Choices;
        foreach(double t in new[]{-.12,-.002,.8,-.11,3.4,-.001})for(int j=0;j<3;j++)graph.Sample(t,j);
        Check(graph.Choices==choices,"constraint probes cleared and reselected an already-published teacher");
        for(int i=0;i<61;i++)
        {double t=i*.05;Same(planned[i],path.Sample(t),"a past shoulder/reach probe changed an already-published plan");for(int j=0;j<3;j++)Same(raw[i*3+j],graph.Sample(t,j),"sample access order changed a planned whole-body trajectory");}
        var fresh=new HumanMotionGraph(Model(),Chart(),null,2);fresh.Sample(-.12,2);Same(graph.Sample(.05,1),fresh.Sample(.05,1),"a negative first probe moved the source epoch before the level start");
    }
    static void ReadinessCannotChangeSourceDuringAPlan()
    {
        var handle=new HumanRunHandle();var graph=new HumanMotionGraph(Model(),Chart(),handle,2);graph.BeginFrame(0);var before=graph.Sample(.15,1);
        handle.Tape=Tape(Chart());graph.Sample(3.4,2);
        Check(!graph.ExactMap && graph.Revision==0,"background replay readiness changed the teacher in the middle of a planning frame");
        Same(before,graph.Sample(.15,1),"source readiness mutated the current plan before a playback boundary");
        graph.BeginFrame(.15);Check(graph.ExactMap && graph.Revision==1,"frame boundary did not publish exactly one source revision");
        graph.BeginFrame(.16);Check(graph.Revision==1,"stable exact replay published a new source revision every frame");
    }
    static void CapturedTeachersSurviveSourceRevision()
    {
        var handle=new HumanRunHandle();var graph=new HumanMotionGraph(Model(),Chart(),handle,2);graph.BeginFrame(0);
        var frozen=graph.Capture(-.65,3.65);var expected=new PhraseState[183];
        for(int i=0;i<61;i++)for(int j=0;j<3;j++)expected[i*3+j]=frozen(i*.05,j);
        var geometry=new PhraseGeometry{Bottom=new MotionVector(0,0,0),Top=new MotionVector(0,0,1),Grip=new MotionVector(),Reach=1,MinimumReach=.1,Forward=new MotionVector(0,0,1),ShoulderAt=delegate(double t){return frozen(t,0).Grip+new MotionVector(-.15,-.23,0);}};
        Func<double,PhraseState> teacher=delegate(double t){return frozen(t,1);};var path=ReplayMotor.Build(teacher(0),new PhraseNote[0],geometry,teacher,9,3);var planned=new PhraseState[61];for(int i=0;i<61;i++)planned[i]=path.Sample(i*.05);
        graph.Sample(30,2);handle.Tape=Tape(Chart());graph.BeginFrame(.15);Check(graph.ExactMap,"capture test did not actually change the live human source");
        for(int i=0;i<61;i++)
        {
            Same(planned[i],path.Sample(i*.05),"source revision changed a published plan whose teacher was captured");
            for(int j=0;j<3;j++)
            {var s=frozen(i*.05,j);var e=expected[i*3+j];Same(s,e,"source adoption/eviction rewrote a captured route");Check((s.Acceleration-e.Acceleration).Length<1e-7 && (s.AngularAcceleration-e.AngularAcceleration).Length<1e-7,"captured route lost its acceleration channels after adoption");}
        }
        var exact=graph.Capture(-.3,3.5);var past=exact(.10,1);var after=exact(.5,1);graph.BeginFrame(15);graph.Sample(20,2);
        Same(past,exact(.10,1),"captured exact adoption lost its preceding graph segment");Same(after,exact(.5,1),"captured exact recording clock followed a later frame update");
    }
    static void CapturedEndingSettlesAllJoints()
    {
        // Starting beyond the chart's ordinary ending region exercises the
        // terminal lazy-settle branch, rather than its long cached hold.
        var m=new HumanMotionModel{Files=1,OptimizerVersion=4};m.Examples.Add(Example(HumanPhase.Celebration,.1));
        var graph=new HumanMotionGraph(m,Chart(),null,2);graph.BeginFrame(200);graph.Sample(200,0);
        var frozen=graph.Capture(200,212);int choices=graph.Choices;
        for(double t=201.25;t<211;t+=.07)for(int j=0;j<3;j++)
        {
            var s=frozen(t,j);Same(s,graph.Sample(t,j),"captured celebration ignored a terminal hand/head settling route");
            if(t>201.85)Check(s.Velocity.Length<1e-8 && s.AngularVelocity.Length<1e-8 && s.Acceleration.Length<1e-8 && s.AngularAcceleration.Length<1e-8,"captured terminal gesture retained nonzero jets after settling");
        }
        Check(choices==1 && graph.Choices==choices,"terminal celebration looped or selected another gesture");
        var normal=new HumanMotionGraph(Model(),Chart(),null,2);normal.BeginFrame(0);var end=normal.Capture(23,160);
        for(int j=0;j<3;j++){var s=end(150,j);Same(s,normal.Sample(150,j),"captured ordinary ending disagreed with its live terminal hold");Check(s.Velocity.Length<1e-8 && s.AngularVelocity.Length<1e-8,"ordinary ending did not retain a zero-motion hold");}
    }
    static void DistinctBreaksNeverRecycleGestures()
    {
        var notes=new System.Collections.Generic.List<HumanChartNote>(Chart());notes.Add(new HumanChartNote{Time=29,Hand=0,Direction=1});notes.Add(new HumanChartNote{Time=29.5,Hand=1,Direction=0});
        var m=Model();m.Examples.Add(Example(HumanPhase.Break,.15));
        var graph=new HumanMotionGraph(m,notes.ToArray(),null,2);graph.BeginFrame(0);
        int first=graph.Sample(9,1).HumanSource,second=graph.Sample(16,1).HumanSource;
        Check(first>=0 && second>=0 && first!=second,"a later break reused a non-playing demonstration already performed in the level");
        var exhausted=graph.Sample(24,1);int choices=graph.Choices;
        Check(exhausted.HumanSource==-1 && exhausted.HumanGripWeight==0 && exhausted.HumanWristWeight==0,"exhausted gestures borrowed/repeated a human sequence instead of an honest idle hold");
        Check(exhausted.Velocity.Length<1e-8 && exhausted.AngularVelocity.Length<1e-8,"exhausted break gestures did not settle");
        graph.Sample(26,2);Check(graph.Choices==choices,"exhausted break kept attempting to select gestures");
        var captured=graph.Capture(23,27);Same(exhausted,captured(24,1),"capturing an exhausted break restored a used gesture");
        // Repetition necessary to play a repeating note pattern remains legal.
        Check(graph.Sample(29,1).HumanSource==0,"gesture uniqueness incorrectly excluded recurring playing patterns");
    }
}
