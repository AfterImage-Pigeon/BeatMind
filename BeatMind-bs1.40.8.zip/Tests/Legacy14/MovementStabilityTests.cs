using System;
using System.Collections.Generic;
using SaberMind;

// A note is already on the recorded blade at contact. Score assistance may
// accelerate its cut locally; it must not rewrite a distant opening gesture.
class MovementStabilityTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseState Human(double t,double first,double spacing,int color)
    {
        double f=Math.PI/spacing,a=.45*Math.Sin(f*(t-first));
        return new PhraseState{Time=t,Grip=new MotionVector(color==0 ? -.3 : .3,1.3,.3),
            Rotation=MotionRotation.Exp(new MotionVector(a,0,0)),
            AngularVelocity=new MotionVector(.45*f*Math.Cos(f*(t-first)),0,0),
            AngularAcceleration=new MotionVector(-.45*f*f*Math.Sin(f*(t-first)),0,0)};
    }
    static int Main()
    {
        try
        {
            foreach(int color in new[]{0,1})foreach(int budget in new[]{3,6,9})foreach(double spacing in new[]{.5,.08})
                LongOpening(color,budget,1.5,spacing);
            foreach(int color in new[]{0,1})LongOpening(color,9,3.0,.5);
            foreach(int color in new[]{0,1})foreach(double speed in new[]{8.0,10.5,12.0})ShoulderCrossing(color,speed);
            ProjectedSeedContinuity();
            ProjectionRoundTrips();
            ProjectedRepairContinuity();
            RepairKeepsScoredContact();
            Console.WriteLine(checks+" localized movement / opening / cut / replan assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void RepairKeepsScoredContact()
    {
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(.2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=1};
        Func<double,PhraseState> teacher=delegate(double t)
        {
            const double sigma=.008;double x=t-.744,angle=1.6*Math.Exp(-x*x/(sigma*sigma));
            return new PhraseState{Time=t,Grip=g.Shoulder+new MotionVector(0,-.2,.35),Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),AngularVelocity=new MotionVector(-2*x/(sigma*sigma)*angle,0,0),AngularAcceleration=new MotionVector((-2/(sigma*sigma)+4*x*x/(sigma*sigma*sigma*sigma))*angle,0,0)};
        };
        var note=new PhraseNote{Id=91,Time=1,Center=teacher(1).Grip+new MotionVector(.15,-.20,.55),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=1,LocalNps=2};
        var seed=ConstrainedReplayTrajectory.Project(teacher(0),g);var path=ReplayMotor.Build(seed,new[]{note},g,teacher,9,2);
        Check(path.StabilityFallbacks>0,"contact-preserving repair fixture did not exercise a real unsafe source interval");
        var hit=path.Sample(note.Time);
        Check(CutSafety.BladeDistance(hit,note.Center,g)<.025,"repair discarded its physically feasible fitted contact");
        Check(!path.Contact(note.Id).LimitedContact,"feasible repaired cut was marked lost");
        Check(MotionVector.Dot(hit.Velocity+MotionVector.Cross(hit.AngularVelocity,hit.Rotation.Rotate(g.Top)),note.Direction)>1,"repair discarded the fitted cut tangent");
        Check((path.Contact(note.Id).TargetDirection-note.Direction).Length<1e-9,"repair dropped contact-direction metadata");
        for(double t=.002;t<2;t+=1.0/240)
        {var s=path.Sample(t);Check(s.Velocity.Length<=18 && s.AngularVelocity.Length<=125,"preserved cut introduced an unsafe transition");}
        const double epsilon=1e-6;var left=path.Sample(1-epsilon);var right=path.Sample(1+epsilon);
        Check((MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/(2*epsilon)-hit.AngularVelocity).Length<.005,"contact repair snapped or lost wrist derivatives at its cut");
    }
    static void ProjectionRoundTrips()
    {
        foreach(bool moving in new[]{false,true})foreach(int color in new[]{0,1})
        {
            var baseShoulder=new MotionVector(color==0 ? -.2 : .2,1.47,.03);
            var sv=new MotionVector(.08,-.025,.013);var sa=new MotionVector(-.02,.007,.012);
            var g=new PhraseGeometry{Reach=.69,MinimumReach=.12,Shoulder=baseShoulder,Forward=new MotionVector(0,0,1)};
            if(moving)g.ShoulderAt=delegate(double t){return baseShoulder+sv*t+sa*(t*t*.5);};
            foreach(double radius in new[]{.045,.10,.118,.12,.1247,.1248,.1249,.40,.675,.6796,.67965,.680,.685,.689,.69,.70,.75,.80})
            {
                const double time=.71;var shoulder=moving ? g.ShoulderAt(time) : baseShoulder;
                var direction=new MotionVector(color==0 ? -.5 : .5,.3,.8).Unit;
                var side=MotionVector.Cross(direction,new MotionVector(0,1,0)).Unit;
                var raw=new PhraseState{Time=time,Grip=shoulder+direction*radius,
                    Velocity=direction*.4+side*.6+(moving ? sv+sa*time : new MotionVector()),
                    Acceleration=direction*.2-side*.1+(moving ? sa : new MotionVector()),
                    Rotation=MotionRotation.Exp(new MotionVector(.3,-.2,.1)),AngularVelocity=new MotionVector(3,1,2),AngularAcceleration=new MotionVector(-2,4,1)};
                var output=ConstrainedReplayTrajectory.Project(raw,g);
                var restored=ConstrainedReplayTrajectory.Project(ConstrainedReplayTrajectory.Unproject(output,g),g);
                Check((restored.Grip-output.Grip).Length<1e-7,"Projection preimage lost a reachable position.");
                Check((restored.Velocity-output.Velocity).Length<.002,"Projection preimage lost linear velocity near a radial limit.");
                Check((restored.Acceleration-output.Acceleration).Length<.03,"Projection preimage lost acceleration near a radial limit.");
                Check(HumanMotionModel.Finite(restored.Grip.X) && HumanMotionModel.Finite(restored.Velocity.X) && HumanMotionModel.Finite(restored.Acceleration.X),"Projection preimage escaped to a non-finite pose or derivative.");
                Check(MotionRotation.Log(restored.Rotation*output.Rotation.Inverse).Length<1e-8 && (restored.AngularVelocity-output.AngularVelocity).Length<1e-8,"Radial preimage altered wrist motion.");
            }
        }
    }
    static void ProjectedRepairContinuity()
    {
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(.2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=1};
        Func<double,PhraseState> teacher=delegate(double t)
        {
            const double sigma=.008,center=.744;double x=t-center,f=Math.Exp(-x*x/(sigma*sigma)),angle=1.6*f;
            double w=-2*x/(sigma*sigma)*angle,a=(-2/(sigma*sigma)+4*x*x/(sigma*sigma*sigma*sigma))*angle;
            return new PhraseState{Time=t,Grip=g.Shoulder+new MotionVector(0,0,.78),Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),AngularVelocity=new MotionVector(w,0,0),AngularAcceleration=new MotionVector(a,0,0)};
        };
        var seed=ConstrainedReplayTrajectory.Project(teacher(0),g);
        var path=ReplayMotor.Build(seed,new PhraseNote[0],g,teacher,9,2.0);
        Check(path.StabilityFallbacks>0,"The deliberately unsafe source pulse didn't exercise the repair bridge.");
        foreach(double t in new[]{1e-8,.24-.000001,.24,.24+.000001,1.76-.000001,1.76,1.76+.000001,1.999999})
        {
            var s=path.Sample(t);const double e=1e-7;var left=path.Sample(Math.Max(0,t-e));var right=path.Sample(t+e);
            Check((s.Grip-seed.Grip).Length<1e-6,"A stability repair applied reach projection twice at a boundary.");
            Check((right.Grip-left.Grip).Length<1e-6,"A stability repair teleported the projected grip.");
            if(t>e)Check(((right.Grip-left.Grip)/(2*e)-s.Velocity).Length<.003,"Repair boundary velocity disagreed with its visible trajectory.");
            Check(HumanMotionModel.Finite(s.Velocity.Length) && HumanMotionModel.Finite(s.AngularVelocity.Length),"Repair generated non-finite derivatives.");
        }
    }
    static void ProjectedSeedContinuity()
    {
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(.2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=1};
        foreach(double radius in new[]{.685,.69,.78})
        {
            Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=g.Shoulder+new MotionVector(0,0,radius)};};
            var seed=ConstrainedReplayTrajectory.Project(teacher(0),g);seed.Time=0;
            var path=ReplayMotor.Build(seed,new PhraseNote[0],g,teacher,9,1.0);
            var after=path.Sample(1e-8);
            Check((after.Grip-seed.Grip).Length<1e-6,"Applying the reach barrier twice teleported an already reachable seed.");
            Check((after.Velocity-seed.Velocity).Length<.001,"Applying the reach barrier twice reset seed velocity.");
        }
    }
    static void ShoulderCrossing(int color,double speed)
    {
        // Reproduces the real 63.43 s failure: a fast but continuous recorded
        // hand passes about 4.7 cm from the inferred shoulder. A broad spherical
        // detour must not inflate its radius and double the source hand speed.
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(color==0 ? -.21 : .21,1.47,.03),
            Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=color};
        var axis=new MotionVector(color==0 ? -6.8 : 6.8,7.5,-2.7).Unit;
        var perpendicular=MotionVector.Cross(axis,new MotionVector(0,0,1)).Unit;
        Func<double,PhraseState> source=delegate(double t)
        {
            return new PhraseState{Time=t,Grip=g.Shoulder+perpendicular*.0468+axis*((t-1)*speed),Velocity=axis*speed,
                Rotation=MotionRotation.Exp(new MotionVector(.2*Math.Sin(t*2),0,0)),
                AngularVelocity=new MotionVector(.4*Math.Cos(t*2),0,0),AngularAcceleration=new MotionVector(-.8*Math.Sin(t*2),0,0)};
        };
        var adapted=ReachTeacher.Adapt(source,g,0,2);
        for(double t=.65;t<1.35;t+=.001)
        {
            var recorded=source(t);var detour=adapted(t);var actual=ConstrainedReplayTrajectory.Project(detour,g);
            Check(actual.Velocity.Length<=18,"A shoulder detour amplified a bounded recorded grip velocity into a whip.");
            Check((actual.Grip-g.Shoulder).Length>=g.MinimumReach-1e-8 && (actual.Grip-g.Shoulder).Length<=g.Reach+1e-8,"Shoulder detour violated physical reach.");
            Check(MotionRotation.Log(detour.Rotation*recorded.Rotation.Inverse).Length<1e-8 &&
                (detour.AngularVelocity-recorded.AngularVelocity).Length<1e-8,"Shoulder safety repair retimed the captured wrist motion.");
            const double e=1e-6;var left=ConstrainedReplayTrajectory.Project(adapted(t-e),g);var right=ConstrainedReplayTrajectory.Project(adapted(t+e),g);
            Check(((right.Grip-left.Grip)/(2*e)-actual.Velocity).Length<.01,"Shoulder detour velocity disagreed with its visible path at "+t+"; difference "+((right.Grip-left.Grip)/(2*e)-actual.Velocity).Length+"; speed "+actual.Velocity.Length+".");
        }
    }
    static void LongOpening(int color,int budget,double first,double spacing)
    {
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Bottom=new MotionVector(),Grip=new MotionVector(),
            Shoulder=new MotionVector(color==0 ? -.2 : .2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=color};
        Func<double,PhraseState> teacher=delegate(double t){return Human(t,first,spacing,color);};
        var notes=new List<PhraseNote>();
        for(int i=0;i<2;i++)notes.Add(new PhraseNote{Id=i,Time=first+i*spacing,
            Center=new MotionVector(color==0 ? -.3 : .3,1.3,1),Direction=new MotionVector(0,i==0 ? -1 : 1,0),
            Forward=g.Forward,Spacing=spacing,LocalNps=2/spacing});
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,budget,Math.Min(3.4,first+spacing+.35));
        for(double t=.001;t<first-.50;t+=.007)
        {
            var actual=path.Sample(t);var recorded=teacher(t);
            Check((actual.Grip-recorded.Grip).Length<.02,"Cut fitting displaced the hand during a distant recorded opening.");
            Check(MotionRotation.Log(actual.Rotation*recorded.Rotation.Inverse).Length<.15,
                "A future scored cut rewrote the wrist gesture more than half a second before the first note.");
            Check(HumanMotionModel.Finite(actual.Grip.X) && Math.Abs(actual.Rotation.Length-1)<1e-8,"Opening produced an invalid pose.");
        }
        foreach(var note in notes)
        {
            if(path.Contact(note.Id)==null)continue;
            var cut=path.Sample(note.Time);var profile=CutSafety.StrokeFor(note);
            Check(CutSafety.BladeDistance(cut,note.Center,g)<.006,"Local stability fix lost an exactly feasible contact.");
            var swingAxis=MotionVector.Cross(cut.Rotation.Rotate(new MotionVector(0,0,1)),note.Direction).Unit;
            Check(MotionVector.Dot(cut.AngularVelocity,swingAxis)>=profile.Speed*.96,"Local stability fix reduced the cut's existing angular-speed floor.");
            var tipVelocity=cut.Velocity+MotionVector.Cross(cut.AngularVelocity,cut.Rotation.Rotate(g.Top));
            Check(MotionVector.Dot(tipVelocity,note.Direction)>1.4,"The blade moved against the note's cut direction.");
            const double e=1e-7;var left=path.Sample(note.Time-e);var right=path.Sample(note.Time+e);
            Check((left.Grip-right.Grip).Length<1e-5 && MotionRotation.Log(left.Rotation*right.Rotation.Inverse).Length<1e-4,"Contact teleported the hand or wrist.");
            Check((left.Velocity-right.Velocity).Length<.01 && (left.AngularVelocity-right.AngularVelocity).Length<.03,"Contact discarded linear or angular momentum.");
            Check((left.Acceleration-right.Acceleration).Length<1 && (left.AngularAcceleration-right.AngularAcceleration).Length<5,"Contact introduced a discontinuous acceleration target.");
        }
        for(double t=.03;t<Math.Min(3.3,first+spacing+.20);t+=.019)
        {
            const double e=1e-6;var state=path.Sample(t);var left=path.Sample(t-e);var right=path.Sample(t+e);
            var velocity=(right.Grip-left.Grip)/(2*e);
            var wrist=MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/(2*e);
            Check((velocity-state.Velocity).Length<.004,"Published grip velocity disagreed with the continuous path.");
            Check((wrist-state.AngularVelocity).Length<.006,"Published wrist angular motion disagreed with the continuous path.");
        }
        if(first<2 && spacing>.1)
        {
            double now=first+.12;var seed=path.Sample(now);seed.Time=now;
            var next=notes[1];next.Committed=path.Contact(next.Id);
            var continued=ReplayMotor.Build(seed,new[]{next},g,teacher,budget,1.0);
            var restart=continued.Sample(now+1e-8);
            Check((restart.Grip-seed.Grip).Length<1e-5 && MotionRotation.Log(restart.Rotation*seed.Rotation.Inverse).Length<1e-5,"Replanning reset the outgoing pose.");
            Check((restart.Velocity-seed.Velocity).Length<.01 && (restart.AngularVelocity-seed.AngularVelocity).Length<.02,"Replanning reset the outgoing motion.");
            Check((restart.Acceleration-seed.Acceleration).Length<1 && (restart.AngularAcceleration-seed.AngularAcceleration).Length<5,"Replanning reset the outgoing acceleration.");
            var oldCut=path.Sample(next.Time);var newCut=continued.Sample(next.Time);
            Check((oldCut.Grip-newCut.Grip).Length<.006 && MotionRotation.Log(oldCut.Rotation*newCut.Rotation.Inverse).Length<.03,"Replanning changed a committed reachable contact.");
        }
    }
}
