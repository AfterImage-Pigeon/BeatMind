using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SaberMind;
class WholeBodyTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static void Reject(Action a,string message){bool rejected=false;try{a();}catch(IOException){rejected=true;}catch(InvalidDataException){rejected=true;}Check(rejected,message);}
    static int Main(string[] args)
    {try{Run(args[0]);Console.WriteLine(checks+" whole-body motion assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static void Text(BinaryWriter w,string s){byte[] b=Encoding.UTF8.GetBytes(s);w.Write(b.Length);w.Write(b);}
    static void Pose(BinaryWriter w,double x,double y,double z,MotionRotation q){w.Write((float)x);w.Write((float)y);w.Write((float)z);w.Write((float)q.X);w.Write((float)q.Y);w.Write((float)q.Z);w.Write((float)q.W);}
    static void Vec(BinaryWriter w,float x,float y,float z){w.Write(x);w.Write(y);w.Write(z);}
    internal static void Write(string path,int score,bool bot,double style)
    {
        using(var f=File.Create(path))using(var w=new BinaryWriter(f))
        {
            string stamp=Path.GetFileNameWithoutExtension(path);stamp=stamp.Substring(stamp.LastIndexOf('-')+1);
            w.Write(0x442d3d69);w.Write((byte)1);w.Write((byte)0);
            foreach(var s in new[]{"0.0","1.40.8",stamp,"test",bot ? "SaberMind" : "Human","steam","OpenVR","Index","Index","hash","song","mapper","ExpertPlus"})Text(w,s);
            w.Write(score);Text(w,"Standard");Text(w,"Default");Text(w,"");w.Write(18f);w.Write(false);w.Write(1.7f);w.Write(0f);w.Write(0f);w.Write(0f);
            w.Write((byte)1);w.Write(2041);
            for(int i=0;i<=2040;i++)
            {
                double t=i/120.0,angle=Math.Sin(t*Math.PI*4)*1.1,celebrate=t>14 ? Math.Min(1,(t-14)*.8) : 0;
                w.Write((float)t);w.Write(120);
                Pose(w,Math.Sin(t)*.018,1.7+Math.Sin(t*1.2)*.012,Math.Sin(t*.7)*.012,MotionRotation.Exp(new MotionVector(Math.Sin(t)*.025,Math.Sin(t*.8)*.045,Math.Sin(t*.6)*.025)));
                Pose(w,-.3-Math.Sin(t*2)*style,1.20+Math.Sin(t*4*Math.PI)*style+celebrate*.75,.25+Math.Cos(t*2)*style,MotionRotation.Exp(new MotionVector(angle,Math.Sin(t*2)*.08,Math.Sin(t)*.10)));
                Pose(w,.3+Math.Sin(t*2)*style,1.20-Math.Sin(t*4*Math.PI)*style+celebrate*.60,.25-Math.Cos(t*2)*style,MotionRotation.Exp(new MotionVector(-angle,Math.Sin(t*2)*-.07,Math.Sin(t)*-.08)));
            }
            w.Write((byte)2);w.Write(80);
            for(int i=0;i<40;i++)for(int hand=0;hand<2;hand++)
            {
                int direction=(i+hand)%2;double t=1+i*.25+(i>=20 ? 3 : 0);
                w.Write(30000+(hand==0 ? 1000 : 2000)+hand*10+direction);w.Write((float)(t+.04));w.Write((float)t);w.Write(0);
                w.Write(true);w.Write(true);w.Write(true);w.Write(false);w.Write(8f);Vec(w,0,direction==0 ? 1 : -1,0);w.Write(hand);w.Write(-.04f);w.Write(0f);Vec(w,0,1,.8f);Vec(w,0,0,1);w.Write(.02f);w.Write(0f);w.Write(1f);w.Write(1f);
            }
        }
    }
    static void Run(string root)
    {
        Directory.CreateDirectory(root);string folder=Path.Combine(root,"replays"),cache=Path.Combine(root,"cache");Directory.CreateDirectory(folder);
        for(int i=0;i<15;i++)Write(Path.Combine(folder,"test-human-"+(1700000000+i)+".bsor"),64000,false,.015+i*.002);
        Write(Path.Combine(folder,"test-low-1700010000.bsor"),61000,false,.02);Write(Path.Combine(folder,"test-bot-1700010001.bsor"),64000,true,.02);
        Write(Path.Combine(folder,"test-exit-song-1700010002.bsor"),64000,false,.02);
        int progress=0;var model=HumanMotionTraining.Load(folder,cache,delegate(string s){progress++;},null);
        Check(model.Valid() && model.Files==15 && model.Rejected==3,"93% / full-run / bot provenance filtering changed");
        Check(model.PointCount()==129,"dense full-pose representation missing");
        Check(model.PhaseCounts[0]>0 && model.PhaseCounts[1]>0 && model.PhaseCounts[2]>0 && model.PhaseCounts[3]+model.PhaseCounts[4]>0,"openings/breaks/endings weren't learned");
        Check(model.PhaseCounts[4]>0,"captured raised-arm celebration wasn't recognized");Check(progress>15 && model.ValidationExamples>0,"real optimization/held-out progress missing");
        Check(model.ContextValidationError<=model.MeanValidationError+1e-12,"calibrated retrieval was worse than the measured generic baseline");
        var warm=HumanMotionTraining.Load(folder,cache,null,null);Check(warm.CachedFiles==18 && warm.Cuts==model.Cuts,"warm cache reread/refit all recordings");
        Check(warm.ContextWeight==model.ContextWeight && warm.BoundaryWeight==model.BoundaryWeight,"warm cache lost measured sequence-selection calibration");
        var replay=HumanReplayLibrary.Read(Path.Combine(folder,"test-human-1700000000.bsor"));var tape=HumanTape.FromReplay(replay,"fixture");
        Check(Math.Abs(tape.Notes[0].Time-1)<1e-6 && Math.Abs(replay.Notes[0].Time-tape.Notes[0].Time-.04)<1e-5,"score-event clock replaced the native chart clock");
        Check(tape.Poses.Length==tape.Times.Length*21,"full simultaneous tracking discarded");
        TestContinuousLearning(model);
        TestFuturePlanningKeepsCurrentMotion();
        var graph=new HumanMotionGraph(model,tape.Notes,new HumanRunHandle{Tape=tape},2);graph.Sample(0,0);
        for(double t=.4;t<16;t+=.091)for(int j=0;j<3;j++)
        {var actual=graph.Sample(t,j);var expected=tape.Sample(t,j);Check((actual.Grip-expected.Grip).Length<.00001 && MotionRotation.Log(actual.Rotation*expected.Rotation.Inverse).Length<.00001,"exact-run opening/break/ending lost recorded motion");}
        Check(graph.ExactMap,"matching full human replay wasn't used");
        var different=(HumanChartNote[])tape.Notes.Clone();different[0]=new HumanChartNote{Time=50,Hand=0,Lane=3,Layer=2,Direction=7};
        var wrong=new HumanChartNote[]{different[0],different[0]};Check(HumanMotionGraph.Align(tape,wrong)==null,"wrong chart replay was played as exact motion");
        var learned=new HumanMotionGraph(model,tape.Notes,null,2);
        for(double t=0;t<16;t+=.019)for(int j=0;j<3;j++){var s=learned.Sample(t,j);Check(HumanMotionModel.Finite(s.Grip.X) && Math.Abs(s.Rotation.Length-1)<1e-6,"learned graph emitted invalid pose");}
        Check(learned.Choices>2 && learned.Searches>learned.Choices,"pattern / boundary-conditioned graph selection absent");
        // Starting shortly before a phase boundary must crop the source clip,
        // not accelerate a complete 2.5-second demonstration into 100 ms.
        var lateGraph=new HumanMotionGraph(model,tape.Notes,null,2);
        for(double t=.779;t<.84;t+=.002)for(int j=0;j<3;j++)Check(lateGraph.Sample(t,j).AngularVelocity.Length<35,"short phase remainder compressed an entire human sequence into a grip whip");
        var joinedGraph=new HumanMotionGraph(model,tape.Notes,null,2);
        joinedGraph.Sample(0,0);
        foreach(double t in new[]{.78,1.78,2.78,3.78})for(int j=0;j<3;j++)
        {
            double h=1e-8;var a=joinedGraph.Sample(t-h,j);var b=joinedGraph.Sample(t+h,j);
            Check((a.Grip-b.Grip).Length<1e-5 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-5,"graph sequence transition jumped to an independent pose");
            Check((a.Velocity-b.Velocity).Length<.001 && (a.AngularVelocity-b.AngularVelocity).Length<.001,"graph transition discarded outgoing velocity or wrist momentum");
            Check((a.Acceleration-b.Acceleration).Length<.05 && (a.AngularAcceleration-b.AngularAcceleration).Length<.10,"graph transition discarded outgoing acceleration");
        }
        TestMotor(tape);
        TestReachBarrier();
        TestShoulderDetours();
        var corrupt=HumanMotionTraining.Read<HumanMotionModel>(Path.Combine(cache,"HumanMotionModel.json.gz"));corrupt.Examples[0].Curve[0]=float.NaN;Check(!corrupt.Valid(),"corrupt tracking accepted");
        corrupt=HumanMotionTraining.Read<HumanMotionModel>(Path.Combine(cache,"HumanMotionModel.json.gz"));corrupt.Examples[0].Kinematics[1]=float.NaN;Check(!corrupt.Valid(),"corrupt temporal derivatives accepted");
        var bad=Path.Combine(root,"bad.bsor");File.WriteAllText(bad,"not a replay");Reject(delegate{HumanReplayLibrary.Read(bad);},"bad replay format accepted");
        Console.WriteLine("Phases: "+string.Join(",",Array.ConvertAll(model.PhaseCounts,delegate(int n){return n.ToString();}))+"; learned boundary weight "+model.BoundaryWeight);
    }
    static void TestShoulderDetours()
    {
        var g=new PhraseGeometry{MinimumReach=.12,Reach=.69,Forward=new MotionVector(0,0,1)};
        var a=new PhraseState{Time=0,Grip=new MotionVector(-.3,0,.025),Velocity=new MotionVector(.5,0,0),AngularVelocity=new MotionVector(0,1,0)};
        var b=new PhraseState{Time=.6,Grip=new MotionVector(.3,0,.025),Velocity=new MotionVector(.5,0,0),Rotation=MotionRotation.Exp(new MotionVector(0,.4,0)),AngularVelocity=new MotionVector(0,1,0)};
        var arc=new ReachTransition(a,b,g);double peak=0;
        for(double t=.001;t<.599;t+=.002)
        {
            var s=arc.Sample(t);peak=Math.Max(peak,s.Velocity.Length);
            Check(s.Grip.Length>=g.MinimumReach-1e-8,"shoulder detour passed through the forbidden reach sphere");
            double h=1e-6;var left=arc.Sample(t-h);var right=arc.Sample(t+h);
            Check(((right.Grip-left.Grip)/(2*h)-s.Velocity).Length<.00001,"spherical hand detour lost analytic velocity");
        }
        Check(peak<5,"shoulder projection amplified a compact pivot into a grip whip");
        foreach(var end in new[]{a,b}){var s=arc.Sample(end.Time);Check((s.Grip-end.Grip).Length<1e-8 && (s.Velocity-end.Velocity).Length<1e-8 && (s.Acceleration-end.Acceleration).Length<1e-7 && (s.AngularVelocity-end.AngularVelocity).Length<1e-8,"arm detour discarded endpoint momentum or wrist rotation");}
        Func<double,PhraseState> source=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(.3*Math.Sin(20*t),.01,.015),Velocity=new MotionVector(6*Math.Cos(20*t),0,0),Acceleration=new MotionVector(-120*Math.Sin(20*t),0,0),Rotation=MotionRotation.Exp(new MotionVector(.4*Math.Sin(3*t),0,0)),AngularVelocity=new MotionVector(1.2*Math.Cos(3*t),0,0),AngularAcceleration=new MotionVector(-3.6*Math.Sin(3*t),0,0)};};
        var adapted=ReachTeacher.Adapt(source,g,.05,1.4);
        for(double t=.05;t<1.4;t+=.003)
        {
            var s=adapted(t);var raw=source(t);
            Check(s.Grip.Length>=g.MinimumReach-1e-8 && s.Velocity.Length<18,"source motion still whipped around the inferred shoulder");
            Check(MotionRotation.Log(s.Rotation*raw.Rotation.Inverse).Length<1e-10 && (s.AngularVelocity-raw.AngularVelocity).Length<1e-10,"an arm reach correction changed recorded wrist timing");
        }
    }
    static void TestFuturePlanningKeepsCurrentMotion()
    {
        var chart=new HumanChartNote[100];for(int i=0;i<chart.Length;i++)chart[i]=new HumanChartNote{Time=.1+i*.1,Hand=i%2};
        var m=new HumanMotionModel{Files=1,OptimizerVersion=4};
        for(int p=0;p<5;p++){var e=ShortExample();e.Phase=(HumanPhase)p;e.Context=HumanContext.Describe(chart,0,.10,e.Phase);if(p==0)e.Anchors=new[]{new HumanAnchor{Phase=.5,Hand=0,Direction=0}};m.Examples.Add(e);}
        var right=ShortExample();right.Anchors=new[]{new HumanAnchor{Phase=.5,Hand=1,Direction=0}};m.Examples.Add(right);
        var graph=new HumanMotionGraph(m,chart,null,2);var before=graph.Sample(.02,1);graph.Sample(3.4,2);int choices=graph.Choices;var after=graph.Sample(.02,1);
        Check(choices>8 && graph.Choices==choices,"look-ahead evicted and reselected the current sequence");
        Check((before.Grip-after.Grip).Length<1e-12 && MotionRotation.Log(before.Rotation*after.Rotation.Inverse).Length<1e-12 && (before.Velocity-after.Velocity).Length<1e-12 && (before.AngularVelocity-after.AngularVelocity).Length<1e-12,"future planning changed the currently displayed human motion");
    }
    static HumanMotionExample ShortExample()
    {
        var e=Example(false);e.Duration=.10;
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {double t=e.Duration*p/128;var s=new PhraseState{Time=t,Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.3+.005*t,.28),Velocity=new MotionVector(0,.005,0),Rotation=MotionRotation.Exp(new MotionVector(.1+.005*t,0,0)),AngularVelocity=new MotionVector(.005,0,0)};HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);}
        return e;
    }
    static void TestReachBarrier()
    {
        var g=new PhraseGeometry{Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1)};
        foreach(double r in new[]{.045,.119,.1247,.1248,.1249,.67,.6796,.67965,.6797,.74})
        {
            var raw=new PhraseState{Time=1,Grip=new MotionVector(r,0,0),Velocity=new MotionVector(.4,.1,0),Acceleration=new MotionVector(.2,-.1,0)};
            var s=ConstrainedReplayTrajectory.Project(raw,g);
            Check(s.Grip.Length>=g.MinimumReach-1e-10 && s.Grip.Length<=g.Reach+1e-10,"articulated reach still needed a later hand-position clamp");
            double h=1e-6;var left=raw.Copy();var right=raw.Copy();left.Grip-=raw.Velocity*h;right.Grip+=raw.Velocity*h;
            var a=ConstrainedReplayTrajectory.Project(left,g);var b=ConstrainedReplayTrajectory.Project(right,g);
            Check(((b.Grip-a.Grip)/(2*h)-s.Velocity).Length<.0001,"reach correction changed position without matching velocity");
        }
    }
    static HumanMotionExample Example(bool reverse)
    {
        var e=new HumanMotionExample{Phase=HumanPhase.Playing,StartTime=2.0,Duration=1.25,Score=.96,Recording="continuous",Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new HumanAnchor[0]};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {
            double t=e.Duration*(reverse ? 128-p : p)/128,x=2*Math.PI*t,sign=reverse ? -1 : 1;
            var s=new PhraseState{Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.3+.025*Math.Sin(x),.3),Rotation=MotionRotation.Exp(new MotionVector(.2*Math.Sin(x),0,0)),
                Velocity=new MotionVector(0,sign*.025*2*Math.PI*Math.Cos(x),0),Acceleration=new MotionVector(0,-.025*4*Math.PI*Math.PI*Math.Sin(x),0),
                AngularVelocity=new MotionVector(sign*.2*2*Math.PI*Math.Cos(x),0,0),AngularAcceleration=new MotionVector(-.2*4*Math.PI*Math.PI*Math.Sin(x),0,0)};
            HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
        }
        return e;
    }
    static void TestContinuousLearning(HumanMotionModel model)
    {
        foreach(var e in model.Examples)
        {
            Check(e.Kinematics.Length==129*36 && HumanMotionModel.Finite(e.StartTime),"sequence time / full derivative channels discarded");
            var tape=HumanTape.FromExample(e);
            foreach(int p in new[]{0,1,64,127,128})for(int j=0;j<3;j++)
            {
                var s=tape.Sample(e.Duration*p/128,j);int k=p*36+j*12;
                Check((s.Velocity-HumanMotionModel.Position(e.Kinematics,k)).Length<.00001 && (s.Acceleration-HumanMotionModel.Position(e.Kinematics,k+3)).Length<.0001,"saved linear derivatives were reconstructed from isolated poses");
                Check((s.AngularVelocity-HumanMotionModel.Position(e.Kinematics,k+6)).Length<.00001 && (s.AngularAcceleration-HumanMotionModel.Position(e.Kinematics,k+9)).Length<.0001,"saved wrist derivatives were discarded at a sequence boundary");
            }
        }
        var forward=Example(false);var reversed=Example(true);
        Check(HumanMotionModel.CurveDistance(forward,forward)<1e-12,"sequence self-distance changed");
        Check(HumanMotionModel.CurveDistance(forward,reversed)>.02,"a reversed bag of the same poses matched continuous human motion");
        var altered=Example(false);for(int i=0;i<altered.Kinematics.Length;i++)altered.Kinematics[i]*=-1;
        Check(HumanMotionModel.CurveDistance(forward.Curve,altered.Curve)<1e-12 && HumanMotionModel.CurveDistance(forward,altered)>.02,"training ignored velocity / acceleration / angular motion");
        Check(HumanMotionModel.BoundaryDistance(forward,altered)>.02,"transition fitting ignored outgoing momentum");
        var curve=HumanTape.FromExample(forward);
        for(double t=.03;t<1.22;t+=.013)
        {
            double h=.000001;var a=curve.Sample(t-h,1);var b=curve.Sample(t+h,1);var s=curve.Sample(t,1);
            Check(((b.Grip-a.Grip)/(2*h)-s.Velocity).Length<1e-6,"continuous position does not integrate its velocity");
            Check(((b.Velocity-a.Velocity)/(2*h)-s.Acceleration).Length<1e-5,"continuous speed does not integrate its acceleration");
            Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*h)-s.AngularVelocity).Length<1e-6,"wrist arc lost angular momentum between poses");
        }
        var outgoing=new PhraseState[3];for(int j=0;j<3;j++){outgoing[j]=curve.Sample(0,j);outgoing[j].Velocity*=1.4;outgoing[j].Acceleration*=1.96;outgoing[j].AngularVelocity*=1.4;outgoing[j].AngularAcceleration*=1.96;}
        Check(HumanMotionModel.BoundaryDistance(forward,outgoing,1.4)<1e-12,"time scaling did not scale velocity and acceleration coherently");
        var incoming=curve.Sample(.6,1);incoming.Time=.3;var prior=curve.Sample(.2,1);prior.Time=0;var transition=new MotionTransition(prior,incoming);
        foreach(double t in new[]{0,.015,.285,.3})
        {
            var s=transition.Sample(t);var expected=t==0 ? prior : t==.3 ? incoming : null;
            if(expected!=null)Check((s.Velocity-expected.Velocity).Length<1e-9 && (s.Acceleration-expected.Acceleration).Length<1e-8 && (s.AngularVelocity-expected.AngularVelocity).Length<1e-9 && (s.AngularAcceleration-expected.AngularAcceleration).Length<1e-8,"temporal join changed the measured endpoint derivatives");
            else{var a=transition.Sample(t-1e-8);var b=transition.Sample(t+1e-8);Check((a.Acceleration-b.Acceleration).Length<.02 && (a.AngularAcceleration-b.AngularAcceleration).Length<.02,"short edge bridge broke acceleration continuity");}
        }
    }
    static void TestMotor(HumanTape tape)
    {
        var g=new PhraseGeometry{Bottom=new MotionVector(0,0,0),Top=new MotionVector(0,0,1),Grip=new MotionVector(),Shoulder=new MotionVector(-.2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.70,MinimumReach=.12,Color=0};
        var notes=new List<PhraseNote>();for(int i=0;i<7;i++)notes.Add(new PhraseNote{Id=i,Time=1+i*.22,Center=new MotionVector(i%3==0 ? -.85 : -.45,1.15+(i%2)*.3,.45),Direction=new MotionVector(0,i%2==0 ? -1 : 1,0),Forward=g.Forward,Spacing=.22,LocalNps=9});
        var seed=tape.Sample(.5,1);seed.Time=.5;
        var phrase=ReplayMotor.Build(seed,notes,g,delegate(double t){return tape.Sample(t,1);},9,2.5);
        Check(phrase.Evaluator!=null && phrase.Knots.Count>notes.Count,"continuous full-recording trajectory missing");
        double maxSpeed=0,maxReach=0;
        for(double t=.5;t<2.99;t+=.001)
        {
            var s=phrase.Sample(t);maxSpeed=Math.Max(maxSpeed,s.Velocity.Length);maxReach=Math.Max(maxReach,(s.Grip-g.Shoulder).Length-g.Reach);
            Check(HumanMotionModel.Finite(s.Acceleration.X) && s.Rotation.Length>.999,"motor invalid pose");
        }
        foreach(var n in notes)
        {
            var cut=phrase.Sample(n.Time);Check(phrase.Contact(n.Id)!=null && CutSafety.ContactFits(cut,n.Center,g,.00001),"contact no longer intersects cube");
            MotionVector blade=cut.Rotation.Rotate(g.Top-g.Grip);MotionVector speed=cut.Velocity+MotionVector.Cross(cut.AngularVelocity,blade);
            Check(MotionVector.Dot(speed,n.Direction)>1,"actual blade velocity doesn't follow the white arrow");
        }
        for(int i=1;i+1<phrase.Knots.Count;i++)
        {
            double t=phrase.Knots[i].Time,e=1e-7;var a=phrase.Sample(t-e);var b=phrase.Sample(t+e);
            Check((a.Grip-b.Grip).Length<.001 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<.001,"position/rotation snapped at a route knot");
            Check((a.Velocity-b.Velocity).Length<.1 && (a.AngularVelocity-b.AngularVelocity).Length<.1,"velocity discontinuity at route knot");
        }
        Console.WriteLine("Motor max grip speed "+maxSpeed+" m/s; reach overshoot "+maxReach+" m");
        Check(maxReach<.04,"large reach overshoot survived validation");Check(maxSpeed<16,"contact retargeting created a grip teleport");
        double now=1.04;var continuing=phrase.Sample(now);continuing.Time=now;
        var remaining=new List<PhraseNote>();foreach(var n in notes)if(n.Time>now){n.Committed=phrase.Contact(n.Id);remaining.Add(n);}
        var next=ReplayMotor.Build(continuing,remaining,g,delegate(double t){return tape.Sample(t,1);},9,1.7);
        var start=next.Sample(now);Check((start.Grip-continuing.Grip).Length<1e-8 && (start.Velocity-continuing.Velocity).Length<1e-8 && MotionRotation.Log(start.Rotation*continuing.Rotation.Inverse).Length<1e-8,"handoff discarded outgoing motion");
        foreach(var n in remaining)if(next.Contact(n.Id)!=null)Check(CutSafety.BladeDistance(next.Contact(n.Id),n.Center,g)<.00001,"replanning changed committed contact");
    }
}
static class WholeBodyTestExtensions { public static int PointCount(this HumanMotionModel m){return m.Examples[0].Curve.Length/HumanMotionModel.Channels;} }
