using System;
using System.Collections;
using System.IO;
using System.Reflection;
using SaberMind;

class ContactScheduleNativeTests
{
    static string game,path;static int checks;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static Assembly Resolve(object sender,ResolveEventArgs args)
    {
        string requested=new AssemblyName(args.Name).Name;
        if(requested==AssemblyName.GetAssemblyName(path).Name)return Assembly.LoadFrom(path);
        foreach(string folder in new[]{"Libs","Plugins",Path.Combine("Beat Saber_Data","Managed")})
        {string file=Path.Combine(game,folder,requested+".dll");if(File.Exists(file))return Assembly.LoadFrom(file);}
        return null;
    }
    static int Run()
    {
        Assembly plugin=typeof(CutSchedule).Assembly;
        Check(Path.GetFullPath(plugin.Location)==path,"tested installed build instead of requested build");
        Type tracked=plugin.GetType("SaberMind.TrackedNote",true);
        var list=(IList)Activator.CreateInstance(typeof(System.Collections.Generic.List<>).MakeGenericType(tracked));
        Action<object,string,object> set=delegate(object o,string field,object value){tracked.GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(o,value);};
        for(int i=0;i<40;i++)
        {
            object note=Activator.CreateInstance(tracked,true);set(note,"Time",(float)(76.8526+i*.06465));set(note,"Color",1);set(note,"Variant",i%2==0 ? 5 : 4);list.Add(note);
        }
        var method=plugin.GetType("SaberMind.Session",true).GetMethod("ResolveContactSchedule",BindingFlags.Static|BindingFlags.NonPublic);
        method.Invoke(null,new object[]{list});
        var property=tracked.GetProperty("HitTime",BindingFlags.Instance|BindingFlags.NonPublic);
        for(int i=0;i<list.Count;i++)
        {
            var note=list[i];double actual=(double)property.GetValue(note,null);
            Check((bool)tracked.GetField("HasScheduledHit",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(note),"native resolver failed to publish hit time");
            Check((int)tracked.GetField("Variant",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(note)==(i%2==0 ? 5 : 4),"native schedule overwrote learned request");
            if(i>0)Check(actual>(double)property.GetValue(list[i-1],null),"native note schedule reversed chart order");
        }
        // Live spawned notes alias this same TrackedNote. Resolving a later
        // preparation choice updates its clock, not a second playback copy.
        set(list[0],"Variant",0);method.Invoke(null,new object[]{list});
        Check(Math.Abs((double)property.GetValue(list[0],null)-(float)76.8526)<1e-10,"native schedule retained stale preparation time");
        Console.WriteLine(checks+" shipped native scheduled-contact assertions passed (no Unity/gameplay execution).");return 0;
    }
    static int Main(string[] args)
    {try{game=args[0];path=Path.GetFullPath(args[1]);AppDomain.CurrentDomain.AssemblyResolve+=Resolve;return Run();}catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}
