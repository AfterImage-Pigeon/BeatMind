using System;
using System.Collections.Generic;
using SaberMind;

class BoundedProductionWristTests
{
    const double Radians=Math.PI/180;
    static int checks,cases,failures;
    static double worstContactError,minimumDirection=1,minimumContactSpeed=double.PositiveInfinity,maximumPlateauError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    static bool Finite(MotionVector value){return Finite(value.X) && Finite(value.Y) && Finite(value.Z);}
    static PhraseGeometry Geometry(int hand,int body)
    {
        double yaw=body==0 ? 0 : 67*Radians,height=body==0 ? 0 : .16;
        var rotation=MotionRotation.Exp(new MotionVector(0,yaw,0));
        return new PhraseGeometry{Top=new MotionVector(0,0,1),Grip=new MotionVector(),
            Shoulder=rotation.Rotate(new MotionVector(hand==0 ? -.14 : .14,1.58+height,-.10)),Forward=rotation.Rotate(new MotionVector(0,0,1)),
            Color=hand,Reach=.90,MinimumReach=.10,StableFastGrip=true,ControlledWrist=true,SwingSpeedScale=1.5};
    }
    static Func<double,PhraseState> Teacher(int hand,int body)
    {
        double yaw=body==0 ? 0 : 67*Radians,height=body==0 ? 0 : .16;
        var frame=MotionRotation.Exp(new MotionVector(0,yaw,0));
        var grip=frame.Rotate(new MotionVector(hand==0 ? -.30 : .30,1.30+height,.22));
        var rotation=frame*MotionRotation.Exp(new MotionVector(-25*Radians,0,0));
        return delegate(double time){return new PhraseState{Time=time,Grip=grip,Rotation=rotation,HumanSource=12,HumanGripWeight=1,HumanWristWeight=1};};
    }
    static List<PhraseNote> Notes(PhraseGeometry g,Func<double,PhraseState> teacher,double spacing,int arrow,bool alternating)
    {
        int[] opposite={1,0,3,2,7,6,5,4};var notes=new List<PhraseNote>();
        var frame=MotionRotation.FromTo(new MotionVector(0,0,1),g.Forward,new MotionVector(0,1,0));var human=teacher(0);
        var center=human.Grip+human.Rotation.Rotate(g.Top-g.Grip)*.67;
        for(int i=0;i<4;i++)
            notes.Add(new PhraseNote{Id=i,Time=.5+spacing*i,Spacing=spacing,LocalNps=1/spacing,ScoringType=1,Center=center,
                Direction=frame.Rotate(HumanContext.Direction(alternating && i%2!=0 ? opposite[arrow] : arrow)),Forward=g.Forward});
        return notes;
    }
    static void Bounds(PhraseState state,PhraseGeometry g,string context,double time)
    {
        double pitch,side;WristMotionLimits.Angles(state.Rotation,g,out pitch,out side);
        Check(pitch>=-40*Radians-1e-9 && pitch<=100*Radians+1e-9,context+": pitch limit violated at "+time+" degrees="+pitch/Radians);
        Check(side>=-45*Radians-1e-9 && side<=45*Radians+1e-9,context+": sideways limit violated at "+time+" degrees="+side/Radians);
        Check(Finite(state.AngularVelocity) && Finite(state.AngularAcceleration),context+": nonfinite angular jets at "+time);
    }
    static double Validate(MotionPhrase path,List<PhraseNote> notes,PhraseGeometry g,string context)
    {
        double start=path.Knots[0].Time,end=path.Knots[path.Knots.Count-1].Time;
        for(double time=start;time<end;time+=.001)Bounds(path.Sample(time),g,context,time);
        Bounds(path.Sample(end),g,context,end);double speedSum=0;
        foreach(var note in notes)
        {
            if(note.Time<=start+.004 || note.Time>=end-.025)continue;
            var contact=path.Contact(note.Id);Check(contact!=null,context+": contact missing at "+note.Time);
            var pose=path.Sample(note.Time);Bounds(pose,g,context,note.Time);
            double error=CutSafety.BladeDistance(pose,note.Center,g);worstContactError=Math.Max(worstContactError,error);
            Check(error<.025,context+": attainable contact missed at "+note.Time+" error="+error);
            var blade=pose.Rotation.Rotate((g.Top-g.Bottom).Unit);var bottom=pose.Rotation.Rotate(g.Bottom-g.Grip);
            double along=MotionVector.Dot(note.Center-pose.Grip-bottom,blade);var lever=bottom+blade*along;
            var velocity=pose.Velocity+MotionVector.Cross(pose.AngularVelocity,lever);var plane=velocity-note.Forward*MotionVector.Dot(velocity,note.Forward);
            double direction=MotionVector.Dot(plane.Unit,note.Direction),contactSpeed=MotionVector.Dot(velocity,note.Direction);
            minimumDirection=Math.Min(minimumDirection,direction);minimumContactSpeed=Math.Min(minimumContactSpeed,contactSpeed);
            Check(plane.Length>=1.5 && direction>.65,context+": contact direction failed at "+note.Time+" alignment="+direction+" planeSpeed="+plane.Length);
            Check(contactSpeed>=1.5-1e-8,context+": contact cut speed failed at "+note.Time+" speed="+contactSpeed);
            Check(contact.SteadyWristMotion && Finite(contact.SwingStart) && Finite(contact.SwingEnd),context+": contact lacks its steady swing envelope");
            double before=note.Time-contact.SwingStart,after=contact.SwingEnd-note.Time;
            Check(before>0 && after>0,context+": steady envelope has no approach/release");
            double width=Math.Min(.060,Math.Min(before,after)*.78);double speed=pose.AngularVelocity.Length;speedSum+=speed;
            Check(speed>1,context+": contact has no wrist pace");
            for(int i=0;i<=20;i++)
            {
                double time=note.Time-width+2*width*i/20;var sample=path.Sample(time);Bounds(sample,g,context,time);
                double difference=(sample.AngularVelocity-pose.AngularVelocity).Length;maximumPlateauError=Math.Max(maximumPlateauError,difference);
                Check(difference<1e-5,context+": wrist slows before/after contact at "+time+" delta="+difference+" plateauHalfWidth="+width);
                Check(sample.AngularAcceleration.Length<.001,context+": constant-speed contact core has angular acceleration at "+time);
            }
        }
        return speedSum/notes.Count;
    }
    static double Sequence(int hand,int body,int arrow,double spacing,bool alternating,bool replan)
    {
        string context="controlled hand="+hand+" body="+body+" arrow="+arrow+" spacing="+spacing+" alternating="+alternating;
        var g=Geometry(hand,body);var teacher=Teacher(hand,body);var notes=Notes(g,teacher,spacing,arrow,alternating);
        double horizon=notes[notes.Count-1].Time+.30;var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,horizon);
        double speed=Validate(path,notes,g,context);
        if(replan)
        {
            foreach(var note in notes)note.Committed=path.Contact(note.Id);
            double time=.10;var seed=path.Sample(time);seed.Id=-1;
            var refreshed=ReplayMotor.Build(seed,notes,g,teacher,9,horizon-time);
            Validate(refreshed,notes,g,context+" committed replan");
            foreach(var note in notes)
            {
                var before=path.Contact(note.Id);var after=refreshed.Contact(note.Id);
                Check(MotionRotation.Log(before.Rotation*after.Rotation.Inverse).Length<1e-8,context+": committed replan moved contact orientation");
                Check((before.AngularVelocity-after.AngularVelocity).Length<1e-6,context+": committed replan changed wrist pace");
                Check((before.AngularAcceleration-after.AngularAcceleration).Length<.001,context+": committed replan changed contact acceleration");
            }
        }
        return speed;
    }
    static void RunCase(Action action,string context)
    {
        cases++;
        try{action();}
        catch(Exception error){failures++;Console.Error.WriteLine("FAIL "+context+": "+error.Message);}
    }
    static int Main()
    {
        foreach(int hand in new[]{0,1})foreach(int body in new[]{0,1})
        {
            double previousSpeed=0;
            foreach(double spacing in new[]{.60,.20,.125,.083333333333})
            {
                double currentSpacing=spacing;
                RunCase(delegate{
                    double speed=Sequence(hand,body,0,currentSpacing,false,currentSpacing==.20);
                    Check(speed>previousSpeed, "denser cadence did not pick up wrist pace: hand="+hand+" body="+body+" spacing="+currentSpacing+" current="+speed+" previous="+previousSpeed);
                    previousSpeed=speed;Console.WriteLine("PACE hand="+hand+" body="+body+" spacing="+currentSpacing+" meanContactRadSec="+speed);
                },"cadence hand="+hand+" body="+body+" spacing="+currentSpacing);
                foreach(int arrow in new[]{0,1,2,3,4,5,6,7})foreach(bool alternating in new[]{false,true})
                {
                    if(arrow==0 && !alternating)continue;
                    int currentArrow=arrow;bool currentAlternating=alternating;
                    RunCase(delegate{Sequence(hand,body,currentArrow,currentSpacing,currentAlternating,currentSpacing==.20 && currentArrow==1 && currentAlternating);},
                        "sequence hand="+hand+" body="+body+" arrow="+currentArrow+" spacing="+currentSpacing+" alternating="+currentAlternating);
                }
            }
        }
        Console.WriteLine(checks+" controlled production wrist assertions across "+cases+" cases; failures="+failures+"; worst contact error="+worstContactError+"m; minimum direction="+minimumDirection+"; minimum cut speed="+minimumContactSpeed+"m/s; maximum contact plateau delta="+maximumPlateauError+"rad/s");
        return failures==0 ? 0 : 1;
    }
}
