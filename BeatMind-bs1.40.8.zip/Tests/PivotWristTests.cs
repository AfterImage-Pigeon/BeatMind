using System;
using System.Collections.Generic;
using SaberMind;

class PivotWristTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseGeometry Geometry(int color)
    {return new PhraseGeometry{Bottom=new MotionVector(0,0,.12),Top=new MotionVector(0,0,1.1),Shoulder=new MotionVector(color==0 ? -.15 : .15,1.47,.025),Reach=.69,MinimumReach=.12,Forward=new MotionVector(0,0,1),Color=color};}
    static int Main()
    {
        try
        {
            foreach(int hand in new[]{0,1})foreach(int direction in new[]{0,1,2,3})CompactPivot(hand,direction);
            foreach(int hand in new[]{0,1})OffsetPivot(hand);
            foreach(int hand in new[]{0,1})Recovery(hand,false);
            foreach(int hand in new[]{0,1})Recovery(hand,true);
            BreakGesture();
            Console.WriteLine(checks+" compact pivot / wrist recovery assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void CompactPivot(int hand,int direction)
    {
        var g=Geometry(hand);double x=hand==0 ? -.3 : .3;
        var human=new PhraseState{Time=1,Grip=new MotionVector(x,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(-.8,0,.1))};
        var note=new PhraseNote{Id=182,Time=1,Center=new MotionVector(x,1.09,.825),Direction=HumanContext.Direction(direction),Forward=g.Forward,Spacing=.4,LocalNps=4};int tested;
        var fit=ReplayMotor.FitContact(human,note,g,null,9,out tested);
        Check((fit.Grip-human.Grip).Length<1e-7,"a feasible held-wrist cut translated the whole saber instead of preserving its grip");
        Check(CutSafety.BladeDistance(fit,note.Center,g)<1e-7,"fixed-pivot rigid contact solve failed to hit the note centre");
        Check(MotionVector.Dot(fit.Velocity+MotionVector.Cross(fit.AngularVelocity,fit.Rotation.Rotate(g.Top-g.Grip)),note.Direction)>1.5,"pivot cut lost its arrow direction / angular cut speed");
        Check(fit.AngularVelocity.Length>=CutSafety.StrokeFor(note).Speed,"compact pivot lowered the existing cut-speed floor");
        Check((fit.Grip-g.Shoulder).Length<=g.Reach,"compact pivot escaped arm reach");
    }
    static void OffsetPivot(int hand)
    {
        var g=Geometry(hand);g.Grip=new MotionVector(.045,-.022,-.04);double x=hand==0 ? -.3 : .3;
        var human=new PhraseState{Time=1,Grip=new MotionVector(x,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(-.8,.2,.1))};
        var note=new PhraseNote{Id=8,Time=1,Center=new MotionVector(x,1.09,.825),Direction=new MotionVector(0,1,0),Forward=g.Forward,Spacing=.4,LocalNps=4};int tested;
        var fit=ReplayMotor.FitContact(human,note,g,null,9,out tested);
        Check((fit.Grip-human.Grip).Length<1e-7 && CutSafety.BladeDistance(fit,note.Center,g)<1e-7,"a non-axial saber socket moved the hand or lost contact");
    }
    static void Recovery(int hand,bool alternate)
    {
        var g=Geometry(hand);double x=hand==0 ? -.3 : .3;
        Func<double,PhraseState> teacher=delegate(double t)
        {
            double angle=2*Math.Sin(10*t+2.4);
            return new PhraseState{Time=t,Grip=new MotionVector(x,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(angle,0,0)),AngularVelocity=new MotionVector(20*Math.Cos(10*t+2.4),0,0),AngularAcceleration=new MotionVector(-200*Math.Sin(10*t+2.4),0,0)};
        };
        var notes=new List<PhraseNote>();for(int i=0;i<3;i++)notes.Add(new PhraseNote{Id=i,Time=.4+i*.4,Center=new MotionVector(x,1.09,.825),Direction=new MotionVector(0,alternate && i%2!=0 ? -1 : 1,0),Forward=g.Forward,Spacing=.4,LocalNps=4});
        var path=ReplayMotor.Build(ConstrainedReplayTrajectory.Project(teacher(0),g),notes,g,teacher,9,1.6);
        double total=0;var before=path.Sample(.4);
        for(double t=.401;t<1.2;t+=.001)
        {
            var s=path.Sample(t);total+=MotionRotation.Log(s.Rotation*before.Rotation.Inverse).Length;before=s;
            Check(s.AngularVelocity.Length<=125,"recovery introduced an unsafe wrist speed");
            const double e=1e-7;var l=path.Sample(t-e);var r=path.Sample(t+e);
            Check((MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.002,"wrist recovery velocity disagrees with the visible rotation at "+t+" hand "+hand+" alternate "+alternate+" error "+(MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length);
        }
        // Full 115/75 scoring arcs plus their reverse recovery legitimately
        // travel farther than the old compact strokes. Detect an extra winding
        // separately from that required out-and-back travel.
        Check(total<4*Math.PI,"repeated cuts contain extra wrist oscillations beyond scored arcs and recovery");
        for(int i=0;i+1<notes.Count;i++)
        {
            double arc=0,signed=0;var initial=path.Sample(notes[i].Time);var prior=initial;
            for(double t=notes[i].Time+.001;t<notes[i+1].Time;t+=.001){var s=path.Sample(t);var step=MotionRotation.Log(s.Rotation*prior.Rotation.Inverse);arc+=step.Length;signed+=step.X;prior=s;}
            var finish=path.Sample(notes[i+1].Time);var finalStep=MotionRotation.Log(finish.Rotation*prior.Rotation.Inverse);signed+=finalStep.X;
            Check(Math.Abs(signed-MotionRotation.Log(finish.Rotation*initial.Rotation.Inverse).X)<.02,"the wrist completed an extra 360 instead of reversing between its scored swings");
            Check(arc<4*Math.PI,"the wrist repeated its recovery path more than once");
        }
        foreach(var note in notes)
        {
            var s=path.Sample(note.Time);Check(CutSafety.BladeDistance(s,note.Center,g)<.025,"recovery moved a scored contact");
            Check(MotionVector.Dot(s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Grip)),note.Direction)>1.5,"recovery changed cut direction or cut speed");
            Check(s.AngularVelocity.Length+1e-7>=CutSafety.StrokeFor(note).Speed,"recovery lowered the learned contact-speed floor");
        }
        // Replan inside the first release. The previous cut is no longer in
        // the next-note list, but its outgoing wrist must still be connected.
        var seed=path.Sample(.57);seed.Id=-1;
        var replanned=ReplayMotor.Build(seed,new[]{notes[1],notes[2]},g,teacher,9,1.0);
        var start=replanned.Sample(seed.Time+1e-8);
        Check(MotionRotation.Log(start.Rotation*seed.Rotation.Inverse).Length<1e-5,"replan snapped its outgoing wrist");
        Check((start.AngularVelocity-seed.AngularVelocity).Length<.001,"replan reset outgoing angular momentum");
        foreach(double t in new[]{.655-.000001,.655,.655+.000001,.715-.000001,.715,.715+.000001})
        {const double e=1e-7;var s=replanned.Sample(t);var l=replanned.Sample(t-e);var r=replanned.Sample(t+e);Check((MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.002,"replan recovery boundary snapped");}
    }
    static void BreakGesture()
    {
        var g=Geometry(1);
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(.3,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(0,0,3*t)),AngularVelocity=new MotionVector(0,0,3)};};
        var path=ReplayMotor.Build(teacher(0),new PhraseNote[0],g,teacher,9,2.8);
        for(double t=.01;t<2.7;t+=.01)
        {var s=path.Sample(t);var human=teacher(t);Check(MotionRotation.Log(s.Rotation*human.Rotation.Inverse).Length<1e-7,"note-free human gesture was replaced by a cut recovery");Check((s.AngularVelocity-human.AngularVelocity).Length<1e-7,"break wrist speed changed");}
    }
}
