using System;
using SaberMind;
class FrameStallTraceTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main()
    {
        try
        {
            var trace=new FrameStallTrace();trace.Begin(1,0,1000,.1,0);trace.TickDuration(2);trace.MoveDuration(3);trace.MoveDuration(4);trace.CollectionDuration(.5);
            trace.Begin(1,5,1000,.105,0);Check(trace.Count==0,"Two saber updates counted as separate frames");trace.Begin(2,40,1000,.14,1);
            var s=trace.At(0);Check(s.GapMilliseconds==40 && s.SongTime==.1,"Gap attributed to wrong frame");Check(s.TickMilliseconds==2 && s.MoveMilliseconds==7 && s.CollectionMilliseconds==.5 && s.Collections==1,"Per-phase stall timings lost");
            trace.Reset();trace.Begin(3,10000,1000,5,1);Check(trace.Count==1,"Pause was recorded as a gameplay stall");
            long t=10000;for(int i=4;i<200;i++){t+=40;trace.Begin(i,t,1000,i*.04,1);}
            Check(trace.Count==64 && trace.Total==197,"Stall trace grew beyond its fixed bound");Check(trace.At(0).SongTime<trace.At(63).SongTime,"Ring lost chronological ordering");
            Check(trace.Summary().Contains("gaps include engine/render time outside AI"),"Trace incorrectly claims AI caused every gap");
            Console.WriteLine(checks+" bounded frame-gap attribution assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
