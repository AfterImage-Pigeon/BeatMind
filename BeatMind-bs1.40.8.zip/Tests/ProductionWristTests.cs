using System;
using System.Collections.Generic;
using SaberMind;

class ProductionWristReviewTests
{
    static int checks;static double maxWError,maxAlphaError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static PhraseGeometry Geometry(int hand,double scale,bool stable,bool offset,bool wide)
    {
        return new PhraseGeometry{Top=new MotionVector(0,0,1),Grip=offset ? new MotionVector(.045,-.022,-.04) : new MotionVector(),
            Shoulder=new MotionVector(hand==0 ? -.15 : .15,wide ? 1.55 : 1.77,wide ? -.10 : -.025),
            Forward=new MotionVector(0,0,1),Reach=wide ? 1.0 : .65,MinimumReach=.12,Color=hand,
            StableFastGrip=stable,SwingSpeedScale=scale};
    }
    static Func<double,PhraseState> IdleTeacher(int hand,double amplitude)
    {
        double x=hand==0 ? -.3 : .3,w=8*Math.PI;
        return delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(x,1.3+amplitude*Math.Sin(w*t),.25),
            Velocity=new MotionVector(0,amplitude*w*Math.Cos(w*t),0),Acceleration=new MotionVector(0,-amplitude*w*w*Math.Sin(w*t),0),
            Rotation=MotionRotation.Exp(new MotionVector(.55,0,0)),HumanSource=12,HumanGripWeight=1,HumanWristWeight=1};};
    }
    static List<PhraseNote> Notes(int hand,double spacing,double nps,bool alternate,bool wide,int count,int arrow=0)
    {
        var notes=new List<PhraseNote>();double x=hand==0 ? -.3 : .3;var opposite=new[]{1,0,3,2,7,6,5,4};
        for(int i=0;i<count;i++)notes.Add(new PhraseNote{Id=i,Time=.5+i*spacing,Center=new MotionVector(wide ? i%2==0 ? -.4 : .4 : x,1.09,.825),
            Direction=HumanContext.Direction(alternate && i%2!=0 ? opposite[arrow] : arrow),Forward=new MotionVector(0,0,1),Spacing=spacing,LocalNps=nps});
        return notes;
    }
    static void Jets(MotionPhrase path,double time,string context)
    {
        const double e=1e-7;var l=path.Sample(time-e);var r=path.Sample(time+e);var m=path.Sample(time);
        double w=(MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*e)-m.AngularVelocity).Length;
        double a=((r.AngularVelocity-l.AngularVelocity)/(2*e)-m.AngularAcceleration).Length;
        maxWError=Math.Max(maxWError,w);maxAlphaError=Math.Max(maxAlphaError,a);
        Check(w<.01,context+": rotation and angular velocity disagree "+w+" at "+time);
        if(a>=.15)
        {
            var finerLeft=path.Sample(time-e*.1);var finerRight=path.Sample(time+e*.1);
            double finer=((finerRight.AngularVelocity-finerLeft.AngularVelocity)/(e*.2)-m.AngularAcceleration).Length;
            Check(finer<a*.15+.001,context+": angular acceleration error does not converge at "+time+" coarse="+a+" fine="+finer);
        }
        else Check(a<.15,context+": angular velocity and acceleration disagree "+a+" at "+time);
        Check((r.AngularVelocity-l.AngularVelocity).Length<.03,context+": wrist speed snaps");
        var halfLeft=path.Sample(time-e*.5);var halfRight=path.Sample(time+e*.5);
        double change=(r.AngularAcceleration-l.AngularAcceleration).Length,halfChange=(halfRight.AngularAcceleration-halfLeft.AngularAcceleration).Length;
        Check(halfChange<change*.60+.001,context+": acceleration has an instantaneous jump at "+time+" full="+change+" half="+halfChange);
    }
    static void GeneratedSpeed(int hand,double spacing,double nps,bool alternate,int arrow=0)
    {
        string context="generated hand="+hand+" spacing="+spacing+" nps="+nps+" alternating="+alternate+" arrow="+arrow;
        var teacher=IdleTeacher(hand,0);var notes=Notes(hand,spacing,nps,alternate,false,3,arrow);
        var baselineGeometry=Geometry(hand,1,false,false,false);var fastGeometry=Geometry(hand,1.5,false,false,false);
        var baseline=ReplayMotor.Build(teacher(0),notes,baselineGeometry,teacher,9,3.4);
        var fast=ReplayMotor.Build(teacher(0),notes,fastGeometry,teacher,9,3.4);
        foreach(var note in notes)
        {
            var old=baseline.Contact(note.Id);var now=fast.Contact(note.Id);
            Check(HumanMotionModel.Finite(old.SwingStart) && HumanMotionModel.Finite(now.SwingStart),context+": fixture did not use generated swing");
            Check((now.AngularVelocity-old.AngularVelocity*1.5).Length<2e-6,context+": actual contact speed did not increase exactly 50%; old="+old.AngularVelocity.Length+" new="+now.AngularVelocity.Length);
            Check(MotionRotation.Log(now.Rotation*old.Rotation.Inverse).Length<1e-10,context+": contact quaternion moved");
            Check(Math.Abs((note.Time-now.SwingStart)*1.5-(note.Time-old.SwingStart))<1e-9,context+": preparation duration was not affine compressed");
            Check(Math.Abs((now.SwingEnd-note.Time)*1.5-(old.SwingEnd-note.Time))<1e-9,context+": release duration was not affine compressed");
            for(int p=0;p<=180;p++)
            {
                double source=old.SwingStart+(old.SwingEnd-old.SwingStart)*p/180;
                double time=note.Time+(source-note.Time)/1.5;
                var a=baseline.Sample(source);var b=fast.Sample(time);
                Check(MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length<2e-8,context+": affine acceleration deleted or changed a scored pose");
                Check((b.AngularVelocity-a.AngularVelocity*1.5).Length<2e-5,context+": accelerated swing changed its velocity waveform");
                Check((b.AngularAcceleration-a.AngularAcceleration*2.25).Length<.001,context+": accelerated swing changed its acceleration waveform");
            }
            var before=BladeSwingScoring.Measure(baseline.Sample,baselineGeometry,note.Time);
            var after=BladeSwingScoring.Measure(fast.Sample,fastGeometry,note.Time);
            Check(!before.BeforeFull || after.BeforeFull,context+": accelerated blade lost a full before-angle rating");
            Check(!before.AfterFull || after.AfterFull,context+": accelerated blade lost a full after-angle rating");
            foreach(double boundary in new[]{now.SwingStart,now.Time,now.SwingEnd})Jets(fast,boundary,context);
            Check(CutSafety.BladeDistance(fast.Sample(note.Time),note.Center,fastGeometry)<.025,context+": hit missed after retime");
        }
        if(spacing==.30 && !alternate && arrow==0)
        {
            var previous=fast;var first=fast.Contact(0);
            foreach(double seedTime in new[]{.10,.20,.30,.35,first.SwingStart-.02,first.SwingStart-.006})
            {
                if(seedTime<=previous.Knots[0].Time || seedTime>=first.SwingStart-.001)continue;
                foreach(var note in notes)note.Committed=previous.Contact(note.Id);
                var seed=previous.Sample(seedTime);seed.Id=-1;
                var refreshed=ReplayMotor.Build(seed,notes,fastGeometry,teacher,9,3.4);
                foreach(var note in notes)
                {
                    var expected=previous.Contact(note.Id);var actual=refreshed.Contact(note.Id);
                    Check((actual.AngularVelocity-expected.AngularVelocity).Length<1e-6,context+": early replan compounded a future committed speed");
                    for(int p=0;p<=90;p++)
                    {
                        double t=expected.SwingStart+(expected.SwingEnd-expected.SwingStart)*p/90;var a=previous.Sample(t);var b=refreshed.Sample(t);
                        Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<2e-8,context+": early replan changed committed scored orientation at seed="+seedTime+" sample="+t);
                    }
                }
                Jets(refreshed,seedTime+.000001,context+" early replan");previous=refreshed;
            }
        }
    }
    static void DenseGrip(int hand,double nps,bool offset,bool wide)
    {
        string context="dense hand="+hand+" nps="+nps+" offset="+offset+" wide="+wide;
        var teacher=IdleTeacher(hand,.045);var g=Geometry(hand,1.5,true,offset,wide);var notes=Notes(hand,1/nps,nps,true,wide,8);
        var seed=ConstrainedReplayTrajectory.Project(teacher(0),g);var path=ReplayMotor.Build(seed,notes,g,teacher,9,3.4);
        double first=notes[0].Time,last=notes[notes.Count-1].Time,maxTipTravel=0;
        var old=path.Sample(first);var oldTip=old.Grip+old.Rotation.Rotate(g.Top-g.Grip);
        for(int p=0;p<=900;p++)
        {
            double time=first+(last-first)*p/900;var s=path.Sample(time);
            Check((s.Grip-seed.Grip).Length<1e-7,context+": whole handle moved through a feasible fixed-pivot run");
            Check(s.Velocity.Length<1e-6 && s.Acceleration.Length<1e-5,context+": teacher bob survived in handle derivatives");
            var tip=s.Grip+s.Rotation.Rotate(g.Top-g.Grip);maxTipTravel=Math.Max(maxTipTravel,(tip-oldTip).Length);oldTip=tip;
            Check((s.Grip-g.Shoulder).Length<=g.Reach+.001,context+": handle escaped reach");
            if(p%30==15)Jets(path,time,context);
        }
        Check(maxTipTravel>.001,context+": stable handle also froze the blade arc");
        foreach(var note in notes)
        {
            var s=path.Sample(note.Time);Check(CutSafety.BladeDistance(s,note.Center,g)<.025,context+": stable pivot missed a compatible note");
            var velocity=s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Grip));
            Check(MotionVector.Dot(velocity,note.Direction)>1.5,context+": fixed pivot lost arrow or cut speed");
        }
        var firstContact=path.Contact(notes[0].Id);
        if(HumanMotionModel.Finite(firstContact.SwingStart))
        {
            var previous=path;
            foreach(double remaining in new[]{.04,.02,.01,.006})
            {
                double time=notes[0].Time-remaining;
                if(time<=firstContact.SwingStart+.00001)continue;
                foreach(var note in notes)note.Committed=previous.Contact(note.Id);
                var refreshSeed=previous.Sample(time);refreshSeed.Id=-1;
                var next=ReplayMotor.Build(refreshSeed,notes,g,teacher,9,3.4);
                foreach(var note in notes)
                {var a=previous.Contact(note.Id);var b=next.Contact(note.Id);Check((a.AngularVelocity-b.AngularVelocity).Length<1e-7,context+": committed replan compounded 50% wrist speed");}
                for(int p=1;p<=80;p++)
                {
                    double t=time+(firstContact.SwingEnd-time)*p/80;var a=previous.Sample(t);var b=next.Sample(t);
                    Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<2e-8,context+": replan changed a committed generated pose");
                    Check((a.AngularVelocity-b.AngularVelocity).Length<2e-6,context+": replan restarted wrist acceleration");
                }
                previous=next;
            }
        }
    }
    static void Measured(int hand)
    {
        var g=Geometry(hand,1,false,false,false);g.Top=new MotionVector(0,0,1.1);g.Bottom=new MotionVector(0,0,.12);g.Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.47,.025);g.Reach=.69;
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(hand==0 ? -.3 : .3,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(2*Math.Sin(8*t),0,0)),AngularVelocity=new MotionVector(16*Math.Cos(8*t),0,0),AngularAcceleration=new MotionVector(-128*Math.Sin(8*t),0,0),HumanSource=3,HumanGripWeight=1,HumanWristWeight=1};};
        var notes=new List<PhraseNote>();foreach(double time in new[]{.8,1.2})
        {var s=teacher(time);var direction=MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top));direction.Z=0;notes.Add(new PhraseNote{Id=notes.Count,Time=time,Center=s.Grip+s.Rotation.Rotate(new MotionVector(0,0,.9)),Direction=direction.Unit,Forward=g.Forward,Spacing=.4,LocalNps=4});}
        var old=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.6);g.SwingSpeedScale=1.5;
        var fast=ReplayMotor.Build(teacher(0),notes,g,teacher,9,1.6);var contacts=new List<PhraseState>();foreach(var n in notes)contacts.Add(old.Contact(n.Id).Copy());
        var clock=new ReplayWristClock(0,1.6,contacts,1.5);
        foreach(var note in notes)
        {
            var a=old.Contact(note.Id);var b=fast.Contact(note.Id);Check(double.IsNaN(a.SwingStart) && double.IsNaN(b.SwingStart),"measured qualified human arc was replaced by generated curve");
            Check((b.AngularVelocity-a.AngularVelocity*1.5).Length<1e-6,"measured contact speed did not increase exactly 50%");
            var score=BladeSwingScoring.Measure(fast.Sample,g,note.Time);Check(score.BeforeFull && score.AfterFull,"retimed measured arc lost native scoring travel");
            Check(CutSafety.BladeDistance(fast.Sample(note.Time),note.Center,g)<1e-7,"retimed measured arc moved contact");
        }
        for(double t=.001;t<1.599;t+=.001)
        {
            double source,rate,acceleration;clock.Map(t,out source,out rate,out acceleration);var a=old.Sample(source);var b=fast.Sample(t);
            Check(MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length<2e-8,"retimed measured orientation path lost a source pose");
            Check((b.AngularVelocity-a.AngularVelocity*rate).Length<2e-6,"retimed measured velocity violated source clock");
            Check((b.AngularAcceleration-a.AngularAcceleration*(rate*rate)-a.AngularVelocity*acceleration).Length<.001,"retimed measured acceleration violated source clock");
            if((int)(t*1000)%31==0)Jets(fast,t,"measured");
        }
        foreach(var note in notes)note.Committed=fast.Contact(note.Id);
        var refreshSeed=fast.Sample(.72);refreshSeed.Id=-1;
        var refreshed=ReplayMotor.Build(refreshSeed,notes,g,teacher,9,1.6);
        foreach(var note in notes)Check((fast.Contact(note.Id).AngularVelocity-refreshed.Contact(note.Id).AngularVelocity).Length<1e-6,"measured committed replan compounded speed");
    }
    static void MixedClockOwnership()
    {
        var source=new PhraseState{Time=.5,Grip=new MotionVector(-.3,1.3,.25),Rotation=MotionRotation.Exp(new MotionVector(.2,-.04,.08)),
            AngularVelocity=new MotionVector(4,-1,.5),AngularAcceleration=new MotionVector(8,-3,2),SwingStart=.30,SwingPeak=.5,SwingEnd=.75,ScoringPrepStart=.30};
        var committed=source.Copy();committed.WristSource=new ContactWristSource(source);committed.WristSpeedScale=1.5;
        committed.AngularVelocity*=1.5;committed.AngularAcceleration*=2.25;
        committed.SwingStart=committed.Time-(committed.Time-source.SwingStart)/1.5;committed.SwingEnd=committed.Time+(source.SwingEnd-committed.Time)/1.5;
        committed.ScoringPrepStart=committed.SwingStart;
        var g=Geometry(0,1.5,false,false,true);g.PlanningStart=.10;
        var prepRotation=MotionRotation.Exp(source.AngularVelocity*(-.5*(source.Time-source.SwingStart)))*source.Rotation;
        foreach(bool previousOverlap in new[]{false,true})foreach(bool nextOverlap in new[]{false,true})foreach(bool spedNeighbour in new[]{false,true})
        {
            string context="mixed-clock previous-overlap="+previousOverlap+" next-overlap="+nextOverlap+" sped="+spedNeighbour;
            var previous=new PhraseState{Time=.10,Rotation=prepRotation,WristSpeedScale=spedNeighbour ? 1.5 : 1,SwingEnd=previousOverlap ? .302 : .290};
            var next=new PhraseState{Time=.85,WristSpeedScale=spedNeighbour ? 1.5 : 1,SwingStart=nextOverlap ? .746 : .760};
            // The accelerated windows fit. Restoring the slower source would
            // encroach on the neighbouring release/preparation in overlap cases.
            Check(committed.SwingStart>previous.SwingEnd && committed.SwingEnd<next.SwingStart,context+": fixture already overlaps its accelerated windows");
            var note=new PhraseNote{Id=0,Time=committed.Time,Committed=committed,NextPose=next};int evaluated;
            var fitted=ReplayMotor.FitContact(source,note,g,previous,9,out evaluated);
            bool retained=spedNeighbour && (previousOverlap || nextOverlap);var expected=retained ? committed : source;
            Check(fitted.WristSpeedScale==(retained ? 1.5 : 1),context+": incorrect source-clock ownership");
            Check((fitted.AngularVelocity-expected.AngularVelocity).Length<1e-12 && (fitted.AngularAcceleration-expected.AngularAcceleration).Length<1e-12,context+": neighbouring owned arc changed the contact jets");
            Check(fitted.SwingStart==expected.SwingStart && fitted.SwingPeak==expected.SwingPeak && fitted.SwingEnd==expected.SwingEnd,context+": preparation/release windows changed clock ownership");
            Check(!Object.ReferenceEquals(fitted,committed) && evaluated==0,context+": committed contact was modified or refitted");
            Check(committed.WristSpeedScale==1.5 && (committed.AngularVelocity-source.AngularVelocity*1.5).Length<1e-12,context+": restoration mutated the published contact");
            Check(previous.SwingEnd==(previousOverlap ? .302 : .290) && next.SwingStart==(nextOverlap ? .746 : .760),context+": restoration modified a neighbouring arc");
        }
        // A six-millisecond gap is reserved around the slower source window,
        // even when its timestamps do not literally overlap the other swing.
        foreach(bool previousSide in new[]{false,true})
        {
            var previous=new PhraseState{Time=.10,Rotation=prepRotation,WristSpeedScale=1.5,SwingEnd=previousSide ? .296 : .290};
            var next=new PhraseState{Time=.85,WristSpeedScale=1.5,SwingStart=previousSide ? .760 : .754};
            Check(previous.SwingEnd<source.SwingStart && next.SwingStart>source.SwingEnd,"mixed-clock margin fixture contains literal overlap");
            int evaluated;var fitted=ReplayMotor.FitContact(source,new PhraseNote{Time=.5,Committed=committed,NextPose=next},g,previous,9,out evaluated);
            Check(fitted.WristSpeedScale==1.5 && fitted.SwingStart==committed.SwingStart && fitted.SwingEnd==committed.SwingEnd,"mixed-clock restoration discarded the neighbour's transition margin");
        }
        // Measured contacts have no generated preparation window. Their actual
        // contact time still owns the wrist: an earlier source release may not
        // reach it or enter its six-millisecond transition margin.
        foreach(double nextTime in new[]{.749,.754,.760})
        {
            string context="mixed-clock measured next contact="+nextTime;
            var next=new PhraseState{Time=nextTime,WristSpeedScale=1,AngularVelocity=new MotionVector(0,29.57,0),HumanSource=7,HumanWristWeight=1};
            Check(double.IsNaN(next.SwingStart) && double.IsNaN(next.SwingEnd),context+": fixture has a generated preparation/release window");
            Check(committed.SwingEnd<next.Time-.006,context+": fixture's accelerated release already reaches the measured contact");
            int evaluated;var fitted=ReplayMotor.FitContact(source,new PhraseNote{Time=.5,Committed=committed,NextPose=next},g,null,9,out evaluated);
            bool retained=nextTime<.756;var expected=retained ? committed : source;
            Check(fitted.WristSpeedScale==(retained ? 1.5 : 1) && fitted.SwingEnd==expected.SwingEnd,context+": source release crossed the measured contact or restoration was unnecessarily blocked");
            Check((fitted.AngularVelocity-expected.AngularVelocity).Length<1e-12 && (fitted.AngularAcceleration-expected.AngularAcceleration).Length<1e-12,context+": source-clock contact jets changed");
            Check(evaluated==0 && next.AngularVelocity.Y==29.57 && double.IsNaN(next.SwingStart),context+": restoration refitted or modified the measured neighbour");
        }
    }
    static void FutureContactDirection(int hand)
    {
        foreach(int arrow in new[]{0,1,2,3,4,5,6,7})
        {
            string context="future contact hand="+hand+" arrow="+arrow;var direction=HumanContext.Direction(arrow);var blade=new MotionVector(0,0,1);
            var swing=MotionVector.Cross(blade,direction).Unit;
            var human=new PhraseState{Time=.5,Grip=new MotionVector(hand==0 ? -.3 : .3,1.3,.25),Rotation=MotionRotation.Identity,
                Velocity=direction*8+blade*3,Acceleration=direction*2,AngularVelocity=-swing*6+blade*.8,AngularAcceleration=-swing*12,HumanSource=3,HumanGripWeight=1,HumanWristWeight=1};
            var note=new PhraseNote{Id=0,Time=.5,Center=human.Grip+blade*.7,Direction=direction,Forward=blade,Spacing=.5,LocalNps=4};
            var g=Geometry(hand,1,false,false,true);int evaluated;var slow=ReplayMotor.FitContact(human,note,g,null,9,out evaluated);
            var slowTip=slow.Velocity+MotionVector.Cross(slow.AngularVelocity,slow.Rotation.Rotate(g.Top-g.Grip));var slowPlane=slowTip-blade*MotionVector.Dot(slowTip,blade);
            Check(slowPlane.Length>=1.5 && MotionVector.Dot(slowPlane.Unit,direction)>.65,context+": baseline fixture did not pass the current contact-plane check");
            var uncheckedFast=slow.Velocity+MotionVector.Cross(slow.AngularVelocity*1.5,slow.Rotation.Rotate(g.Top-g.Grip));uncheckedFast-=blade*MotionVector.Dot(uncheckedFast,blade);
            Check(MotionVector.Dot(uncheckedFast,direction)<0,context+": increasing only angular speed would not reverse the fixture's arrow motion");
            g.SwingSpeedScale=1.5;var fast=ReplayMotor.FitContact(human,note,g,null,9,out evaluated);
            Check((fast.Grip-slow.Grip).Length<1e-12 && MotionRotation.Log(fast.Rotation*slow.Rotation.Inverse).Length<1e-12,context+": future contact validation moved a valid fitted contact");
            Check((fast.Velocity-human.Velocity).Length<1e-12 && (fast.Acceleration-human.Acceleration).Length<1e-12,context+": future arrow safety replaced the measured grip motion");
            Check(Math.Abs(MotionVector.Dot(fast.AngularVelocity,fast.Rotation.Rotate(blade))-.8)<1e-10,context+": future arrow safety discarded measured blade roll");
            foreach(double scale in new[]{1.0,1.5})
            {
                var top=fast.Rotation.Rotate(g.Top-g.Grip);var tip=fast.Velocity+MotionVector.Cross(fast.AngularVelocity*scale,top);var plane=tip-blade*MotionVector.Dot(tip,blade);
                var bottom=fast.Rotation.Rotate(g.Bottom-g.Grip);var forward=fast.Rotation.Rotate(blade);double distance=MotionVector.Dot(note.Center-fast.Grip-bottom,forward);
                var contact=fast.Velocity+MotionVector.Cross(fast.AngularVelocity*scale,bottom+forward*distance);
                Check(plane.Length>=1.5 && MotionVector.Dot(plane.Unit,direction)>.65,context+": fitted wrist cut is unsafe at scale "+scale);
                Check(MotionVector.Dot(contact,direction)>=1.5,context+": fitted blade contact loses direction/speed at scale "+scale);
            }
        }
    }
    static int Main()
    {
        try
        {
            MixedClockOwnership();
            foreach(int hand in new[]{0,1})
            {
                foreach(double spacing in new[]{.30,.20,.125,.083333333333})foreach(bool alternate in new[]{false,true})GeneratedSpeed(hand,spacing,1/spacing,alternate);
                foreach(int arrow in new[]{1,2,3,4,5,6,7})foreach(bool alternate in new[]{false,true})GeneratedSpeed(hand,.125,8,alternate,arrow);
                foreach(double nps in new[]{5.0,8,12,20})DenseGrip(hand,nps,false,false);
                DenseGrip(hand,8,true,false);DenseGrip(hand,8,true,true);Measured(hand);FutureContactDirection(hand);
            }
            Console.WriteLine(checks+" production dense grip / 50% wrist / native arc / committed replan assertions passed; maximum angular velocity/acceleration derivative errors="+maxWError+"/"+maxAlphaError);return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
