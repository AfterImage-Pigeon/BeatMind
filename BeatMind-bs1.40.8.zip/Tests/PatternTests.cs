using System;
using System.Collections.Generic;
using SaberMind;

internal static class PatternTests
{
    private static void Check(bool condition,string message)
    { if(!condition) throw new Exception(message);Console.WriteLine("PASS: "+message); }
    private static PatternEvent Note(double time,int hand,bool dot,double x=0,double y=-1,int lane=-1,int layer=1)
    { return new PatternEvent {Time=time,Hand=hand,Dot=dot,Direction=new PlanarStroke(x,y),Lane=lane<0 ? hand==0 ? 1 : 2 : lane,Layer=layer}; }
    private static bool Close(PlanarStroke actual,double x,double y)
    { PlanarStroke wanted=new PlanarStroke(x,y);return PlanarStroke.Dot(actual,wanted.Unit)>.99999; }
    private static void Main()
    {
        Check(PatternFlow.Analyze(new PatternEvent[0]).Patterns.Length==0,"empty charts are valid");
        var dots=new List<PatternEvent>();
        for(int n=0;n<8;n++) dots.Add(Note(n*.25,0,true));
        PatternAnalysis analysis=PatternFlow.Analyze(dots);
        for(int n=0;n<dots.Count;n++) Check(Close(analysis.Directions[n],0,n%2==0 ? -1 : 1),"same-hand dot "+n+" alternates without resetting down");
        Check(analysis.Patterns[3].Is(MotionPatternKind.Stream) && analysis.Patterns[3].Is(MotionPatternKind.Repeated) &&
            analysis.Patterns[3].Is(MotionPatternKind.DotSequence) && analysis.Patterns[3].Alternation==1,
            "regular alternating dots are recognized as a continuous repeating stream");
        var interleaved=new[] {Note(0,0,true),Note(.1,1,true),Note(.2,1,true),Note(.3,0,true),Note(8,0,true)};
        analysis=PatternFlow.Analyze(interleaved);
        Check(Close(analysis.Directions[0],0,-1) && Close(analysis.Directions[1],0,-1) &&
            Close(analysis.Directions[2],0,1) && Close(analysis.Directions[3],0,1) && Close(analysis.Directions[4],0,-1),
            "hands keep independent stroke phase, including after a long gap");
        analysis=PatternFlow.Analyze(new[] {Note(0,0,false,1,-1),Note(.2,0,true),Note(.4,0,true),Note(.6,0,false,-1,1)});
        Check(Close(analysis.Directions[0],1,-1) && Close(analysis.Directions[1],-1,1) &&
            Close(analysis.Directions[2],1,-1) && Close(analysis.Directions[3],-1,1),
            "dots inherit the actual diagonal swing plane and arrows remain exact");
        analysis=PatternFlow.Analyze(new[] {Note(0,0,true),Note(0,0,true),Note(.2,0,true),Note(.2,0,false,1,0),Note(.4,0,true)});
        Check(Close(analysis.Directions[0],-1,0) && Close(analysis.Directions[1],-1,0) &&
            Close(analysis.Directions[2],1,0) && Close(analysis.Directions[3],1,0) && Close(analysis.Directions[4],-1,0),
            "same-time dot stacks share one stroke, including an arrow after a dot in chart order");
        analysis=PatternFlow.Analyze(new[] {Note(0,0,true),Note(.2,0,true),Note(.4,0,false,1,0)});
        Check(Close(analysis.Directions[0],1,0) && Close(analysis.Directions[1],-1,0),
            "a leading dot run prepares the next arrow using alternating parity");
        analysis=PatternFlow.Analyze(new[] {Note(0,0,true,0,-1,0),Note(.2,0,true,0,-1,1),Note(.4,0,true,0,-1,2)});
        Check(Close(analysis.Directions[0],1,0) && Close(analysis.Directions[1],-1,0),
            "an unanchored lateral dot run uses its travel axis instead of forced vertical strokes");
        var tech=new[] {Note(0,0,false,0,-1,0),Note(.2,0,false,1,0,2),Note(.4,0,false,0,1,0),
            Note(.6,0,false,-1,0,2),Note(.8,0,false,0,-1,0)};
        analysis=PatternFlow.Analyze(tech);
        Check(analysis.Patterns[2].Is(MotionPatternKind.Stream) && analysis.Patterns[2].Is(MotionPatternKind.Tech) &&
            analysis.Patterns[2].Is(MotionPatternKind.Crossover),"rhythmic tech streams and required crossovers are recognized together");
        for(int n=0;n<tech.Length;n++) Check(Close(analysis.Directions[n],tech[n].Direction.X,tech[n].Direction.Y),
            "pattern recognition does not change arrow "+n);
        analysis=PatternFlow.Analyze(new[] {Note(0,0,true),Note(2,0,true),Note(4,0,true),Note(6,0,true)});
        Check(!analysis.Patterns[1].Is(MotionPatternKind.Stream),"isolated dots across breaks are not classified as a stream");
        var transition=new List<PatternEvent> {Note(0,0,false,0,-1)};
        for(int n=1;n<=5;n++) transition.Add(Note(n*.2,0,true));
        transition.Add(Note(1.2,0,false,1,0));
        analysis=PatternFlow.Analyze(transition);
        Check(Close(analysis.Directions[1],0,1),"a new dot run first reverses the previous arrow");
        for(int n=2;n<=5;n++)
        {
            double cosine=PlanarStroke.Dot(analysis.Directions[n],analysis.Directions[n-1].Reverse);
            Check(cosine>=Math.Cos(18.00001*Math.PI/180),"upcoming tech preparation remains bounded at dot "+n);
        }
        Check(Close(analysis.Directions[6],1,0),"upcoming arrow stays exact during dot-axis preparation");
        var hints=new List<PatternEvent>();
        for(int n=0;n<6;n++)
        { PatternEvent note=Note(n*.2,0,true,n<2 ? 0 : 1,n<2 ? -1 : 0);note.HasDirectionHint=true;hints.Add(note); }
        analysis=PatternFlow.Analyze(hints);
        Check(Close(analysis.Directions[0],0,-1) && Close(analysis.Directions[1],0,1),"No Arrows hints cannot force every dot down");
        for(int n=1;n<hints.Count;n++) Check(PlanarStroke.Dot(analysis.Directions[n],analysis.Directions[n-1].Reverse)>=Math.Cos(18.00001*Math.PI/180),
            "No Arrows changes swing plane gradually while maintaining alternation "+n);
        PatternAnalysis again=PatternFlow.Analyze(hints);
        Check(Close(again.Directions[5],analysis.Directions[5].X,analysis.Directions[5].Y),"look-ahead and repeated analysis do not advance dot phase");
    }
}
