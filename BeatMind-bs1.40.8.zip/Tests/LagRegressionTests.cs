using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using Newtonsoft.Json;
using SaberMind;

class LagRegressionTests
{
    static int checks;
    static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static void Equal(MotionVector a,MotionVector b){Check(a.X==b.X && a.Y==b.Y && a.Z==b.Z,"value polynomial changed recorded motion");}
    static PhraseState State(Random rng,double time)
    {
        return new PhraseState{Time=time,Grip=Vector(rng),Velocity=Vector(rng)*9,Acceleration=Vector(rng)*150,Rotation=MotionRotation.Exp(Vector(rng)*3),AngularVelocity=Vector(rng)*65,AngularAcceleration=Vector(rng)*700,HumanSource=3,HumanGripWeight=.6,HumanWristWeight=.8};
    }
    static MotionVector Vector(Random rng){return new MotionVector(rng.NextDouble()*2-1,rng.NextDouble()*2-1,rng.NextDouble()*2-1);}
    static void Polynomials()
    {
        var rng=new Random(1616);
        for(int i=0;i<400;i++)
        {
            var a=State(rng,0);var b=State(rng,.015+rng.NextDouble()*3.5);var old=new LegacyPhraseCurve(a,b);var current=new PhraseCurve(a,b);
            for(int p=0;p<=120;p++)
            {
                double t=b.Time*p/120;var x=old.Sample(t);var y=current.Sample(t);
                Equal(x.Grip,y.Grip);Equal(x.Velocity,y.Velocity);Equal(x.Acceleration,y.Acceleration);Equal(x.AngularVelocity,y.AngularVelocity);Equal(x.AngularAcceleration,y.AngularAcceleration);
                Check(x.Rotation.X==y.Rotation.X && x.Rotation.Y==y.Rotation.Y && x.Rotation.Z==y.Rotation.Z && x.Rotation.W==y.Rotation.W,"curve storage changed wrist angle");
            }
        }
        var left=State(rng,0);var right=State(rng,1);long before=Allocated();
        for(int i=0;i<20000;i++)GC.KeepAlive(new LegacyPhraseCurve(left,right));long oldBytes=Allocated()-before;before=Allocated();
        for(int i=0;i<20000;i++)GC.KeepAlive(new PhraseCurve(left,right));long currentBytes=Allocated()-before;
        Check(currentBytes<oldBytes*.6,"temporary polynomial allocation regression");Console.WriteLine("Curve construction bytes: "+oldBytes+" -> "+currentBytes);
    }
    static void ScoringSteps()
    {
        var g=new PhraseGeometry{Top=new MotionVector(0,0,1)};int probes=0;
        Func<double,PhraseState> teacher=delegate(double t){probes++;return new PhraseState{Time=t,Grip=new MotionVector(-.3,1.3,.3),Rotation=MotionRotation.Exp(new MotionVector(4*Math.Sin(t*7),0,0))};};
        var expected=BladeSwingScoring.Measure(teacher,g,1,120);SwingScoreArc actual=new SwingScoreArc();
        var iterator=BladeSwingScoring.MeasureSteps(teacher,g,1,120,delegate(SwingScoreArc score){actual=score;}).GetEnumerator();int steps=0;
        while(true){int before=probes;bool more=iterator.MoveNext();Check(probes-before<=1,"one scoring work item still samples the whole replay window");if(!more)break;steps++;}
        Check(steps>2,"scored window was not incrementally evaluated");Check(expected.BeforeDegrees==actual.BeforeDegrees && expected.AfterDegrees==actual.AfterDegrees,"incremental scoring changed angle ratings");
        Check(expected.Start.Equals(actual.Start) && expected.End.Equals(actual.End),"incremental scoring changed protected release timing");
    }
    static void GatedCache(string folder)
    {
        Directory.CreateDirectory(folder);string path=Path.Combine(folder,"ordered.json.gz");var input=new double[80000];var rng=new Random(42);for(int i=0;i<input.Length;i++)input[i]=rng.NextDouble();HumanMotionTraining.Write(path,input);
        double[] output=null;Exception failure=null;int gates=0;var blocked=new ManualResetEvent(false);var release=new ManualResetEvent(false);
        var worker=new Thread(delegate(){try{output=HumanMotionTraining.Read<double[]>(path,delegate{if(++gates==3){blocked.Set();if(!release.WaitOne(5000))throw new Exception("gate timeout");}});}catch(Exception e){failure=e;}});worker.IsBackground=true;worker.Start();
        Check(blocked.WaitOne(5000),"in-flight cached decoding did not reach an inner idle checkpoint");Check(output==null && worker.IsAlive && gates==3,"decoding continued while playback owns the idle gate");release.Set();Check(worker.Join(5000),"cached decoder did not resume");if(failure!=null)throw failure;
        Check(JsonConvert.SerializeObject(input)==JsonConvert.SerializeObject(output),"idle checkpoint changed learned data");Check(gates>3,"only file entry was gated");
        int writes=0;HumanMotionTraining.Write(path,input,delegate{writes++;});Check(writes>3,"model serialization can still run an entire write without an idle checkpoint");
        var reread=HumanMotionTraining.Read<double[]>(path);Check(JsonConvert.SerializeObject(input)==JsonConvert.SerializeObject(reread),"checkpointed write changed persisted learning");blocked.Dispose();release.Dispose();
    }
    static void WarmCache(string folder)
    {
        var example=new HumanMotionExample{Duration=1,Recording="trusted",Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new HumanAnchor[0]};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)HumanTape.Put(example.Curve,p*21+j*7,new MotionVector(j*.2,1.3,.3),MotionRotation.Identity);
        var model=new HumanMotionModel{Files=1,Cuts=1,LearningPoseSamples=129,LearningBudgetVersion=HumanMotionTraining.LearningBudgetVersion,AvailableSequences=1,OptimizerVersion=4,Fingerprint="previous source inventory",PhaseCounts=new[]{1,0,0,0,0}};
        model.Examples.Add(example);model.Recordings.Add(new HumanRecording{Path="trusted.bsor",Identity="trusted",Accuracy=.95,Frames=100,Notes=2});Check(model.Valid(),"cached-model fixture was not eligible");
        string cache=Path.Combine(folder,"warm");Directory.CreateDirectory(cache);HumanMotionTraining.Write(Path.Combine(cache,"HumanMotionModel.json.gz"),model);HumanMotionModel ready=null;
        var refreshed=HumanMotionTraining.LoadFiles(new string[0],cache,null,null,null,delegate(HumanMotionModel cached){ready=cached;});
        Check(ready!=null && ready.Valid(),"changed inventory hid a completed valid model until all new replay learning finished");
        Check(!refreshed.Valid(),"empty refresh fabricated a replacement model");Check(JsonConvert.SerializeObject(model)==JsonConvert.SerializeObject(ready),"early cached availability changed learned parameters or demonstrations");
    }
    static int Main(string[] args){try{Polynomials();ScoringSteps();GatedCache(args[0]);WarmCache(args[0]);Console.WriteLine(checks+" lag / exact movement parity / replay gating assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
