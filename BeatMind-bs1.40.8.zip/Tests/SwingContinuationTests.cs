using System;
using SaberMind;

class SwingContinuationTests
{
    static int checks;
    static void Check(bool condition,string message)
    {checks++;if(!condition)throw new Exception(message);}
    static void Near(double actual,double expected,string message)
    {Check(Math.Abs(actual-expected)<1e-10,message);}

    static PhraseState Recorded(double time)
    {
        double elapsed=time-.8;
        return new PhraseState{Time=time,Grip=new MotionVector(-.25,1.3+.2*elapsed,.3),
            Velocity=new MotionVector(0,.2,0),Rotation=MotionRotation.Exp(new MotionVector(12*elapsed,0,0)),
            AngularVelocity=new MotionVector(12,0,0)};
    }
    static MotionPhrase Published()
    {
        var phrase=new MotionPhrase{Evaluator=Recorded};
        phrase.Knots.Add(Recorded(.8));
        var contact=Recorded(1);contact.Id=21;contact.ScoringReleaseEnd=1.185;
        contact.SwingStart=.85;contact.SwingPeak=1;contact.SwingEnd=1.185;
        phrase.Knots.Add(contact);phrase.Knots.Add(Recorded(1.7));return phrase;
    }
    static MotionPhrase Replacement(MotionPhrase previous,double now,double until)
    {
        var phrase=new MotionPhrase{Evaluator=Recorded};phrase.Knots.Add(Recorded(until));
        var next=Recorded(1.5);next.Id=22;phrase.Knots.Add(next);
        phrase.CarryFrom(previous,now,until);return phrase;
    }

    static void EarlyContact()
    {
        var previous=Published();double actual=.957;
        foreach(double now in new[]{actual,.98,1.04,1.11,1.175})
        {
            double until=SwingContinuation.ReleaseUntil(previous,now,21,actual,1.5);
            Near(until,1.185,"early-cut/replan truncated the selected stroke's release");
            var replacement=Replacement(previous,now,until);
            for(double t=now;t<until;t+=.0025)
            {
                var old=previous.Sample(t);var played=replacement.Sample(t);
                Check((old.Grip-played.Grip).Length<1e-12,"release changed hand trajectory after note removal");
                Check(MotionRotation.Log(old.Rotation*played.Rotation.Inverse).Length<1e-10,"release rotation stopped or snapped");
                Check((old.AngularVelocity-played.AngularVelocity).Length<1e-12,"release lost wrist momentum");
                Check((old.Acceleration-played.Acceleration).Length<1e-12,"release changed acceleration");
            }
            var outgoing=previous.Sample(until-.000001);var incoming=replacement.Sample(until+.000001);
            Check(MotionRotation.Log(outgoing.Rotation*incoming.Rotation.Inverse).Length<.000025,"handoff snapped at release endpoint");
            Check((outgoing.AngularVelocity-incoming.AngularVelocity).Length<1e-12,"handoff changed angular speed");
        }
        Near(SwingContinuation.ReleaseUntil(previous,1.2,21,actual,1.5),1.2,"completed release continued retaining old route");
    }
    static void OwnershipAndPriority()
    {
        var previous=Published();
        Near(SwingContinuation.ReleaseUntil(previous,.98,-1,double.NaN,1.5),.98,"uncut upcoming contact acquired release ownership");
        Near(SwingContinuation.ReleaseUntil(previous,1.04,-1,double.NaN,1.5),1.185,"scheduled contact lost release during revision change");
        Near(SwingContinuation.ReleaseUntil(previous,.96,21,.957,1.1),1.095,"release postponed next hit");
        Check(1.1>1.095+.004,"carry removed the upcoming note at its contact guard");
        Near(SwingContinuation.ReleaseUntil(previous,1.097,21,.957,1.1),1.097,"nearby next contact made carry time move backwards");
        Near(SwingContinuation.ReleaseUntil(previous,.96,21,1.01,1.5),.96,"future cut timestamp owned current route");
        Near(SwingContinuation.ReleaseUntil(previous,.96,21,.4,1.5),.96,"stale cut timestamp retained old route");
        var carried=Replacement(previous,.957,1.185);
        Near(SwingContinuation.ReleaseUntil(carried,1.02,21,.957,1.5),1.185,"second replan lost carried cut contact");
        Near(SwingContinuation.NextContactTime(carried,.96,21),1.5,"pending resolved note was selected as next contact");
        previous.Contact(21).ScoringReleaseEnd=double.NaN;
        Near(SwingContinuation.ReleaseUntil(previous,.96,21,.957,1.5),1.185,"committed swing window was ignored when scoring metadata absent");
        previous.Contact(21).ScoringReleaseEnd=6;
        Near(SwingContinuation.ReleaseUntil(previous,.96,21,.957,1.5),.96,"invalid multi-second scoring envelope retained old route");
        Near(SwingContinuation.ReleaseUntil(null,1.04,21,1,1.5),1.04,"missing previous route changed clock");
    }
    static int Main()
    {
        try{EarlyContact();OwnershipAndPriority();Console.WriteLine(checks+" swing continuation assertions passed.");return 0;}
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
