using System;
using SaberMind;
class V14FasterSwingTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseState Teacher(double t,int hand)
    {return new PhraseState{Time=t,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};}
    static PhraseGeometry Geometry(int hand,double speed)
    {return new PhraseGeometry{SwingSpeedScale=speed,Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};}
    static PhraseNote Note(int hand,int arrow)
    {return new PhraseNote{Id=0,Time=.5,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(arrow),Forward=new MotionVector(0,0,1),Spacing=1.14,LocalNps=1};}
    static int Main()
    {
        try
        {
            foreach(int hand in new[]{0,1})foreach(int arrow in new[]{0,1,2,3,4,5,6,7})
            {
                Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand);};var n=Note(hand,arrow);
                var original=ReplayMotor.Build(teacher(0),new[]{Note(hand,arrow)},Geometry(hand,1),teacher,9,1.5);
                var boosted=ReplayMotor.Build(teacher(0),new[]{n},Geometry(hand,1.5),teacher,9,1.5);
                var a=original.Contact(0);var b=boosted.Contact(0);
                Check(a.Time==b.Time,"Boost changed cut time");Check((a.Grip-b.Grip).Length<1e-8,"Boost changed contact grip");
                Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8,"Boost changed fitted contact rotation");
                Check(Math.Abs(b.AngularVelocity.Length/a.AngularVelocity.Length-1.5)<1e-8,"Contact speed is not 50% faster");
                Check(Math.Abs((a.Time-a.SwingStart)/(b.Time-b.SwingStart)-1.5)<1e-8,"Preparation clock compounded the speed boost");
                Check(Math.Abs((a.SwingEnd-a.Time)/(b.SwingEnd-b.Time)-1.5)<1e-8,"Follow-through clock changed arc size");
                Check(CutSafety.BladeDistance(boosted.Sample(n.Time),n.Center,Geometry(hand,1.5))<1e-7,"Boost changed a reachable contact");
                for(int i=0;i<=150;i++)
                {
                    double t=b.SwingStart+(b.SwingEnd-b.SwingStart)*i/150;
                    var slow=original.Sample(a.Time+(t-b.Time)*1.5);var fast=boosted.Sample(t);
                    Check(MotionRotation.Log(slow.Rotation*fast.Rotation.Inverse).Length<1e-7,"Boost changed the original progressive swing shape");
                    Check((fast.AngularVelocity-slow.AngularVelocity*1.5).Length<1e-6,"Boost introduced a speed plateau or lag");
                    Check((fast.AngularAcceleration-slow.AngularAcceleration*2.25).Length<1e-5,"Boost changed the normalized acceleration envelope");
                }
                foreach(double remaining in new[]{.08,.04,.02,.01,.006})
                {
                    n.Committed=b;var seed=boosted.Sample(n.Time-remaining);seed.Id=-1;
                    var refreshed=ReplayMotor.Build(seed,new[]{n},Geometry(hand,1.5),teacher,9,1.5);var c=refreshed.Contact(0);
                    Check(c.SwingStart==b.SwingStart && c.SwingEnd==b.SwingEnd && c.SwingPeak==b.SwingPeak,"Committed replan changed the 50% clock");
                    for(double t=seed.Time+1e-6;t<b.SwingEnd;t+=.002)
                    {var before=boosted.Sample(t);var after=refreshed.Sample(t);Check(MotionRotation.Log(before.Rotation*after.Rotation.Inverse).Length<1e-8,"Replan snapped an active wrist");Check((before.AngularVelocity-after.AngularVelocity).Length<1e-6,"Replan multiplied speed twice");}
                }
                var human=teacher(n.Time);human.HumanWristWeight=.8;human.AngularVelocity=new MotionVector(-2,.2,.1);human.AngularAcceleration=new MotionVector(.4,.6,.8);int tested;
                n.Committed=null;var normal=ReplayMotor.FitContact(human,n,Geometry(hand,1),teacher(0),9,out tested);
                var faster=ReplayMotor.FitContact(human,n,Geometry(hand,1.5),teacher(0),9,out tested);
                Check((normal.Grip-faster.Grip).Length<1e-8 && MotionRotation.Log(normal.Rotation*faster.Rotation.Inverse).Length<1e-8,"Human replay contact fitting changed beyond speed");
                Check((faster.AngularVelocity-normal.AngularVelocity*1.5).Length<1e-8 && (faster.AngularAcceleration-normal.AngularAcceleration*2.25).Length<1e-8,"Human replay contact speed jets were not scaled coherently");
                Check((faster.Velocity-normal.Velocity*1.5).Length<1e-8 && (faster.Acceleration-normal.Acceleration*2.25).Length<1e-8,"Hand and wrist were accelerated independently");
            }
            CounterbalancedCut();
            Console.WriteLine(checks+" v14 50% speed / arc shape / contact time / committed replan assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void CounterbalancedCut()
    {
        var human=Teacher(.5,0);human.Rotation=MotionRotation.Exp(new MotionVector(1.264,0,0));human.HumanWristWeight=.8;
        human.Velocity=new MotionVector(0,-5.5,0);human.AngularVelocity=new MotionVector(-12,0,0);
        var n=Note(0,1);n.Center=human.Grip+human.Rotation.Rotate(new MotionVector(0,0,.75));int tested;
        var normal=ReplayMotor.FitContact(human,n,Geometry(0,1),Teacher(0,0),9,out tested);
        var faster=ReplayMotor.FitContact(human,n,Geometry(0,1.5),Teacher(0,0),9,out tested);
        var v=normal.Velocity+MotionVector.Cross(normal.AngularVelocity,normal.Rotation.Rotate(Geometry(0,1).Top));
        var boosted=faster.Velocity+MotionVector.Cross(faster.AngularVelocity,faster.Rotation.Rotate(Geometry(0,1).Top));
        Check(MotionVector.Dot(v,n.Direction)>1.5,"Counterbalanced cut fixture is invalid");
        Check((boosted-v*1.5).Length<1e-8,"Speed boost reverses a human hand/wrist counterbalanced cut");
    }
}
