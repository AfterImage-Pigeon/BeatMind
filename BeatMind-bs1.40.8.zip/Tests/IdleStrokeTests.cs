using System;
using System.Collections.Generic;
using SaberMind;

class IdleStrokeTests
{
    static int checks;
    static void Check(bool ok,string why){checks++;if(!ok)throw new Exception(why);}
    static int Main()
    {
        try
        {
            foreach(int hand in new[]{0,1})foreach(int direction in new[]{0,1,2,3,4,5,6,7})
                foreach(double spacing in new[]{1.14,.30,.125})Stroke(hand,direction,spacing);
            Console.WriteLine(checks+" idle-source swing / contact / pivot / continuity assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void Stroke(int hand,int direction,double spacing)
    {
        double x=hand==0 ? -.3529 : .3529;
        var g=new PhraseGeometry{Bottom=new MotionVector(),Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};
        Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(x,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};};
        var notes=new List<PhraseNote>();
        for(int i=0;i<2;i++)notes.Add(new PhraseNote{Id=i,Time=.5+i*spacing,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(direction),Forward=g.Forward,Spacing=spacing,LocalNps=spacing<.2 ? 8 : spacing<.5 ? 4 : 1});
        var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,2.5);
        foreach(var note in notes)
        {
            double half=CutSafety.StrokeFor(note).HalfSwing;
            var cut=path.Sample(note.Time);var a=path.Sample(note.Time-half);var b=path.Sample(note.Time+half);
            Check(CutSafety.BladeDistance(cut,note.Center,g)<.025,"idle stroke lost its fitted contact");
            Check((cut.Grip-teacher(note.Time).Grip).Length<1e-7,"idle stroke translated the whole saber");
            Check(cut.AngularVelocity.Length>=CutSafety.StrokeFor(note).Speed-1e-7,"idle stroke changed peak cut speed");
            Check(MotionRotation.Log(cut.Rotation*a.Rotation.Inverse).Length>.35*half*cut.AngularVelocity.Length,"idle source has no actual pre-swing; only a contact velocity spike");
            Check(MotionRotation.Log(b.Rotation*cut.Rotation.Inverse).Length>.35*half*cut.AngularVelocity.Length,"idle source lost follow-through");
            for(double t=note.Time-half+.001;t<note.Time+half;t+=.001)
            {
                var s=path.Sample(t);const double e=1e-5;var l=path.Sample(t-e);var r=path.Sample(t+e);
                double error=(MotionRotation.Log(r.Rotation*l.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length;
                Check(error<.002,"idle stroke rotation/velocity disagree hand="+hand+" direction="+direction+" spacing="+spacing+" t="+t.ToString("R")+" error="+error+" repairs="+path.StabilityFallbacks);
                Check(s.AngularVelocity.Length<=125,"idle stroke introduced excessive wrist speed");
            }
            foreach(double offset in new[]{-.03,-.01,.01,.03})
            {
                if(Math.Abs(offset)>=half*.7)continue;
                var s=path.Sample(note.Time+offset);var velocity=MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Grip))+s.Velocity;
                velocity-=g.Forward*MotionVector.Dot(velocity,g.Forward);
                Check(velocity.Length>1.5,"idle stroke stays below valid cut speed near note arrival");
                Check(MotionVector.Dot(velocity.Unit,note.Direction)>.5,"idle stroke reverses during contact window");
            }
        }
        // Retain the already accelerating stroke when replanning near a cut.
        var seed=path.Sample(.46);seed.Id=-1;
        var again=ReplayMotor.Build(seed,notes,g,teacher,9,1.8);
        var entry=again.Sample(seed.Time+1e-8);
        Check(MotionRotation.Log(entry.Rotation*seed.Rotation.Inverse).Length<1e-5,"idle-source replan snapped wrist");
        Check((entry.AngularVelocity-seed.AngularVelocity).Length<.002,"idle-source replan reset swing velocity");
    }
}
