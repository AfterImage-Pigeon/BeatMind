using System;
using SaberMind;
class ReplayWristRollTests
{
    static int checks;
    static void Check(bool condition,string why){checks++;if(!condition)throw new Exception(why);}
    static PhraseState Base(double t)
    {return new PhraseState{Time=t,Rotation=MotionRotation.Exp(new MotionVector((t-1)*8,0,0)),AngularVelocity=new MotionVector(8,0,0)};}
    static PhraseState Teacher(double t)
    {var s=Base(t);s.Rotation=s.Rotation*MotionRotation.Exp(new MotionVector(0,0,.25*Math.Sin((t-1)*8)));s.HumanSource=7;return s;}
    static PhraseState Contact(){var s=Base(1);s.SwingStart=.75;s.SwingEnd=1.25;return s;}
    static void Motion()
    {
        var blade=new MotionVector(0,0,1);var roll=ReplayWristRoll.Capture(Teacher,Contact(),blade);
        Check(roll!=null,"measured wrist roll was discarded");double visible=0;
        for(int i=0;i<=500;i++)
        {
            double t=.75+i*.001;var original=Base(t);var s=Base(t);roll.Apply(s);
            Check((s.Rotation.Rotate(blade)-original.Rotation.Rotate(blade)).Length<1e-12,"roll changed scored blade direction");
            visible=Math.Max(visible,MotionRotation.Log(s.Rotation*original.Rotation.Inverse).Length);
            double h=1e-6;var a=Base(t-h);roll.Apply(a);var b=Base(t+h);roll.Apply(b);
            var rate=MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*h);
            Check((rate-s.AngularVelocity).Length<.00001,"reported roll velocity disagrees with actual quaternion motion");
            Check(((b.AngularVelocity-a.AngularVelocity)/(2*h)-s.AngularAcceleration).Length<.002,"roll acceleration is not temporally coherent");
        }
        Check(visible>.10,"demonstration changed no visible wrist movement");
        foreach(double t in new[]{.75,1.0,1.25}){var a=Base(t);var b=Base(t);roll.Apply(b);Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-12 && (a.AngularVelocity-b.AngularVelocity).Length<1e-12 && (a.AngularAcceleration-b.AngularAcceleration).Length<1e-12,"contact/boundary jets changed");}
        var retained=Contact();retained.WristRoll=roll;Check(object.ReferenceEquals(retained.Copy().WristRoll,roll),"handoff lost frozen roll ownership");
        Check(ReplayWristRoll.Capture(delegate(double t){var s=Teacher(t);s.HumanSource=t<1 ? 6 : 7;return s;},Contact(),blade)==null,"roll mixed two independent demonstrations");
        Check(ReplayWristRoll.Capture(delegate(double t){var s=Base(t);s.Rotation=MotionRotation.Identity;return s;},Contact(),blade)==null,"constant wrist acquired invented variation");
        Check(ReplayWristRoll.Capture(delegate(double t){var s=Teacher(t);s.Rotation=s.Rotation*-1;return s;},Contact(),blade)!=null,"quaternion sign destroyed demonstration continuity");
    }
    static void Allocation()
    {
        var a=Base(0);var b=Base(1);double sum=0;for(int i=0;i<50;i++){var warm=new PhraseCurve(a,b);sum+=warm.End;}
        long before=GC.GetAllocatedBytesForCurrentThread();
        for(int i=0;i<10000;i++){var curve=new PhraseCurve(a,b);sum+=curve.End;}
        long bytes=GC.GetAllocatedBytesForCurrentThread()-before;GC.KeepAlive(sum);
        Check(bytes==0,"motion polynomial construction still allocates a heap object per probe: "+bytes);
    }
    static void PublishedOwnership()
    {
        var g=new PhraseGeometry{Bottom=new MotionVector(),Top=new MotionVector(0,0,1),Forward=new MotionVector(0,0,1),Shoulder=new MotionVector(-.25,1.4,0),Reach=.85,MinimumReach=.08,ControlledWrist=true,StableFastGrip=true,SwingSpeedScale=1.5};
        Func<double,PhraseState> teacher=delegate(double t){var s=Teacher(t);s.Grip=new MotionVector(-.25,1.2,.4);s.HumanWristWeight=s.HumanGripWeight=1;return s;};
        var seed=teacher(.6);seed.Rotation=WristMotionLimits.Fit(seed.Rotation,g);seed.AngularVelocity=seed.AngularAcceleration=new MotionVector();
        var note=new PhraseNote{Id=10,Time=1,Center=new MotionVector(-.25,1.2,1.15),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=.5,LocalNps=2};
        var first=ReplayMotor.Build(seed,new[]{note},g,teacher,9,1.4);
        var contact=first.Contact(note.Id);Check(contact!=null && contact.WristRoll!=null,"production swing failed to retain measured roll");
        note.Committed=contact;var nextSeed=first.Sample(.7);nextSeed.Time=.7;
        var next=ReplayMotor.Build(nextSeed,new[]{note},g,teacher,9,1.3);
        Check(object.ReferenceEquals(next.Contact(note.Id).WristRoll,contact.WristRoll),"replan selected a fresh roll curve for an owned swing");
        double a=Math.Max(.71,contact.SwingStart),b=contact.SwingEnd;
        for(int i=0;i<=80;i++){double t=a+(b-a)*i/80;var old=first.SampleWrist(t);var fresh=next.SampleWrist(t);Check(MotionRotation.Log(old.Rotation*fresh.Rotation.Inverse).Length<1e-7 && (old.AngularVelocity-fresh.AngularVelocity).Length<1e-6,"committed replan changed the active human roll trajectory");}
    }
    static int Main(){try{Motion();Allocation();PublishedOwnership();Console.WriteLine(checks+" replay wrist roll / contact preservation / polynomial allocation assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
