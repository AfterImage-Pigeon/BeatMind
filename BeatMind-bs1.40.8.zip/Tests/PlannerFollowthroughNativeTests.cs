using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using SaberMind;

// Exercises the shipped planner's publication path without Unity objects,
// a launched game, or changing replay/learning state.
class PlannerFollowthroughNativeTests
{
    static string game;
    static string pluginPath,pluginName;
    static int checks;
    static double handoff;
    static void Check(bool condition,string message)
    {checks++;if(!condition)throw new Exception(message);}
    static Assembly Resolve(object sender,ResolveEventArgs args)
    {
        string requested=new AssemblyName(args.Name).Name;
        // The installed plugin may still be the preceding version. Resolve
        // the test's explicitly selected build before searching game folders.
        if(string.Equals(requested,pluginName,StringComparison.OrdinalIgnoreCase))
            return Assembly.LoadFrom(pluginPath);
        string name=requested+".dll";
        foreach(string folder in new[]{"Libs","Plugins",Path.Combine("Beat Saber_Data","Managed")})
        {string path=Path.Combine(game,folder,name);if(File.Exists(path))return Assembly.LoadFrom(path);}
        return null;
    }
    static PhraseState Outgoing(double time)
    {
        double t=time-.8;
        return new PhraseState{Time=time,Grip=new MotionVector(-.25,1.3+.2*t,.3),Velocity=new MotionVector(0,.2,0),
            Rotation=MotionRotation.Exp(new MotionVector(12*t,0,0)),AngularVelocity=new MotionVector(12,0,0)};
    }
    static PhraseState Requested(double time)
    {
        var state=Outgoing(time);double t=time-handoff;
        state.Rotation=MotionRotation.Exp(new MotionVector(12*(time-.8)+.1*t*t*t,0,0));
        state.AngularVelocity=new MotionVector(12+.3*t*t,0,0);state.AngularAcceleration=new MotionVector(.6*t,0,0);
        return state;
    }
    static void Case(Assembly plugin,double publication,double nextHit,double pendingHandoff)
    {
        handoff=pendingHandoff;
        var previous=new MotionPhrase{Evaluator=Outgoing};previous.Knots.Add(Outgoing(.8));
        var cut=Outgoing(1);cut.Id=21;cut.ScoringReleaseEnd=1.185;previous.Knots.Add(cut);previous.Knots.Add(Outgoing(1.8));
        var next=new MotionPhrase{Evaluator=Requested};next.Knots.Add(Requested(pendingHandoff));
        var contact=Requested(nextHit);contact.Id=22;next.Knots.Add(contact);next.Knots.Add(Requested(1.8));
        var ctor=typeof(ReplayPlanJob).GetConstructors(BindingFlags.Instance|BindingFlags.NonPublic)[0];
        var job=(ReplayPlanJob)ctor.Invoke(new object[]{next,null});
        Type handType=plugin.GetType("SaberMind.Hand",true);object hand=Activator.CreateInstance(handType,true);
        Action<string,object> set=delegate(string name,object value){handType.GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(hand,value);};
        set("Phrase",previous);set("PendingPlan",job);set("PendingStart",.91);set("PendingHandoff",pendingHandoff);
        set("PendingRevision",3);set("MotionRevision",2);set("LastCutMapIndex",21);set("LastCutSongTime",.957);
        var publish=plugin.GetType("SaberMind.MovementPlanner",true).GetMethod("Publish",BindingFlags.Static|BindingFlags.NonPublic);
        publish.Invoke(null,new object[]{hand,publication});
        var actual=(MotionPhrase)handType.GetField("Phrase",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(hand);
        double release=Math.Min(1.185,nextHit-.005);
        for(double time=.957;time<release;time+=.001)
        {
            var old=previous.Sample(time);var played=actual.Sample(time);
            Check(MotionRotation.Log(old.Rotation*played.Rotation.Inverse).Length<1e-10,"pending publication interrupted release rotation");
            Check((old.AngularVelocity-played.AngularVelocity).Length<1e-12,"pending publication stopped wrist momentum");
        }
        double joinStart=Math.Max(publication,Math.Max(pendingHandoff,release));
        foreach(double boundary in new[]{joinStart,Math.Min(joinStart+.045,nextHit)})
        {
            var a=actual.Sample(boundary-.000001);var b=actual.Sample(boundary+.000001);
            Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<.00003,"publication connector snapped at a boundary");
            Check((a.AngularVelocity-b.AngularVelocity).Length<.0001,"publication connector changed angular speed instantly");
        }
        var hit=actual.Sample(nextHit);
        Check(MotionRotation.Log(hit.Rotation*contact.Rotation.Inverse).Length<1e-10,"late connector changed next contact orientation");
        Check((hit.AngularVelocity-contact.AngularVelocity).Length<1e-10,"late connector changed next cut speed");
        Check((int)handType.GetField("MotionRevision",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(hand)==3,"release preservation prevented revision publication");
        Check(handType.GetField("PendingPlan",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(hand)==null,"publication retained disposed planning job");
    }
    static int Run(string path)
    {
        // Use the assembly that owns the statically referenced test types.
        // Loading another same-identity path can create a second CLR context
        // whose identically named MotionPhrase cannot be assigned to Hand.
        var plugin=typeof(MotionPhrase).Assembly;
        Check(plugin.GetType("SaberMind.MotionPhrase",true)==typeof(MotionPhrase),"planner and fixture types loaded in different assembly contexts");
        Check(string.Equals(Hash(plugin.Location),Hash(path),StringComparison.Ordinal),"planner regression loaded a different build from the explicitly requested plugin");
        Case(plugin,1.045,1.24,1.10);Case(plugin,1.13,1.24,1.10);Case(plugin,1.22,1.24,1.10);
        Case(plugin,1.045,1.17,1.10);
        Console.WriteLine(checks+" shipped planner follow-through assertions passed (no Unity/gameplay execution).");return 0;
    }
    static string Hash(string path)
    {using(var stream=File.OpenRead(path))using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(stream));}
    static int Main(string[] args)
    {try{game=args[0];pluginPath=Path.GetFullPath(args[1]);pluginName=AssemblyName.GetAssemblyName(pluginPath).Name;AppDomain.CurrentDomain.AssemblyResolve+=Resolve;return Run(pluginPath);}catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}
