using System;
using System.Collections.Generic;
using SaberMind;

// Independent work-folder checks for the output wrist clock. No shared test
// or motion source files are changed by this harness.
class ReplayWristClockReviewTests
{
    static int checks;
    static double maxRateError,maxAccelerationError,maxWError,maxAlphaError;
    static void Check(bool condition,string message)
    {checks++;if(!condition)throw new Exception(message);}
    static PhraseState Contact(int id,double time,double applied)
    {return new PhraseState{Id=id,Time=time,WristSpeedScale=applied};}
    static PhraseState Original(double t)
    {
        double a=.8*t+.3*Math.Sin(2.1*t),b=.45*Math.Cos(1.3*t);
        double ad=.8+.63*Math.Cos(2.1*t),bd=-.585*Math.Sin(1.3*t);
        double add=-1.323*Math.Sin(2.1*t),bdd=-.7605*Math.Cos(1.3*t);
        MotionVector x=new MotionVector(1,0,0),z=new MotionVector(0,0,1);
        var qx=MotionRotation.Exp(x*a);var zw=qx.Rotate(z*bd);
        return new PhraseState{Time=t,Grip=new MotionVector(.3,1.3+.02*Math.Sin(t),.25),
            Rotation=qx*MotionRotation.Exp(z*b),AngularVelocity=x*ad+zw,
            AngularAcceleration=x*add+qx.Rotate(z*bdd)+MotionVector.Cross(x*ad,zw)};
    }
    static PhraseState Warped(ReplayWristClock clock,double t)
    {
        double source,rate,acceleration;clock.Map(t,out source,out rate,out acceleration);
        var s=Original(source);s.Time=t;
        s.AngularAcceleration=s.AngularAcceleration*(rate*rate)+s.AngularVelocity*acceleration;
        s.AngularVelocity*=rate;return s;
    }
    static void Case(string label,double seed,double end,List<PhraseState> contacts)
    {
        var clock=new ReplayWristClock(seed,end,contacts,1.5);
        foreach(var contact in contacts)
        {
            double source,rate,acceleration;clock.Map(contact.Time,out source,out rate,out acceleration);
            Check(Math.Abs(source-contact.Time)<1e-10,label+": contact time moved");
            Check(Math.Abs(rate-1.5/contact.WristSpeedScale)<1e-9,label+": committed contact speed compounded");
            Check(Math.Abs(acceleration)<1e-8,label+": nonzero contact clock acceleration");
            var before=Original(contact.Time);var after=Warped(clock,contact.Time);
            Check(MotionRotation.Log(after.Rotation*before.Rotation.Inverse).Length<1e-10,label+": contact orientation changed");
        }
        foreach(double boundary in new[]{seed,end})
        {
            double source,rate,acceleration;clock.Map(boundary,out source,out rate,out acceleration);
            Check(Math.Abs(source-boundary)<1e-10 && Math.Abs(rate-1)<1e-8 && Math.Abs(acceleration)<1e-8,label+": outer clock jet changed");
        }
        double oldSource=double.NegativeInfinity;
        const int count=6000;
        for(int i=0;i<=count;i++)
        {
            double t=seed+(end-seed)*i/count,source,rate,acceleration;
            clock.Map(t,out source,out rate,out acceleration);
            Check(source>=oldSource-1e-11 && rate>0,label+": clock reverses");oldSource=source;
            Check(rate<=1.5000001,label+": clock exceeds intended speed scale");
            Check(Math.Abs(clock.Unmap(source)-t)<2e-9,label+": inverse clock does not preserve metadata time");
            if(i==0 || i==count)continue;
            double e=Math.Min(1e-6,(end-seed)*1e-6),ls,lr,la,rs,rr,ra;
            clock.Map(t-e,out ls,out lr,out la);clock.Map(t+e,out rs,out rr,out ra);
            double rateError=Math.Abs((rs-ls)/(2*e)-rate),accError=Math.Abs((rr-lr)/(2*e)-acceleration);
            maxRateError=Math.Max(maxRateError,rateError);maxAccelerationError=Math.Max(maxAccelerationError,accError);
            Check(rateError<2e-6,label+": source clock velocity disagrees with source positions");
            Check(accError<.002,label+": source clock acceleration disagrees with source velocity");
            var a=Warped(clock,t-e);var b=Warped(clock,t+e);var m=Warped(clock,t);
            double wError=(MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-m.AngularVelocity).Length;
            double alphaError=((b.AngularVelocity-a.AngularVelocity)/(2*e)-m.AngularAcceleration).Length;
            maxWError=Math.Max(maxWError,wError);maxAlphaError=Math.Max(maxAlphaError,alphaError);
            Check(wError<3e-6,label+": rotation and retimed angular velocity disagree");
            Check(alphaError<.004,label+": retimed angular acceleration violates chain rule");
            var sourcePose=Original(source);
            Check(MotionRotation.Log(m.Rotation*sourcePose.Rotation.Inverse).Length<1e-10,label+": wrist pose identity changed");
        }
    }
    static int Main()
    {
        try
        {
            Case("one contact",0,1.5,new List<PhraseState>{Contact(0,.5,1)});
            Case("dense mixed",0,2,new List<PhraseState>{Contact(0,.5,1),Contact(1,.7,1),Contact(2,.825,1),Contact(3,.908333333333,1),Contact(4,1.01,1)});
            Case("sparse break",0,5,new List<PhraseState>{Contact(0,.8,1),Contact(1,3.5,1)});
            Case("committed mixed",.65,2,new List<PhraseState>{Contact(0,.7,1.5),Contact(1,.825,1.5),Contact(2,.908333333333,1),Contact(3,1.01,1)});
            Case("near contact seed",.494,1.5,new List<PhraseState>{Contact(0,.5,1.5),Contact(1,.625,1)});
            Case("empty break",0,1.5,new List<PhraseState>());
            GeneratedWindow();
            GeneratedAffineClock();
            AppliedWrapper();
            Console.WriteLine(checks+" independent wrist-clock assertions passed; maximum clock velocity/acceleration errors="+maxRateError+"/"+maxAccelerationError+", wrist velocity/acceleration errors="+maxWError+"/"+maxAlphaError);
            return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
    static void GeneratedWindow()
    {
        var contact=Contact(0,.5,1.5);contact.SwingStart=.35;contact.SwingPeak=.5;contact.SwingEnd=.58;
        var clock=new ReplayWristClock(0,1.4,new List<PhraseState>{contact,Contact(1,.72,1)},1.5);
        for(int i=0;i<=300;i++)
        {
            double t=contact.SwingStart+(contact.SwingEnd-contact.SwingStart)*i/300,source,rate,acceleration;
            clock.Map(t,out source,out rate,out acceleration);
            Check(Math.Abs(source-t)<1e-10 && Math.Abs(rate-1)<1e-8 && Math.Abs(acceleration)<1e-7,"generated affine swing was retimed for a second time");
        }
    }
    static void AppliedWrapper()
    {
        var first=Original(.5);first.Id=0;first.ScoringReleaseEnd=.68;
        var second=Original(.85);second.Id=1;second.ScoringReleaseEnd=1.0;
        var oldContacts=new List<PhraseState>{first.Copy(),second.Copy()};
        var clock=new ReplayWristClock(0,1.5,oldContacts,1.5);
        var path=new MotionPhrase{Evaluator=Original};path.Knots.Add(Original(0));path.Knots.Add(first);path.Knots.Add(second);path.Knots.Add(Original(1.5));
        ReplayWristClock.Apply(path,1.5);
        var once=new List<PhraseState>();
        for(int i=0;i<=1500;i++)
        {
            double t=i*.001;var expected=Warped(clock,t);var actual=path.Sample(t);once.Add(actual.Copy());
            Check((actual.Grip-Original(t).Grip).Length<1e-12,"wrist-only production wrapper moved handle timing");
            Check(MotionRotation.Log(actual.Rotation*expected.Rotation.Inverse).Length<1e-10,"production wrapper changed changing-axis source pose");
            Check((actual.AngularVelocity-expected.AngularVelocity).Length<1e-10,"production wrapper angular velocity disagrees with clock");
            Check((actual.AngularAcceleration-expected.AngularAcceleration).Length<1e-8,"production wrapper acceleration disagrees with clock chain rule");
        }
        foreach(var old in oldContacts)
        {
            var actual=path.Contact(old.Id);
            Check(actual.WristSpeedScale==1.5,"production contact failed to remember applied speed scale");
            Check(Math.Abs(actual.ScoringReleaseEnd-clock.Unmap(old.ScoringReleaseEnd))<1e-10,"production wrapper did not map scoring release ownership");
        }
        ReplayWristClock.Apply(path,1.5);
        for(int i=0;i<once.Count;i++)
        {
            var actual=path.Sample(i*.001);var old=once[i];
            Check(MotionRotation.Log(actual.Rotation*old.Rotation.Inverse).Length<1e-10,"applying the same clock compounded orientation");
            Check((actual.AngularVelocity-old.AngularVelocity).Length<1e-10,"applying the same clock compounded wrist speed");
        }
    }
    static void GeneratedAffineClock()
    {
        var a=Contact(0,.5,1);a.SwingStart=.35;a.SwingPeak=.5;a.SwingEnd=.58;
        var b=Contact(1,.72,1);b.SwingStart=.59;b.SwingPeak=.72;b.SwingEnd=.79;
        var clock=new ReplayWristClock(0,1.4,new List<PhraseState>{a,b},1.5);
        foreach(var c in new[]{a,b})
        {
            double start=c.Time+(c.SwingStart-c.Time)/1.5,end=c.Time+(c.SwingEnd-c.Time)/1.5;
            for(int p=0;p<=300;p++)
            {
                double t=start+(end-start)*p/300,source,rate,acceleration;clock.Map(t,out source,out rate,out acceleration);
                Check(Math.Abs(source-(c.Time+(t-c.Time)*1.5))<1e-10,"generated source clock was not affine within scored arc");
                Check(Math.Abs(rate-1.5)<1e-8 && Math.Abs(acceleration)<1e-6,"generated affine source clock changed its derivative jets");
            }
        }
        double previous=double.NegativeInfinity;
        for(int p=0;p<=14000;p++)
        {
            double t=p*.0001,source,rate,acceleration;clock.Map(t,out source,out rate,out acceleration);
            Check(source>=previous-1e-12 && rate>0,"generated recovery source clock reverses");
            Check(Math.Abs(clock.Unmap(source)-t)<1e-9,"generated recovery inverse clock moved source pose");previous=source;
        }
    }
}
