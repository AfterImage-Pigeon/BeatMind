using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;
using SaberMind;
class PlaybackPerformanceTests
{
    static int checks;
    static void Check(bool valid,string message){checks++;if(!valid)throw new Exception(message);}
    static HumanMotionExample Example()
    {
        var e=new HumanMotionExample{Duration=1.25,Recording="recorded",Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new[]{new HumanAnchor{Hand=0,Direction=1,Phase=.4}}};
        for(int p=0;p<129;p++)for(int j=0;j<3;j++)
        {double t=p*1.25/128;var s=new PhraseState{Time=t,Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.2+j*.1+.01*t,.25),Velocity=new MotionVector(0,.01,0),Rotation=MotionRotation.Exp(new MotionVector(.2*t,0,0)),AngularVelocity=new MotionVector(.2,0,0)};HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);}return e;
    }
    static int Main(string[] args)
    {try{Run(args[0]);Console.WriteLine(checks+" playback caching / bounded streaming assertions passed.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
    static void Run(string root)
    {
        Directory.CreateDirectory(root);var e=Example();var tape=HumanTape.FromExample(e);
        for(int i=0;i<400;i++)for(int j=0;j<3;j++)
        {double t=(i*17%119+1)*1.25/128+.001;var state=tape.Sample(t,j);Check((state.Velocity-new MotionVector(0,.01,0)).Length<.00001,"curve reuse changed ordered velocities");Check((state.AngularVelocity-new MotionVector(.2,0,0)).Length<.00001,"curve reuse changed angular motion");}
        var source=new HumanMotionFile{Key="cached",ReplayIdentity="trusted",Cuts=80,Recording=new HumanRecording{Identity="trusted",Path="source",Accuracy=.95,Frames=100,Notes=2}};
        for(int i=0;i<40;i++)source.Examples.Add(e);
        var files=new List<HumanMotionTraining.CachedSource>();
        for(int i=0;i<64;i++){string path=Path.Combine(root,i+".json.gz");HumanMotionTraining.Write(path,source);files.Add(HumanMotionTraining.IndexSource(path,source,i));}
        var budget=new HumanMotionModel();HumanMotionTraining.ApplyLearningBudget(files,budget);
        int expectedCount=Math.Min(64*40,HumanMotionTraining.MaximumLearningPoseSamples/HumanMotionModel.Points);
        long baseline=GC.GetTotalMemory(true),maximum=0;int count=0,waits=0;
        foreach(var sample in HumanMotionTraining.Examples(files,null,delegate{waits++;}))
        {count++;if(count%40==0)maximum=Math.Max(maximum,GC.GetTotalMemory(true)-baseline);Check(sample.Curve.Length==129*21,"stream lost demonstration poses");}
        Check(count==expectedCount && count==budget.Cuts && waits>=count,"stream skipped budgeted demonstrations or idle checks");Check((long)count*HumanMotionModel.Points<=HumanMotionTraining.MaximumLearningPoseSamples,"stream exceeded the current learning pose cap");Check(maximum<32L*1024*1024,"training retained the full replay library");
        var subset=files.GetRange(0,2);var inMemory=new List<HumanMotionExample>();foreach(var sample in HumanMotionTraining.Examples(subset,null,null))inMemory.Add(sample);
        var fit=typeof(HumanMotionTraining).GetMethod("Fit",BindingFlags.Static|BindingFlags.NonPublic);
        var expected=(List<HumanMotionExample>)fit.Invoke(null,new object[]{inMemory,null});
        var actual=(List<HumanMotionExample>)fit.Invoke(null,new object[]{HumanMotionTraining.Examples(subset,null,null),null});
        Check(JsonConvert.SerializeObject(actual)==JsonConvert.SerializeObject(expected),"bounded streaming changed fitted parameters, weights or ordering");
        Console.WriteLine("Streaming retained peak bytes: "+maximum+"; raw arrays if all retained: "+(2560L*129*57*4));
        var model=new HumanMotionModel();model.Examples.Add(e);model.Examples.Add(new HumanMotionExample{Phase=HumanPhase.Opening,Duration=e.Duration,Recording=e.Recording,Context=e.Context,Curve=e.Curve,Kinematics=e.Kinematics,Anchors=new HumanAnchor[0]});
        var chart=new[]{new HumanChartNote{Time=1,Hand=0,Direction=1},new HumanChartNote{Time=1.5,Hand=0,Direction=1},new HumanChartNote{Time=2,Hand=0,Direction=1}};
        var prepared=new HumanMotionGraph(model,chart,null,2);for(double t=0;t<7;t+=.5)prepared.PrepareUntil(t);int searches=prepared.Searches,choices=prepared.Choices;
        var ordinary=new HumanMotionGraph(model,chart,null,2);
        for(double t=0;t<5;t+=.017)for(int j=0;j<3;j++)
        {prepared.BeginFrame(t);ordinary.BeginFrame(t);var a=prepared.Sample(t,j);var b=ordinary.Sample(t,j);Check((a.Grip-b.Grip).Length<1e-8 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8,"preparation changed the selected continuous motion");}
        Check(prepared.Choices==choices && prepared.Searches==searches,"prepared gameplay repeated graph search");
    }
}
