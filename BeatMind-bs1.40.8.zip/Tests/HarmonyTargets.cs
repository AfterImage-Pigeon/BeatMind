using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HarmonyLib;

// Resolve the shipped attributes using the installed Harmony implementation.
// No game methods, Unity objects, authentication or patch application are run.
internal static class HarmonyTargets
{
    private static string game;
    private static int Main(string[] args)
    {
        try
        {
            game=args[0];
            AppDomain.CurrentDomain.AssemblyResolve+=Resolve;
            return Check(args[1]);
        }
        catch(Exception error) {Console.Error.WriteLine(error);return 1;}
    }
    private static Assembly Resolve(object sender,ResolveEventArgs args)
    {
        string name=new AssemblyName(args.Name).Name+".dll";
        foreach(string folder in new[]{"Libs","Plugins",Path.Combine("Beat Saber_Data","Managed")})
        {
            string path=Path.Combine(game,folder,name);
            if(File.Exists(path))return Assembly.LoadFrom(path);
        }
        return null;
    }
    private static int Check(string pluginPath)
    {
        Assembly plugin=Assembly.LoadFrom(pluginPath);
        MethodInfo resolve=typeof(Harmony).Assembly.GetType("HarmonyLib.PatchTools").GetMethod("GetOriginalMethod",BindingFlags.Static|BindingFlags.NonPublic);
        int count=0;
        foreach(Type patch in plugin.GetTypes())
        {
            List<HarmonyMethod> attributes=HarmonyMethodExtensions.GetFromType(patch);
            if(attributes.Count==0)continue;
            HarmonyMethod target=HarmonyMethod.Merge(attributes);
            if(!target.methodType.HasValue)target.methodType=MethodType.Normal;
            MethodBase original=(MethodBase)resolve.Invoke(null,new object[]{target});
            if(original==null)throw new Exception("Harmony cannot resolve "+patch.FullName);
            if(patch.Name=="CompanionAuthenticationPatch")
            {
                // Reproduce the failed 1.0.0.4 attribute: omitted constructor
                // parameters mean a zero-argument constructor in Harmony.
                var old=new HarmonyMethod{declaringType=target.declaringType,methodType=MethodType.Constructor};
                if(resolve.Invoke(null,new object[]{old})!=null)throw new Exception("Constructor regression no longer reproduces.");
                if(original.GetParameters().Length!=2)throw new Exception("Wrong authentication constructor.");
                Console.WriteLine("PASS: old constructor target fails; explicit two-argument target resolves.");
            }
            count++;
        }
        if(count!=32)throw new Exception("Expected 32 resolved hooks; got "+count);
        Console.WriteLine("PASS: all 32 targets resolve through installed Harmony (no Unity/gameplay execution).");
        return 0;
    }
}
