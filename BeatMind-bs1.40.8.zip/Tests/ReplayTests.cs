using System;
using System.IO;
using SaberMind;

internal static class ReplayTests
{
    private static void Check(bool okay,string name)
    { if(!okay) throw new Exception(name); Console.WriteLine("PASS: "+name); }
    private static ReplayPose Pose(float x,float q=1)
    { return new ReplayPose {X=x,Qw=q}; }
    private static BestReplay Candidate(int score)
    {
        var result=new BestReplay {Identity="song|Expert",Model="Natural",Result=new MeasuredRun {
            Completed=true,Maximum=1000,RawScore=score,Score=score,Good=10 } };
        result.Frames.Add(new ReplayFrame {Time=0,Head=Pose(0),Left=Pose(0)});
        result.Frames.Add(new ReplayFrame {Time=1,Head=Pose(2),Left=Pose(2,-1)});
        result.Decisions["note-1"]=new ReplayChoice {Variant=3,CutScore=110,Good=true};
        return result;
    }
    private static void Main(string[] args)
    {
        Check(BreakTiming.Strength(.4,0,1)==0 && BreakTiming.Strength(.8,0,1.9)>0 &&
            BreakTiming.Strength(1.3,0,1.9)==0,"a break exists only in the middle of a note gap");
        Check(BreakTiming.Strength(4.5,0,double.PositiveInfinity)==1 &&
            BreakTiming.Strength(0,double.NegativeInfinity,3)==1,
            "long intros and endings can use a resting pose");
        var store=new ReplayStore(args[0]);
        Check(store.SaveIfBetter(Candidate(800)),"first completed run becomes the best replay");
        Check(!store.SaveIfBetter(Candidate(790)) && store.Load("song|Expert","Natural").Result.RawScore==800,
            "worse replays are discarded");
        Check(store.SaveIfBetter(Candidate(850)) && store.Load("song|Expert","Natural").Result.RawScore==850,
            "higher score replaces the previous replay");
        BestReplay best=store.Load("song|Expert","Natural");
        Check(best.Decisions["note-1"].CutScore==110 && Math.Abs(best.Pose(.5f,0).X-1)<.001f,
            "head movement and successful cut decisions survive a replay round trip");
        ReplayPose saber=best.Pose(.5f,1);
        Check(Math.Abs(saber.Qw-1)<.001f,
            "saber interpolation uses the shortest quaternion path");
        Check(store.Load("song|Easy","Natural")==null && store.Load("song|Expert","Rapid")==null,
            "replays are isolated by level and model");
        Check(Path.GetDirectoryName(store.FileFor("../song","Natural"))==args[0],
            "replay identifiers cannot escape the replay directory");
    }
}
