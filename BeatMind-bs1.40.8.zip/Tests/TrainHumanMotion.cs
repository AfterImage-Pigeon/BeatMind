using System;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;
using SaberMind;
class TrainHumanMotion
{
    static int Main(string[] args)
    {
        try
        {
            var time=Stopwatch.StartNew();int updates=0;
            string[] paths=args.Length>2 ? new AutomaticReplays(args[0],args[2],Path.Combine(args[1],"BotReplayWindows.json")).Collect(true,DateTime.UtcNow) : Directory.GetFiles(args[0],"*.bsor");
            HumanMotionModel model=HumanMotionTraining.LoadFiles(paths,args[1],delegate(string s){if(++updates%10==0 || !s.StartsWith("Reading")) Console.WriteLine(s);},delegate(string s){Console.WriteLine("REJECT: "+s);});
            if(!model.Valid()) throw new Exception("No valid trained model.");
            var report=new {inspected=paths.Length,files=model.Files,rejected=model.Rejected,duplicates=model.Duplicates,transitions=model.Cuts,prototypes=model.Examples.Count,points=HumanMotionModel.Points,
                learnedParameters=model.Examples.Count*HumanMotionModel.Points*HumanMotionModel.TotalChannels,cached=model.CachedFiles,
                heldOutExamples=model.ValidationExamples,contextualError=model.ContextValidationError,meanError=model.MeanValidationError,
                elapsedSeconds=time.Elapsed.TotalSeconds,peakMemoryMB=Process.GetCurrentProcess().PeakWorkingSet64/1048576.0};
            File.WriteAllText(Path.Combine(args[1],"TrainingReport.json"),JsonConvert.SerializeObject(report,Formatting.Indented));
            Console.WriteLine(JsonConvert.SerializeObject(report));return 0;
        }
        catch(Exception e) {Console.Error.WriteLine(e.ToString());return 1;}
    }
}
