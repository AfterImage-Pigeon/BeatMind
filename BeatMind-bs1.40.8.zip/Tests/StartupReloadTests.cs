using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using SaberMind;

// Exercise the real Plugin and AutomaticReplays orchestration entirely offline.
// Only replay metadata is real; Unity, model decoding and all game stores are
// replaced with controlled test dependencies. No installed game files are used.
namespace HarmonyLib { public sealed class Harmony { public Harmony(string id){} public void PatchAll(Assembly assembly){} public void UnpatchSelf(){} } }
namespace IPA
{
    public enum RuntimeOptions { DynamicInit }
    public sealed class PluginAttribute:Attribute { public PluginAttribute(RuntimeOptions options){} }
    public sealed class InitAttribute:Attribute {}
    public sealed class OnEnableAttribute:Attribute {}
    public sealed class OnDisableAttribute:Attribute {}
}
namespace IPA.Utilities { public static class UnityGame { public static string UserDataPath; } }
namespace IPA.Logging { public sealed class Logger { public void Info(string message){} public void Warn(string message){} public void Error(string message){} } }
namespace UnityEngine
{
    public class Object { public static void DontDestroyOnLoad(Object obj){} public static void Destroy(Object obj){} }
    public sealed class GameObject:Object { public GameObject(string name){} public T AddComponent<T>() where T:new() { return new T(); } }
}
namespace BS_Utils.Gameplay { public static class ScoreSubmission { public static void RemoveProlongedDisable(string id){} } }
namespace SaberMind
{
    internal sealed class MemoryStore { internal MemoryStore(string path){} }
    internal sealed class ReplayStore { internal ReplayStore(string path){} }
    public sealed class Runtime { internal void Shutdown(){} }
    internal sealed class Session
    {
        internal static Session Current;
        internal static bool ActiveSongPlaying;
        internal static void Stop(string reason){}
    }
    internal static class Settings
    {
        internal sealed class State { internal bool AutoLearnOwnReplays; }
        internal static State Current=new State();
        internal static void Load(){}
    }
    internal static class MultiplayerIntegration { internal static void Initialize(){} internal static void Shutdown(){} }
    public sealed class HumanMotionModel
    {
        public bool IsValid;
        public int LearningPoseSamples=129,Cuts=1,Files,Rejected,ValidationExamples;
        public double ContextValidationError,MeanValidationError;
        public bool Valid(){ return IsValid; }
    }
    public static class HumanMotionTraining
    {
        public const int MaximumLearningPoseSamples=500000;
        internal static int Calls,HoldNext,ThrowNext;
        internal static bool AlwaysInvalid;
        internal static readonly ManualResetEvent Entered=new ManualResetEvent(false),Release=new ManualResetEvent(false);
        internal static readonly List<string[]> Sources=new List<string[]>();
        internal static void Reset()
        { Calls=HoldNext=ThrowNext=0;AlwaysInvalid=false;Sources.Clear();Entered.Reset();Release.Reset(); }
        public static HumanMotionModel LoadFiles(string[] sources,string cache,Action<string> progress,Action<string> warning,Action waitForIdle)
        {return LoadFiles(sources,cache,progress,warning,waitForIdle,null);}
        public static HumanMotionModel LoadFiles(string[] sources,string cache,Action<string> progress,Action<string> warning,Action waitForIdle,Action<HumanMotionModel> cachedReady)
        {
            Interlocked.Increment(ref Calls);Sources.Add((string[])sources.Clone());
            bool hold=Interlocked.Exchange(ref HoldNext,0)!=0,fail=Interlocked.Exchange(ref ThrowNext,0)!=0;
            Entered.Set();if(hold && !Release.WaitOne(5000))throw new Exception("Test release timed out.");
            if(fail)throw new IOException("Controlled model load failure.");
            return new HumanMotionModel{IsValid=sources.Length>0 && !AlwaysInvalid,Files=sources.Length};
        }
    }
}

internal sealed class StartupReloadTests
{
    private static int checks;
    private static bool baseline;
    private static string artifacts;
    private static readonly FieldInfo Importing=typeof(Plugin).GetField("importingHumanReplays",BindingFlags.Static|BindingFlags.NonPublic);
    private static readonly FieldInfo Polling=typeof(Plugin).GetField("pollingHumanReplays",BindingFlags.Static|BindingFlags.NonPublic);
    private static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    private static void WaitIdle()
    {
        DateTime timeout=DateTime.UtcNow.AddSeconds(5);
        while((int)Importing.GetValue(null)!=0 || (int)Polling.GetValue(null)!=0)
        {if(DateTime.UtcNow>timeout)throw new Exception("Importer did not finish.");Thread.Sleep(1);}
    }
    private static void Poll(){Plugin.PollHumanReplays();WaitIdle();}
    private sealed class Fixture:IDisposable
    {
        internal readonly string Folder;
        internal readonly Plugin PluginInstance;
        private int sequence;
        internal Fixture(string name)
        {
            WaitIdle();HumanMotionTraining.Reset();Plugin.HumanMotion=null;Plugin.AutomaticHumanReplays=null;
            Session.Current=null;Session.ActiveSongPlaying=false;Settings.Current=new Settings.State();
            string root=Path.Combine(artifacts,"test-data",name+"-"+Guid.NewGuid().ToString("N"));
            IPA.Utilities.UnityGame.UserDataPath=root;
            Folder=Path.Combine(root,"AIPlayAndLearn","HumanReplays");Directory.CreateDirectory(Folder);
            PluginInstance=new Plugin(new IPA.Logging.Logger());
        }
        internal string Add(string name)
        {
            string path=Path.Combine(Folder,name+".bsor");File.WriteAllBytes(path,new byte[]{1,2,3});
            File.SetLastWriteTimeUtc(path,DateTime.UtcNow.AddMinutes(-10).AddSeconds(++sequence));return path;
        }
        internal void Start(){PluginInstance.Enable();WaitIdle();}
        internal void StartHeld()
        {
            HumanMotionTraining.HoldNext=1;PluginInstance.Enable();
            Check(HumanMotionTraining.Entered.WaitOne(5000),"Held startup never entered LoadFiles.");
        }
        internal void FinishHeld(){HumanMotionTraining.Release.Set();WaitIdle();}
        public void Dispose(){HumanMotionTraining.Release.Set();WaitIdle();PluginInstance.Disable();}
    }
    private static void StartupOnce()
    {
        using(var f=new Fixture("startup-once"))
        {
            f.Add("initial");f.Start();Check(HumanMotionTraining.Calls==1,"Startup did not load exactly once.");
            var model=Plugin.HumanMotion;Poll();
            Check(HumanMotionTraining.Calls==(baseline ? 2 : 1),"First unchanged startup poll decoded again.");
            if(!baseline)Check(object.ReferenceEquals(model,Plugin.HumanMotion),"Unchanged poll replaced the model.");
            Poll();Check(HumanMotionTraining.Calls==(baseline ? 2 : 1),"Stable later poll reloaded.");
            Console.WriteLine("Unchanged startup model-load calls: "+HumanMotionTraining.Calls);
        }
    }
    private static void ArrivalDuringLoad()
    {
        using(var f=new Fixture("arrival-during-load"))
        {
            f.Add("initial");f.StartHeld();f.Add("arrived");f.FinishHeld();
            Check(HumanMotionTraining.Sources[0].Length==1,"Initial load included a later arrival.");
            Poll();Check(HumanMotionTraining.Calls==2,"Arrival during import was swallowed.");
            Check(HumanMotionTraining.Sources[1].Length==2,"Follow-up omitted the later source.");
            Poll();Check(HumanMotionTraining.Calls==2,"Arrival follow-up repeated without change.");
        }
    }
    private static void EditDuringLoad()
    {
        using(var f=new Fixture("edit-during-load"))
        {
            string path=f.Add("initial");f.StartHeld();File.AppendAllText(path,"changed");
            File.SetLastWriteTimeUtc(path,DateTime.UtcNow.AddMinutes(-5));f.FinishHeld();
            Poll();Check(HumanMotionTraining.Calls==2,"Metadata change during import was swallowed.");
            Poll();Check(HumanMotionTraining.Calls==2,"Metadata follow-up repeated without change.");
        }
    }
    private static void CompletedInvalidOrEmpty(bool empty)
    {
        using(var f=new Fixture(empty ? "empty" : "invalid"))
        {
            if(!empty)f.Add("initial");HumanMotionTraining.AlwaysInvalid=true;f.Start();
            Check(Plugin.HumanMotion==null,"Invalid result became the active model.");
            Poll();Check(HumanMotionTraining.Calls==(baseline ? 2 : 1),"Completed nonusable scan repeated after startup.");
            f.Add("later");Poll();
            Check(HumanMotionTraining.Calls==(baseline ? 3 : 2),"Nonusable scan suppressed later source changes.");
        }
    }
    private static void FailureBehavior()
    {
        using(var f=new Fixture("startup-failure"))
        {
            f.Add("initial");HumanMotionTraining.ThrowNext=1;f.Start();
            Check(Plugin.HumanMotion==null,"Failed startup published a model.");
            Poll();Check(HumanMotionTraining.Calls==2,"Initial failure prevented the existing first-poll retry.");
            Poll();Check(HumanMotionTraining.Calls==2,"Successful retry repeated without change.");
        }
        using(var f=new Fixture("poll-failure"))
        {
            f.Add("initial");f.Start();Poll();int before=HumanMotionTraining.Calls;var model=Plugin.HumanMotion;
            f.Add("later");HumanMotionTraining.ThrowNext=1;Poll();
            Check(HumanMotionTraining.Calls==before+1,"Changed source did not start its load.");
            Check(object.ReferenceEquals(model,Plugin.HumanMotion),"Failed reload replaced the previous model.");
            Poll();Check(HumanMotionTraining.Calls==before+1,"Candidate changed existing poll failure retry policy.");
        }
    }
    private static int Main(string[] args)
    {
        try
        {
            artifacts=Path.GetFullPath(args[0]);baseline=args.Length>1 && args[1]=="baseline";
            IPA.Utilities.UnityGame.UserDataPath=artifacts;
            StartupOnce();ArrivalDuringLoad();EditDuringLoad();CompletedInvalidOrEmpty(true);CompletedInvalidOrEmpty(false);FailureBehavior();
            Console.WriteLine(checks+" startup snapshot assertions passed ("+(baseline ? "baseline reference" : "candidate")+").");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
