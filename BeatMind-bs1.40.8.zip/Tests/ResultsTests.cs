using System;
using SaberMind;

internal static class ResultsTests
{
    private static void Check(bool condition,string label)
    {if(!condition) throw new Exception(label);Console.WriteLine("PASS: "+label);}
    private static void Main()
    {
        string warning="<color=#ff0000ff>  \n<size=50%><b>Score Submission Disabled by: SaberMind | SaberMind";
        string repeated="LEVEL CLEARED"+warning+warning+warning;
        Check(ResultsText.RemoveRepeatedWarning(repeated)=="LEVEL CLEARED",
            "repeated insurance notices do not cover the results panel");
        Check(ResultsText.RemoveRepeatedWarning(ResultsText.RemoveRepeatedWarning(repeated)+warning)=="LEVEL CLEARED",
            "a redraw cannot restore another warning line");
        Check(ResultsText.RemoveRepeatedWarning("LEVEL CLEARED")=="LEVEL CLEARED",
            "normal results remain unchanged");
        string rank="<line-height=27.5%><size=60%>-94.69<size=45%>%\n<color=#FF0000>-184.20%";
        Check(ResultsText.PositiveRank(rank,true)=="<line-height=27.5%><size=60%>94.69<size=45%>%",
            "insurance sign and misleading difference are removed from the visible rank");
        Check(ResultsText.PositiveRank(rank,false)==rank && ResultsText.PositiveRank("SS",true)=="SS",
            "ordinary rank text is untouched");
        GoalStep first=AutoRestartPolicy.Evaluate(0,.96,true);
        GoalStep reset=AutoRestartPolicy.Evaluate(first.Streak,.94,true);
        GoalStep second=AutoRestartPolicy.Evaluate(reset.Streak,.97,true);
        GoalStep third=AutoRestartPolicy.Evaluate(second.Streak,.95,true);
        GoalStep reached=AutoRestartPolicy.Evaluate(third.Streak,.96,true);
        Check(first.Streak==1 && first.Restart && reset.Streak==0 && reset.Restart
            && second.Streak==1 && third.Streak==2 && third.Restart
            && reached.Streak==3 && reached.Reached && !reached.Restart,
            "auto-restart stops only after three consecutive measured 95% runs");
        Check(!AutoRestartPolicy.Evaluate(2,double.NaN,true).Restart
            && !AutoRestartPolicy.Evaluate(2,.99,false).Restart,
            "unmeasured or ineligible runs cannot trigger the restart loop");
        foreach(int target in AutoRestartPolicy.TargetPercentOptions)
        {
            double accuracy=target/100.0;
            GoalStep below=AutoRestartPolicy.Evaluate(2,accuracy-.00001,true,target);
            GoalStep at=AutoRestartPolicy.Evaluate(2,accuracy,true,target);
            Check(below.Streak==0 && below.Restart && at.Streak==3 && at.Reached && !at.Restart,
                target+"% dropdown goal uses the actual threshold and still requires three consecutive runs");
        }
        Check(AutoRestartPolicy.NormalizeTargetPercent(-1)==95 && AutoRestartPolicy.NormalizeTargetPercent(101)==95
            && AutoRestartPolicy.NormalizeTargetPercent(93)==95
            && AutoRestartPolicy.Evaluate(2,.95,true,0).Reached,
            "missing or invalid target configuration falls back to the existing 95% goal");
        Check(AutoRestartPolicy.Status(AutoRestartPolicy.Evaluate(2,.98,true,98),.98,98)
                =="98% reached in 3 consecutive runs. Auto-restart stopped."
            && AutoRestartPolicy.Status(AutoRestartPolicy.Evaluate(1,.96,true,97),.96,97)
                =="Accuracy 96.00%; target 97%; streak 0/3. Auto-restarting.",
            "restart and completion messages display the selected target");
    }
}
