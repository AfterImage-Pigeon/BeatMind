using System;
using SaberMind;

class MultiplayerTests
{
    static int checks;
    static void Check(bool value,string why){if(!value)throw new Exception(why);checks++;}
    static int Main()
    {
        try
        {
            DateTime now=new DateTime(2026,10,1,12,0,0,DateTimeKind.Utc);
            var invite=new PrivateBotInvite {Enabled=true,PrivateLobby=true,Model=2,Code="ABCDE",HostUserId="host-auth-id",Nonce="private-lobby-one",CreatedUtc=now,ExpiresUtc=now.AddHours(1)};
            Check(MultiplayerPolicy.ValidInvite(invite,now),"Valid private invitation rejected");
            Check(!MultiplayerPolicy.MayJoin(false,invite,"host-auth-id","ABCDE",now),"Human host could enter bot role");
            Check(!MultiplayerPolicy.MayJoin(true,invite,"host-auth-id","ABCDE",now),"Host identity reused for second participant");
            Check(!MultiplayerPolicy.MayJoin(true,invite,null,"ABCDE",now),"Missing authenticated identity accepted");
            Check(!MultiplayerPolicy.MayJoin(true,invite,"other-auth-id","wrong-code",now),"Uninvited lobby accepted");
            Check(MultiplayerPolicy.MayJoin(true,invite,"other-auth-id","abcde",now),"Legitimate separate-account native code join rejected");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",false,true,2,1,now),"Took control before native connection");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","stranger-auth-id",true,true,2,1,now),"Uninvited lobby owner accepted");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,false,2,1,now),"Public lobby accepted");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,true,5,1,now),"Non-1v1 capacity accepted");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,true,2,0,now),"Played after human disconnect");
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,true,2,2,now),"Duplicate/additional peer accepted");
            Check(MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,true,2,1,now),"Valid native companion proof rejected");
            invite.Enabled=false;
            Check(!MultiplayerPolicy.MayControl(true,invite,"other-auth-id","host-auth-id",true,true,2,1,now),"Host OFF left stale AI control");
            invite.Enabled=true;invite.ExpiresUtc=now;
            Check(!MultiplayerPolicy.ValidInvite(invite,now),"Expired invite accepted");
            invite.ExpiresUtc=now.AddDays(1);
            Check(!MultiplayerPolicy.ValidInvite(invite,now),"Unbounded invitation accepted");
            invite.ExpiresUtc=now.AddHours(1);invite.Model=3;
            Check(!MultiplayerPolicy.ValidInvite(invite,now),"Fourth model accepted");
            Check(ModelProfile.All.Length==3,"Existing three-model architecture changed");
            var wave=new DeliberateWaveDetector();bool triggered=false;
            for(int i=0;i<100;i++)triggered|=wave.Sample(i*.05,1.72,1.2,Math.Sin(i*.3)*.15);
            Check(!triggered,"Low hand movements trigger social waves");
            wave=new DeliberateWaveDetector();triggered=false;
            for(int i=0;i<100;i++)triggered|=wave.Sample(i*.05,1.72,1.7,0);
            Check(!triggered,"Stillness triggers social waves");
            wave=new DeliberateWaveDetector();int responses=0;
            for(int i=0;i<100;i++)if(wave.Sample(i*.05,1.72,1.7,Math.Sin(i*.05*10)*.15))responses++;
            Check(responses==1,"Deliberate wave does not trigger one response followed by cooldown: "+responses);
            Console.WriteLine("PASS: "+checks+" private multiplayer/account/lifecycle/gesture checks");return 0;
        }catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
