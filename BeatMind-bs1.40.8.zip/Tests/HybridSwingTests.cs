using System;
using System.Collections.Generic;
using SaberMind;
class HybridSwingTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static PhraseGeometry Geometry(int hand)
    {return new PhraseGeometry{ScoredHumanSwings=true,Top=new MotionVector(0,0,1),Shoulder=new MotionVector(hand==0 ? -.15 : .15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=hand};}
    static PhraseState Teacher(double t,int hand,bool roll)
    {
        double twist=roll ? .16*Math.Sin(6*t) : 0;
        var q=MotionRotation.Exp(new MotionVector(.55,0,0))*MotionRotation.Exp(new MotionVector(0,0,twist));
        return new PhraseState{Time=t,HumanSource=4,HumanGripWeight=.8,HumanWristWeight=.8,Grip=new MotionVector(hand==0 ? -.3529 : .3529,1.4118+.008*Math.Sin(4*t),.2794),Velocity=new MotionVector(0,.032*Math.Cos(4*t),0),Acceleration=new MotionVector(0,-.128*Math.Sin(4*t),0),Rotation=q,
            // Reproduce a valid-looking teacher that has slowed right at hit.
            AngularVelocity=q.Rotate(new MotionVector(0,0,roll ? .96*Math.Cos(6*t) : 0)),AngularAcceleration=q.Rotate(new MotionVector(0,0,roll ? -5.76*Math.Sin(6*t) : 0))};
    }
    static PhraseNote Note(int hand,int id,double time,int arrow,double spacing,double nps)
    {return new PhraseNote{Id=id,Time=time,Center=new MotionVector(hand==0 ? -.3 : .3,1.0649,1.05),Direction=HumanContext.Direction(arrow),Forward=new MotionVector(0,0,1),Spacing=spacing,LocalNps=nps};}
    static double TipRate(PhraseState s,PhraseGeometry g)
    {return MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Bottom)).Length;}
    static int Main()
    {
        try
        {
            foreach(int hand in new[]{0,1})foreach(bool roll in new[]{false,true})foreach(int arrow in new[]{0,1,2,3,4,5,6,7})
            {
                Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand,roll);};var g=Geometry(hand);var n=Note(hand,0,.6,arrow,1.14,1);
                var path=ReplayMotor.Build(teacher(0),new[]{n},g,teacher,9,1.7);var c=path.Contact(0);
                Check(!c.LimitedContact,"Ordinary hybrid contact became infeasible");
                Check(CutSafety.BladeDistance(path.Sample(n.Time),n.Center,g)<1e-7,"Hybrid lost fitted contact");
                Check(c.SwingPeak==n.Time && c.ScoringReleaseEnd==c.SwingEnd,"Hybrid starts braking before contact or drops release ownership");
                Check(Math.Abs(c.AngularVelocity.Length-CutSafety.StrokeFor(n).Speed)<1e-7,"Slow cut does not retain the 0.9.9 speed band");
                double hitRate=TipRate(path.Sample(n.Time),g),prior=0;
                for(int i=0;i<=100;i++)
                {
                    double t=c.SwingStart+(n.Time-c.SwingStart)*i/100;var s=path.Sample(t);double rate=TipRate(s,g);
                    Check(rate+1e-7>=prior,"Visible blade brakes before the note");prior=rate;
                    Check(Math.Abs(s.Rotation.Length-1)<1e-9,"Invalid wrist rotation");
                }
                Check(hitRate>=CutSafety.StrokeFor(n).Speed*.99,"Human teacher braking weakened the actual cut");
                Check(TipRate(path.Sample(n.Time+.01),g)>hitRate*.90,"Swing stops immediately after hitting");
                Check(MotionRotation.Log(c.Rotation*path.Sample(c.SwingStart).Rotation.Inverse).Length>=100*Math.PI/180-1e-7,"Slow hybrid cut lost full preparation angle");
                Check(MotionRotation.Log(path.Sample(c.SwingEnd).Rotation*c.Rotation.Inverse).Length>=64*Math.PI/180-1e-7,"Slow hybrid cut lost follow-through angle");
                foreach(double remaining in new[]{.08,.03,.01})
                {
                    n.Committed=c;var seed=path.Sample(n.Time-remaining);seed.Id=-1;
                    var next=ReplayMotor.Build(seed,new[]{n},g,teacher,9,1.7);var committed=next.Contact(0);
                    Check(object.ReferenceEquals(c.WristRoll,committed.WristRoll),"Replan replaced an ongoing replay roll");
                    Check(c.SwingStart==committed.SwingStart && c.SwingPeak==committed.SwingPeak && c.SwingEnd==committed.SwingEnd,"Replan restarted the scored clock");
                    for(double t=seed.Time+1e-6;t<c.SwingEnd;t+=.004)
                    {var a=path.Sample(t);var b=next.Sample(t);Check(MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8,"Hybrid replan changed a visible wrist");Check((a.AngularVelocity-b.AngularVelocity).Length<1e-6,"Hybrid replan compounded or slowed speed");}
                }
                // At both endpoints and contact, wrist roll is C2 zero. In the
                // middle it follows measured source twist, without moving tip.
                foreach(double t in new[]{c.SwingStart,c.SwingPeak,c.SwingEnd})
                {const double e=1e-7;var a=path.Sample(t-e);var b=path.Sample(t+e);var s=path.Sample(t);Check((MotionRotation.Log(b.Rotation*a.Rotation.Inverse)/(2*e)-s.AngularVelocity).Length<.02,"Hybrid boundary has incompatible angular velocity");}
            }
            foreach(int hand in new[]{0,1})foreach(double spacing in new[]{.30,.125,.06})
            {
                var g=Geometry(hand);Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,hand,true);};var notes=new List<PhraseNote>();
                for(int i=0;i<4;i++)notes.Add(Note(hand,i,.6+i*spacing,i%2==0 ? 1 : 0,spacing,2/spacing));
                var path=ReplayMotor.Build(teacher(0),notes,g,teacher,9,2.5);
                foreach(var n in notes)
                {var c=path.Contact(n.Id);var s=path.Sample(n.Time);Check(CutSafety.BladeDistance(s,n.Center,g)<.025,"Dense hybrid missed a reachable nominal contact");Check(MotionVector.Dot(s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top)),n.Direction)>1.5,"Dense hybrid lost arrow direction");Check(c.SwingPeak==n.Time,"Dense contact speed apex drifted");}
                for(double t=.01;t<notes[3].Time+.05;t+=.003)
                {var s=path.Sample(t);Check(s.AngularVelocity.Length<126,"Dense hybrid made an unbounded wrist loop");Check((s.Grip-g.Shoulder).Length<g.Reach+.001,"Dense hybrid violated reach");}
            }
            CloseCommittedRelease();
            Console.WriteLine(checks+" hybrid 0.9.9 contact / v14 replay / no pre-hit braking / follow-through assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    static void CloseCommittedRelease()
    {
        var g=Geometry(0);Func<double,PhraseState> teacher=delegate(double t){return Teacher(t,0,false);};
        var first=Note(0,0,.6,1,.152666,14);var alone=ReplayMotor.Build(teacher(0),new[]{first},g,teacher,9,1.7);
        first.Committed=alone.Contact(0);Check(first.Committed.SwingEnd>.614,"Close-cut fixture does not reproduce overlapping committed release");
        var second=Note(0,1,.614,1,.152666,14);var seed=alone.Sample(.55);seed.Id=-1;
        var combined=ReplayMotor.Build(seed,new[]{first,second},g,teacher,9,1.7);
        Check(combined.Contact(0)!=null && combined.Contact(1)!=null,"Committed release caused the next 14 ms contact to disappear");
        Check(combined.Contact(0).Time==first.Time && combined.Contact(1).Time==second.Time,"Close-cut correction changed hit times");
        Check(combined.Contact(0).SwingEnd<second.Time-.002,"Virtual release still extends past the next hit");
        var old=alone.Sample(.59);var corrected=combined.Sample(.59);
        Check(MotionRotation.Log(old.Rotation*corrected.Rotation.Inverse).Length<1e-7,"Future release correction changed the preceding approach");
    }
}
