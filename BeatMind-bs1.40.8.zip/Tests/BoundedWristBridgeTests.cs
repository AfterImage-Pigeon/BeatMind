using System;
using SaberMind;

class BoundedWristBridgeTests
{
    const double Radians=Math.PI/180;
    static int checks;static double maximumWError,maximumAlphaError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static void Near(MotionVector actual,MotionVector expected,double tolerance,string message)
    {Check((actual-expected).Length<=tolerance,message+": error="+(actual-expected).Length);}
    static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    static bool Finite(MotionVector value){return Finite(value.X) && Finite(value.Y) && Finite(value.Z);}
    static PhraseGeometry Geometry(double yaw,MotionVector axis)
    {
        var bottom=new MotionVector(.02,-.01,.03);
        return new PhraseGeometry{Bottom=bottom,Top=bottom+axis.Unit*.9,Forward=new MotionVector(Math.Sin(yaw),.17,Math.Cos(yaw))};
    }
    static void Basis(PhraseGeometry g,out MotionVector forward,out MotionVector right,out MotionVector up,out MotionVector blade)
    {up=new MotionVector(0,1,0);forward=new MotionVector(g.Forward.X,0,g.Forward.Z).Unit;right=MotionVector.Cross(up,forward);blade=(g.Top-g.Bottom).Unit;}
    static PhraseState Pose(PhraseGeometry g,double time,double pitch,double side,double roll,double pd,double sd,double rd,double pdd,double sdd,double rdd)
    {
        MotionVector f,right,up,local;Basis(g,out f,out right,out up,out local);
        var pitchRotation=MotionRotation.Exp(right*(-pitch));var rotatedUp=pitchRotation.Rotate(up);
        var canonical=pitchRotation*MotionRotation.Exp(up*side)*MotionRotation.FromTo(local,f,up);
        var blade=canonical.Rotate(local);var wp=right*(-pd);var ws=rotatedUp*sd;var wr=blade*rd;
        return new PhraseState{Time=time,Grip=new MotionVector(-.3+time*.2,1.2+time*.1,.25),Rotation=canonical*MotionRotation.Exp(local*roll),
            AngularVelocity=wp+ws+wr,AngularAcceleration=right*(-pdd)+rotatedUp*sdd+MotionVector.Cross(wp,ws)+blade*rdd+MotionVector.Cross(wp+ws,wr)};
    }
    static void Bounds(PhraseState pose,PhraseGeometry g,string context)
    {
        MotionVector f,right,up,local;Basis(g,out f,out right,out up,out local);var blade=pose.Rotation.Rotate(local);
        double pitch=Math.Atan2(MotionVector.Dot(blade,up),MotionVector.Dot(blade,f))/Radians;
        double side=Math.Asin(Math.Max(-1,Math.Min(1,MotionVector.Dot(blade,right))))/Radians;
        Check(pitch>=-40-1e-9 && pitch<=100+1e-9,context+": pitch escaped bounds at "+pitch);
        Check(side>=-45-1e-9 && side<=45+1e-9,context+": side escaped bounds at "+side);
    }
    static void Endpoint(BoundedWristBridge bridge,PhraseState expected,string context)
    {
        var actual=bridge.Sample(expected.Time);
        Check(MotionRotation.Log(actual.Rotation*expected.Rotation.Inverse).Length<1e-10,context+": endpoint quaternion changed");
        Near(actual.AngularVelocity,expected.AngularVelocity,1e-10,context+": endpoint angular velocity changed");
        Near(actual.AngularAcceleration,expected.AngularAcceleration,1e-9,context+": endpoint angular acceleration changed");
        Near(actual.Grip,expected.Grip,1e-12,context+": endpoint grip changed");
        Near(actual.Velocity,expected.Velocity,1e-9,context+": endpoint grip velocity was clamped");
        Near(actual.Acceleration,expected.Acceleration,1e-8,context+": endpoint grip acceleration was clamped");
    }
    static void Dense(BoundedWristBridge bridge,PhraseGeometry g,string context)
    {
        double epsilon=(bridge.End-bridge.Start)*1e-6;
        for(int i=0;i<=600;i++)
        {
            double time=bridge.Start+(bridge.End-bridge.Start)*i/600;var s=bridge.Sample(time);
            Bounds(s,g,context);Check(Finite(s.AngularVelocity) && Finite(s.AngularAcceleration),context+": nonfinite angular jets");
            if(i==0 || i==600)continue;
            var left=bridge.Sample(time-epsilon);var right=bridge.Sample(time+epsilon);
            double wError=(MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/(2*epsilon)-s.AngularVelocity).Length;
            double alphaError=((right.AngularVelocity-left.AngularVelocity)/(2*epsilon)-s.AngularAcceleration).Length;
            maximumWError=Math.Max(maximumWError,wError);maximumAlphaError=Math.Max(maximumAlphaError,alphaError);
            Check(wError<1e-6,context+": quaternion and angular velocity disagree at "+time+" error="+wError);
            Check(alphaError<1e-5,context+": angular velocity and acceleration disagree at "+time+" error="+alphaError);
        }
    }
    static void BodyFramesAndBladeAxes()
    {
        foreach(double yaw in new[]{0,70*Radians,-137*Radians})
        foreach(MotionVector axis in new[]{new MotionVector(0,0,1),new MotionVector(1,.2,.3),new MotionVector(0,0,-1)})
        {
            var g=Geometry(yaw,axis);string context="body yaw="+yaw+" blade="+axis.X+","+axis.Y+","+axis.Z;
            var a=Pose(g,1,-30*Radians,-40*Radians,170*Radians,0,0,0,0,0,0);
            var b=Pose(g,1.6,95*Radians,43*Radians,-175*Radians,0,0,0,0,0,0);
            var bridge=new BoundedWristBridge(a,b,g);Check(bridge.Safe,context+": zero-jet bounded endpoints rejected");
            Endpoint(bridge,a,context);Endpoint(bridge,b,context);Dense(bridge,g,context);
        }
        var corners=Geometry(0,new MotionVector(0,0,1));
        foreach(double pitch in new[]{-40*Radians,100*Radians})foreach(double side in new[]{-45*Radians,45*Radians})
        {
            var a=Pose(corners,1,pitch,side,0,0,0,0,0,0,0);var b=Pose(corners,2,pitch,side,0,0,0,0,0,0,0);
            var bridge=new BoundedWristBridge(a,b,corners);Check(bridge.Safe,"stationary rectangle corner rejected");Bounds(bridge.Sample(1.5),corners,"corner");
        }
    }
    static void NonzeroJetsAndUnboundedGrip()
    {
        var g=Geometry(33*Radians,new MotionVector(.15,-.3,1));
        var a=Pose(g,.4,-20*Radians,-20*Radians,35*Radians,.3,.15,.5,.4,-.2,.25);
        var b=Pose(g,.9,55*Radians,30*Radians,75*Radians,-.2,-.12,-.4,-.3,.25,-.2);
        a.Velocity=new MotionVector(25,-17,11);b.Velocity=new MotionVector(-13,9,-21);
        a.Acceleration=new MotionVector(1000,-300,450);b.Acceleration=new MotionVector(-500,100,600);
        var bridge=new BoundedWristBridge(a,b,g);Check(bridge.Safe,"feasible nonzero jets or unconstrained grip motion rejected");
        Endpoint(bridge,a,"nonzero");Endpoint(bridge,b,"nonzero");Dense(bridge,g,"nonzero");
    }
    static void RejectUnsafeControls()
    {
        var g=Geometry(0,new MotionVector(0,0,1));
        var a=Pose(g,1,95*Radians,0,0,10,0,0,0,0,0);var b=Pose(g,1.4,80*Radians,0,0,0,0,0,0,0,0);
        var pitchBridge=new BoundedWristBridge(a,b,g);Check(!pitchBridge.Safe,"outside pitch control polygon accepted");Endpoint(pitchBridge,a,"unsafe pitch");
        a=Pose(g,1,0,40*Radians,0,0,10,0,0,0,0);b=Pose(g,1.4,0,20*Radians,0,0,0,0,0,0,0);
        var sideBridge=new BoundedWristBridge(a,b,g);Check(!sideBridge.Safe,"outside side control polygon accepted");Endpoint(sideBridge,a,"unsafe side");
        a=Pose(g,1,-41*Radians,0,0,0,0,0,0,0,0);b=Pose(g,2,0,0,0,0,0,0,0,0,0);
        Check(!new BoundedWristBridge(a,b,g).Safe,"outside endpoint pitch accepted");
        a=Pose(g,1,0,46*Radians,0,0,0,0,0,0,0);Check(!new BoundedWristBridge(a,b,g).Safe,"outside endpoint side accepted");
    }
    static void RollBranchAndQuaternionSign()
    {
        var g=Geometry(-71*Radians,new MotionVector(1,.1,.5));
        var a=Pose(g,1,20*Radians,15*Radians,170*Radians,0,0,0,0,0,0);
        var b=Pose(g,2,20*Radians,15*Radians,-170*Radians,0,0,0,0,0,0);
        foreach(bool flipped in new[]{false,true})
        {
            var end=b.Copy();if(flipped)end.Rotation=end.Rotation*-1;
            var bridge=new BoundedWristBridge(a,end,g);Check(bridge.Safe,"nearest roll branch rejected");double travel=0;
            var previous=bridge.Sample(bridge.Start);
            for(int i=1;i<=1000;i++)
            {var current=bridge.Sample(bridge.Start+(bridge.End-bridge.Start)*i/1000);travel+=MotionRotation.Log(current.Rotation*previous.Rotation.Inverse).Length;Check(current.AngularVelocity.Length<40*Radians,"roll connector made an unnecessary full turn");previous=current;}
            Check(Math.Abs(travel-20*Radians)<1e-10,"nearest roll branch lost its 20 degree travel");Endpoint(bridge,end,"roll sign");
        }
        var same=a.Copy();same.Time=2;same.Rotation=same.Rotation*-1;
        var stationary=new BoundedWristBridge(a,same,g);var sample=stationary.Sample(1.5);
        Check(sample.AngularVelocity.Length<1e-12 && sample.AngularAcceleration.Length<1e-12,"quaternion sign generated wrist movement");
    }
    static void C2Handoff()
    {
        var g=Geometry(42*Radians,new MotionVector(.2,.1,1));
        var a=Pose(g,1,-20*Radians,-25*Radians,-20*Radians,0,0,0,0,0,0);
        var middle=Pose(g,1.5,30*Radians,15*Radians,15*Radians,.35,-.2,.4,.2,-.1,.15);
        var end=Pose(g,2.1,65*Radians,-5*Radians,60*Radians,0,0,0,0,0,0);
        var first=new BoundedWristBridge(a,middle,g);var second=new BoundedWristBridge(middle,end,g);
        Check(first.Safe && second.Safe,"feasible C2 handoff rejected");Endpoint(first,middle,"first handoff");Endpoint(second,middle,"second handoff");
        const double epsilon=1e-6;
        var left=first.Sample(middle.Time-epsilon);var right=second.Sample(middle.Time+epsilon);
        var halfLeft=first.Sample(middle.Time-epsilon*.5);var halfRight=second.Sample(middle.Time+epsilon*.5);
        double wError=(MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/(2*epsilon)-middle.AngularVelocity).Length;
        double alphaError=((right.AngularVelocity-left.AngularVelocity)/(2*epsilon)-middle.AngularAcceleration).Length;
        Check(wError<1e-6 && alphaError<.001,"joined quaternion/velocity/acceleration do not retain the shared endpoint jets");
        Check((halfRight.AngularAcceleration-halfLeft.AngularAcceleration).Length<(right.AngularAcceleration-left.AngularAcceleration).Length*.60+1e-8,"C2 handoff has a nonconvergent acceleration jump");
        Dense(first,g,"first handoff");Dense(second,g,"second handoff");
    }
    static int Main()
    {
        try
        {
            BodyFramesAndBladeAxes();NonzeroJetsAndUnboundedGrip();RejectUnsafeControls();RollBranchAndQuaternionSign();C2Handoff();
            Console.WriteLine(checks+" bounded wrist polygon / endpoint jets / body frame / blade axis / roll / C2 assertions passed; maximum angular velocity/acceleration derivative errors="+maximumWError+"/"+maximumAlphaError);return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
