using System;
using SaberMind;

class PreparationContactTests
{
    static int checks;
    static void Check(bool ok,string label){checks++;if(!ok)throw new Exception(label);}
    static int Main()
    {
        try
        {
            var g=new PhraseGeometry{Bottom=new MotionVector(),Top=new MotionVector(0,0,1),Grip=new MotionVector(),Shoulder=new MotionVector(-.3,1.4,.1),MinimumReach=.08,Reach=.7,Forward=new MotionVector(0,0,1)};
            var pivot=new MotionVector(-.3,1.2,.3);var center=pivot+new MotionVector(0,0,.8);double hit=1;
            foreach(double speed in new[]{22.3,40.6,45.8,52.4,90.0,120.0})
            {
                double rate=speed;
                Func<double,PhraseState> pose=delegate(double time){double t=time-hit;return new PhraseState{Time=time,Grip=pivot,Rotation=MotionRotation.Exp(new MotionVector(rate*t,0,0)),AngularVelocity=new MotionVector(rate,0,0)};};
                Check(PreparationContact.Quality(pose,g,center,g.Forward,new MotionVector(0,-1,0),hit,false)>.999999,"correct fast cut lost quality at true contact");
                foreach(double dt in new[]{1.0/72,1.0/90,1.0/120})
                {
                    // Reproduce the old first-frame-after-contact pose. At
                    // higher cadence its blade already leaves the note.
                    var late=pose(hit+dt);double distance=CutSafety.BladeDistance(late,center,g);
                    Check(distance>0.14,"fixture did not reproduce the after-contact evaluation error");
                    Check(PreparationContact.Quality(pose,g,center,g.Forward,new MotionVector(0,-1,0),hit,false)>.999999,"practice cadence changed continuous contact validity");
                }
                Check(PreparationContact.Quality(pose,g,center,g.Forward,new MotionVector(0,1,0),hit,false)==0,"wrong arrow received simulated confidence");
                Check(PreparationContact.Quality(pose,g,center,g.Forward,new MotionVector(0,1,0),hit,true)>.999999,"dot note was judged against an arrow");
            }
            Func<double,PhraseState> still=delegate(double t){return new PhraseState{Time=t,Grip=pivot};};
            Check(PreparationContact.Quality(still,g,center,g.Forward,new MotionVector(0,-1,0),hit,true)==0,"motionless blade received valid cut confidence");
            Func<double,PhraseState> missed=delegate(double t){return new PhraseState{Time=t,Grip=pivot+new MotionVector(1,0,0),AngularVelocity=new MotionVector(40,0,0)};};
            Check(PreparationContact.Quality(missed,g,center,g.Forward,new MotionVector(0,-1,0),hit,false)<.1,"reach-limited missed blade received valid confidence");
            foreach(double offset in new[]{-.035,-.020,0,.020,.035})
            {
                double time=hit+offset;
                Func<double,PhraseState> shifted=delegate(double t){return new PhraseState{Time=t,Grip=pivot,Rotation=MotionRotation.Exp(new MotionVector(45*(t-time),0,0)),AngularVelocity=new MotionVector(45,0,0)};};
                Check(PreparationContact.Quality(shifted,g,center,g.Forward,new MotionVector(0,-1,0),time,false)>.999999,"learned cut offset was replaced by nominal note time");
            }
            Console.WriteLine(checks+" continuous-contact preparation / timing-offset / direction / reach assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
