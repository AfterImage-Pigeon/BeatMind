using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using SaberMind;

class LearningOptimizationTests
{
    static int checks;
    static void Check(bool value,string label){checks++;if(!value)throw new Exception(label);}
    static List<HumanMotionExample> Input()
    {
        var list=new List<HumanMotionExample>();
        for(int i=0;i<400;i++)
        {
            var e=new HumanMotionExample{Count=1+i%3,Phase=(HumanPhase)(i%5),Duration=1.25,StartTime=i*1.5,Sequence=i,Recording="measured-run-"+(i%13),Score=.93+.0001*i,Context=new double[48],Curve=new float[129*21],Kinematics=new float[129*36],Anchors=new HumanAnchor[0]};
            for(int c=0;c<48;c++)e.Context[c]=.03*Math.Sin((i+1)*(c+3)*.011);
            e.Context[0]=(int)e.Phase;
            for(int p=0;p<129;p++)for(int j=0;j<3;j++)
            {
                double time=e.Duration*p/128,rate=.7+(i%19)*.1;
                var s=new PhraseState{Grip=new MotionVector(j==0 ? 0 : j==1 ? -.3 : .3,1.2+j*.1+.12*Math.Sin(time*rate+i*.23),.25+.06*Math.Cos(i*.17)),Velocity=new MotionVector(0,.12*rate*Math.Cos(time*rate+i*.23),0),Acceleration=new MotionVector(0,-.12*rate*rate*Math.Sin(time*rate+i*.23),0),Rotation=MotionRotation.Exp(new MotionVector(rate*time+i*.02,j*.05,0)),AngularVelocity=new MotionVector(rate,0,0)};
                HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
            }
            Check(HumanMotionModel.ValidExample(e),"benchmark input is not a valid continuous demonstration");list.Add(e);
        }
        return list;
    }
    static IEnumerable<HumanMotionExample> ChangedOrder(List<HumanMotionExample> list,Func<int> iteration)
    {
        int pass=iteration();bool reverse=pass==3;
        for(int i=0;i<list.Count;i++)yield return list[reverse ? list.Count-1-i : i];
    }
    static int Main(string[] args)
    {
        try
        {
            var input=Input();var fit=typeof(HumanMotionTraining).GetMethod("Fit",BindingFlags.Static|BindingFlags.NonPublic);
            var elapsed=new List<double>();List<HumanMotionExample> fitted=null;
            for(int run=0;run<3;run++){var clock=Stopwatch.StartNew();fitted=(List<HumanMotionExample>)fit.Invoke(null,new object[]{input,null});elapsed.Add(clock.Elapsed.TotalMilliseconds);}
            elapsed.Sort();string digest=HumanMotionTraining.Digest(JsonConvert.SerializeObject(fitted));
            if(args.Length>1 && args[1]=="capture")
            {File.WriteAllText(args[0],JsonConvert.SerializeObject(new{ReferenceVersion="1.0.0.24",InputExamples=input.Count,BankExamples=fitted.Count,FittedSha256=digest,MedianMilliseconds=elapsed[1]},Formatting.Indented));}
            else
            {
                var golden=JsonConvert.DeserializeObject<Dictionary<string,object>>(File.ReadAllText(args[0]));
                Check((string)golden["FittedSha256"]==digest,"equivalent optimization changed learned trajectories, derivatives, representatives or weights");
                Check(Convert.ToInt32(golden["BankExamples"])==fitted.Count,"equivalent optimization changed the learned bank size");
                int iteration=0;bool rejected=false;
                try{fit.Invoke(null,new object[]{ChangedOrder(input,delegate{return ++iteration;}),null});}catch(TargetInvocationException e){rejected=e.InnerException is InvalidDataException;}
                Check(rejected,"memoized assignments accepted reordered demonstration sequences");
                Console.WriteLine("Equivalent-fit benchmark: "+Convert.ToDouble(golden["MedianMilliseconds"]).ToString("0.0")+" ms reference, "+elapsed[1].ToString("0.0")+" ms optimized (offline fixture, not VR).");
            }
            foreach(var e in input)Check(HumanMotionModel.ValidExample(e),"fitting damaged source demonstration data");
            Console.WriteLine(checks+" equivalent replay fitting / sequence-order assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
