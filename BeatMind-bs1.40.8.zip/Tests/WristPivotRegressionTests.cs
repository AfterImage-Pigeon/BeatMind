using System;
using System.Collections.Generic;
using System.Diagnostics;
using SaberMind;

class WristPivotRegressionTests
{
    static int checks;
    static double sink;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    static PhraseGeometry Geometry()
    {return new PhraseGeometry{Top=new MotionVector(0,0,1),Forward=new MotionVector(0,0,1),Shoulder=new MotionVector(-.14,1.58,-.10),Reach=.90,MinimumReach=.10,Color=0,ControlledWrist=true,StableFastGrip=true,SwingSpeedScale=1.5};}
    static PhraseState Human(double t)
    {
        var q=MotionRotation.Exp(new MotionVector(-25*Math.PI/180,0,0));
        return new PhraseState{Time=t,Grip=new MotionVector(-.30,1.30,.22),Rotation=q,
            AngularVelocity=q.Rotate(new MotionVector(0,0,35))+new MotionVector(-2,0,0),HumanSource=12,HumanGripWeight=1,HumanWristWeight=1};
    }
    static MotionPhrase Tagged(int tag)
    {
        Func<double,PhraseState> pose=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(tag,t,0),AngularVelocity=new MotionVector(tag,0,0),HumanSource=tag};};
        var path=new MotionPhrase{Evaluator=pose,WristEvaluator=pose,RawTeacher=pose,AdaptedTeacher=pose};
        path.Knots.Add(pose(0));path.Knots.Add(pose(2));return path;
    }
    static void NestedCarry()
    {
        var a=Tagged(1);var b=Tagged(2);b.CarryFrom(a,.20,.80);
        var c=Tagged(3);c.CarryFrom(b,.40,1.10);
        for(double t=.4;t<1.10;t+=.002)
        {
            int expected=t<.8 ? 1 : 2;
            Check(c.Sample(t).HumanSource==expected,"overlapping carry selected the future seed instead of the outgoing pose");
            Check(c.SampleWrist(t).HumanSource==expected,"overlapping carry lost wrist ownership");
            Check(c.TeacherAt(t,false).HumanSource==expected && c.TeacherAt(t,true).HumanSource==expected,"overlapping carry changed the frozen diagnostic teacher");
        }
        Check(c.Sample(1.10).HumanSource==3,"carry did not end at its published boundary");
        var expectedPose=c.Sample(.65);
        for(int i=0;i<100;i++){var next=Tagged(10+i);next.CarryFrom(c,.60,.90);c=next;}
        Check((c.Sample(.65).Grip-expectedPose.Grip).Length<1e-12,"repeated overlapping handoffs changed a carried stroke");
    }
    static void SpeedOnly()
    {
        var random=new Random(7319);var g=Geometry();var curves=new List<BoundedWristBridge>();
        for(int k=0;k<80;k++)
        {
            var a=new PhraseState{Time=0,Rotation=MotionRotation.Exp(new MotionVector((random.NextDouble()-.5)*.8,(random.NextDouble()-.5)*.8,(random.NextDouble()-.5)*2)),AngularVelocity=new MotionVector(random.NextDouble()*8,random.NextDouble()*8,random.NextDouble()*8)};
            var b=new PhraseState{Time=.1+random.NextDouble(),Rotation=MotionRotation.Exp(new MotionVector((random.NextDouble()-.5)*.8,(random.NextDouble()-.5)*.8,(random.NextDouble()-.5)*2)),AngularVelocity=new MotionVector(random.NextDouble()*8,random.NextDouble()*8,random.NextDouble()*8)};
            var curve=new BoundedWristBridge(a,b,g);curves.Add(curve);
            for(int i=0;i<=100;i++){double t=b.Time*i/100;Check(Math.Abs(curve.AngularSpeed(t)-curve.Sample(t).AngularVelocity.Length)<1e-9,"allocation-free feasibility probe changed angular speed");}
        }
        var method=typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",Type.EmptyTypes);
        if(method!=null)
        {
            var allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),method);
            for(int i=0;i<100;i++)sink+=curves[i%curves.Count].AngularSpeed(.05);
            long start=allocated();var watch=Stopwatch.StartNew();
            for(int i=0;i<100000;i++)sink+=curves[i%curves.Count].AngularSpeed(.05);
            watch.Stop();long speedBytes=allocated()-start;
            start=allocated();for(int i=0;i<100000;i++)sink+=curves[i%curves.Count].Sample(.05).AngularVelocity.Length;
            long poseBytes=allocated()-start;
            Check(speedBytes<2048,"speed-only probes still allocate discarded poses");
            Check(poseBytes>speedBytes+1000000,"allocation comparison did not exercise the old pose probe cost");
            Console.WriteLine("100000 feasibility probes: speed-only allocated "+speedBytes+" bytes; pose probes allocated "+poseBytes+" bytes; speed-only elapsed "+watch.Elapsed.TotalMilliseconds+"ms");
        }
    }
    static void ArcAndPivot()
    {
        foreach(double spacing in new[]{.60,.125})
        {
            var g=Geometry();var human=Human(0);var center=human.Grip+human.Rotation.Rotate(g.Top)*.67;
            var notes=new List<PhraseNote>();int count=spacing>.2 ? 1 : 4;
            for(int i=0;i<count;i++)notes.Add(new PhraseNote{Id=i,Time=.5+spacing*i,Center=center,Direction=new MotionVector(0,i%2==0 ? 1 : -1,0),Forward=g.Forward,Spacing=spacing,LocalNps=1/spacing,ScoringType=1});
            var path=ReplayMotor.Build(Human(0),notes,g,Human,9,1.5);
            foreach(var note in notes)
            {
                var contact=path.Contact(note.Id);Check(contact!=null,"contact missing");
                var at=path.Sample(note.Time);Check(CutSafety.ContactFits(at,note.Center,g,.025),"wrist pivot lost an attainable contact");
                var blade=at.Rotation.Rotate(g.Top);var radial=MotionVector.Cross(at.AngularVelocity,blade);
                Check(radial.Length>at.AngularVelocity.Length*.98,"the scored swing is axial roll instead of tip travel");
                double distance=MotionVector.Dot(note.Center-at.Grip,blade);Check(distance>.50,"contact fitting put the block beside the grip: lever="+distance);
                if(count==1)
                {
                    double before=contact.SwingStart,after=contact.SwingEnd;
                    var first=path.Sample(before);var last=path.Sample(after);
                    double pre=Math.Acos(MotionPhrase.Clamp(MotionVector.Dot(first.Rotation.Rotate(g.Top),blade),-1,1));
                    double post=Math.Acos(MotionPhrase.Clamp(MotionVector.Dot(last.Rotation.Rotate(g.Top),blade),-1,1));
                    Check(pre>.8 && post>.8,"tip did not sweep a broad arc above/below the contact");
                    for(int i=1;i<160;i++)
                    {
                        var s=path.Sample(before+(after-before)*i/160);
                        Check((s.Grip-at.Grip).Length<.001,"reachable isolated swing translated the wrist during the tip arc");
                        Check(WristMotionLimits.Contains(s.Rotation,g),"broad arc left the configured blade bounds");
                    }
                }
            }
        }
    }
    static void ImpossibleReach()
    {
        var g=Geometry();var previous=Human(0);previous.Time=.4;
        var note=new PhraseNote{Id=1,Time=.5,Center=new MotionVector(-3,3,2),Direction=new MotionVector(0,-1,0),Forward=g.Forward,Spacing=.1,LocalNps=10};
        int evaluations;var contact=ReplayMotor.FitContact(Human(.5),note,g,previous,9,out evaluations);
        Check(contact.LimitedContact,"impossible reach was presented as an accurate contact");
        Check((contact.Grip-g.Shoulder).Length<=g.Reach*.985+1e-9,"fallback left the invertible reach domain");
        var decoded=ConstrainedReplayTrajectory.Unproject(contact,g);
        Check(Finite(decoded.Grip.Length) && Finite(decoded.Velocity.Length) && Finite(decoded.Acceleration.Length),"fallback inversion made nonfinite grip jets");
        Check(decoded.Velocity.Length<1000 && decoded.Acceleration.Length<1000000,"fallback near the reach barrier amplified grip jets");
    }
    static void GripOnlyParity()
    {
        var g=Geometry();
        foreach(bool spherical in new[]{false,true})
        {
            var a=Human(0);var b=Human(.3);a.Velocity=new MotionVector(1,.2,.3);b.Velocity=new MotionVector(-.2,1,.4);b.Grip+=new MotionVector(.1,.05,0);
            var curve=new ReachTransition(a,b,g,spherical);
            for(int i=0;i<=120;i++)
            {
                double t=i*.3/120;var full=curve.Sample(t);var grip=curve.SampleGrip(t);
                Check((full.Grip-grip.Grip).Length<1e-12,"grip-only sampling changed the reach route");
                Check((full.Velocity-grip.Velocity).Length<1e-10 && (full.Acceleration-grip.Acceleration).Length<1e-8,"grip-only sampling changed reach derivatives");
            }
        }
    }
    static int Main()
    {
        try{NestedCarry();SpeedOnly();ArcAndPivot();ImpossibleReach();GripOnlyParity();Console.WriteLine(checks+" wrist pivot / overlapping handoff / feasibility allocation assertions passed.");GC.KeepAlive(sink);return 0;}
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
