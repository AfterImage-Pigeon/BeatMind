using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using SaberMind;
using UnityEngine;

// Audit helper only. Executes the installed managed SaberMovementData and
// SaberSwingRatingCounter code in an ordinary process; never starts Unity/VR.
public static class NativeSwingAngleOracle
{
    public sealed class Rating
    {
        public double Before, After, RegisteredTime;
        public bool NotePlaneWasCut, Finished;
        public int BeforePoints { get { return (int)Math.Round(70*Math.Min(1,Before)); } }
        public int AfterPoints { get { return (int)Math.Round(30*Math.Min(1,After)); } }
    }
    public static Rating Evaluate(Func<double,PhraseState> sample,PhraseGeometry geometry,PhraseNote note,
        double registrationTime,double step,double phase)
    {
        var data=new SaberMovementData();
        var counter=new SaberSwingRatingCounter();
        bool active=false;
        double first=Math.Max(0,registrationTime-.52);
        int count=(int)Math.Ceiling((registrationTime+.55-first)/step);
        for(int i=0;i<=count;i++)
        {
            double t=first+(i+phase)*step;
            var s=sample(t);
            var top=s.Grip+s.Rotation.Rotate(geometry.Top-geometry.Grip);
            var bottom=s.Grip+s.Rotation.Rotate(geometry.Bottom-geometry.Grip);
            data.AddNewData(ToUnity(top),ToUnity(bottom),(float)t);
            if(!active && t>=registrationTime)
            {
                // Init replaces the original up plane with cross(cut plane,
                // note forward), so only the note's actual forward is needed.
                var forward=note.Forward.Length>.01 ? note.Forward.Unit : geometry.Forward.Unit;
                var up=-note.Direction.Unit;
                var rotation=RotationFor(forward,up);
                counter.Init(data,ToUnity(note.Center),rotation,true,true);
                active=true;
            }
        }
        return new Rating{Before=counter.beforeCutRating,After=counter.afterCutRating,
            RegisteredTime=registrationTime,NotePlaneWasCut=(bool)Get(counter,"_notePlaneWasCut"),Finished=(bool)Get(counter,"_finished")};
    }
    private static object Get(object obj,string name)
    {return obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(obj);}
    private static Vector3 ToUnity(MotionVector v){return new Vector3((float)v.X,(float)v.Y,(float)v.Z);}
    private static Quaternion RotationFor(MotionVector forward,MotionVector up)
    {
        // Managed matrix-to-quaternion conversion avoids native LookRotation.
        var right=MotionVector.Cross(up,forward).Unit;up=MotionVector.Cross(forward,right).Unit;
        double a=right.X,b=up.X,c=forward.X,d=right.Y,e=up.Y,f=forward.Y,g=right.Z,h=up.Z,j=forward.Z;
        double x,y,z,w,tr=a+e+j;
        if(tr>0){double s=Math.Sqrt(tr+1)*2;w=s*.25;x=(h-f)/s;y=(c-g)/s;z=(d-b)/s;}
        else if(a>e && a>j){double s=Math.Sqrt(1+a-e-j)*2;w=(h-f)/s;x=s*.25;y=(b+d)/s;z=(c+g)/s;}
        else if(e>j){double s=Math.Sqrt(1+e-a-j)*2;w=(c-g)/s;x=(b+d)/s;y=s*.25;z=(f+h)/s;}
        else{double s=Math.Sqrt(1+j-a-e)*2;w=(d-b)/s;x=(c+g)/s;y=(f+h)/s;z=s*.25;}
        return new Quaternion((float)x,(float)y,(float)z,(float)w);
    }
}

class NativeSwingAngleAudit
{
    private static string game;
    static int Main(string[] args)
    {
        game=args.Length>0 ? args[0] : @"C:\Users\comma\BSManager\BSInstances\1.40.8 (3)";
        AppDomain.CurrentDomain.AssemblyResolve+=delegate(object sender,ResolveEventArgs e)
        {
            string name=new AssemblyName(e.Name).Name+".dll";
            foreach(string dir in new[]{Path.Combine(game,"Beat Saber_Data","Managed"),Path.Combine(game,"Libs")})
            {string path=Path.Combine(dir,name);if(File.Exists(path))return Assembly.LoadFrom(path);}
            return null;
        };
        try{return Run();}catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    static int Run()
    {
        Console.WriteLine("Native SaberSwingRating steps: before100="+SaberSwingRating.BeforeCutStepRating(100,0)+
            "; after60="+SaberSwingRating.AfterCutStepRating(60,0)+
            "; normal75="+SaberSwingRating.BeforeCutStepRating(100,75)+
            "; normal82.5="+SaberSwingRating.BeforeCutStepRating(100,82.5f)+
            "; normal90="+SaberSwingRating.BeforeCutStepRating(100,90));
        foreach(double spacing in new[]{1.14,.30,.125,.06})
        foreach(int arrow in new[]{0,1,2,3,4,5,6,7})
        {
            var geometry=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(.15,1.77,-.025),Forward=new MotionVector(0,0,1),Reach=.65,MinimumReach=.12,Color=1};
            Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(.3529,1.4118,.2794),Rotation=MotionRotation.Exp(new MotionVector(.55,0,0))};};
            var notes=new List<PhraseNote>();
            for(int i=0;i<3;i++)notes.Add(new PhraseNote{Id=i,Time=.5+i*spacing,Center=new MotionVector(.3,1.0649,1.05),Direction=HumanContext.Direction(arrow),Forward=geometry.Forward,Spacing=spacing,LocalNps=spacing<.2 ? 8 : spacing<.5 ? 4 : 1});
            var path=ReplayMotor.Build(teacher(0),notes,geometry,teacher,9,3.4);
            foreach(var note in notes)
            {
                double before=1,after=1;int planes=0;
                foreach(double phase in new[]{0,.25,.5,.75})
                {
                    // Register around planned contact, as a swept collision can
                    // start before the saber top crosses the scoring plane.
                    var rating=NativeSwingAngleOracle.Evaluate(path.Sample,geometry,note,note.Time-.025,1.0/90,phase);
                    before=Math.Min(before,rating.Before);after=Math.Min(after,rating.After);
                    if(rating.NotePlaneWasCut)planes++;
                }
                Console.WriteLine("spacing="+spacing+" arrow="+arrow+" id="+note.Id+
                    " before="+before.ToString("F6")+" after="+after.ToString("F6")+" plane_cross_phases="+planes+"/4");
            }
        }
        return 0;
    }
}
