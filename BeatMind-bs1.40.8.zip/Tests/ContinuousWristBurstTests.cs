using System;
using System.Collections.Generic;
using SaberMind;

class ContinuousWristBurstTests
{
    const double Radians=Math.PI/180;
    static int checks;static double maximumWError,maximumAlphaError,maximumOuterWError,maximumOuterAlphaError;
    static void Check(bool condition,string message){checks++;if(!condition)throw new Exception(message);}
    static PhraseGeometry Geometry(double yaw,MotionVector axis)
    {return new PhraseGeometry{Top=axis.Unit,Forward=new MotionVector(Math.Sin(yaw),0,Math.Cos(yaw)),SwingSpeedScale=1.5};}
    static PhraseState Pose(PhraseGeometry g,double time,double pitch,double side,double roll)
    {
        var up=new MotionVector(0,1,0);var right=MotionVector.Cross(up,g.Forward).Unit;var local=(g.Top-g.Bottom).Unit;
        return new PhraseState{Time=time,Grip=new MotionVector(.3,1.3,.2),Rotation=MotionRotation.Exp(right*(-pitch))*MotionRotation.Exp(up*side)*MotionRotation.FromTo(local,g.Forward,up)*MotionRotation.Exp(local*roll),
            AngularVelocity=new MotionVector(90,-40,50),AngularAcceleration=new MotionVector(300,-700,600),TargetDirection=new MotionVector(0,-1,0)};
    }
    static PhraseState Recorded(double time,double[] quaternion)
    {return new PhraseState{Time=time,Grip=new MotionVector(.3,1.3,.2),Rotation=new MotionRotation(quaternion[0],quaternion[1],quaternion[2],quaternion[3]),TargetDirection=new MotionVector(0,-1,0)};}
    static void Contacts(ContinuousWristBurst burst,IList<PhraseState> original,string context)
    {
        for(int i=0;i<original.Count;i++)
        {
            var expected=original[i];var adjusted=burst.AdjustedContacts[i];var sampled=burst.Sample(expected.Time);
            Check(expected.Time==adjusted.Time && (expected.Grip-adjusted.Grip).Length==0,context+": contact time/grip changed");
            Check(MotionRotation.Log(expected.Rotation*adjusted.Rotation.Inverse).Length<1e-12,context+": contact orientation changed");
            Check(MotionRotation.Log(expected.Rotation*sampled.Rotation.Inverse).Length<1e-10,context+": curve moved contact orientation");
            Check((sampled.AngularVelocity-adjusted.AngularVelocity).Length<1e-8 && (sampled.AngularAcceleration-adjusted.AngularAcceleration).Length<1e-6,context+": contact jets disagree with curve");
            Check(adjusted.WristSpeedScale==1.5 && adjusted.WristSource==null,context+": continuous burst can receive a second speed boost");
            Check(!Object.ReferenceEquals(expected,adjusted),context+": burst modified an input contact");
        }
    }
    static void Dense(ContinuousWristBurst burst,PhraseGeometry g,bool directions,string context)
    {
        double epsilon=(burst.End-burst.Start)*1e-6;
        for(int i=0;i<=1000;i++)
        {
            double time=burst.Start+(burst.End-burst.Start)*i/1000;var s=burst.Sample(time);
            Check(WristMotionLimits.Contains(s.Rotation,g),context+": bounded burst leaves angle range");
            Check(s.AngularVelocity.Length<180,context+": continuous burst exceeds physical speed");
            if(directions)
            {
                var velocity=s.Velocity+MotionVector.Cross(s.AngularVelocity,s.Rotation.Rotate(g.Top-g.Grip));var plane=velocity-g.Forward*MotionVector.Dot(velocity,g.Forward);
                Check(MotionVector.Dot(plane.Unit,new MotionVector(0,-1,0))>.65,context+": down burst reversed or lost arrow direction");
                Check(MotionVector.Dot(velocity,new MotionVector(0,-1,0))>1.5,context+": down burst loses cut speed");
            }
            if(i==0 || i==1000)continue;
            var left=burst.Sample(time-epsilon);var right=burst.Sample(time+epsilon);
            double span=right.Time-left.Time;
            double wError=(MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/span-s.AngularVelocity).Length;
            double alphaError=((right.AngularVelocity-left.AngularVelocity)/span-s.AngularAcceleration).Length;
            maximumWError=Math.Max(maximumWError,wError);maximumAlphaError=Math.Max(maximumAlphaError,alphaError);
            Check(wError<1e-5,context+": analytic rotation/velocity mismatch "+wError);
            Check(alphaError<.005,context+": analytic velocity/acceleration mismatch "+alphaError);
        }
    }
    static void RecordedBurst()
    {
        var g=Geometry(0,new MotionVector(0,0,1));
        var a=Recorded(33.604000091552734,new[]{-.5634394670086011,.1417455500081169,-.35246008074820606,.7336320995900656});
        var raw=Recorded(33.61800003051758,new[]{-.4446354647618285,.11892019463925568,-.8421021781193806,-.2811071190660052});
        var incompatible=new ContinuousWristBurst(new[]{a,raw},g);
        Check(!incompatible.Safe,"unrelated raw 154 degree roll change was accepted at 180 rad/s");
        // Reproduce contact-frame transport: retain the second blade direction,
        // carry the first roll forward, then add legitimate measured axial roll.
        var b=raw.Copy();var bladeA=a.Rotation.Rotate(g.Top);var bladeB=b.Rotation.Rotate(g.Top);
        const double measuredRollRate=12;
        b.Rotation=MotionRotation.FromTo(bladeA,bladeB,new MotionVector(0,1,0))*a.Rotation*MotionRotation.Exp(g.Top*(measuredRollRate*(b.Time-a.Time)));
        Check((b.Rotation.Rotate(g.Top)-bladeB).Length<1e-12,"roll transport changed recorded blade direction");
        var contacts=new[]{a,b};var burst=new ContinuousWristBurst(contacts,g);
        Check(burst.Safe,"parallel-transported recorded 14 ms burst is not feasible; peak="+burst.MaximumAngularSpeed);
        Contacts(burst,contacts,"recorded");Dense(burst,g,true,"recorded");
        Outer(burst,g,contacts,"recorded");
        Console.WriteLine("RECORDED raw peak="+incompatible.MaximumAngularSpeed+"; transported roll peak="+burst.MaximumAngularSpeed+"rad/s; measured roll rate="+measuredRollRate);
    }
    static void MultipleContacts()
    {
        foreach(double yaw in new[]{0,55*Radians})foreach(MotionVector axis in new[]{new MotionVector(0,0,1),new MotionVector(.15,-.2,1)})
        {
            var g=Geometry(yaw,axis);var contacts=new List<PhraseState>();
            contacts.Add(Pose(g,1,80*Radians,25*Radians,10*Radians));
            contacts.Add(Pose(g,1.025,35*Radians,30*Radians,14*Radians));
            contacts.Add(Pose(g,1.050,-15*Radians,35*Radians,18*Radians));
            var burst=new ContinuousWristBurst(contacts,g);Check(burst.Safe,"ordered three-contact burst rejected");
            Contacts(burst,contacts,"multiple");Dense(burst,g,false,"multiple");
            Outer(burst,g,contacts,"multiple");
            var middle=burst.AdjustedContacts[1];const double epsilon=1e-7;
            var left=burst.Sample(middle.Time-epsilon);var right=burst.Sample(middle.Time+epsilon);
            var halfLeft=burst.Sample(middle.Time-epsilon*.5);var halfRight=burst.Sample(middle.Time+epsilon*.5);
            Check((right.AngularVelocity-left.AngularVelocity).Length<.01,"burst contact has a velocity jump");
            Check((halfRight.AngularAcceleration-halfLeft.AngularAcceleration).Length<(right.AngularAcceleration-left.AngularAcceleration).Length*.6+.001,"burst contact has a C2 acceleration jump");
        }
    }
    static void Outer(ContinuousWristBurst burst,PhraseGeometry g,IList<PhraseState> contacts,string context)
    {
        var first=burst.AdjustedContacts[0].Copy();var last=burst.AdjustedContacts[burst.AdjustedContacts.Count-1].Copy();
        burst.SetApproachAndRelease(.34,.42);
        Check(burst.Safe,context+": outer continuation exceeds speed or bounds");
        Check(burst.PrepStart<burst.Start && burst.ReleaseEnd>burst.End,context+": outer continuation has no positive duration");
        Check(burst.Start-burst.PrepStart<=.34+1e-12 && burst.ReleaseEnd-burst.End<=.42+1e-12,context+": outer continuation ignores available time");
        Contacts(burst,contacts,context+" with outer");
        double epsilon=Math.Min(burst.End-burst.Start,Math.Min(burst.Start-burst.PrepStart,burst.ReleaseEnd-burst.End))*1e-6;
        for(int i=0;i<=1000;i++)
        {
            double time=burst.PrepStart+(burst.ReleaseEnd-burst.PrepStart)*i/1000;var s=burst.Sample(time);
            Check(WristMotionLimits.Contains(s.Rotation,g),context+": outer wrist leaves angle rectangle");
            Check(s.AngularVelocity.Length<=180,context+": outer wrist exceeds speed limit");
            if(i==0 || i==1000)continue;
            var left=burst.Sample(time-epsilon);var right=burst.Sample(time+epsilon);double span=right.Time-left.Time;
            double wError=(MotionRotation.Log(right.Rotation*left.Rotation.Inverse)/span-s.AngularVelocity).Length;
            double alphaError=((right.AngularVelocity-left.AngularVelocity)/span-s.AngularAcceleration).Length;
            maximumOuterWError=Math.Max(maximumOuterWError,wError);maximumOuterAlphaError=Math.Max(maximumOuterAlphaError,alphaError);
            Check(wError<1e-5,context+": outer analytic rotation/velocity mismatch "+wError);
            Check(alphaError<.005,context+": outer analytic velocity/acceleration mismatch "+alphaError);
        }
        foreach(double time in new[]{burst.PrepStart,burst.ReleaseEnd})
        {
            var state=burst.Sample(time);Check(state.AngularVelocity.Length<1e-8 && state.AngularAcceleration.Length<1e-6,context+": remote outer endpoint is not stationary");
        }
        Check(MotionRotation.Log(first.Rotation*burst.Sample(burst.Start).Rotation.Inverse).Length<1e-12 && MotionRotation.Log(last.Rotation*burst.Sample(burst.End).Rotation.Inverse).Length<1e-12,context+": outer continuation changes contact rotations");
        foreach(double time in new[]{burst.Start,burst.End})
        {
            double step=Math.Min(burst.Start-burst.PrepStart,burst.ReleaseEnd-burst.End)*1e-5;
            var center=burst.Sample(time);var left=burst.Sample(time-step);var right=burst.Sample(time+step);
            var halfLeft=burst.Sample(time-step*.5);var halfRight=burst.Sample(time+step*.5);
            Check((right.AngularVelocity-left.AngularVelocity).Length<.05,context+": outer contact velocity jumps");
            double gap=(right.AngularAcceleration-left.AngularAcceleration).Length;
            Check((halfRight.AngularAcceleration-halfLeft.AngularAcceleration).Length<gap*.7+.002,context+": outer contact acceleration is not C2");
            Check((center.AngularVelocity-(time==burst.Start ? first : last).AngularVelocity).Length<1e-12,context+": outer contact jet changed");
        }
    }
    static void OuterBudgets()
    {
        var g=Geometry(0,new MotionVector(0,0,1));
        var contacts=new[]{Pose(g,2,20*Radians,10*Radians,0),Pose(g,2.025,20*Radians,10*Radians,15*Radians)};
        var burst=new ContinuousWristBurst(contacts,g);burst.SetApproachAndRelease(.34,.42);
        double speed=burst.AdjustedContacts[0].AngularVelocity.Length;
        Check(Math.Abs((burst.Start-burst.PrepStart)*speed*.91-115*Radians)<1e-12,"roll-only approach ignores 115 degree budget");
        Check(Math.Abs((burst.ReleaseEnd-burst.End)*speed*.91-75*Radians)<1e-12,"roll-only release ignores 75 degree budget");
        burst.SetApproachAndRelease(.001,.002);
        Check(Math.Abs(burst.Start-burst.PrepStart-.001)<1e-12 && Math.Abs(burst.ReleaseEnd-burst.End-.002)<1e-12,"outer continuation ignores short supplied availability");
        Check(burst.Sample(burst.PrepStart).AngularVelocity.Length<1e-10 && burst.Sample(burst.ReleaseEnd).AngularVelocity.Length<1e-10,"short outer continuation has moving endpoints");
    }
    static int Main()
    {
        try
        {
            RecordedBurst();MultipleContacts();OuterBudgets();Console.WriteLine(checks+" continuous wrist burst contact / bounded path / roll transport / C2 / outer continuation / derived jet assertions passed; maximum angular velocity/acceleration derivative errors="+maximumWError+"/"+maximumAlphaError+"; outer="+maximumOuterWError+"/"+maximumOuterAlphaError);return 0;
        }
        catch(Exception error){Console.Error.WriteLine(error);return 1;}
    }
}
