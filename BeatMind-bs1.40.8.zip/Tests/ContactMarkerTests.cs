using System;
using SaberMind;

// Reproduces real contacts lost behind optional release markers only 1.4 ms
// earlier, and an inherited release marker 5.3 ms after an incoming contact.
class ContactMarkerTests
{
    static int checks;
    static void Check(bool ok,string message){checks++;if(!ok)throw new Exception(message);}
    static int Main()
    {
        try
        {
            foreach(double offset in new[]{-.0014,-.00197,.0053})
            {
                var g=new PhraseGeometry{Top=new MotionVector(0,0,1),Shoulder=new MotionVector(.2,1.47,0),Forward=new MotionVector(0,0,1),Reach=.69,MinimumReach=.12,Color=1};
                Func<double,PhraseState> teacher=delegate(double t){return new PhraseState{Time=t,Grip=new MotionVector(.3,1.3,.25),HumanWristWeight=1};};
                var first=teacher(1);first.Id=173;first.AngularVelocity=new MotionVector(-8,0,0);first.SwingStart=.5;first.SwingPeak=1;first.SwingEnd=1.3+offset;
                var notes=new[]{new PhraseNote{Id=173,Time=1,Center=new MotionVector(.3,1.3,.9),Direction=new MotionVector(0,1,0),Forward=g.Forward,Spacing=.3,Committed=first},
                    new PhraseNote{Id=174,Time=1.3,ScoringType=5,Center=new MotionVector(.3,1.3,.9),Direction=new MotionVector(0,1,0),Forward=g.Forward,Spacing=.3}};
                var path=ReplayMotor.Build(teacher(.3),notes,g,teacher,9,1.6);
                Check(path.Contact(173)!=null,"release marker removed the original contact");
                Check(path.Contact(174)!=null,"optional release marker silently discarded the incoming contact at offset "+offset);
                Check(path.Contact(174).Time==1.3,"marker priority shifted the incoming contact time");
                for(int i=1;i<path.Knots.Count;i++)Check(path.Knots[i].Time>path.Knots[i-1].Time,"release/contact knots are not ordered");
            }
            Console.WriteLine(checks+" contact priority / inherited marker assertions passed.");return 0;
        }
        catch(Exception e){Console.Error.WriteLine(e);return 1;}
    }
}
