# 1.0.0.21 — restore 1.0.0.14 motion, accelerate swings by 50%

This restores the user's chosen 1.0.0.14 trajectory engine. The later forced wrist arcs, range fitting, added roll generator and wrist burst controller are no longer used by the gameplay planner. Human replay fitting and v14 progressive fallback acceleration are restored. Current learning, persistence, the 250,000 timestamp budget, three models, menus, invisible body, F6 camera controls and unranked protections remain in place.

New fitted contacts receive one 1.5× speed increase. Linear and angular velocity scale together; corresponding acceleration scales by 2.25. An offline regression initially found three otherwise valid cuts becoming directionally invalid when only angular velocity was increased: the recorded hand translation and wrist rotation counterbalanced each other. Scaling the connected contact jet preserves that relationship. Contact grip, orientation and hit time remain fitted using v14 behavior. The original progressive fallback window is compressed by 1.5, preserving its normalized wrist arc and acceleration profile. Committed contacts retain their boosted speed and clock without another multiplication during replanning.

This restores v14's original constraints as requested. The later −40°…100° pitch and −45°…45° side limits are no longer applied. Whole trajectory sampling remains continuous; the speed change is not a global replay time warp. Existing reach or stability adaptation can still restrict a contact or its speed.

## Verification

- Built against the installed Beat Saber 1.40.8 assemblies, without compiler warnings or errors.
- Generated 1,248 motion states by compiling the actual archived v14 source. The restored engine at baseline speed passed 24,960 component comparisons, with a maximum numerical difference of 6.78×10⁻¹¹.
- Passed 15,426 focused checks covering the 50% boost, preserved fallback arc and progressive acceleration, fitted contact position/orientation/time, repeated committed replans, and counterbalanced human hand/wrist motion.
- Passed the original v14 movement regressions and the current replay alignment, 250,000 timestamp cap, collection ownership, learning/persistence, separate menu bindings, unranked policies and all 32 native Harmony target checks. Native target checks resolve game methods; they do not execute gameplay.
- Replayed eight eligible human recordings offline using the existing 250,000 timestamp model: 1,337 plans, 5,915 nominal contacts and 666,649 sampled states per variant. Both baseline and faster variants had zero unconstrained contact misses, zero unconstrained direction differences and zero reach violations. Stability-limited nominal misses changed from 243 to 181; direction differences on limited contacts changed from 10 to 15. These are geometric proxies, not Beat Saber cut scores or measured in-game accuracy.
- Faster replay peak grip speed was 20.44 m/s, peak angular speed 182.56 rad/s; maximum angular derivative error was 1.55×10⁻⁵ rad/s. The offline linear speed guard explicitly uses the requested 1.5× baseline budget (27 m/s rather than 18 m/s). No runtime rotation clamp or extra smoothing was added to pass this check.

## Remaining lag investigation

The last installed v20 log recorded peak planning slices under 1.5 ms, so that evidence does not establish planning as the remaining lag source. Its 141.50 ms collection peak included pre-song training, so it cannot establish a gameplay collection pause either.

A fixed 64-record frame-gap trace now records gameplay gaps above 25 ms, AI tick/saber CPU duration, explicit collection duration and observed collection cycles. It formats/logs only when the session ends; ordinary recording has no per-frame allocation or file writes. Pause/training boundaries are excluded. Gameplay-only collection peaks are reported separately from training peaks. Collection policy is unchanged. Frame gaps include game/render/other-plugin time and are not automatically attributed to the AI.

No in-game or VR session was run for this build. Remaining lag, visual feel, actual early blade collisions and cut accuracy need live verification. F6 uses the retained v20 implementation and also needs that live check.
