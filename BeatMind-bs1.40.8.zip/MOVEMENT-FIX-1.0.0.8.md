# Movement fix 1.0.0.8

The fallback controller uses one opening gesture per level, one unused gesture per contiguous break, and one captured ending. A gesture plays once at its recorded speed, is cropped if its region is short, and settles if the region is long. Exhausted or missing gesture demonstrations produce an idle interval. Opening preparation finishes before the first cut. Exact-map playback remains one temporally ordered human recording.

## Confirmed causes and changes

- Backward constraint probes could clear and regenerate already chosen human sequences. Both hands could therefore jump without a new note or route. Earlier probes now use stable pre-roll; look-ahead cannot regenerate published motion.
- An asynchronously loaded exact replay could take over during a future sample, using a future timestamp or changing the teacher halfway through a plan. Adoption now occurs at the playback frame boundary. A source revision requests a new plan; existing plans retain immutable shared head/left/right trajectories and their shoulder geometry.
- One-second destination spans compressed 1.25-second playing demonstrations by 25%. Playing spans now retain source duration and recorded speed. The existing scored-contact speed floor and learned timing policy are unchanged.
- Long interpolation intervals spread fast local tracker derivatives into extra loops. Their middle now follows the actual position/rotation travel required by the transition; short C2 edges preserve the measured endpoint derivatives.
- Mandatory approximately 102-degree preparation and 60-degree release waypoints added swings over the human recording. These universal arcs were removed. The motor carries the same fitted displacement and wrist offset through the actual recorded approach and recovery.
- A shoulder detour interpolated its endpoint radii, replacing a real arm tuck with a large orbit. Source detours now preserve the original time-varying radius and its derivatives, changing only the direction around the forbidden shoulder region. Only unsafe local windows are expanded. Recorded wrist motion remains unchanged.
- Applying the radial projection to an already projected seed or repair endpoint caused a millimetre-sized teleport. Corrections and repair joins now use the analytical projection preimage, so the final constraint is applied once while retaining pose, velocity and acceleration.
- Sparse safety probes could miss brief motion spikes inside a long interval. Certification also samples at 240 Hz.
- Spawned notes could retain approximate map poses because geometry was refreshed only after deciding to replan. Native contact geometry now refreshes before validity checks, including upcoming contacts.
- Contact geometry used nominal note time even when learned timing scheduled a different hit. It now predicts the native parabolic jump at the preserved timing offset. At typical jump speeds, 20 ms can represent about 40 cm. Arrow directions include the actual parent rotation.
- Motion derivatives used capped Unity frame time while poses used song time. They now use elapsed per-hand song time. Traces include raw teacher/planned derivatives, repair stage, and sample interval.
- Contact candidate scoring repeatedly sampled the same other-hand pose. It is now evaluated once per contact fit.

## Verification

The offline suites cover opening/break exclusivity and exhaustion, stable playback under out-of-order queries, asynchronous source adoption, frozen plans, recorded source speed, localized score assistance, exact feasible contacts, preserved cut speed, arrow direction, visible/analytic derivative agreement, shoulder crossings, projection round-trips, repair boundaries, native learned-offset geometry, and song-clock handling. Existing policy, results, restart, dot-pattern, replay, menu, and unranked hook checks remain.

The old implementation fails the localized-opening regression: a future cut rewrites the wrist by approximately 50 degrees more than half a second before its first note. A real-recording shoulder failure was also reproduced at 63.43 seconds: radius grew from 0.1615 m to 0.5539 m and speed from 10.50 m/s to 20.33 m/s. The corrected detour retains the original radius and measures 11.57 m/s there.

The user clip is only 0.408 seconds long. It shows abrupt broad sweeps; it alone cannot prove the full cause. Newer live logs from build 1.0.0.7 measured simultaneous movement spikes up to approximately 83 m/s before the first note. The offline work isolates several underlying failures; it does not reproduce that exact live frame with native Unity geometry.

The broad validator uses actual human recordings and approximate offline note geometry. Its proxy contact misses, stability-limited contacts, runtime cost, and measured extrema remain in MovementFixValidation-1.0.0.8.json. Proxy misses are not an in-game accuracy measurement. No VR playthrough, perfect-score claim, or successful multiplayer test is asserted.

The replay model, saved learning, settings, best replays, three AI models, invisible articulated body, F8, score-submission blocking, and existing controls remain. Errors originating in other installed mods were not edited or claimed fixed.
