# SaberMind private 1v1 companion foundation

Build: BeatMind Human Beta V1.0.0, DLL file version 1.0.0.4, Beat Saber PCVR 1.40.8.

This build adds the Create Server controls and an opt-in native multiplayer gameplay adapter for a **separate, independently authenticated Beat Saber client**. It does not create another authenticated player inside your current game. A second signed-in account/client is required. No second account or live multiplayer connection was available for validation, so this is a foundation awaiting an actual two-client test, not a verified one-click opponent.

## Why a separate client

The installed native `IMultiplayerSessionManager` has one `localPlayer`. `ConnectedPlayerManager.HandleConnected` creates that local player using the connection manager's authenticated user ID and name. `NetworkPlayerModel` uses an `IPlatformUserModel` and a platform authentication provider. The verified interfaces do not expose a factory for adding another authenticated local participant. MultiplayerCore adds custom packets and synchronization options; it does not provide a second platform identity. BeatTogether authenticates player tickets and creates ordinary multiplayer connections.

The supported architecture is therefore: human's normal client + a second licensed/signed-in client running the same mod in explicit companion mode. Both connect normally to a private lobby. Authentication, ownership, entitlements, map loading, server protections and synchronization remain native. The bot does not borrow the host's identity, alter their username or occupy their avatar.

Primary source references examined:

- [MultiplayerCore](https://github.com/Goobwabber/MultiplayerCore), commit `0f20a09b3a0360c9c13985f1f8996f5fb7cacd2d`: `Players/MpPlayerManager.cs`, node/score synchronization extensions.
- [BeatTogether](https://github.com/BeatTogether/BeatTogether), commit `82fd4a48370ccd33e66ab5280e4c7a84447a38c0`: server selection/configuration.
- [BeatTogether MasterServer](https://github.com/BeatTogether/BeatTogether.MasterServer), commit `c2ca5a8906d3d45928d69a5145544f190308ab03`: `GetMultiplayerInstanceController` validates identity/authentication and creates private sessions. The dedicated transport owner can be a server; the adapter verifies the invited human in the session's real participant list.

Installed `Main`, `BGNetCore`, `Networking`, `PlatformUserModel`, `GameplayCore`, BSML and BS Utils assembly metadata/IL supplied the actual hook signatures. Read-only inspection captures are in `MultiplayerResearch`; public source clones are development references and are not included in the install ZIP.

## Host setup

1. Use your normal Beat Saber client/account. Do not add the companion startup flag to this client.
2. ONLINE → CREATE SERVER. The options appear to the **left** of the native panel: **Let SaberMind join you?** and **SaberMind Model**. The dropdown appears only while enabled. Model 1/2/3 map to the existing Rapid/Natural/Human Simulation profiles; your solo model preference is unchanged.
   During online song selection, the same controls are also available in **Mods → SaberMind 1v1**. The solo learning menu remains **Solo → Mods → BeatMind**. The two 1v1 views share settings and refresh together, with independent UI bindings.
3. Enable SaberMind and create the server. The form is constrained to a private, two-player lobby. With SaberMind OFF, the original form passes through unchanged.
4. Once native creation succeeds, the mod writes `UserData/AIPlayAndLearn/SaberMindPrivateInvite.json`. This contains the ordinary private code, host's network ID, selected model and an expiring lobby nonce. It contains no authentication tickets or platform credentials.

## Companion setup

Use a second legitimately signed-in Beat Saber client/account, typically on a second machine, with this build and compatible multiplayer mods installed. Both clients must use the same multiplayer service and have the selected maps available/entitled through the normal game.

Make the host's invitation file readable by both clients using a file share you control. **Use the live file**, rather than a detached copy, for ON/OFF and model changes. The host may choose another invitation location with `--sabermind-invite "D:\SaberMindPrivate\Invite.json"`; its default remains the UserData path above. No file share or second game process is created automatically.

Start only the second client with:

```text
--sabermind-companion --sabermind-invite "\\YOUR-HOST\YOUR-SHARE\SaberMindPrivateInvite.json"
```

Use the normal ONLINE → join-by-code flow on that client, using the private code in the invitation. This foundation currently requires normal UI joining/readiness; it does not launch, sign in or navigate another client automatically. Select/ready the same map and settings normally. Keep per-player difficulty/modifier overrides off when you want an identical chart. The adapter consumes the actual scene's transformed beatmap and gameplay settings, not a separate copy of the map.

The companion's displayed network name is **SaberMind**. The alias is restricted to explicit companion mode with a valid invite and an authenticated ID different from the host's. Account IDs and authentication tickets are never replaced. If the connected name, private code, capacity or invited peer identity does not match, the AI refuses control and disconnects. Public matchmaking, arbitrary server joins and creating lobbies are disabled in companion mode. An ordinary host client is unaffected by these companion-only guards.

## Gameplay and lifecycle

- Native song synchronization starts the existing `Session` at native `MultiplayerController.StartGameplay`. No accelerated pre-song trainer or automatic solo restart runs in multiplayer.
- The existing note policy, pattern planner, imitation matcher, saved map/general skills and body/wrist pipeline remain authoritative. The current implementation already uses **65 phase points**, not the older 48; it retains that higher resolution.
- Only the companion's injected local note manager, score controller, player transforms and sabers are controlled/observed. Remote players and the human host have no AI session in their process.
- The companion uses the same body/arm motor and anatomical wrist/reach limits. In multiplayer the physical FK grip and constrained wrist drive the actual saber; unreachable targets may miss. Solo's existing accuracy behavior is preserved.
- Native collision/cut callbacks produce all scores, combos, bad cuts, misses and failures. The adapter never calls a successful-cut injection method, changes notes or edits synchronized scores. The solo no-fail assistance is not applied in multiplayer; server-selected gameplay modifiers still apply normally.
- Native `MultiplayerLocalActiveClient` publishes the final head/hand transforms using its ordinary synchronization buffers, packet rates and remote interpolation. Motion phase points are not sent over the network. Learning is saved from actual cuts/results after the attempt.
- Model 3 can recognize a deliberate raised-hand wave from measured remote controller motion and give one coordinated body/arm/wrist response with a cooldown. Default lobby behavior is stillness. Gameplay/scene preparation suspends lobby behavior immediately. No fake avatar is rendered.
- F8 stops AI control for the current run. The current score remains unranked. Later normally started private rounds can use the companion again.
- Native completion, client destruction, disconnect, host departure, invite replacement/revocation and shutdown dispose the AI/social rigs and restore tracked transforms. A changed model is used on the next song. No duplicate local player, avatar or menu is created.
- The host's OFF toggle revokes the live invitation; the companion notices within approximately 0.5 seconds and disconnects. If you use a detached file copy, it cannot receive host-side model/revocation changes. Native host-disconnect detection still applies.
- BS Utils submission blocking is applied before the companion controls a saber and retained after takeover. Private multiplayer scores remain real; external ranked submissions are blocked. No PP estimates are fabricated.

## Diagnostics and validation

Logs report architecture/role, private invitation setup, join requests, connection/cleanup failures, native map/song binding, real gameplay completion and deliberate gesture responses. Codes/tickets are not logged by this adapter. Existing measured saber/replay traces remain available.

The project compiles against the installed 1.40.8 assemblies. Offline policy checks cover explicit role, separate identity, expiry, private code, private capacity, real invited-peer presence, host OFF, disconnect conditions and gesture detection/cooldown. Static checks verify native hook/field signatures and embedded menu bindings. Existing solo, learning, dot-pattern, imitation and speed-envelope regressions run alongside them.

These checks do **not** validate VR layout, network authentication acceptance, ready/rematch behavior, remote avatar pose offsets, map entitlement/loading or live cutting/score accuracy across two clients. Those require the second signed-in client and actual private multiplayer testing. If a binding/identity check fails, the foundation stops instead of creating a substitute opponent.

Changed integration files: `MultiplayerPolicy.cs`, `MultiplayerIntegration.cs`, `MultiplayerPatches.cs`, `MultiplayerMenu.cs/.bsml`, `MultiplayerGestures.cs`, `MultiplayerSocial.cs`. `Session.cs` adds the local multiplayer entry point/ownership/physical constraints; `Patches.cs` scopes observation/pose control and keeps solo no-fail out of multiplayer. `Models.cs`, `Plugin.cs`, `Menu.cs` and `Build.ps1` add persisted options, initialization, cleanup and verified references/resources. The movement planner changes are documented separately in `OPENING-OVAL-NOTES.md`.
