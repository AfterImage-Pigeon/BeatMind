# Continuous human motion rebuild — 1.0.0.7

## What was replaced

The earlier residual movement library reconstructed motion around generated swings. Its paired same-hand windows and independent channel gating could omit the shared body clock, openings, breaks and endings. The new implementation operates on simultaneous full head and saber motion, preserving each demonstration's temporal order and recorded transitions.

Old gameplay trajectory/deformation engines were backed up under `Backups/before-whole-body-rebuild` and removed from active Source. Obsolete tests against the deleted engines were archived there too. Saved note timing/stroke learning, models, scoring, results, leaderboard blocking, replay storage, training screen and multiplayer integration remain.

## Underlying problems fixed

- Human poses and target contact grips could be fitted independently of saber rotation. The new contact solver fits grip, wrist rotation and blade contact distance together, with both outgoing and upcoming motion in its cost.
- A normalized quaternion polynomial could approach zero magnitude when opposing wrist orientations were combined, causing angular instability. Rotation interpolation now uses analytic SO(3) curves, with consistent angular velocity and acceleration.
- High instantaneous tracking acceleration was being extended over long handoffs. Short C2 boundary joins preserve the true outgoing/incoming derivatives while preventing that micro-impulse from defining the entire recovery.
- An initial head glance was used as a world-forward calibration. Recorded BeatLeader poses already use the level origin frame; registration now uses the median standing position without rotating the map to the first glance.
- Score-event time was confused with physical note time. BeatLeader's installed recorder writes native `noteData.time` to the BSOR `spawnTime` field. The movement chart uses that field, not the later score-processing timestamp.
- Recorded saber-root poses were treated as hand/grip poses. The body rig now converts them using each native saber's actual grip socket and the corresponding angular velocity/acceleration offset terms.
- A last-stage IK clamp could change a planned hand target. Continuous radial barriers now carry matching position, velocity and acceleration at both reach boundaries before the articulated pose is published.
- The minimum-reach sphere could amplify tangential velocity when a hand path passed close to the inferred shoulder. Source proximity windows and incompatible Cartesian joins now receive continuous shoulder-relative arcs, with transported direction frames, matching endpoint derivatives and unchanged recorded wrist motion. Unsafe local recovery joins are checked and expanded before publication. Safety probes include the short edges of each span, not just its interior.
- Expanding two local stability repairs could make them overlap. Repairs are merged again before joining, avoiding a handoff into the middle of another bridge.
- A short phase remainder could squeeze an entire recorded sequence into a tiny interval. Temporal scaling is bounded; brief remainders crop a continuous source sequence, and a short source clip limits the destination span instead of abruptly freezing midway through it.
- A cache bounded by eight clips could evict the currently displayed sequence when a three-second look-ahead generated many short fragments. It now retains eight seconds of motion, so future planning cannot reselect the present pose or reset its momentum.

## Temporal learning

`HumanMotion.cs` stores a sequence's source start time, duration and ordering, 129 coordinated pose samples and 36 derivative channels alongside its 21 pose channels. Reconstructing a retained sequence uses its stored derivatives, including the endpoints; it does not infer a new motion from isolated pose targets.

`HumanMotionTraining.cs` fits whole measured examples. Its motion loss compares corresponding ordered times, position/orientation, linear velocity/acceleration and angular velocity/acceleration. Acceleration loss is robust to isolated tracking impulses; the original derivatives remain stored. Whole recordings are held out for validation, so neighbouring snippets from the same run cannot leak into both sides of the validation split. Boundary matching is optimized from the observable starting posture and motion. Tracking gap repairs are never presented as measured human training data.

The initial fixed context strength did not outperform the generic sequence baseline on separate recordings. Context and incoming-motion strength are now jointly calibrated, with that baseline included as a real candidate. This installation's additional calibration uses every third non-held-out recording to build an independent validation bank; held-out recordings never enter that bank. The final demonstration bank still uses all eligible recordings. The validation loss includes kinematics, so this calibrates motion continuity rather than just selecting similar positions. These errors measure sequence reconstruction, not cut accuracy or a subjective human-realism score.

`HumanMotionGraph.cs` maintains one clock for the head and both hands. A compatible full chart uses the complete qualifying source recording and a shared time warp. Other charts use whole sequences selected by both hands' upcoming pattern and outgoing momentum. A time warp scales velocity by its rate and acceleration by rate squared plus the clock acceleration term. Both linear and rotational motion obey those same rules. C2 transitions keep the previous sequence's position, velocity, acceleration, wrist rotation, angular velocity and angular acceleration. An ending settles once rather than abruptly zeroing its final derivatives or looping a victory gesture.

`ReplayMotor.cs` and `ConstrainedReplayTrajectory.cs` adapt that continuous demonstration to actual note geometry, native arrow directions, blade contact, learned hit times, the retained contact-speed floor and anatomical reach. Dense patterns retain joint planning through their contact sequence. Dot notes can use successful measured cut directions on an exact chart; the existing pattern-aware alternation remains available otherwise. No per-frame randomness is added.

`BodyRig.cs` reconstructs an invisible articulated player. Replay data directly measures head and saber roots; torso, shoulder and elbow motion is inferred. User proportions and native grip offsets connect those to the displayed sabers. The arm hierarchy has no renderers.

## Verification and practical limits

The regression suite covers ordered versus reversed demonstrations, identical poses with different motion derivatives, derivative storage/reconstruction including sequence endpoints, time scaling, analytic velocity/acceleration, wrist angular motion, synchronized exact-map head/hands, openings/breaks/endings/captured celebration, eligibility/bot filtering, cache/corrupt data, exact valid contacts, native arrow-direction velocity, continuous handoffs and reach limits. Existing policy, persistence, restart, dot pattern, multiplayer and results tests remain. Both menu resources and all 32 Harmony targets are resolved against this installed game.

The real-recording validator exercises multiple whole human recordings over hundreds of thousands of time samples. Its note positions are a quantized offline proxy, not the live Unity note jump geometry: BSOR lacks the native transformed chart positions needed to reproduce those exactly. It reports proxy misses and stability-limited contacts openly. Unflagged infeasible contacts, nonfinite trajectories, reach violations or discontinuous angular derivatives fail validation. These are geometry/stability checks, not an in-game accuracy benchmark.

Exact leaderboard scores are neither manufactured nor submitted. Recorded maximum-score calculations retain regular/arc/chain scoring and the multiplier ramp; PP stays unavailable without reliable data. Existing measured predictions are historical feedback, not a claim about this new motor's live performance.

This release was built and validated offline. No successful VR session or private multiplayer match is claimed. Absolute realism, identical human performance and perfect note scores are not promised. The game must still be used to measure visual quality, cut scores and frame-time behaviour.
