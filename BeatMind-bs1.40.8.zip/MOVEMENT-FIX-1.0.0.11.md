# SaberMind hand pivot and wrist recovery — 1.0.0.11

Beat Saber PCVR 1.40.8. Public name remains BeatMind Human Beta V1.0.0.

## Evidence

Inspected `Beat Saber 2026.10.02 - 17.18.10.02.mp4` (25.626 seconds, approximately 120 fps), including detailed 50 ms frame sequences at 3.15–3.85 and 8.55–9.15 seconds. The first interval shows the broad recovery arcs; the second shows the return/preparation around an upward cut. The clip ends near song time 46.227, giving an approximate clip-to-song offset of 20.60 seconds.

The saved 17:16:27 game log identifies 100Bills / Expert. The accompanying trace compares the frozen human teacher, adapted pose, planned rotation, controller command and final saber transform. Controller/final rotation error is zero at the trace's reported precision. At song time 23.9598, the right teacher turns about 4.7 degrees between saved samples while the command turns about 91.6 degrees. At song time 33.2671, the left teacher grip travels about 7.5 mm between samples while the requested grip travels about 235 mm. These demonstrate amplification in fitting/planning, rather than proving every movement in the recording has one cause. Some source demonstrations themselves contain large wrist movements.

## Confirmed causes and changes

- **ReplayMotor.cs:** the contact optimizer could trade grip travel against the penalty for changing wrist orientation. Its fixed-pivot candidate iteratively aimed from the blade bottom, then rotated that bottom around the hand, leaving the contact approximation inconsistent with the actual pivot. It also admitted an orientation parallel to the required arrow, then compensated with handle velocity. Contact fitting now solves the rigid blade/pivot equation directly, checks whether angular tip motion can make the instructed cut in the note plane, and prefers minimum grip displacement among valid candidates. Existing reach checks, contact-speed policy, learned timing and committed contacts remain. The handle can still move when blade/arm reach requires it.
- **ConstrainedReplayTrajectory.cs:** recovery orientation composed an independently interpolated contact offset with a moving replay wrist frame. That could add an extra recovery arc. Recovery now joins the physically fitted wrist frames, with exact outgoing/incoming rotation derivatives. Existing cut approach and follow-through windows remain on their scored route. A replan also connects its outgoing seed to the next cut; the preceding note has already left the upcoming-note list in that case. Opening and long-break gestures are not replaced.
- **TrajectoryMath.cs:** the wrist recovery uses a shortest-orientation macro with monotone angular progress. Opposing or transverse tracker velocity is retained at its short continuous boundary joins rather than carried across the whole recovery polynomial. Ordinary human recording interpolation and other transition callers retain their existing behavior. A rotation-only sampler avoids calculating unused grip channels for the new wrist join.
- **Plugin.cs:** file/build version is 1.0.0.11. Assembly/manifest identity is unchanged.
- **Tests/PivotWristTests.cs, Tests/Run.ps1:** focused pivot, non-axial socket, repeated cut, recovery derivative, replan and break-gesture coverage.

No model, training-format, source eligibility, note-selection, learning feedback, timing-offset, stroke-speed setting, body rendering, HUD, or leaderboard feature changes. All bot gameplay remains unranked. There is no per-frame rotation clamp or random motion added.

## Verification

- Release compilation succeeds. All regression suites and all 32 installed Harmony target/binding checks pass. New suite: 7,062 assertions. The old build fails the new fixed-pivot contact regression.
- Fixed-pivot fixture: a previous candidate moved the grip about 66.4 mm; the corrected fit preserves that pivot and places the blade through the note centre. Both hands, all four cardinal arrows and a non-axial saber socket are covered.
- Repeated-up/alternating-cut fixture: unnecessary angular travel over two recoveries falls from about 14.41 to 7.07 radians (final exact value in PivotFixValidation-1.0.0.11.json). Each individual recovery remains below a full turn; contact direction/speed and continuous angular derivatives are checked. Note-free human rotations remain unchanged.
- Same-map offline reproduction, now 46.23 seconds: 145 contact probes, zero fitted-contact misses, 141 good swept-collision proxies, three wrong-direction proxies and zero wrong-hand proxies, before and after. Raw human source sampling is unchanged. Planned angular travel falls from about 838.40 to 692.31 radians across both hands. Angular derivative error is below 0.000001 rad/s. The remaining three simulated direction errors are not claimed fixed.
- Eight real qualifying recordings: 1,337 plans, 5,915 contacts, 666,649 samples. Approximate-geometry contact misses fall 540 → 494; direction differences 48 → 33. All remaining contact misses are marked limited; there are no unmarked misses or unreachable contacts. Maximum grip speed is about 17.91 m/s and wrist speed about 124.41 rad/s, within the existing certification bounds. Angular derivative error is about 0.000014 rad/s.
- Offline planning timings vary. Same-map mean approximately 4.73 → 4.98 ms; peak 27.56 → 30.14 ms. The eight-recording runs measure mean approximately 6.42 → 7.00 ms, peak 55.15 → 51.03 ms. These are CPU harness timings, not measured VR frame times; this patch does not claim a gameplay performance improvement.

The same-map collision harness approximates note volumes/NJS and does not reproduce every live learned offset or Unity collision. Recorded demonstration checks use approximate map geometry. The modified build has **not been tested in-game or in VR**. Actual visual behavior, cut scores and gameplay frame times require the user's test. Existing learned data and settings are preserved by installation verification.

