# 1.0.0.22 — 0.9.9 scored swings with 1.0.0.14 human motion

The user requested the swinging/accuracy behavior of SaberMind 0.9.9, the human replay movement of 1.0.0.14, and a fix for remaining lag and pre-contact braking. The original 0.9.9 ZIP and archived v14 source were inspected. Current learning, persistence, three models, the 250,000 timestamp cap, invisible body, menus, F6 controls and all unranked protections remain in place.

## Confirmed causes

The user's v21 gameplay log directly correlates six frame stalls with explicit full collection:

| Song time | Frame gap | Explicit GC |
| --- | --- | --- |
| 1.120 s | 215.18 ms | 209.34 ms |
| 3.106 s | 205.12 ms | 193.62 ms |
| 5.263 s | 195.74 ms | 190.84 ms |
| 8.072 s | 205.30 ms | 200.16 ms |
| 11.260 s | 195.73 ms | 190.37 ms |
| 13.085 s | 194.01 ms | 188.22 ms |

The recorded player does not support incremental GC. The old policy treated a note-free rendered interval as a safe place for a full collection and repeated it after 8 MB of growth and a two-second cooldown. That still stalls rendering. One separate 31.12 ms frame gap had no collection and negligible AI CPU work; its cause remains unconfirmed. Scene-transition exceptions from other installed plugins also appear, but this patch does not modify those plugins.

The v14 human branch deliberately retained measured wrist speed, including braking or a reversal near the retargeted contact. Its progressive stroke was only used when the teacher wrist was stationary. The 0.9.9 branch instead owns an arrow-directed contact velocity with four density bands. Simply multiplying a braking replay velocity cannot restore that behavior.

## Changes

- Production uses the v14 preferred replay grip/orientation fit, continuous body/head/hand motion and gestures. The cut uses the 0.9.9 contact bands: 1,275 / 2,325 / 2,625 / 3,000 degrees per second, retaining faster useful measured motion and necessary cadence adaptation. There is no second blanket 1.5 multiplier on those already-boosted 0.9.9 bands.
- A progressive wrist stroke now applies to human-guided cuts as well as idle fallback. Its apex is exactly at contact, with zero angular acceleration there. Preparation and release remain smooth and connected; the swing cannot begin decelerating before the nominal hit. Slow feasible cuts reserve 100° preparation and 64° release; dense timing can require shorter arcs or a higher cadence pace. Existing reach/stability adaptation still applies.
- Axial wrist roll is captured from one temporally ordered teacher window after recovery timing is finalized. The modifier is C2 zero at contact and its boundaries, preserves the fitted cut, and remains the same immutable object across ordinary committed replans. This is measured motion, not jitter.
- A queued plan rechecks release ownership when published. A cut that occurs while planning is pending cannot have its release interrupted by the late connector. Existing contact times remain fixed.
- Real replay validation reproduced a committed release extending past a following contact 14 ms away. Its virtual end knot caused that contact to disappear. A still-future conflicting release is shortened before the next exact hit; the existing approach/contact jet is retained. All 5,915 checked contacts are now present.
- Normal non-incremental playback no longer runs full collections inside rendered breaks or on the old timer. Collection occurs before playback or while genuinely paused. Heap growth is checked twice per second, and a 512 MB deferred-growth safety request stops the song clock before collecting, then resumes it. That emergency can still produce a visible pause, but collection does not consume the active song's cut interval. Supported incremental players retain their budgeted collection path.
- Removed redundant caller-owned pose clones and one redundant projection copy. Note-free plans use the existing 3.4-second horizon instead of rebuilding a 0.9-second horizon repeatedly. No learning model or replay-selection policy changed.

## Verification and limits

The release compiled against the installed 1.40.8 assemblies. Passing checks include 24,960 original v14 motion parity assertions (hybrid disabled), 34,773 replay capture ownership assertions, 18,441 hybrid speed/contact/roll/close-transition assertions, 35 collection lifecycle/safety assertions and 1,826 checks exercising the shipped planner's follow-through publication through the compiled DLL. The original v14 movement regressions and current learning-cap, alignment, persistence, models, menus, unranked policies and all 32 native hook bindings also pass.

Eight eligible recordings were replayed offline using the same capped human model: 1,337 plans, 5,915 nominal contacts and 666,649 samples in each variant. Baseline and hybrid both have zero unconstrained contact misses, zero unconstrained direction differences, zero missing planned contacts and zero reach violations. Stability-limited nominal misses decreased from 243 to 66, and direction differences from 10 to 6. These are geometric proxies, not actual Beat Saber cut scores or in-game accuracy.

Hybrid maximum sampled grip speed was 17.91 m/s, wrist speed 121.40 rad/s, and angular derivative error 3.45×10⁻⁵ rad/s. A separate allocation stress probe at 240 samples/s and four whole-plan rebuilds/s allocated 605.2 MB for v21 versus 532.4 MB for the hybrid over 30 simulated seconds, about 12% less. That probe includes an intentionally high rebuild rate and is not a native game heap or frame-time measurement. Planning still allocates; long/high-pressure sessions can trigger stopped-clock maintenance. The retained trace records actual runtime behavior for the next test.

No game or VR session was launched for this release. Actual cut scoring, visual realism, native early collisions, the remaining unrelated frame gap and total in-game memory growth need live verification. All gameplay remains unranked.
