# 1.0.0.23 — compact fast-stream pivots and connected wrist motion

This patch addresses the fast-part breakdown in `Beat Saber 2026.10.04 - 00.35.10.10.mp4`. The clip's broad motion is visible in the 29.8–30.8 s detail, with the fast breakdown especially visible around 32.49–33.60 s. Video and song clocks were not precisely synchronized; the trace timestamps below are song times, not asserted frame matches.

## Confirmed pipeline causes

The v22 runtime log records 514 good cuts, 82 bad cuts and 162 misses. All 82 bad cuts had incorrect direction; none had insufficient speed. The available sampled trace records the final saber rotation matching the commanded rotation. The excessive motion is already present in the planned pose, rather than introduced by a later body/transform overwrite.

At song 13.5231 s, hand 0 moves at 18.77 m/s with a planned speed of 19.236 m/s; its planned grip differs from the teacher by 0.4119 m. There is no target, route or contact-fit change at that sample. At 23.4165 s, hand 0 reaches 16.29 m/s and 5,709 degrees/s, again without those updates. These are direct evidence of excessive planned travel, not proof that every visible event has one cause. Debug tracing was disabled, so the ordinary trace has only roughly 0.1-second samples.

The restored contact fitter was using an unrelated human hand position as its preferred grip through dense patterns. Some orientation candidates also used the chord toward the next note, including a blade pointed away from the note field. Independently generated preparation and release windows could leave only about 8.47 ms to recover between substantially different wrist frames. Finally, reach repair could substitute a different wrist trajectory while retaining the original scored swing clock. Replans could then reconstruct the original stroke against the substituted pose. Wrist joins previously ran after that repair.

A broader replay check reproduced another issue in the axial wrist-roll modifier: finite swing/twist decomposition near a half-turn could create rapid axial rotation even when the demonstration's angular speed was modest. The intermediate candidate peaked at 250.31 rad/s; integrating the measured angular velocity about the blade removed that artificial twist and brought the broader peak to 175.70 rad/s. No per-frame rotation clamp was added.

## Changes

- `MovementPlanner.cs` enables the existing stable fast-grip policy in the shipped planner. The restored contact-speed bands remain in use; there is no additional speed multiplier.
- `ReplayMotor.cs` fits dense contacts around a compact pattern pivot, prefers the previous wrist frame, removes unrelated next-note chord/roll candidates from dense fitting, and gives the wrist ownership of dense cut velocity. Exact reach and contact fitting remain active.
- `ConstrainedReplayTrajectory.cs` computes upcoming-pattern pivot hints; holds and smoothly repositions the grip through dense patterns; plans shared wrist curves through close contacts; preserves active curves during replans; validates joins before grip repair; and preserves the scored wrist during that repair. Dense outer release windows request 64 degrees where cadence permits. Faster patterns adapt to their actual contact spacing.
- `TrajectoryMath.cs` adds immutable contact-to-contact SO(3) curves with exact endpoint angular velocity and acceleration. Shorter endpoint support prevents peak-speed jets from being extrapolated over the whole interval. Links do not retain chains of prior plans.
- `ReplayWristRoll.cs` derives production axial roll by integrating the recorded angular motion about the current blade, rather than using a singular finite swing/twist decomposition. Source ownership, contact preservation and smooth boundaries remain.
- `Plugin.cs` records DLL version 1.0.0.23. Assembly identity remains unchanged.

Learning, source recordings, scoring rules, result blocking, models, camera controls and collection policy are unchanged. The simulated body remains invisible.

## Verification

The game-referenced DLL compiles. The complete offline suite passes, including 57,488 focused fast-stream, directed-contact, derivative, half-turn roll, replan and ownership assertions. The original v14 golden comparison passes 24,960 assertions with a maximum numerical difference of 6.777e-11. Installed Harmony resolves all 32 targets; 1,826 shipped planner follow-through assertions pass. These checks load game assemblies but do not run Unity gameplay.

Using the user's current fitted model, map `the beast i worship` (Standard ExpertPlus), configured two-metre body proportions and an approximation of the traced native note geometry, the same 29.5–43.0 song-second window contains 453 primary contact checks:

| Offline proxy result | v22 | v23 |
| --- | ---: | ---: |
| Wrong-direction contacts | 62 | 0 |
| Reverse motion near an incoming block | 69 | 0 |
| Contacts marked physically limited | 112 | 13 |

The map proxy still marks 13 difficult contacts limited. Its minimum measured post-contact angle is 38.35 degrees, so this is not a guarantee of full swing-angle scoring on every dense note. Some overhead/follow-through samples still point backward legitimately; the check does not classify every backward orientation as a bug.

Eight qualifying real human recordings also pass 1,337 plans, 5,915 primary contact checks and 666,649 trajectory samples. There are zero unmarked contact misses, zero wrong-direction contacts, zero unreachable contacts and no missing contact records. There are 163 contacts explicitly marked limited, including 162 geometric proxy misses; these remain a limitation. The maximum contact angular speed is 120 rad/s, maximum total angular speed 175.70 rad/s, maximum grip speed 17.28 m/s, and maximum angular derivative error 6.47e-6. Mean whole-plan time is 12.28 ms in this offline run; runtime planning continues to use its existing frame slices. The legacy hybrid fixture is unchanged from v22.

These map/replay checks approximate native block geometry, collision and scoring. They do not reproduce the installed game's actual physics loop, every stacked note, or the exact timing of the recording. No successful in-game or VR test is claimed, and 100+ points on every note is not established.

The existing safety collector was still observable in the previous runtime log: three stopped-clock memory collections corresponded to roughly 195–209 ms gaps. This patch does not change that policy or claim to eliminate all lag.
