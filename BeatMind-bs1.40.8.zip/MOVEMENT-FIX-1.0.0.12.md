# SaberMind idle-source swing fix — 1.0.0.12

Beat Saber PCVR 1.40.8. This patch only fixes the missing stroke after the compact-pivot update.

The user's 18:20:03 game log identifies build 1.0.0.11 and the 100Bills Easy attempt. It reports zero active replay wrist/grip motion and 0 good / 64 bad / 0 missed notes. All 64 bad cuts failed the speed check. Early cuts measured about 0.5–0.8 m/s. The accompanying trace shows stationary teacher wrist targets and short planned speed peaks, so this is a movement fallback failure rather than normal learning progress.

The contact fitter correctly kept a reachable hand pivot in place. However, the trajectory's Side() approach/release copied a stationary source orientation. The correction interpolation then restricted the contact angular-velocity jet to short edges. The blade arrived almost stationary despite the fitted contact having the correct instantaneous angular velocity.

ConstrainedReplayTrajectory now detects an unrecorded, stationary wrist source around a cut. Only in that case it adds the missing pre-swing and release frames, derived from the fitted contact angular velocity and the existing CutSafety.StrokeFor half-swing duration. Those frames rotate around the fitted hand pivot and join with the existing continuous curves. Cut time, cut pose, arrow, contact speed, reach limits and recovery planning remain unchanged. Adjacent-note spacing bounds the stroke window. Measured replay wrist motion uses the existing path. No learning, model, settings, HUD, body, leaderboard or feature changes were made.

Files: Source/ConstrainedReplayTrajectory.cs; Source/Plugin.cs (file/build version only); Tests/IdleStrokeTests.cs; Tests/IdleCollisionTests.cs; Tests/Run.ps1; documentation. The assembly and manifest identity remain unchanged.

Verification:

- Release compilation and every regression suite pass, including all 32 installed Harmony targets and bindings.
- The old build fails the new idle-source pre-swing regression. The fixed build passes 26,912 stroke/contact/pivot/continuous-derivative/replan assertions, covering both hands, eight arrow directions and sparse/dense cadences.
- An incoming-note swept-collision proxy using the recorded idle hand geometry tests both hands, eight directions and NJS 10, 12 and 16. Before: 48 contacts, all 48 too slow. After: 48 contacts, zero too slow and zero wrong-direction proxies. This is approximate geometry, not Unity collision or an in-game score.
- The previous compact-pivot and wrist recovery suite still passes all 7,062 assertions.
- The 46.23-second 100Bills Expert offline reproduction retains 145 contact probes, zero fitted misses, 141 good collision proxies, three wrong-direction proxies and zero wrong-hand proxies. The three existing direction errors are not claimed fixed.

The modified build has not been tested in-game or in VR. Learning data and settings are preserved during installation. All AI gameplay remains unranked.
