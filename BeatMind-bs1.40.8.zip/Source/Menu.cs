using System;
using System.Collections.Generic;
using System.ComponentModel;
using BeatSaberMarkupLanguage.Attributes;
using BeatSaberMarkupLanguage.GameplaySetup;
using BeatSaberMarkupLanguage.Util;
using UnityEngine;
using UnityEngine.UI;
using HarmonyLib;
using System.Reflection;

namespace SaberMind
{
    public sealed class PlayMenu : INotifyPropertyChanged, IDisposable
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private GameplaySetup registeredWith;
        private readonly MultiplayerOptions onlineOptions = new MultiplayerOptions();
        private string lastMenuError, lastPredictionError;
        private string mode = "Off";
        private string status = "Choose a level, select a mode, then press Play.";
        private string prediction = new ModelMemory().Prediction(), predictionKey;
        private string lastHumanReplayStatus;
        [UIComponent("menu-root")] private RectTransform menuRoot = null;
        [UIComponent("play-page")] private RectTransform playPage = null;
        [UIComponent("training-page")] private RectTransform trainingPage = null;
        [UIComponent("human-replay-page")] private RectTransform humanReplayPage = null;
        [UIComponent("predictions-page")] private RectTransform predictionsPage = null;
        [UIComponent("body-page")] private RectTransform bodyPage = null;
        [UIComponent("hud-page")] private RectTransform hudPage = null;
        [UIAction("#post-parse")]
        private void LayoutPages()
        {
            // BSML's tab background has no LayoutElement, and vertical tags
            // default to fitting their width. Make both dimensions explicit so
            // the parent cannot allocate zero-sized pages or collapse the width.
            SetPageLayout(playPage,48); SetPageLayout(trainingPage,43); SetPageLayout(humanReplayPage,48);
            SetPageLayout(predictionsPage,48); SetPageLayout(bodyPage,48); SetPageLayout(hudPage,43);
            if (menuRoot != null)
            {
                ContentSizeFitter fit = menuRoot.GetComponent<ContentSizeFitter>();
                if (fit != null) { fit.horizontalFit = ContentSizeFitter.FitMode.Unconstrained; fit.verticalFit = ContentSizeFitter.FitMode.Unconstrained; }
                LayoutRebuilder.ForceRebuildLayoutImmediate(menuRoot);
            }
        }
        private static void SetPageLayout(RectTransform page,float height)
        {
            if (page == null) throw new InvalidOperationException("BeatMind menu page binding is missing.");
            LayoutElement size = page.GetComponent<LayoutElement>() ?? page.gameObject.AddComponent<LayoutElement>();
            size.minHeight = size.preferredHeight = height; size.flexibleHeight = 0; size.flexibleWidth = 1;
            foreach (Transform container in page.childCount > 0 ? new Transform[] { page, page.GetChild(0) } : new Transform[] { page })
            {
                ContentSizeFitter fit = container.GetComponent<ContentSizeFitter>();
                if (fit != null) { fit.horizontalFit = ContentSizeFitter.FitMode.Unconstrained; fit.verticalFit = ContentSizeFitter.FitMode.Unconstrained; }
            }
        }
        [UIValue("models")] public List<object> Models
        { get { var names = new List<object>(); foreach (ModelProfile p in ModelProfile.All) names.Add(p.Name); return names; } }
        [UIValue("model")] public string Model
        {
            get { return Settings.Current.Model; }
            set { Settings.Current.Model = ModelProfile.Find(value).Name; SaveSettings(); Changed("Model"); Changed("ModelDescription"); }
        }
        [UIValue("model-description")] public string ModelDescription { get { return ModelProfile.Find(Model).Description; } }
        [UIValue("predictions")] public string Predictions { get { return prediction; } }
        [UIValue("simulated-camera")] public bool SimulatedCamera
        { get { return Settings.Current.SimulatedCamera; } set { Settings.Current.SimulatedCamera = value; SaveSettings(); } }
        [UIValue("auto-restart-goal")] public bool AutoRestartGoal
        { get { return Settings.Current.AutoRestartGoal95; } set { Settings.Current.AutoRestartGoal95 = value; SaveSettings(); } }
        [UIValue("accuracy-goals")] public List<object> AccuracyGoals
        { get { var goals=new List<object>();foreach(int percent in AutoRestartPolicy.TargetPercentOptions) goals.Add(percent+"%");return goals; } }
        [UIValue("accuracy-goal")] public string AccuracyGoal
        {
            get { return Settings.TrainingTargetPercent+"%"; }
            set
            {
                int percent;
                if(!int.TryParse((value??"").TrimEnd('%'),out percent)) return;
                int target=AutoRestartPolicy.NormalizeTargetPercent(percent);
                if(target==Settings.TrainingTargetPercent) return;
                Settings.Current.TrainToAccuracyPercent=target;
                // A streak measured against a different goal cannot carry over.
                Session.CancelAutoRestart();
                SaveSettings();Changed("AccuracyGoal");
                SetStatus("Training goal: "+target+"% in 3 consecutive completed runs.");
            }
        }
        [UIValue("readiness-threshold")] public float ReadinessThreshold
        { get { return Settings.Current.ReadinessThreshold; } set { Settings.Current.ReadinessThreshold = value; SaveSettings(); } }
        [UIValue("human-replay-style")] public bool HumanReplayStyle
        { get { return Settings.Current.UseHumanReplayStyle; } set { Settings.Current.UseHumanReplayStyle=value;SaveSettings(); } }
        [UIValue("human-replay-status")] public string HumanReplayStatus
        { get { return Plugin.HumanReplayStatus??"No human replays imported."; } }
        [UIValue("auto-human-replays")] public bool AutoHumanReplays
        {get {return Settings.Current.AutoLearnOwnReplays;} set {Settings.Current.AutoLearnOwnReplays=value;SaveSettings();Plugin.ReloadHumanReplays();}}
        [UIAction("reload-human-replays")] public void ReloadHumanReplays()
        { Plugin.ReloadHumanReplays();Changed("HumanReplayStatus"); }
        [UIValue("gameplay-hud")] public bool GameplayHud
        { get { return Settings.Current.ShowGameplayHud; } set { Settings.Current.ShowGameplayHud=value;SaveSettings(); } }
        [UIValue("training-details")] public bool TrainingDetails
        { get { return Settings.Current.ShowTrainingDetails; } set { Settings.Current.ShowTrainingDetails=value;SaveSettings(); } }
        [UIValue("hud-right")] public bool HudRight
        { get { return Settings.Current.HudOnRight; } set { Settings.Current.HudOnRight=value;SaveSettings(); } }
        [UIValue("hud-scale")] public float HudScale
        { get { return Settings.Current.HudScale; } set { Settings.Current.HudScale=value;SaveSettings(); } }
        [UIValue("hud-opacity")] public float HudOpacity
        { get { return Settings.Current.HudOpacity; } set { Settings.Current.HudOpacity=value;SaveSettings(); } }
        [UIValue("show-body")] public bool ShowBody
        { get { return Settings.Current.ShowBody; } set { Settings.Current.ShowBody = value; SaveSettings(); } }
        [UIValue("height")] public float Height
        { get { return Settings.Current.Height; } set { Settings.Current.Height = value; SaveSettings(); } }
        [UIValue("shoulder-width")] public float ShoulderWidth
        { get { return Settings.Current.ShoulderWidth; } set { Settings.Current.ShoulderWidth = value; SaveSettings(); } }
        [UIValue("upper-arm")] public float UpperArm
        { get { return Settings.Current.UpperArm; } set { Settings.Current.UpperArm = value; SaveSettings(); } }
        [UIValue("forearm")] public float Forearm
        { get { return Settings.Current.Forearm; } set { Settings.Current.Forearm = value; SaveSettings(); } }
        [UIValue("hand-length")] public float HandLength
        { get { return Settings.Current.Hand; } set { Settings.Current.Hand = value; SaveSettings(); } }
        [UIValue("torso-length")] public float TorsoLength
        { get { return Settings.Current.Torso; } set { Settings.Current.Torso = value; SaveSettings(); } }
        private void SaveSettings() { Settings.Save(); InvalidatePredictions(); }
        internal void InvalidatePredictions() { predictionKey = null; }
        [UIValue("modes")] public List<object> Modes { get { return new List<object> { "Off", "Play & learn", "Play learned", "Watch best replay" }; } }
        [UIValue("mode")] public string Mode
        {
            get { return mode; }
            set
            {
                if (value != "Off" && value != "Play & learn" && value != "Play learned" && value != "Watch best replay") return;
                mode = value;
                if (mode == "Off") BS_Utils.Gameplay.ScoreSubmission.RemoveProlongedDisable(Plugin.Id);
                else BS_Utils.Gameplay.ScoreSubmission.ProlongedDisableSubmission(Plugin.Id);
                Changed("Mode");
            }
        }
        [UIValue("status")] public string Status { get { return status; } }
        internal bool Enabled { get { return mode != "Off"; } }
        internal bool Learning { get { return mode == "Play & learn"; } }
        internal bool Watching { get { return mode == "Watch best replay"; } }
        internal void SetStatus(string text) { status = text; Changed("Status"); }
        private void Changed(string name) { if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(name)); }
        internal void Update()
        {
            try
            {
                if (!MainMenuAwaiter.WaitForMainMenuAsync().IsCompleted) return;
                GameplaySetup setup = GameplaySetup.Instance;
                if (setup != null && setup != registeredWith)
                {
                    setup.AddTab("BeatMind", "SaberMind.Menu.bsml", this, MenuType.Solo);
                    setup.AddTab("SaberMind 1v1", "SaberMind.MultiplayerMenu.bsml", onlineOptions, MenuType.Online);
                    registeredWith = setup;
                    lastMenuError = null;
                    Plugin.Log.Info("SaberMind menus registered: BeatMind learning (Solo), SaberMind 1v1 (Online).");
                }
            }
            catch (Exception error)
            {
                if(lastMenuError!=error.Message) { lastMenuError=error.Message;Plugin.Log.Error("SaberMind menu registration will retry: " + error); }
            }
            // A selected-map/prediction error must not disable either menu.
            try
            {
                if (Session.Current == null) RefreshPredictions();
                if(lastHumanReplayStatus!=HumanReplayStatus)
                {lastHumanReplayStatus=HumanReplayStatus;Changed("HumanReplayStatus");}
                lastPredictionError=null;
            }
            catch (Exception error)
            { if(lastPredictionError!=error.Message) {lastPredictionError=error.Message;Plugin.Log.Warn("BeatMind prediction update: "+error.Message);} }
        }
        public void Dispose()
        {
            try { if (registeredWith != null) { registeredWith.RemoveTab("BeatMind");registeredWith.RemoveTab("SaberMind 1v1"); } }
            catch (Exception error) { Plugin.Log.Warn(error.Message); }
            onlineOptions.Dispose();registeredWith=null;
        }
        private void RefreshPredictions()
        {
            StandardLevelDetailView selected = UnityEngine.Object.FindObjectOfType<StandardLevelDetailView>();
            if (selected == null || selected.beatmapKey.beatmapCharacteristic == null) return;
            PlayerData data = AccessTools.Field(typeof(StandardLevelDetailView), "_playerData").GetValue(selected) as PlayerData;
            if (data == null) return;
            string identity = Session.Identity(selected.beatmapKey, data.gameplayModifiers, data.playerSpecificSettings, null);
            string key = Session.ModelKey(ModelProfile.Find(Model), Settings.Current);
            if (predictionKey == identity + key) return;
            predictionKey = identity + key;
            try { prediction = Plugin.Store.Load(identity).ForModel(key).Prediction(); }
            catch (Exception error) { prediction = "Predictions unavailable: saved learning could not be read."; Plugin.Log.Warn(error.Message); }
            Changed("Predictions");
        }
    }

    public sealed class Runtime : MonoBehaviour
    {
        internal readonly PlayMenu Menu = new PlayMenu();
        private static readonly MethodInfo RestartResults=AccessTools.Method(typeof(ResultsViewController),"RestartButtonPressed");
        private ResultsViewController restartView;
        private LevelCompletionResults restartResult;
        private float restartAt;
        private float nextMenuPoll;
        private float nextReplayPoll;
        private bool stopped;
        private AiCollectionScope replayCollection;
        internal void SuspendReplayCollection()
        {if(replayCollection!=null){replayCollection.Dispose();replayCollection=null;}}
        internal void QueueAutoRestart(ResultsViewController view,LevelCompletionResults result)
        {
            if(view==null || result==null || !Session.AutoRestartRequested || !Settings.Current.AutoRestartGoal95
                || !Menu.Enabled || object.ReferenceEquals(restartResult,result)) return;
            restartView=view;restartResult=result;restartAt=Time.unscaledTime+2.5f;
        }
        internal void ClearAutoRestartQueue()
        {restartView=null;restartResult=null;}
        private void CancelAutoRestart()
        {ClearAutoRestartQueue();Session.CancelAutoRestart();}
        private void Update()
        {
            if (stopped) return;
            if(Session.Current==null && Plugin.ReplayLearningBusy)
            {if(replayCollection==null)replayCollection=new AiCollectionScope();replayCollection.Tick(Time.frameCount,Time.unscaledTime,true);}
            else SuspendReplayCollection();
            MultiplayerIntegration.Tick();
            if(Time.unscaledTime>=nextReplayPoll) {nextReplayPoll=Time.unscaledTime+5;Plugin.PollHumanReplays();}
            if (Time.unscaledTime >= nextMenuPoll) { nextMenuPoll = Time.unscaledTime + .5f; Menu.Update(); }
            if (Input.GetKeyDown(KeyCode.F8))
            {
                if(Session.Current!=null)
                {
                    Session.Stop("Stopped with F8");
                    // Keep this run unranked even after manual control is restored.
                    BS_Utils.Gameplay.ScoreSubmission.DisableSubmission(Plugin.Id);
                }
                CancelAutoRestart();
            }
            if(Session.Current!=null && Input.GetKeyDown(KeyCode.F7))
            { Settings.Current.ShowGameplayHud=!Settings.Current.ShowGameplayHud;Settings.Save(); }
            if (Session.Current != null)
            {
                try { Session.Current.Tick(); }
                catch (Exception error) { Plugin.Log.Error("Training view/control error: " + error); Session.Stop("Training control error"); }
            }
            if(restartView!=null)
            {
                if(!Settings.Current.AutoRestartGoal95 || !Menu.Enabled)
                    CancelAutoRestart();
                else if(Time.unscaledTime>=restartAt)
                {
                    if(!restartView.isInViewControllerHierarchy) {CancelAutoRestart();return;}
                    ResultsViewController view=restartView;
                    restartView=null;restartResult=null;Session.AutoRestartRequested=false;
                    try
                    {
                        if(RestartResults==null) throw new MissingMethodException("Results restart action unavailable");
                        RestartResults.Invoke(view,null);
                    }
                    catch(Exception error) { Session.CancelAutoRestart();Plugin.Log.Error("Auto-restart failed: "+error); }
                }
            }
        }
        private void LateUpdate()
        {
            if(stopped || Session.Current==null) return;
            try { Session.Current.RecordFrame(); }
            catch(Exception error) { Plugin.Log.Warn("Replay recording stopped: "+error.Message); }
        }
        private void OnApplicationQuit() { CancelAutoRestart();Session.Stop("Game closed");MultiplayerIntegration.Shutdown(); }
        internal void Shutdown() { stopped = true;SuspendReplayCollection();CancelAutoRestart();Menu.Dispose(); }
    }
}

