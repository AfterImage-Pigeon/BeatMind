using System;
using System.Collections.Generic;
namespace SaberMind
{
    // Align whole recorded motion intervals to the events that caused them.
    // A single monotone source clock drives the head and both hands; matching
    // an isolated pose cannot admit the intervening unrelated human cuts.
    public sealed class HumanEventAlignment
    {
        internal sealed class Event
        {internal double Time;internal int Mask;internal readonly int[] Direction={-1,-1};internal readonly double[] X=new double[2],Y=new double[2];}
        public double SourceStart,SourceEnd,DestinationEnd,Cost;
        public int MatchedEvents,RequestedEvents;
        public MotionPhrase Clock;
        // One graph owns immutable event snapshots for its fixed model and
        // chart. Nonzero sequential crops rebuild with their original filter.
        internal sealed class PreparedSource {internal List<Event> Events;}
        internal sealed class PreparedTarget {internal List<Event> Events;}
        internal static PreparedSource PrepareSource(HumanMotionExample example,HumanTape tape)
        {return new PreparedSource{Events=BuildSource(example,tape,0)};}
        internal static PreparedTarget PrepareTarget(IList<HumanChartNote> chart,double start,double end)
        {return new PreparedTarget{Events=BuildTarget(chart,start,end)};}
        private static List<Event> BuildSource(HumanMotionExample example,HumanTape tape,double minimumSource)
        {
            var source=new List<Event>();foreach(var a in example.Anchors)
            {
                double time=a.Phase*example.Duration;if(time<minimumSource+.001)continue;
                int direction=a.Direction;
                if(direction==8)
                {
                    var pose=tape.Sample(time,a.Hand+1);MotionVector blade=pose.Rotation.Rotate(new MotionVector(0,0,.65));
                    var velocity=pose.Velocity+MotionVector.Cross(pose.AngularVelocity,blade);velocity.Z=0;
                    if(velocity.Length>.25){double bestDirection=.65;for(int d=0;d<8;d++){double match=MotionVector.Dot(velocity.Unit,HumanContext.Direction(d));if(match>bestDirection){bestDirection=match;direction=d;}}}
                }
                Add(source,time,a.Hand,direction,a.Lane,a.Layer);
            }
            source.Sort(delegate(Event a,Event b){return a.Time.CompareTo(b.Time);});
            return source;
        }
        private static List<Event> BuildTarget(IList<HumanChartNote> chart,double start,double end)
        {
            var target=new List<Event>();int first=HumanContext.Lower(chart,start+.001);
            for(int i=first;i<chart.Count && chart[i].Time<end-.002;i++){var n=chart[i];Add(target,n.Time,n.Hand,n.Direction,n.Lane,n.Layer);}
            target.Sort(delegate(Event a,Event b){return a.Time.CompareTo(b.Time);});
            return target;
        }
        public static HumanEventAlignment Match(HumanMotionExample example,HumanTape tape,IList<HumanChartNote> chart,double start,double end,double minimumSource)
        {return Match(example,tape,chart,start,end,minimumSource,null,null);}
        internal static HumanEventAlignment Match(HumanMotionExample example,HumanTape tape,IList<HumanChartNote> chart,double start,double end,double minimumSource,PreparedSource preparedSource,PreparedTarget preparedTarget)
        {
            var source=minimumSource==0 && preparedSource!=null ? preparedSource.Events : BuildSource(example,tape,minimumSource);
            var target=preparedTarget==null ? BuildTarget(chart,start,end) : preparedTarget.Events;
            if(target.Count==0 || source.Count==0)return null;
            HumanEventAlignment bestPlan=null;double best=double.MaxValue;
            for(int offset=0;offset<source.Count;offset++)
            {
                int matched=0;double spatial=0;
                while(matched<target.Count && offset+matched<source.Count)
                {
                    var a=source[offset+matched];var b=target[matched];if(!Compatible(a,b))break;
                    for(int h=0;h<2;h++)if((a.Mask&(1<<h))!=0)spatial+=Math.Abs(a.X[h]-b.X[h])*.035+Math.Abs(a.Y[h]-b.Y[h])*.045;
                    matched++;
                }
                if(matched==0)continue;
                // A boundary is between cuts, so neither the preceding nor
                // the following source cut leaks into this cropped interval.
                double begin=offset==0 ? Math.Max(0,minimumSource) : Math.Max(minimumSource,(source[offset-1].Time+source[offset].Time)*.5);
                int last=offset+matched-1;double finish=last+1<source.Count ? (source[last].Time+source[last+1].Time)*.5 : example.Duration;
                double destination=matched<target.Count ? (target[matched-1].Time+target[matched].Time)*.5 : end;
                // Crop unused pre/post-roll instead of squeezing a long source
                // prefix into a short destination lead. The interior events
                // set the cadence; a one-event crop retains its native clock.
                double cadence=matched>1 ? (source[last].Time-source[offset].Time)/(target[matched-1].Time-target[0].Time) : 1;
                begin=Math.Max(begin,source[offset].Time-(target[0].Time-start)*cadence);
                finish=Math.Min(finish,source[last].Time+(destination-target[matched-1].Time)*cadence);
                if(begin>=source[offset].Time-.004 || finish<=source[last].Time+.004 || destination<=target[matched-1].Time+.004)continue;
                var clock=new MotionPhrase();clock.Knots.Add(Knot(start,begin));
                for(int p=0;p<matched;p++)clock.Knots.Add(Knot(target[p].Time,source[offset+p].Time));
                clock.Knots.Add(Knot(destination,finish));double tempo=0;bool valid=true;
                for(int p=0;p+1<clock.Knots.Count;p++)
                {
                    double rate=(clock.Knots[p+1].Grip.X-clock.Knots[p].Grip.X)/(clock.Knots[p+1].Time-clock.Knots[p].Time);
                    if(rate<=0 || !HumanMotionModel.Finite(rate)){valid=false;break;}tempo+=Math.Abs(Math.Log(rate));
                }
                if(!valid)continue;
                SetRates(clock);
                double cost=(target.Count-matched)*2.0+spatial/Math.Max(1,matched)+tempo/(matched+1)*.08;
                if(cost<best){best=cost;bestPlan=new HumanEventAlignment{SourceStart=begin,SourceEnd=finish,DestinationEnd=destination,Cost=cost,MatchedEvents=matched,RequestedEvents=target.Count,Clock=clock};}
            }
            return bestPlan;
        }
        public bool PreservesTrainingDomain(HumanTape tape)
        {
            // Selection must use the same physical temporal context as the
            // training examples. Reject an incompatible clock; never clamp a
            // displayed wrist or silently distort the human pose sequence.
            double start=Clock.Knots[0].Time;
            for(int p=0;p<=128;p++)for(int j=0;j<3;j++)
            {
                var s=Sample(tape,start+(DestinationEnd-start)*p/128,j);
                if(s.Velocity.Length>(j==0 ? 3 : 14) || s.AngularVelocity.Length>(j==0 ? 6 : 66))return false;
            }
            return true;
        }
        private static PhraseState Knot(double time,double source)
        {return new PhraseState{Time=time,Grip=new MotionVector(source,0,0)};}
        private static void SetRates(MotionPhrase clock)
        {
            var rates=new double[clock.Knots.Count-1];for(int i=0;i<rates.Length;i++)rates[i]=(clock.Knots[i+1].Grip.X-clock.Knots[i].Grip.X)/(clock.Knots[i+1].Time-clock.Knots[i].Time);
            for(int i=0;i<clock.Knots.Count;i++)
            {
                // Harmonic rates never exceed twice either neighboring
                // secant. Quintic zero-acceleration joins stay monotone while
                // retaining positive speed through the actual cut time.
                double rate=i==0 ? rates[0] : i==rates.Length ? rates[rates.Length-1] : 2*rates[i-1]*rates[i]/(rates[i-1]+rates[i]);
                clock.Knots[i].Velocity=new MotionVector(rate,0,0);
            }
        }
        private static void Add(List<Event> list,double time,int hand,int direction,double x,double y)
        {
            Event found=null;foreach(var e in list)if(Math.Abs(e.Time-time)<.012){found=e;break;}
            if(found==null){found=new Event{Time=time};list.Add(found);}int bit=1<<hand;
            if((found.Mask&bit)!=0){if(found.Direction[hand]!=direction)found.Direction[hand]=-2;return;}
            found.Mask|=bit;found.Direction[hand]=direction;found.X[hand]=x;found.Y[hand]=y;
        }
        private static bool Compatible(Event source,Event target)
        {
            if(source.Mask!=target.Mask)return false;
            for(int h=0;h<2;h++)if((source.Mask&(1<<h))!=0)
            {if(source.Direction[h]<0 || target.Direction[h]<0)return false;if(target.Direction[h]!=8 && source.Direction[h]!=target.Direction[h])return false;}
            return true;
        }
        public PhraseState Sample(HumanTape tape,double time,int joint)
        {
            var clock=Clock.Sample(time);var s=tape.Sample(clock.Grip.X,joint);double rate=clock.Velocity.X,acceleration=clock.Acceleration.X;
            s.Acceleration=s.Acceleration*(rate*rate)+s.Velocity*acceleration;s.Velocity*=rate;
            s.AngularAcceleration=s.AngularAcceleration*(rate*rate)+s.AngularVelocity*acceleration;s.AngularVelocity*=rate;s.Time=time;return s;
        }
    }
}
