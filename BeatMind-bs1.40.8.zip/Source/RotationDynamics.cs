using System;

namespace SaberMind
{
    // Degree-based angular servo: velocity feed-forward plus a critically damped
    // error response. Acceleration limits apply to reversals as well as starts.
    public static class RotationDynamics
    {
        public static bool ContinuousReferenceStep(float degrees, float delta, float speedLimit)
        {
            // Differentiating a pose handoff as if it were continuous motion
            // produces an artificial velocity impulse. The motor still tracks
            // the new pose using its normal acceleration and jerk limits.
            return delta > 0 && degrees <= Math.Max(12f, speedLimit * delta * 1.4f);
        }
    }
}
