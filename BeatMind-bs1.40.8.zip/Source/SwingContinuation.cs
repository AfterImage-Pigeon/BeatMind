using System;

namespace SaberMind
{
    // A cut removes a note from targeting, not its already planned release.
    // Keep that exact curve until its scoring envelope is complete. The next
    // hit still owns its contact; an impossible overlap cannot postpone it.
    public static class SwingContinuation
    {
        public const double ContactLead = .005;

        public static double ReleaseUntil(MotionPhrase phrase, double now,
            int lastCutId, double lastCutTime, double nextHit)
        {
            if (phrase == null) return now;
            double until = now;
            if (lastCutId >= 0 && Finite(lastCutTime)
                && lastCutTime <= now + .001 && lastCutTime >= now - .4)
                until = Release(phrase.Contact(lastCutId), now, until);
            foreach (PhraseState contact in phrase.Knots)
                if (contact.Id >= 0 && contact.Time <= now && contact.Time >= now - .4)
                    until = Release(contact, now, until);
            if (phrase.Knots.Count > 0)
                until = Math.Min(until, phrase.Knots[phrase.Knots.Count - 1].Time);
            if (Finite(nextHit) && nextHit > now)
                until = Math.Min(until, nextHit - ContactLead);
            return Math.Max(now, until);
        }

        public static double NextContactTime(MotionPhrase phrase, double after, int resolvedId)
        {
            double next = double.PositiveInfinity;
            if (phrase != null)
                foreach (PhraseState contact in phrase.Knots)
                    if (contact.Id >= 0 && contact.Id != resolvedId && contact.Time > after)
                        next = Math.Min(next, contact.Time);
            return next;
        }

        private static double Release(PhraseState contact, double now, double until)
        {
            if (contact == null) return until;
            double end = Finite(contact.ScoringReleaseEnd) ? contact.ScoringReleaseEnd : contact.SwingEnd;
            // Scoring owns at most the native 400 ms post-cut observation
            // window. Invalid metadata must not preserve seconds of an old plan.
            if (!Finite(end) || end < contact.Time || end > contact.Time + .400001)
                return until;
            return end > now ? Math.Max(until, end) : until;
        }

        private static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
