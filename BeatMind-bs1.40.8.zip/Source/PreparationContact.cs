using System;

namespace SaberMind
{
    public static class PreparationContact
    {
        // Mirrors the existing articulated hand's radial reach projection.
        // It only evaluates a planned contact; it never writes a live pose.
        private static MotionVector Grip(PhraseState pose,PhraseGeometry geometry,double time)
        {
            MotionVector shoulder=geometry.ShoulderAt==null ? geometry.Shoulder : geometry.ShoulderAt(time),v=pose.Grip-shoulder;
            double distance=Math.Max(geometry.MinimumReach,Math.Min(geometry.Reach,v.Length));
            return shoulder+(MotionVector.Dot(v,v)<.0001 ? geometry.Forward : v.Unit)*distance;
        }
        public static double Quality(Func<double,PhraseState> sample,PhraseGeometry geometry,MotionVector center,MotionVector forward,MotionVector direction,double contactTime,bool noArrow)
        {
            if(sample==null || geometry==null)return 0;
            PhraseState pose=sample(contactTime);MotionVector grip=Grip(pose,geometry,contactTime);
            MotionVector bottom=grip+pose.Rotation.Rotate(geometry.Bottom-geometry.Grip),blade=pose.Rotation.Rotate(geometry.Top-geometry.Bottom);
            double along=MotionPhrase.Clamp(MotionVector.Dot(center-bottom,blade)/Math.Max(.0001,MotionVector.Dot(blade,blade)),0,1);
            MotionVector contact=bottom+blade*along;
            // Differentiate the same reach projection at true contact time.
            // Coarse practice-frame differences can reverse or underestimate a
            // wrist cut that travels most of its scoring arc in one frame.
            const double dt=.0001;
            MotionVector velocity=(Grip(sample(contactTime+dt),geometry,contactTime+dt)-Grip(sample(contactTime-dt),geometry,contactTime-dt))/(2*dt)+MotionVector.Cross(pose.AngularVelocity,contact-grip);
            MotionVector planar=velocity-forward*MotionVector.Dot(velocity,forward);
            double directional=noArrow ? 1 : MotionVector.Dot(planar,planar)<.001 ? 0 : MotionPhrase.Clamp((MotionVector.Dot(planar.Unit,direction)+.1)/.9,0,1);
            double score=MotionPhrase.Clamp(1-(center-contact).Length/.22,0,1)*directional*MotionPhrase.Clamp(planar.Length/1.5,0,1);
            return HumanMotionModel.Finite(score) ? score : 0;
        }
    }
}
