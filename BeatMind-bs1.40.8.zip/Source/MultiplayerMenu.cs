using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using BeatSaberMarkupLanguage;
using BeatSaberMarkupLanguage.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace SaberMind
{
    // Each view gets its own bindings; both views edit the same multiplayer-only
    // settings. Never share RectTransforms between the online tab and server form.
    public sealed class MultiplayerOptions : INotifyPropertyChanged,IDisposable
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private static event Action OptionsChanged;
        private bool disposed;
        public MultiplayerOptions()
        { OptionsChanged+=Refresh;MultiplayerIntegration.StatusChanged+=Refresh; }
        [UIComponent("model-row")] private RectTransform modelRow=null;
        [UIComponent("multiplayer-panel")] private RectTransform panel=null;
        [UIValue("bot-enabled")] public bool Enabled
        {
            get {return Settings.Current.MultiplayerJoinEnabled;}
            set {if(value==Enabled)return;Settings.Current.MultiplayerJoinEnabled=value;Settings.Save();
                MultiplayerIntegration.HostOptionsChanged();NotifyOptionsChanged();}
        }
        [UIValue("bot-models")] public List<object> Models {get {return new List<object>{"Model 1","Model 2","Model 3"};}}
        [UIValue("bot-model")] public string Model
        {
            get {return "Model "+(Settings.Current.MultiplayerModel+1);}
            set {int model;if(!int.TryParse((value??"").Replace("Model ",""),out model)||model<1||model>3)return;
                if(model-1==Settings.Current.MultiplayerModel)return;
                Settings.Current.MultiplayerModel=model-1;Settings.Save();MultiplayerIntegration.HostOptionsChanged();NotifyOptionsChanged();}
        }
        [UIValue("bot-lobby-status")] public string Status
        {get {return Enabled ? MultiplayerIntegration.Status : "Private 1v1 support. A separate signed-in client is required.";}}
        private void Changed(string name) {if(PropertyChanged!=null)PropertyChanged(this,new PropertyChangedEventArgs(name));}
        private static void NotifyOptionsChanged(){if(OptionsChanged!=null)OptionsChanged();}
        internal void Refresh(){RefreshVisibility();Changed("Enabled");Changed("Model");Changed("Status");}
        private void RefreshVisibility() {if(modelRow!=null)modelRow.gameObject.SetActive(Enabled);}
        [UIAction("#post-parse")] private void Layout()
        {
            if(panel==null || modelRow==null)throw new InvalidOperationException("SaberMind lobby UI binding missing.");
            ContentSizeFitter fit=panel.GetComponent<ContentSizeFitter>();
            if(fit!=null){fit.horizontalFit=ContentSizeFitter.FitMode.Unconstrained;fit.verticalFit=ContentSizeFitter.FitMode.Unconstrained;}
            panel.anchorMin=panel.anchorMax=new Vector2(.5f,.5f);panel.pivot=new Vector2(.5f,.5f);
            panel.anchoredPosition=Vector2.zero;panel.sizeDelta=new Vector2(78,54);RefreshVisibility();
        }
        public void Dispose()
        {if(disposed)return;disposed=true;OptionsChanged-=Refresh;MultiplayerIntegration.StatusChanged-=Refresh;PropertyChanged=null;}
    }

    public sealed class MultiplayerMenu : MonoBehaviour
    {
        private GameObject root;
        private MultiplayerOptions options;
        internal void Show(CreateServerViewController view)
        {
            if(root==null)
            {
                options=new MultiplayerOptions();
                try
                {
                root=new GameObject("SaberMind private lobby options",typeof(RectTransform));
                RectTransform rect=(RectTransform)root.transform;rect.SetParent(view.transform,false);
                rect.anchorMin=rect.anchorMax=new Vector2(.5f,.5f);rect.pivot=new Vector2(.5f,.5f);
                // A sibling-sized panel on the left, within the same VR screen.
                rect.anchoredPosition=new Vector2(-104,0);rect.sizeDelta=new Vector2(78,54);
                using(Stream stream=typeof(Plugin).Assembly.GetManifestResourceStream("SaberMind.MultiplayerMenu.bsml"))
                using(var reader=new StreamReader(stream))BSMLParser.Instance.Parse(reader.ReadToEnd(),root,options);
                }
                catch {DisposePanel();throw;}
            }
            root.SetActive(true);options.Refresh();
        }
        private void OnDisable(){if(root!=null)root.SetActive(false);}
        private void OnDestroy(){DisposePanel();}
        internal void DisposePanel()
        {if(options!=null)options.Dispose();options=null;if(root!=null)Destroy(root);root=null;}
    }
}
