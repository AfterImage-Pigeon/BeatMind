using System;
using System.Collections.Generic;
namespace SaberMind
{
    // Frames already use BeatLeader's level-origin axes. Cut-plane points use
    // world space and are not calibration anchors for these tracked poses.
    // Center the floor on the player's usual stance, retaining all recorded
    // leaning, looking, crouching and weight shifts around that stance.
    internal static class ReplayRegistration
    {
        internal struct Result {internal MotionRotation Rotation;internal MotionVector Translation;internal double Error;}
        internal static Result Fit(HumanReplayLibrary.Replay replay)
        {
            var x=new List<double>();var z=new List<double>();
            int step=Math.Max(1,replay.Frames.Count/400);
            for(int i=0;i<replay.Frames.Count;i+=step)
            {x.Add(replay.Frames[i].Head.Position.X);z.Add(replay.Frames[i].Head.Position.Z);}
            x.Sort();z.Sort();
            return new Result{Rotation=MotionRotation.Identity,Translation=new MotionVector(-x[x.Count/2],0,-z[z.Count/2]),Error=0};
        }
    }
}
