using System;
using System.Collections.Generic;
namespace SaberMind
{
    public static class CutSafety
    {
        public struct CutProfile {public bool Dense;public double MinContact,MaxContact,Speed,HalfSwing;}
        // Preserve the existing learned timing/stroke policy and the proven
        // contact-speed floor. The new motor owns the entire trajectory.
        public static CutProfile StrokeFor(PhraseNote n)
        {double nps=n.LocalNps>0 ? n.LocalNps : 1/Math.Max(.04,n.Spacing);bool dense=nps>=5;return new CutProfile{Dense=dense,MinContact=dense ? .84 : .52,MaxContact=dense ? .96 : .82,Speed=(dense ? nps>=12 ? 2000 : nps>=8 ? 1750 : 1550 : 850)*1.5*Math.PI/180,HalfSwing=dense ? MotionPhrase.Clamp(n.Spacing*.27,.014,.033) : MotionPhrase.Clamp(n.Spacing*.28,.052,.085)};}
        public static bool ShouldRefit(PhraseState committed,PhraseNote n,double now)
        {return ContactGeometry.NeedsRefit(committed,n.Time,n.Center,n.Direction,now);}
        public static double BladeDistance(PhraseState s,MotionVector center,PhraseGeometry g)
        {MotionVector a=s.Grip+s.Rotation.Rotate(g.Bottom-g.Grip),b=s.Grip+s.Rotation.Rotate(g.Top-g.Grip),v=b-a;double u=MotionPhrase.Clamp(MotionVector.Dot(center-a,v)/Math.Max(1e-9,MotionVector.Dot(v,v)),0,1);return (center-a-v*u).Length;}
        public static bool ContactFits(PhraseState s,MotionVector center,PhraseGeometry g,double tolerance){return BladeDistance(s,center,g)<=tolerance;}
    }
    // A new constrained replay motor. Actual human poses are its preferred
    // trajectory; scored contacts and anatomical reach are hard constraints.
    // No generated baseline, residual deformation, neutral return or noise.
    public static class ReplayMotor
    {
        private sealed class PoseCache
        {
            private readonly Func<double,PhraseState> sample;private readonly Dictionary<double,PhraseState> poses=new Dictionary<double,PhraseState>();private readonly Queue<double> order=new Queue<double>();
            internal PoseCache(Func<double,PhraseState> sample){this.sample=sample;}
            // Planning consumers treat these as read-only and copy before
            // mutation. Avoid a second heap pose for every safety probe.
            internal PhraseState Sample(double t){PhraseState s;if(!poses.TryGetValue(t,out s)){s=sample(t);poses[t]=s;order.Enqueue(t);while(order.Count>128)poses.Remove(order.Dequeue());}return s;}
        }
        private sealed class VectorCache
        {
            private readonly Func<double,MotionVector> sample;private readonly Dictionary<double,MotionVector> values=new Dictionary<double,MotionVector>();private readonly Queue<double> order=new Queue<double>();
            internal VectorCache(Func<double,MotionVector> sample){this.sample=sample;}
            internal MotionVector Sample(double t){MotionVector s;if(!values.TryGetValue(t,out s)){s=sample(t);values[t]=s;order.Enqueue(t);while(order.Count>128)values.Remove(order.Dequeue());}return s;}
        }
        private static MotionVector Shoulder(PhraseGeometry g,double t){return g.ShoulderAt==null ? g.Shoulder : g.ShoulderAt(t);}
        private static MotionVector Reach(MotionVector p,PhraseGeometry g,double t)
        {MotionVector shoulder=Shoulder(g,t),v=p-shoulder;double min=g.MinimumReach>0 ? g.MinimumReach*1.04 : .08;if(v.Length<min)v=(v.Length>.001 ? v.Unit : g.Forward)*min;return shoulder+v.Limited(g.Reach*.985);}
        public static PhraseState FitContact(PhraseState human,PhraseNote n,PhraseGeometry g,PhraseState previous,int budget,out int evaluations)
        {
            evaluations=0;if(n.Committed!=null)return n.Committed.Copy();
            MotionVector axis=(g.Top-g.Bottom).Unit,side=MotionVector.Cross(n.Forward,n.Direction).Unit;
            var profile=CutSafety.StrokeFor(n);MotionVector shoulder=Shoulder(g,n.Time);PhraseState best=null;double bestCost=double.MaxValue,bestTravel=double.MaxValue;int bestKind=int.MaxValue;
            bool fixedWrist=g.StableFastGrip && profile.Dense;
            bool connected=fixedWrist && previous!=null && previous.Id>=0 && n.Time-previous.Time<=.4;
            MotionVector pivotReference=Reach(connected ? previous.Grip : fixedWrist && n.HasPivotHint ? n.PivotHint : human.Grip,g,n.Time);
            MotionRotation wristReference=connected ? previous.Rotation : human.Rotation;
            bool hasOtherHand=g.OtherHandAt!=null;MotionVector otherGrip=hasOtherHand ? g.OtherHandAt(n.Time) : new MotionVector();
            // Search orientation AND blade contact distance together. Moving
            // the grip independently of the rotation caused incompatible paths.
            int grid=budget>=8 ? 25 : budget>=5 ? 13 : 7;int orientations=grid+(previous==null ? 0 : 2)+(fixedWrist || n.NextPose==null ? 0 : 2)+(fixedWrist || n.Next==null ? 0 : 2);
            for(int c=0;c<orientations;c++)
            {
                MotionRotation q=wristReference*MotionRotation.Exp(axis*(n.WristTwist*.12));
                if(!fixedWrist && n.Next!=null && c>=orientations-2){MotionVector line=(n.Next.Center-n.Center).Unit*(c==orientations-1 ? -1 : 1);if(line.Length>.5)q=MotionRotation.FromTo(q.Rotate(axis),line,n.Direction)*q;} else if(!fixedWrist && n.NextPose!=null && c>=grid+(previous==null ? 0 : 2)){q=n.NextPose.Rotation;if(c%2==0){MotionRotation h=human.Rotation;if(MotionRotation.Dot(q,h)<0)h=h*-1;q=(q+h).Unit;}} else if(c>=grid && previous!=null){q=previous.Rotation;if(c>grid){MotionRotation h=wristReference;if(MotionRotation.Dot(q,h)<0)h=h*-1;q=(q+h).Unit;}} else if(c>0)
                {
                    double angle=(c+1)/2*12*Math.PI/180*MotionPhrase.Clamp(n.Curve,.65,1.35)*(c%2==0 ? -1 : 1);
                    MotionVector pivot=c<9 ? side : c<17 ? n.Direction : n.Forward;
                    q=MotionRotation.Exp(pivot*angle)*q;
                }
                if(fixedWrist)
                {
                    // Candidate grid rotations may include an unrelated roll
                    // about the blade. Parallel-transport the outgoing hand
                    // frame to the candidate blade direction instead. Measured
                    // local roll remains in the immutable replay roll curve.
                    q=MotionRotation.FromTo(wristReference.Rotate(axis),q.Rotate(axis),n.Direction)*wristReference;
                }
                MotionVector blade=q.Rotate(axis);
                double measured=MotionVector.Dot(n.Center-human.Grip-q.Rotate(g.Bottom-g.Grip),blade);
                double length=(g.Top-g.Bottom).Length;
                for(int d=0;d<5;d++)
                {
                    double distance=d==0 ? MotionPhrase.Clamp(measured+n.GripPreference,length*.08,length*.99) : length*(.10+(d-1)*.29);
                    MotionVector grip=n.Center-q.Rotate(g.Bottom+axis*distance-g.Grip);
                    double reach=Math.Max(0,(grip-shoulder).Length-g.Reach*.98);
                    double close=Math.Max(0,g.MinimumReach*1.04-(grip-shoulder).Length);if(reach>0 || close>0)continue;
                    MotionVector horizontal=MotionVector.Cross(new MotionVector(0,1,0),g.Forward).Unit;
                    double cross=MotionVector.Dot(grip-shoulder,horizontal)*(g.Color==0 ? -1 : 1);
                    double changed=MotionRotation.Log(q*human.Rotation.Inverse).Length;
                    double wrist=Angle((grip-shoulder).Unit,blade);
                    double cost=(grip-human.Grip).Length*(grip-human.Grip).Length*9*MotionPhrase.Clamp(n.Lean*n.Torso,.6,1.5)+changed*changed*.18+reach*reach*2500+close*close*2500+Math.Pow(Math.Max(0,-.09+n.Shoulder-cross),2)*2+Math.Pow(Math.Max(0,wrist-(2.35+n.Elbow*.20)),2)*.15;
                    if(previous!=null){double gap=Math.Max(.01,n.Time-previous.Time),travel=(grip-previous.Grip).Length,turn=MotionRotation.Log(q*previous.Rotation.Inverse).Length;cost+=travel*travel*(.018/(gap*gap))+turn*.03+Math.Pow(Math.Max(0,travel-8*gap-.02),2)*2500+Math.Pow(Math.Max(0,turn-65*gap-.08),2)*100;}
                    if(hasOtherHand)cost+=Math.Pow(Math.Max(0,.085-(grip-otherGrip).Length),2)*15;
                    foreach(var extra in n.OtherCenters){var trial=new PhraseState{Grip=grip,Rotation=q};double miss=CutSafety.BladeDistance(trial,extra,g);cost+=miss*miss*200;}
                    int kind=ContactKind(grip,q,n,g);
                    double pivotTravel=(grip-pivotReference).Length;
                    cost+=FutureCost(grip,q,n,g); evaluations++;if(kind<bestKind || kind==bestKind && (pivotTravel<bestTravel-1e-7 || Math.Abs(pivotTravel-bestTravel)<=1e-7 && cost<bestCost))
                    {
                        bestKind=kind;bestTravel=pivotTravel;bestCost=cost;best=human.Copy();best.Id=n.Id;best.Time=n.Time;best.Grip=grip;best.Rotation=q.Unit;best.TargetCenter=n.Center;
                    }
                }
            }
            // A human's measured grip (or the preceding grip) often supplies
            // a better pivot than an orientation-grid candidate. Solve a blade
            // contact from those reachable pivots, including extreme lanes.
            MotionVector toward=(n.Center-shoulder).Unit;
            MotionVector[] pivots=previous==null ? new[]{pivotReference,human.Grip,shoulder+toward*g.Reach*.65,shoulder+toward*g.Reach*.95} : new[]{pivotReference,human.Grip,previous.Grip,(human.Grip+previous.Grip)*.5,shoulder+toward*g.Reach*.65,shoulder+toward*g.Reach*.95};
            foreach(var pivot in pivots)
            {
                MotionVector grip=Reach(pivot,g,n.Time);MotionRotation q=wristReference*MotionRotation.Exp(axis*(n.WristTwist*.12));
                // Solve the rigid blade about its HAND pivot. Aiming from the
                // current blade bottom and rotating that bottom afterward was
                // only an iterative approximation, and missed a valid pivot.
                // |bottom-grip + axis*d| equals the pivot-to-note distance.
                MotionVector offset=g.Bottom-g.Grip,desired=n.Center-grip;
                double alongOffset=MotionVector.Dot(offset,axis),radial=MotionVector.Dot(desired,desired)-MotionVector.Dot(offset-axis*alongOffset,offset-axis*alongOffset);
                if(radial<0)continue;
                double distance=Math.Sqrt(radial)-alongOffset,length=(g.Top-g.Bottom).Length;
                if(distance>length*.99 || distance<.05)continue;
                MotionVector contactOffset=offset+axis*distance;
                q=MotionRotation.FromTo(q.Rotate(contactOffset),desired,n.Direction)*q;
                double changed=MotionRotation.Log(q*human.Rotation.Inverse).Length;
                double cost=(grip-human.Grip).Length*(grip-human.Grip).Length*9*MotionPhrase.Clamp(n.Lean*n.Torso,.6,1.5)+changed*changed*.18;
                if(previous!=null){double gap=Math.Max(.01,n.Time-previous.Time),travel=(grip-previous.Grip).Length,turn=MotionRotation.Log(q*previous.Rotation.Inverse).Length;cost+=travel*travel*(.018/(gap*gap))+turn*.03+Math.Pow(Math.Max(0,travel-8*gap-.02),2)*2500+Math.Pow(Math.Max(0,turn-65*gap-.08),2)*100;}
                foreach(var extra in n.OtherCenters){double miss=CutSafety.BladeDistance(new PhraseState{Grip=grip,Rotation=q},extra,g);cost+=miss*miss*200;}
                int kind=ContactKind(grip,q,n,g);
                double pivotTravel=(grip-pivotReference).Length;
                cost+=FutureCost(grip,q,n,g); evaluations++;if(kind<bestKind || kind==bestKind && (pivotTravel<bestTravel-1e-7 || Math.Abs(pivotTravel-bestTravel)<=1e-7 && cost<bestCost)){bestKind=kind;bestTravel=pivotTravel;bestCost=cost;best=human.Copy();best.Id=n.Id;best.Time=n.Time;best.Grip=grip;best.Rotation=q.Unit;best.TargetCenter=n.Center;}
            }
            if(best==null){best=human.Copy();best.Id=n.Id;best.Time=n.Time;best.TargetCenter=n.Center;best.Grip=n.Center-best.Rotation.Rotate(g.Bottom+axis*((g.Top-g.Bottom).Length*.9)-g.Grip);}
            best.TargetDirection=n.Direction;
            MotionVector b=best.Rotation.Rotate(axis),swingAxis=MotionVector.Cross(b,n.Direction).Unit;
            if(swingAxis.Length<.5)swingAxis=side;
            double along=MotionVector.Dot(human.AngularVelocity,swingAxis);
            // Keep measured wrist roll/banking, with sufficient cut-direction
            // angular motion. The velocity is reached through a C2 approach.
            if(human.HumanWristWeight>0)
            {
                // Transport the measured wrist jet into the fitted blade frame.
                // A universal 1275-3000 degree/s floor and 2 rad/s bank clamp
                // replaced human cadence even when the demonstration was valid.
                MotionRotation transport=best.Rotation*human.Rotation.Inverse;
                best.AngularVelocity=transport.Rotate(human.AngularVelocity);
                best.AngularAcceleration=transport.Rotate(human.AngularAcceleration);
                best.Velocity=human.Velocity;best.Acceleration=human.Acceleration;
                MotionVector contact=best.Rotation.Rotate(g.Bottom-g.Grip);
                double distance=MotionVector.Dot(n.Center-best.Grip-contact,b);
                contact+=b*distance;
                MotionVector top=best.Rotation.Rotate(g.Top-g.Grip);
                MotionVector velocity=best.Velocity+MotionVector.Cross(best.AngularVelocity,top);
                MotionVector plane=velocity-n.Forward*MotionVector.Dot(velocity,n.Forward);
                MotionVector atContact=best.Velocity+MotionVector.Cross(best.AngularVelocity,contact);
                if(plane.Length<1.5 || MotionVector.Dot(plane.Unit,n.Direction)<.65 || MotionVector.Dot(atContact,n.Direction)<1.5)
                {
                    // Retarget the sweep axis rather than translating the hand
                    // to compensate. Keep measured angular speed and blade roll
                    // unless the shorter fitted lever needs more speed to cut.
                    MotionVector measured=best.AngularVelocity;double roll=MotionVector.Dot(measured,b);
                    double swing=Math.Sqrt(Math.Max(0,MotionVector.Dot(measured,measured)-roll*roll));
                    double lever=Math.Min(MotionVector.Dot(MotionVector.Cross(swingAxis,contact),n.Direction),MotionVector.Dot(MotionVector.Cross(swingAxis,top),n.Direction));
                    double required=Math.Max(0,(1.5-MotionVector.Dot(best.Velocity,n.Direction))/Math.Max(.001,lever));
                    best.AngularVelocity=swingAxis*Math.Max(swing,required)+b*roll;
                    best.AngularAcceleration=MotionRotation.FromTo(measured,best.AngularVelocity,swingAxis).Rotate(best.AngularAcceleration);
                }
            }
            else
            {
            best.AngularVelocity=swingAxis*Math.Max(profile.Speed*MotionPhrase.Clamp(n.Wrist,.97,1.03),along)+(human.AngularVelocity-swingAxis*along).Limited(2.0);
            best.AngularAcceleration=human.AngularAcceleration.Limited(200);
            MotionVector lever=best.Rotation.Rotate(g.Bottom+axis*((g.Top-g.Bottom).Length*.65)-g.Grip);
            MotionVector bladeSpeed=best.Velocity+MotionVector.Cross(best.AngularVelocity,lever);
            double wrong=MotionVector.Dot(bladeSpeed,n.Direction);
            if(wrong<1.5)best.Velocity+=n.Direction*(1.5-wrong);
            best.Velocity=best.Velocity.Limited(3.2)*MotionPhrase.Clamp(n.Momentum,.85,1.15);best.Acceleration=best.Acceleration.Limited(80);
            }
            if(g.ScoredHumanSwings)
            {
                // The wrist owns a dense cut. Reusing the unrelated teacher's
                // hand jet here made the entire blade translate through blocks
                // and could counteract its correctly directed angular motion.
                if(fixedWrist)best.Velocity=best.Acceleration=new MotionVector();
                // 0.9.9's four contact-speed bands, applied to the v14 fitted
                // replay pose. A teacher braking/reversing near the contact
                // must not replace the actual arrow-directed cut with a pause.
                double speed=Math.Max(profile.Speed*MotionPhrase.Clamp(n.Wrist,.97,1.03),MotionVector.Dot(best.AngularVelocity,swingAxis));
                MotionVector lever=best.Rotation.Rotate(g.Top-g.Grip);
                MotionVector bottom=best.Rotation.Rotate(g.Bottom-g.Grip);
                double distance=MotionPhrase.Clamp(MotionVector.Dot(n.Center-best.Grip-bottom,b),0,(g.Top-g.Bottom).Length);
                MotionVector contact=bottom+b*distance;
                double tangent=Math.Min(MotionVector.Dot(MotionVector.Cross(swingAxis,lever),n.Direction),MotionVector.Dot(MotionVector.Cross(swingAxis,contact),n.Direction));
                if(tangent>1e-6)speed=Math.Max(speed,(1.5-MotionVector.Dot(best.Velocity,n.Direction))/tangent);
                best.AngularVelocity=swingAxis*speed;
                best.AngularAcceleration=new MotionVector();
                best.SteadyWristMotion=true;
            }
            // Keep the v14 fitted pose and grip. Boost the connected hand/wrist
            // jet once. Scaling rotation alone can reverse a valid cut when
            // human hand translation counterbalances the wrist's follow-through.
            // Committed poses above already own their speed and swing clock.
            double scale=Math.Max(1,g.SwingSpeedScale);
            if(best.WristSpeedScale<scale)
            {double gain=scale/Math.Max(1,best.WristSpeedScale);best.Velocity*=gain;best.Acceleration*=gain*gain;best.AngularVelocity*=gain;best.AngularAcceleration*=gain*gain;best.WristSpeedScale=scale;}
            best.HumanGripWeight=human.HumanGripWeight;best.HumanWristWeight=human.HumanWristWeight;return best;
        }
        private static int ContactKind(MotionVector grip,MotionRotation q,PhraseNote n,PhraseGeometry g)
        {
            // A blade parallel to the arrow cannot produce that cut through a
            // wrist swing. The old fit accepted it, then compensated by moving
            // the entire handle through the note. Test angular tip motion in
            // the note plane before preferring a compact, reachable hand pivot.
            MotionVector blade=q.Rotate((g.Top-g.Bottom).Unit),axis=MotionVector.Cross(blade,n.Direction).Unit;
            // The grip stays behind a front-facing dense contact. Previously
            // a backward next-note chord could win an independent contact fit
            // and require a half-turn recovery only milliseconds later.
            if(g.StableFastGrip && CutSafety.StrokeFor(n).Dense && MotionVector.Dot(blade,n.Forward)<.08)return 3;
            MotionVector v=MotionVector.Cross(axis,q.Rotate(g.Top-g.Grip));v-=n.Forward*MotionVector.Dot(v,n.Forward);
            bool wristCut=v.Length>1e-8 && MotionVector.Dot(v.Unit,n.Direction)>=.5;
            foreach(var extra in n.OtherCenters)if(CutSafety.BladeDistance(new PhraseState{Grip=grip,Rotation=q},extra,g)>.025)return 2;
            return wristCut ? 0 : 1;
        }
        private static double FutureCost(MotionVector grip,MotionRotation q,PhraseNote n,PhraseGeometry g)
        {
            if(n.Next==null || n.NextPose==null)return 0;
            double gap=n.Next.Time-n.Time;if(gap>.4 || gap<=0)return 0;
            double travel=(grip-n.NextPose.Grip).Length,turn=MotionRotation.Log(n.NextPose.Rotation*q.Inverse).Length;
            return (travel*travel*.10+turn*turn*.001)*MotionPhrase.Clamp(n.Anticipation*n.HeadLead,.65,1.4)/(gap*gap);
        }
        private static double Angle(MotionVector a,MotionVector b){return Math.Acos(MotionPhrase.Clamp(MotionVector.Dot(a.Unit,b.Unit),-1,1));}
        public static MotionPhrase Build(PhraseState seed,IList<PhraseNote> notes,PhraseGeometry g,Func<double,PhraseState> teacher,int effort,double horizon)
        {var job=BeginBuild(seed,notes,g,teacher,effort,horizon);while(!job.Advance(1000)){}return job.Result;}
        public static ReplayPlanJob BeginBuild(PhraseState seed,IList<PhraseNote> notes,PhraseGeometry g,Func<double,PhraseState> teacher,int effort,double horizon)
        {var result=new MotionPhrase();return new ReplayPlanJob(result,BuildSteps(result,seed,notes,g,teacher,effort,horizon).GetEnumerator());}
        private static IEnumerable<int> BuildSteps(MotionPhrase path,PhraseState seed,IList<PhraseNote> notes,PhraseGeometry g,Func<double,PhraseState> teacher,int effort,double horizon)
        {
            var raw=teacher;teacher=new PoseCache(teacher).Sample;
            g=new PhraseGeometry{Bottom=g.Bottom,Top=g.Top,Grip=g.Grip,Shoulder=g.Shoulder,Forward=g.Forward,Reach=g.Reach,MinimumReach=g.MinimumReach,Color=g.Color,SwingSpeedScale=g.SwingSpeedScale,ScoredHumanSwings=g.ScoredHumanSwings,
                StableFastGrip=g.StableFastGrip,ShoulderAt=g.ShoulderAt==null ? null : (Func<double,MotionVector>)new VectorCache(g.ShoulderAt).Sample,OtherHandAt=g.OtherHandAt==null ? null : (Func<double,MotionVector>)new VectorCache(g.OtherHandAt).Sample};
            Func<double,PhraseState> adapted=null;
            foreach(int step in ReachTeacher.Prepare(teacher,g,seed.Time,seed.Time+horizon,delegate(Func<double,PhraseState> ready){adapted=ready;}))yield return step;
            teacher=adapted;
            foreach(int step in ConstrainedReplayTrajectory.Prepare(path,seed,notes,g,teacher,effort,horizon))yield return step;
            path.RawTeacher=raw;path.AdaptedTeacher=teacher;
        }
    }
}
