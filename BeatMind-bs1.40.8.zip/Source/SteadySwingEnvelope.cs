using System;

namespace SaberMind
{
    // Analytic scalar angular travel. Only the outer 18% of each side ramps;
    // the wrist keeps its contact speed through the rest of the scored stroke.
    public sealed class SteadySwingEnvelope
    {
        public const double RampFraction=.18,TravelFraction=.91;
        public readonly double Start,Hit,End,Speed;
        private readonly double before,after,rise,fall;

        public SteadySwingEnvelope(double start,double hit,double end,double speed)
        {
            if(!Finite(start) || !Finite(hit) || !Finite(end) || !(start<hit && hit<end))
                throw new ArgumentException("Swing times must be finite and ordered start < hit < end.");
            if(!Finite(speed) || speed<0)throw new ArgumentOutOfRangeException("speed","Swing speed must be finite and nonnegative.");
            Start=start;Hit=hit;End=end;Speed=speed;
            before=hit-start;after=end-hit;rise=before*RampFraction;fall=after*RampFraction;
        }

        public void Sample(double time,out double angleFromContact,out double rate,out double acceleration)
        {
            rate=acceleration=0;
            if(time<=Start){angleFromContact=-Speed*before*TravelFraction;return;}
            if(time>=End){angleFromContact=Speed*after*TravelFraction;return;}
            if(time<Start+rise)
            {
                double u=(time-Start)/rise;
                angleFromContact=-Speed*before*TravelFraction+Speed*rise*Integral(u);
                rate=Speed*Smooth(u);acceleration=Speed*Slope(u)/rise;return;
            }
            if(time>End-fall)
            {
                double u=(time-(End-fall))/fall;
                angleFromContact=Speed*(after-fall+fall*(u-Integral(u)));
                rate=Speed*(1-Smooth(u));acceleration=-Speed*Slope(u)/fall;return;
            }
            angleFromContact=Speed*(time-Hit);rate=Speed;
        }

        private static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
        private static double Smooth(double u){return u*u*u*(10+u*(-15+6*u));}
        private static double Slope(double u){return 30*u*u*(1-u)*(1-u);}
        private static double Integral(double u){return u*u*u*u*(2.5+u*(-3+u));}
    }
}
