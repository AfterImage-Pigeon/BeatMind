using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace SaberMind
{
    public sealed class MemoryStore
    {
        private readonly string directory;
        public MemoryStore(string directory) { this.directory = directory; }
        public string FileFor(string identity)
        {
            using (SHA256 hash = SHA256.Create())
            {
                string name = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(identity))).Replace("-", "").ToLowerInvariant();
                return Path.Combine(directory, name + ".json");
            }
        }
        public LevelMemory Load(string identity)
        {
            string path = FileFor(identity);
            if (!File.Exists(path)) return new LevelMemory { Identity = identity };
            LevelMemory result = JsonConvert.DeserializeObject<LevelMemory>(File.ReadAllText(path));
            if (result == null || result.Format != 1 || result.Identity != identity)
                throw new InvalidDataException("Learning file has an unsupported format or identity.");
            if (result.Notes == null) result.Notes = new System.Collections.Generic.Dictionary<string, NoteMemory>();
            return result;
        }
        public void Save(LevelMemory memory)
        {
            Directory.CreateDirectory(directory);
            string path = FileFor(memory.Identity), temp = path + ".tmp";
            File.WriteAllText(temp, JsonConvert.SerializeObject(memory, Formatting.Indented));
            if (File.Exists(path)) File.Replace(temp, path, path + ".bak");
            else File.Move(temp, path);
        }
    }
}
