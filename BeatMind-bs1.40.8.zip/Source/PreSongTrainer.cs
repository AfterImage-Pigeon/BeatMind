using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace SaberMind
{
    internal sealed class PreSongStatus
    {
        internal int Percent, Sections, Patterns;
        internal string Phase, Pass, SimulatedSpeed, Confidence, Readiness;
    }

    // Work is performed in short main-thread slices while the game's song
    // coroutine waits. Every practice frame advances the same body, arm,
    // wrist and pose functions that drive the visible run at true song time.
    internal sealed class PreSongTrainer : IDisposable
    {
        private sealed class Section
        {
            internal int Start, End, Extra;
            internal float Difficulty;
        }
        private sealed class Job
        {
            internal int Start, End, Candidate, Pass, Estimate;
            internal bool Final;
            internal float Dt;
        }
        private sealed class Result
        {
            internal Vector3 Plan;
            internal float Score;
            internal int Variant;
        }
        private sealed class Runner : IDisposable
        {
            internal BodyRig Rig;
            internal Hand[] Hands = new Hand[2];
            internal int[] Cursor = new int[2];
            internal Vector3[] PreviousContact = new Vector3[2];
            internal bool[] HasContact = new bool[2];
            internal HashSet<int> Evaluated = new HashSet<int>();
            internal float Time, End;
            internal int Steps;
            public void Dispose() { if (Rig != null) Rig.Dispose(); Rig = null; }
        }

        private readonly Session session;
        private readonly IList<NoteData> source;
        private readonly List<TrackedNote> notes = new List<TrackedNote>();
        private readonly List<Section> sections = new List<Section>();
        private readonly Queue<Job> jobs = new Queue<Job>();
        private readonly Dictionary<int, Result> best = new Dictionary<int, Result>();
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private readonly PreSongStatus status = new PreSongStatus();
        private Runner runner;
        private Job current;
        private int analyzed, patterns, practiceTotal, practiceDone, validated, finalEstimate, finalDone;
        private int passNumber, passCount;
        private int cachedSections;
        private string preparationSignature,sourceIdentity;
        private float scoreSum;
        private float simulatedSeconds;
        private bool afterRunner;
        private bool disposed;

        internal bool Done { get; private set; }
        internal PreSongStatus Status { get { return status; } }

        internal PreSongTrainer(Session session)
        {
            this.session=session; source=session.MapNotes;
            status.Phase="Analyzing map..."; status.Pass="analysis";
            status.SimulatedSpeed="fast map scan"; status.Confidence="unmeasured";
            status.Readiness="pending";
            if (source.Count==0) { status.Percent=100; status.Phase="Ready."; Done=true; }
        }

        internal void Tick()
        {
            if (Done || disposed) return;
            long start=Stopwatch.GetTimestamp();
            long budget=Stopwatch.Frequency/350; // about 2.9 ms per rendered frame
            try
            {
                do
                {
                    if (analyzed<source.Count) AnalyzeOne();
                    else if (runner==null)
                    {
                        if (afterRunner) { afterRunner=false; break; }
                        if (jobs.Count==0) { Complete(); break; }
                        StartNext();
                    }
                    else AdvanceOne();
                } while (!Done && Stopwatch.GetTimestamp()-start<budget);
                UpdateStatus();
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        private void AnalyzeOne()
        {
            int index=analyzed++;
            NoteData data=source[index];
            Vector3 origin=session.Body.Origin;
            Quaternion mapRotation=Quaternion.AngleAxis(data.rotation,Vector3.up);
            Vector3 center=origin+mapRotation*(session.Body.MapPoint(data.lineIndex,(int)data.noteLineLayer)-origin);
            Vector3 forward=mapRotation*session.Body.Forward;
            Vector3 right=Vector3.Cross(Vector3.up,forward);
            Vector3 direction=DotFlow.Direction(source,index,right,session.NoArrows);
            direction=Quaternion.AngleAxis(data.cutDirectionAngleOffset,forward)*direction;
            var note=new TrackedNote { Data=data,Key=session.KeyFor(data),MapIndex=index,Time=data.time,Color=(int)data.colorType,
                Center=center,Forward=forward,Direction=direction.normalized,HasPose=true,
                Variant=session.KnownVariant(data),Timing=session.KnownTiming(data),Behavior=session.KnownBehavior(data,index),Style=0,Spacing=1.2f,
                LocalNps=Session.LocalNotesPerSecond(source,index),Pattern=DotFlow.Pattern(source,index,session.NoArrows) };
            if(!session.HasTimingEvidence(data))
                note.Variant=data.timeToNextColorNote<.20f || data.timeToPrevColorNote<.20f ? 3 :
                    data.timeToNextColorNote>.55f && data.timeToPrevColorNote>.55f ? 6 : 0;
            session.ApplyBestDecision(note);
            PretrainedPlan saved;
            if (session.Learned.Pretrained!=null && session.Learned.Pretrained.TryGetValue(note.Key,out saved)
                && saved!=null && saved.Validations>0 && saved.MotionVersion==2)
            {
                note.Plan=new Vector3(0,0,Mathf.Clamp(saved.Z,-.06f,.06f));
                if(!session.HasTimingEvidence(data) && saved.Variant>=0 && saved.Variant<Policy.Variants.Length)note.Variant=saved.Variant;
            }
            for(int i=index-1;i>=0;i--) if(notes[i].Color==note.Color)
            {
                note.Spacing=Mathf.Max(.04f,note.Time-notes[i].Time);
                notes[i].Spacing=Mathf.Min(notes[i].Spacing,note.Spacing);
                break;
            }
            notes.Add(note);
            int bucket=Mathf.FloorToInt((note.Time-session.PracticeStart)/4f);
            Section section=sections.Count==0 ? null : sections[sections.Count-1];
            if (section==null || Mathf.FloorToInt((notes[section.Start].Time-session.PracticeStart)/4f)!=bucket)
            { section=new Section { Start=index,End=index }; sections.Add(section); }
            section.End=index;
            if (note.Spacing<.22f) section.Difficulty+=2;
            if (note.Spacing<.13f) section.Difficulty+=2;
            if (index>0)
            {
                TrackedNote previous=notes[index-1];
                if (Mathf.Abs(note.Time-previous.Time)<.035f) { section.Difficulty+=1.5f; patterns++; }
                if (note.Color==previous.Color)
                {
                    if (Vector3.Dot(note.Direction,previous.Direction)<-.5f) { section.Difficulty+=2; patterns++; }
                    if (Mathf.Abs(data.lineIndex-source[index-1].lineIndex)>1) { section.Difficulty+=1.5f; patterns++; }
                }
            }
            if ((note.Color==0 && data.lineIndex>=2)||(note.Color==1 && data.lineIndex<=1))
            { section.Difficulty+=1; patterns++; }
            if (analyzed==source.Count) BuildJobs();
        }

        internal static Vector3 CutDirection(NoteCutDirection cut,Vector3 right)
        {
            switch(cut)
            {
                case NoteCutDirection.Up: return Vector3.up;
                case NoteCutDirection.Down: return Vector3.down;
                case NoteCutDirection.Left: return -right;
                case NoteCutDirection.Right: return right;
                case NoteCutDirection.UpLeft: return (Vector3.up-right).normalized;
                case NoteCutDirection.UpRight: return (Vector3.up+right).normalized;
                case NoteCutDirection.DownLeft: return (Vector3.down-right).normalized;
                case NoteCutDirection.DownRight: return (Vector3.down+right).normalized;
                default: return Vector3.down;
            }
        }

        private void BuildJobs()
        {
            Session.ResolveContactSchedule(notes);
            sourceIdentity=session.Body.Motion.PreparationIdentity;
            preparationSignature=Signature();
            // One baseline physical pass for every section; additional passes
            // only for sections with dense, abrupt or crossed patterns.
            foreach(Section section in sections)
            {
                var saved=new List<PretrainedPlan>();
                for(int i=section.Start;i<=section.End;i++)
                {PretrainedPlan p=null;if(session.Learned.Pretrained!=null)session.Learned.Pretrained.TryGetValue(notes[i].Key,out p);saved.Add(p);}
                if(PreparationCache.Reusable(saved,preparationSignature,Settings.Current.ReadinessThreshold))
                {
                    cachedSections++;
                    for(int i=section.Start;i<=section.End;i++)
                    {var p=saved[i-section.Start];best[i]=new Result{Plan=notes[i].Plan,Score=p.Confidence,Variant=notes[i].Variant};}
                    continue;
                }
                section.Extra=session.Profile.Index==0 ? (section.Difficulty>=5 ? 1 : 0) :
                    session.Profile.Index==1 ? (section.Difficulty>=4 ? 1 : 0) :
                    (section.Difficulty>=8 ? 3 : section.Difficulty>=3 ? 2 : 0);
                AddJob(section,0,1);
            }
            var difficult=new List<Section>(sections);
            difficult.Sort(delegate(Section a,Section b){return b.Difficulty.CompareTo(a.Difficulty);});
            foreach(Section section in difficult)
                for(int p=1;p<=section.Extra;p++) AddJob(section,p,p+1);
            if(cachedSections<sections.Count)
            {
                var final=new Job { Start=0,End=notes.Count-1,Final=true,Dt=session.Profile.Index==2 ? 1f/120 : 1f/90 };
                final.Estimate=Estimate(final); finalEstimate=final.Estimate; jobs.Enqueue(final);
            }
            passCount=jobs.Count;
        }
        private string Signature()
        {
            var text=new PreparationSignature().Add("geometric-preparation-v26");
            text.Add(session.Memory.Identity).Add(Session.ModelKey(session.Profile,Settings.Current))
                .Add(session.Body.Motion.PreparationIdentity).Add(session.PracticeStart)
                .Add(session.NoArrows).Add(Settings.Current.ReadinessThreshold);
            AddVector(text,session.Body.Origin);AddVector(text,session.Body.Forward);
            foreach(var w in session.MapWalls)
                text.Add(w.time).Add(w.duration).Add(w.lineIndex).Add((int)w.lineLayer).Add(w.width).Add(w.height).Add(w.rotation);
            foreach(var n in notes)
            {
                text.Add(n.Key).Add(n.Variant).Add(n.HitTime);AddVector(text,n.Plan);
                text.Add(n.Data.rotation).Add(n.Data.cutDirectionAngleOffset);
                foreach(float v in n.Behavior.Values)text.Add(v);
            }
            return text.Digest();
        }
        private static void AddVector(PreparationSignature signature,Vector3 value)
        {signature.Add(value.x).Add(value.y).Add(value.z);}
        private void AddJob(Section section,int candidate,int pass)
        {
            var job=new Job { Start=section.Start,End=section.End,Candidate=candidate,Pass=pass,
                Dt=candidate==0 ? 1f/72 : 1f/90 };
            job.Estimate=Estimate(job); practiceTotal+=job.Estimate; jobs.Enqueue(job);
        }
        private int Estimate(Job job)
        { return Mathf.CeilToInt((notes[job.End].Time-notes[job.Start].Time+.95f)/job.Dt)+2; }

        private void StartNext()
        {
            current=jobs.Dequeue(); passNumber++;
            if (!current.Final && current.Candidate>0)
            {
                float mean=0; int count=0;
                for(int i=current.Start;i<=current.End;i++)
                { Result value; if(best.TryGetValue(i,out value)) {mean+=value.Score;count++;} }
                if (count>0 && mean/count>=Settings.Current.ReadinessThreshold)
                { practiceTotal-=current.Estimate; current=null; return; }
            }
            for(int i=current.Start;i<=current.End;i++)
            {
                TrackedNote note=notes[i];Result stored;
                if(current.Final && best.TryGetValue(i,out stored))
                {note.Plan=stored.Plan;note.Variant=stored.Variant;}
                else if(current.Candidate>0)
                {note.Variant=current.Candidate%2==1 ? 3 : 6;note.Plan=new Vector3(0,0,current.Candidate%2==1 ? -.035f : .035f);}
            }
            Session.ResolveContactSchedule(notes);
            runner=new Runner();
            runner.Rig=new BodyRig(session.Body.Origin+Vector3.up*Settings.Current.Height,
                session.Body.Forward,Settings.Current,session.Profile,session.MapWalls);
            runner.Rig.Motion=session.NewMotionGraph();
            bool[] needed=new bool[2];
            for(int i=current.Start;i<=current.End;i++) needed[notes[i].Color]=true;
            for(int c=0;c<2;c++) if(needed[c]) runner.Hands[c]=session.PracticeHand(c,runner.Rig);
            runner.Cursor[0]=runner.Cursor[1]=current.Start;
            runner.Time=Mathf.Max(session.PracticeStart,notes[current.Start].Time-.75f);
            runner.End=notes[current.End].Time+.2f;
            status.Phase=current.Final ? "Validating real-speed timing..." :
                current.Candidate==0 ? "Building movement phrases..." : "Practicing difficult sections...";
        }

        private void AdvanceOne()
        {
            float dt=current.Dt;
            runner.Time+=dt; runner.Steps++;
            simulatedSeconds+=dt;
            if (current.Final) finalDone++; else practiceDone++;
            float t=runner.Time;
            TrackedNote focus=notes[Mathf.Min(current.End,runner.Cursor[0])];
            for(int i=current.Start;i<=current.End;i++) if(notes[i].Time>=t)
            { focus=notes[i]; break; }
            runner.Rig.Tick(t,focus.Center,focus.Behavior,dt);
            for(int color=0;color<2;color++)
            {
                Hand hand=runner.Hands[color]; if(hand==null) continue;
                int cursor=runner.Cursor[color];
                while(cursor<=current.End && (notes[cursor].Color!=color ||
                    t>notes[cursor].HitTime+session.FollowDuration(notes[cursor],NextColor(cursor,color))+.006f)) cursor++;
                runner.Cursor[color]=cursor;
                TrackedNote target=cursor<=current.End && notes[cursor].Color==color ? notes[cursor] : null;
                if (target!=null && t<target.Time-1.45f*target.Behavior.Anticipation) target=null;
                if(target!=hand.Target) {hand.Target=target;hand.TargetChanged=true;}
                if(MovementPlanner.NeedsPlan(hand,t,runner.Rig))
                {
                    var future=new List<TrackedNote>();
                    for(int i=current.Start;i<=current.End;i++)
                    {
                        TrackedNote next=notes[i];if(next.Color!=color || next.HitTime<t-.03f) continue;
                        future.Add(next);if(future.Count>=session.Profile.LookAhead+2) break;
                    }
                    MovementPlanner.Plan(hand,runner.Rig,color,t,future,session.Profile);
                }
                Vector3 position;Quaternion rotation;
                MovementPlanner.Sample(hand,t,out position,out rotation);
                session.SimulatePose(hand,runner.Rig,color,target,position,rotation,dt,2100,t,false);
                // Evaluate each simultaneous note against the whole moving blade.
                for(int i=current.Start;i<=current.End;i++)
                {
                    TrackedNote note=notes[i];double hit=note.HitTime;
                    if(note.Color!=color || hit>t || runner.Evaluated.Contains(i)) continue;
                    runner.Evaluated.Add(i);Record(note,Quality(hand,note));
                }
            }
            if(t>=runner.End)
            {
                runner.Dispose();runner=null;current=null;afterRunner=true;
            }
        }
        private TrackedNote NextColor(int index,int color)
        { for(int i=index+1;i<notes.Count;i++) if(notes[i].Color==color) return notes[i]; return null; }
        private float Quality(Hand hand,TrackedNote note)
        {
            if(hand.Phrase==null)return 0;
            int color=note.Color;
            var geometry=new PhraseGeometry{Bottom=MovementPlanner.V(hand.LocalBladeBottom),Top=MovementPlanner.V(hand.LocalBladeTop),Grip=MovementPlanner.V(hand.LocalGrip),Forward=MovementPlanner.V(runner.Rig.Forward),Reach=runner.Rig.Reach,MinimumReach=runner.Rig.MinimumReach,
                ShoulderAt=delegate(double t){return MovementPlanner.V(runner.Rig.ShoulderAt(t,color));}};
            double hit=note.HitTime;
            return (float)PreparationContact.Quality(hand.Phrase.Sample,geometry,MovementPlanner.V(note.Center),MovementPlanner.V(note.Forward),MovementPlanner.V(note.Direction),hit,
                session.NoArrows || (note.Data!=null && note.Data.cutDirection==NoteCutDirection.Any));
        }
        private void Record(TrackedNote note,float quality)
        {
            if(current.Final)
            {
                validated++;scoreSum+=quality;
                PretrainedPlan plan;
                if(session.Learned.Pretrained==null)
                    session.Learned.Pretrained=new Dictionary<string,PretrainedPlan>();
                if(!session.Learned.Pretrained.TryGetValue(note.Key,out plan) || plan==null)
                    session.Learned.Pretrained[note.Key]=plan=new PretrainedPlan();
                Result result; best.TryGetValue(note.MapIndex,out result);
                plan.Confidence=result==null?0:quality; plan.Validations++;
                if(quality>=.35f && result!=null)
                {
                    plan.X=result.Plan.x;plan.Y=result.Plan.y;plan.Z=result.Plan.z;
                    plan.Variant=result.Variant;plan.MotionVersion=2;
                }
                session.MarkPretrained();
                return;
            }
            Result previous;
            if(!best.TryGetValue(note.MapIndex,out previous) || quality>previous.Score)
                best[note.MapIndex]=new Result {Plan=note.Plan,Score=quality,Variant=note.Variant};
        }

        private void UpdateStatus()
        {
            if(Done) return;
            status.Sections=sections.Count;status.Patterns=patterns;
            status.Pass=analyzed<source.Count ? "analysis" : passNumber+" / "+passCount+" ("+cachedSections+" cached sections)";
            status.Percent=analyzed<source.Count ? Mathf.FloorToInt(20f*analyzed/source.Count) :
                current!=null && current.Final || validated>0 ? 90+Mathf.Min(9,Mathf.FloorToInt(10f*finalDone/Mathf.Max(1,finalEstimate))) :
                20+Mathf.Min(69,Mathf.FloorToInt(70f*practiceDone/Mathf.Max(1,practiceTotal)));
            float mean=0;foreach(Result result in best.Values) mean+=result.Score;
            mean=best.Count==0?0:mean/best.Count;
            status.Confidence=best.Count==0?"unmeasured":Mathf.RoundToInt(mean*100)+"% simulated";
            status.Readiness=validated==0?"pending validation":Mathf.RoundToInt(100*scoreSum/validated)+"% simulated";
            if(analyzed<source.Count) return;
            status.SimulatedSpeed=(simulatedSeconds/Mathf.Max(.1f,(float)clock.Elapsed.TotalSeconds)).ToString("0.0")+"x compute throughput";
        }
        private void Complete()
        {
            // Do not certify passes that straddled an asynchronously loaded
            // human source. Legacy plans remain usable but cannot skip work.
            if(validated==notes.Count && sourceIdentity==session.Body.Motion.PreparationIdentity)
            {
                string signature=Signature();
                foreach(var p in session.Learned.Pretrained.Values)if(p!=null)p.PreparationSignature=null;
                foreach(var n in notes)
                {PretrainedPlan p;if(session.Learned.Pretrained.TryGetValue(n.Key,out p) && p!=null && p.MotionVersion==2 && p.Variant==n.Variant)p.PreparationSignature=signature;}
                session.MarkPretrained();
            }
            status.Percent=100;status.Phase="Ready.";Done=true;
            Plugin.Log.Info("Pre-song geometric practice: "+sections.Count+" sections, "+patterns+
                " difficult patterns, "+cachedSections+" cached sections, "+validated+" real-time validation samples, estimated quality "+
                (validated==0?"N/A":(scoreSum/validated).ToString("0.00"))+". Not actual cut outcomes.");
        }
        public void Dispose()
        { if(disposed)return;disposed=true;if(runner!=null)runner.Dispose();runner=null; }
    }
}
