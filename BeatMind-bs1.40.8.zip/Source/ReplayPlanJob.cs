using System;
using System.Collections.Generic;
using System.Diagnostics;
namespace SaberMind
{
    // Same ordered solver, advanced in small units on the Unity thread. No
    // worker accesses to live transforms, mutable replay tapes or graph clocks.
    public sealed class ReplayPlanJob : IDisposable
    {
        private IEnumerator<int> steps;
        public readonly MotionPhrase Result;
        public bool Done {get;private set;}
        public double TotalMilliseconds,PeakSliceMilliseconds;
        public int Slices;
        internal ReplayPlanJob(MotionPhrase result,IEnumerator<int> steps){Result=result;this.steps=steps;}
        public bool Advance(double milliseconds)
        {
            if(Done)return true;long start=Stopwatch.GetTimestamp();
            try
            {
                do{if(!steps.MoveNext()){Done=true;steps.Dispose();steps=null;break;}}
                while((Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency<milliseconds);
                return Done;
            }
            finally{double elapsed=(Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency;TotalMilliseconds+=elapsed;PeakSliceMilliseconds=Math.Max(PeakSliceMilliseconds,elapsed);Slices++;}
        }
        public void Dispose(){if(steps!=null){steps.Dispose();steps=null;}Done=true;}
    }
}
