using System;
using System.Collections.Generic;

namespace SaberMind
{
    // Ordered close contacts share one continuous wrist path. Coordinate
    // derivatives come from that path, not separate stop/start swing envelopes.
    // The caller fits contact frames/roll first; their q/time/grip stay exact.
    public sealed class ContinuousWristBurst
    {
        public readonly double Start,End;
        public double MaximumAngularSpeed {get;private set;}
        public bool Safe {get;private set;}
        public double PrepStart {get;private set;}
        public double ReleaseEnd {get;private set;}
        public readonly IList<PhraseState> AdjustedContacts;
        private readonly List<BoundedWristBridge> curves=new List<BoundedWristBridge>();
        private readonly MotionVector right,up,local;
        private readonly MotionRotation alignment;
        private readonly Coordinate first,last;
        private readonly bool bounded;
        private readonly double interiorMaximum,speedLimit;
        private SteadySwingEnvelope approach,release;
        private struct Coordinate
        {
            internal double Pitch,Side,Roll,PitchRate,SideRate,RollRate;
        }

        public ContinuousWristBurst(IList<PhraseState> contacts,PhraseGeometry geometry,double maximumSpeed=180)
        {
            if(contacts==null || contacts.Count<2)throw new ArgumentException("A wrist burst requires at least two ordered contacts.","contacts");
            if(geometry==null)throw new ArgumentNullException("geometry");
            if(!Finite(maximumSpeed) || maximumSpeed<=0)throw new ArgumentOutOfRangeException("maximumSpeed");
            int count=contacts.Count;var copies=new List<PhraseState>(count);
            var times=new double[count];var pitch=new double[count];var side=new double[count];var roll=new double[count];
            up=new MotionVector(0,1,0);var forward=new MotionVector(geometry.Forward.X,0,geometry.Forward.Z).Unit;
            if(forward.Length<.5)forward=new MotionVector(0,0,1);
            right=MotionVector.Cross(up,forward).Unit;local=(geometry.Top-geometry.Bottom).Unit;
            if(local.Length<.5)throw new ArgumentException("A nonzero local blade axis is required.","geometry");
            alignment=MotionRotation.FromTo(local,forward,up);
            bool safe=true;
            for(int i=0;i<count;i++)
            {
                var contact=contacts[i];if(contact==null || !Finite(contact.Time) || i>0 && contact.Time<=times[i-1])throw new ArgumentException("Burst contacts must have finite increasing times.","contacts");
                copies.Add(contact.Copy());times[i]=contact.Time;
                WristMotionLimits.Angles(contact.Rotation,geometry,out pitch[i],out side[i]);
                if(!WristMotionLimits.Contains(contact.Rotation,geometry))safe=false;
                var canonical=MotionRotation.Exp(right*(-pitch[i]))*MotionRotation.Exp(up*side[i])*alignment;
                var relative=canonical.Inverse*contact.Rotation.Unit;
                double angle=Wrap(2*Math.Atan2(MotionVector.Dot(relative.Vector,local),relative.W));
                roll[i]=i==0 ? angle : roll[i-1]+Wrap(angle-roll[i-1]);
            }
            Start=times[0];End=times[count-1];
            var pitchRate=Rates(times,pitch);var sideRate=Rates(times,side);var rollRate=Rates(times,roll);
            first=new Coordinate{Pitch=pitch[0],Side=side[0],Roll=roll[0],PitchRate=pitchRate[0],SideRate=sideRate[0],RollRate=rollRate[0]};
            int final=count-1;
            last=new Coordinate{Pitch=pitch[final],Side=side[final],Roll=roll[final],PitchRate=pitchRate[final],SideRate=sideRate[final],RollRate=rollRate[final]};
            for(int i=0;i<count;i++)
            {
                var pitchRotation=MotionRotation.Exp(right*(-pitch[i]));var rotatedUp=pitchRotation.Rotate(up);
                var blade=copies[i].Rotation.Unit.Rotate(local);
                var wp=right*(-pitchRate[i]);var ws=rotatedUp*sideRate[i];var wr=blade*rollRate[i];
                copies[i].AngularVelocity=wp+ws+wr;
                // Each coordinate has zero acceleration at every knot; the
                // transported world axes still contribute their exact jets.
                copies[i].AngularAcceleration=MotionVector.Cross(wp,ws)+MotionVector.Cross(wp+ws,wr);
                // These velocities already use the real contact timestamps.
                // A later wrist clock must not accelerate the burst a second time.
                copies[i].WristSpeedScale=Math.Max(1,geometry.SwingSpeedScale);
                copies[i].WristSource=null;
            }
            double peak=0;
            for(int i=0;i+1<count;i++)
            {
                var curve=new BoundedWristBridge(copies[i],copies[i+1],geometry);curves.Add(curve);
                if(!curve.Safe)safe=false;
                // A smooth analytic bridge is checked across its whole short
                // interval, including both contacts; no sampled pose is clamped.
                for(int step=0;step<=256;step++)peak=Math.Max(peak,curve.AngularSpeed(times[i]+(times[i+1]-times[i])*step/256));
            }
            interiorMaximum=peak;bounded=safe;speedLimit=maximumSpeed;
            MaximumAngularSpeed=peak;Safe=safe && Finite(peak) && peak<=maximumSpeed;
            PrepStart=Start;ReleaseEnd=End;
            AdjustedContacts=copies.AsReadOnly();
        }

        // Continue the same coordinate direction into and out of the burst.
        // Only the remote 18% ramps; the first/last contacts retain their exact
        // rate and acceleration even when pitch and roll axes are not parallel.
        public void SetApproachAndRelease(double preAvailable,double postAvailable)
        {
            if(!Finite(preAvailable) || preAvailable<0)throw new ArgumentOutOfRangeException("preAvailable");
            if(!Finite(postAvailable) || postAvailable<0)throw new ArgumentOutOfRangeException("postAvailable");
            double before=Duration(first,AdjustedContacts[0].AngularVelocity.Length,preAvailable,true,115);
            double after=Duration(last,AdjustedContacts[AdjustedContacts.Count-1].AngularVelocity.Length,postAvailable,false,75);
            PrepStart=Start-before;ReleaseEnd=End+after;
            approach=before>0 && PrepStart<Start ? new SteadySwingEnvelope(PrepStart,Start,Start+before,1) : null;
            release=after>0 && ReleaseEnd>End ? new SteadySwingEnvelope(End-after,End,ReleaseEnd,1) : null;
            double peak=interiorMaximum;
            for(int step=0;step<=256;step++)
            {
                if(approach!=null)peak=Math.Max(peak,OuterSpeed(first,approach,PrepStart+(Start-PrepStart)*step/256));
                if(release!=null)peak=Math.Max(peak,OuterSpeed(last,release,End+(ReleaseEnd-End)*step/256));
            }
            MaximumAngularSpeed=peak;Safe=bounded && Finite(peak) && peak<=speedLimit;
        }

        private static double Duration(Coordinate c,double angularSpeed,double available,bool before,double degrees)
        {
            const double radians=Math.PI/180;
            double result=available;
            if(angularSpeed>0)result=Math.Min(result,degrees*radians/(angularSpeed*SteadySwingEnvelope.TravelFraction));
            result=Math.Min(result,CoordinateDuration(c.Pitch,c.PitchRate,-40*radians,100*radians,before));
            result=Math.Min(result,CoordinateDuration(c.Side,c.SideRate,-45*radians,45*radians,before));
            return Math.Max(0,result);
        }
        private static double CoordinateDuration(double value,double rate,double minimum,double maximum,bool before)
        {
            double direction=before ? -rate : rate;
            if(direction==0)return double.PositiveInfinity;
            double travel=direction>0 ? maximum-value : value-minimum;
            return Math.Max(0,travel)/(Math.Abs(rate)*SteadySwingEnvelope.TravelFraction);
        }
        private PhraseState SampleOuter(Coordinate c,PhraseState contact,SteadySwingEnvelope envelope,double time)
        {
            double phase,rate,acceleration;envelope.Sample(time,out phase,out rate,out acceleration);
            var pitchRotation=MotionRotation.Exp(right*(-(c.Pitch+c.PitchRate*phase)));
            var rotatedUp=pitchRotation.Rotate(up);
            var canonical=pitchRotation*MotionRotation.Exp(up*(c.Side+c.SideRate*phase))*alignment;
            var blade=canonical.Rotate(local);var wp=right*(-c.PitchRate*rate);var ws=rotatedUp*(c.SideRate*rate);var wr=blade*(c.RollRate*rate);
            var result=contact.Copy();result.Time=time;
            result.Rotation=(canonical*MotionRotation.Exp(local*(c.Roll+c.RollRate*phase))).Unit;
            result.AngularVelocity=wp+ws+wr;
            result.AngularAcceleration=right*(-c.PitchRate*acceleration)+rotatedUp*(c.SideRate*acceleration)+MotionVector.Cross(wp,ws)+blade*(c.RollRate*acceleration)+MotionVector.Cross(wp+ws,wr);
            return result;
        }
        private static double OuterSpeed(Coordinate c,SteadySwingEnvelope envelope,double time)
        {
            double phase,rate,acceleration;envelope.Sample(time,out phase,out rate,out acceleration);
            double side=c.Side+c.SideRate*phase;
            return Math.Abs(rate)*Math.Sqrt(Math.Max(0,c.PitchRate*c.PitchRate+c.SideRate*c.SideRate+c.RollRate*c.RollRate-2*c.PitchRate*c.RollRate*Math.Sin(side)));
        }

        private static double[] Rates(double[] times,double[] values)
        {
            int count=times.Length;var slopes=new double[count-1];var rates=new double[count];
            for(int i=0;i+1<count;i++)slopes[i]=(values[i+1]-values[i])/(times[i+1]-times[i]);
            rates[0]=slopes[0];rates[count-1]=slopes[count-2];
            for(int i=1;i+1<count;i++)
            {
                double left=slopes[i-1],right=slopes[i];if(left*right<=0){rates[i]=0;continue;}
                double before=times[i]-times[i-1],after=times[i+1]-times[i];
                double harmonic=(before+after)/(before/left+after/right);
                // Monotone local slopes keep the coordinate control polygon
                // between adjacent contact angles without changing either angle.
                rates[i]=Math.Sign(left)*Math.Min(Math.Abs(harmonic),2*Math.Min(Math.Abs(left),Math.Abs(right)));
            }
            return rates;
        }
        public PhraseState Sample(double time)
        {
            if(time<Start && approach!=null)return SampleOuter(first,AdjustedContacts[0],approach,time);
            if(time>End && release!=null)return SampleOuter(last,AdjustedContacts[AdjustedContacts.Count-1],release,time);
            if(time<=Start){var firstPose=AdjustedContacts[0].Copy();firstPose.Time=time;return firstPose;}
            if(time>=End){var lastPose=AdjustedContacts[AdjustedContacts.Count-1].Copy();lastPose.Time=time;return lastPose;}
            int lo=0,hi=curves.Count;while(lo+1<hi){int mid=(lo+hi)/2;if(curves[mid].Start<=time)lo=mid;else hi=mid;}
            return curves[lo].Sample(time);
        }
        private static double Wrap(double angle)
        {while(angle>Math.PI)angle-=2*Math.PI;while(angle<=-Math.PI)angle+=2*Math.PI;return angle;}
        private static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    }
}
