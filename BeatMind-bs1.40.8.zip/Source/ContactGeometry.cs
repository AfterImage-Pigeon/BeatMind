using System;
namespace SaberMind
{
    // Refresh native jump geometry before deciding whether a published
    // contact remains valid. Lock the actual scoring stroke against late
    // controller animation while replacing approximate map poses early.
    public static class ContactGeometry
    {
        public const double LockAhead=.18,PositionTolerance=.055;
        public static MotionVector JumpCenter(MotionVector start,MotionVector end,double half,double gravity,double offset,double endDistanceOffset)
        {
            double elapsed=half+offset,progress=elapsed/(2*half),x=end.X;
            if(progress<.25 && start.X!=end.X)
            {
                double u=progress*4,e=u<.5 ? 2*u*u : 1-2*(1-u)*(1-u);
                x=start.X+(end.X-start.X)*e;
            }
            double z=start.Z+(end.Z-start.Z)*progress;
            if(progress>=.75){double u=(progress-.75)/.25;z-=endDistanceOffset*u*u*u;}
            return new MotionVector(x,start.Y+gravity*half*elapsed-.5*gravity*elapsed*elapsed,z);
        }
        public static bool NeedsRefit(PhraseState committed,double hit,MotionVector center,MotionVector direction,double now)
        {return Changed(committed,hit,center,direction,now) || committed!=null && committed.LimitedContact && hit-now>LockAhead;}
        public static bool Changed(PhraseState committed,double hit,MotionVector center,MotionVector direction,double now)
        {
            if(committed==null)return false;
            if(Math.Abs(committed.Time-hit)>.001)return true;
            bool directionChanged=committed.TargetDirection.Length>.5 && direction.Length>.5 && MotionVector.Dot(committed.TargetDirection.Unit,direction.Unit)<.996;
            return hit-now>LockAhead && ((committed.TargetCenter-center).Length>PositionTolerance || directionChanged);
        }
    }
    public static class MotionSampling
    {
        // Pose curves and their measured derivatives share the song clock.
        public static double Delta(double now,double previous,double fallback)
        {
            if(double.IsNaN(fallback) || double.IsInfinity(fallback) || fallback<=0)fallback=1.0/90;
            double delta=double.IsNaN(previous) ? fallback : now-previous;
            if(double.IsNaN(delta) || double.IsInfinity(delta) || delta<=0)delta=fallback;
            return Math.Max(.000001,delta);
        }
    }
}
