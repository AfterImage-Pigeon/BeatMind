using System;
using System.Collections.Generic;
namespace SaberMind
{
    // Mirrors the installed SaberMovementData / SaberSwingRating angle rules.
    // Scores world-space blade directions and swing planes, including grip
    // translation. Rotation about the blade itself earns no swing angle.
    public struct SwingScoreArc
    {
        public double BeforeDegrees,AfterDegrees,Start,End;
        public bool BeforeFull{get{return BeforeDegrees+1e-7>=BladeSwingScoring.BeforeFullDegrees;}}
        public bool AfterFull{get{return AfterDegrees+1e-7>=BladeSwingScoring.AfterFullDegrees;}}
    }
    public static class BladeSwingScoring
    {
        public const double BeforeFullDegrees=100,AfterFullDegrees=60,WindowSeconds=.4;
        // Native NoteData.ScoringType values (replay ID prefixes subtract 2).
        public static bool RequiresBefore(int type){return type==1 || type==2 || type==4;}
        public static bool RequiresAfter(int type){return type==1 || type==3;}
        public static SwingScoreArc Measure(Func<double,PhraseState> sample,PhraseGeometry geometry,double contactTime,int sampleRate=240)
        {SwingScoreArc result=new SwingScoreArc();foreach(int step in MeasureSteps(sample,geometry,contactTime,sampleRate,delegate(SwingScoreArc score){result=score;})){}return result;}
        // Each native scoring probe is a separate planning work item. One
        // MoveNext used to sample up to 97 full reach/replay poses, so a
        // nominal 0.9 ms planning slice could not yield during that work.
        internal static IEnumerable<int> MeasureSteps(Func<double,PhraseState> sample,PhraseGeometry geometry,double contactTime,int sampleRate,Action<SwingScoreArc> publish)
        {
            if(sample==null || geometry==null)throw new ArgumentNullException();
            if(sampleRate!=120 && sampleRate!=240)throw new ArgumentOutOfRangeException("sampleRate");
            double step=1.0/sampleRate;int count=sampleRate*2/5;
            var contact=Blade(sample(contactTime),geometry);
            yield return 0;
            var previous=Blade(sample(contactTime-step),geometry);
            yield return 0;
            MotionVector cutNormal=Normal(contact,previous);
            var result=new SwingScoreArc{Start=double.NaN,End=double.NaN};
            var current=contact;
            for(int i=1;i<=count;i++)
            {
                double difference=Angle(Normal(current,previous),cutNormal);
                if(difference>90)break;
                result.BeforeDegrees+=Angle(previous.Direction,current.Direction)*NormalWeight(difference);
                // Use the enclosing sample boundary so reserving this arc
                // retains at least the required scoring travel.
                if(double.IsNaN(result.Start) && result.BeforeFull)result.Start=contactTime-i*step;
                current=previous;
                if(i<count)previous=Blade(sample(contactTime-(i+1)*step),geometry);
                yield return 0;
            }
            previous=contact;
            for(int i=1;i<=count;i++)
            {
                current=Blade(sample(contactTime+i*step),geometry);
                double difference=Angle(Normal(current,previous),cutNormal);
                if(difference>90)break;
                result.AfterDegrees+=Angle(previous.Direction,current.Direction)*NormalWeight(difference);
                if(double.IsNaN(result.End) && result.AfterFull)result.End=contactTime+i*step;
                previous=current;
                yield return 0;
            }
            publish(result);
        }
        public static double NormalWeight(double normalDifferenceDegrees)
        {return 1-MotionPhrase.Clamp((normalDifferenceDegrees-75)/15,0,1);}
        private struct BladePose
        {internal MotionVector Top,Bottom;internal MotionVector Direction{get{return Top-Bottom;}}}
        private static BladePose Blade(PhraseState s,PhraseGeometry g)
        {return new BladePose{Top=s.Grip+s.Rotation.Rotate(g.Top-g.Grip),Bottom=s.Grip+s.Rotation.Rotate(g.Bottom-g.Grip)};}
        private static MotionVector Normal(BladePose current,BladePose previous)
        {
            var normal=MotionVector.Cross(current.Direction,(previous.Top+previous.Bottom)*.5-current.Bottom);
            double magnitude=normal.Length;
            return magnitude>1e-5 ? normal/magnitude : new MotionVector();
        }
        private static double Angle(MotionVector a,MotionVector b)
        {
            double denominator=Math.Sqrt(MotionVector.Dot(a,a)*MotionVector.Dot(b,b));
            // UnityEngine.Vector3.Angle treats a zero direction/normal as zero.
            if(denominator<1e-15)return 0;
            return Math.Acos(MotionPhrase.Clamp(MotionVector.Dot(a,b)/denominator,-1,1))*180/Math.PI;
        }
    }
}
