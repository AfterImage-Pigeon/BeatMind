using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace SaberMind
{
    public sealed class ReplayPose
    {
        public float X, Y, Z, Qx, Qy, Qz, Qw;
    }
    public sealed class ReplayFrame
    {
        public float Time;
        public ReplayPose Head, Left, Right;
    }
    public sealed class ReplayChoice
    {
        public int Variant;
        public float[] Behavior;
        public int CutScore;
        public bool Good;
    }
    public sealed class BestReplay
    {
        public int Format = 1;
        public string Identity, Model;
        public MeasuredRun Result;
        public List<ReplayFrame> Frames = new List<ReplayFrame>();
        public Dictionary<string,ReplayChoice> Decisions = new Dictionary<string,ReplayChoice>();
        public ReplayPose Pose(float time, int side)
        {
            if (Frames == null || Frames.Count == 0) return null;
            int lo = 0, hi = Frames.Count - 1;
            while (lo < hi) { int mid = (lo + hi) / 2; if (Frames[mid].Time < time) lo = mid + 1; else hi = mid; }
            int a = Math.Max(0, lo - 1), b = lo;
            ReplayPose pa = Select(Frames[a], side), pb = Select(Frames[b], side);
            if (pa == null) return pb;
            if (pb == null) return pa;
            if (a == b) return pb;
            float t = Math.Max(0, Math.Min(1, (time - Frames[a].Time) / Math.Max(.001f, Frames[b].Time - Frames[a].Time)));
            float dot = pa.Qx * pb.Qx + pa.Qy * pb.Qy + pa.Qz * pb.Qz + pa.Qw * pb.Qw;
            float sign = dot < 0 ? -1 : 1;
            var p = new ReplayPose { X = L(pa.X,pb.X,t), Y = L(pa.Y,pb.Y,t), Z = L(pa.Z,pb.Z,t),
                Qx = L(pa.Qx,pb.Qx*sign,t), Qy = L(pa.Qy,pb.Qy*sign,t),
                Qz = L(pa.Qz,pb.Qz*sign,t), Qw = L(pa.Qw,pb.Qw*sign,t) };
            float n = (float)Math.Sqrt(p.Qx*p.Qx+p.Qy*p.Qy+p.Qz*p.Qz+p.Qw*p.Qw);
            if (n > .0001f) { p.Qx/=n; p.Qy/=n; p.Qz/=n; p.Qw/=n; }
            return p;
        }
        private static float L(float a,float b,float t) { return a+(b-a)*t; }
        private static ReplayPose Select(ReplayFrame f,int side) { return side==0 ? f.Head : side==1 ? f.Left : f.Right; }
    }
    public sealed class ReplayStore
    {
        private readonly string directory;
        public ReplayStore(string directory) { this.directory = directory; }
        public string FileFor(string identity,string model)
        {
            using (SHA256 hash = SHA256.Create())
                return Path.Combine(directory,BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(identity+"|"+model)))
                    .Replace("-","").ToLowerInvariant()+".replay.gz");
        }
        public BestReplay Load(string identity,string model)
        {
            string path=FileFor(identity,model); if(!File.Exists(path)) return null;
            using(var input=File.OpenRead(path)) using(var gzip=new GZipStream(input,CompressionMode.Decompress))
            using(var reader=new StreamReader(gzip))
            {
                BestReplay result=JsonConvert.DeserializeObject<BestReplay>(reader.ReadToEnd());
                if(result==null || result.Format!=1 || result.Identity!=identity || result.Model!=model ||
                    result.Result==null || result.Result.Maximum<=0 || result.Frames==null || result.Frames.Count==0)
                    throw new InvalidDataException("Best replay has an unsupported format or identity.");
                return result;
            }
        }
        public bool SaveIfBetter(BestReplay candidate)
        {
            if(candidate==null || candidate.Result==null || candidate.Frames==null || candidate.Frames.Count<2 ||
                candidate.Result.Maximum<=0 || candidate.Result.RawScore<0) return false;
            BestReplay previous=Load(candidate.Identity,candidate.Model);
            if(previous!=null && candidate.Result.RawScore<=previous.Result.RawScore) return false;
            Directory.CreateDirectory(directory);
            string path=FileFor(candidate.Identity,candidate.Model), temp=path+".tmp";
            using(var output=File.Create(temp)) using(var gzip=new GZipStream(output,CompressionMode.Compress))
            using(var writer=new StreamWriter(gzip)) writer.Write(JsonConvert.SerializeObject(candidate));
            if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path);
            return true;
        }
    }
}
