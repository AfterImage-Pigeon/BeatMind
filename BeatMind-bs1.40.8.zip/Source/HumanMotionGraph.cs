using System;
using System.Collections.Generic;
using System.Threading;
namespace SaberMind
{
    public sealed class HumanRunHandle
    {public volatile HumanTape Tape;public volatile string Status="Loading the best matching human run...";}
    public static class HumanReplayPreparation
    {
        private static readonly object gate=new object();
        private static readonly object loadGate=new object();
        private static readonly Dictionary<string,HumanRunHandle> runs=new Dictionary<string,HumanRunHandle>();
        private static readonly Queue<string> order=new Queue<string>();
        public static HumanRunHandle Request(HumanMotionModel model,string hash,string difficulty,string mode,Action<string> warning)
        {return Request(model,hash,difficulty,mode,warning,null);}
        public static HumanRunHandle Request(HumanMotionModel model,string hash,string difficulty,string mode,Action<string> warning,Action waitForIdle)
        {
            if(model==null)return new HumanRunHandle{Status="Using the learned motion graph."};
            string key=hash+"|"+difficulty+"|"+mode+"|"+model.Fingerprint+"|"+model.TrainingFingerprint;
            lock(gate)
            {
                HumanRunHandle existing;if(runs.TryGetValue(key,out existing))return existing;
                var handle=new HumanRunHandle();runs[key]=handle;order.Enqueue(key);while(order.Count>3)runs.Remove(order.Dequeue());
                var sources=new List<HumanRecording>();foreach(var r in model.Recordings)if(string.Equals(r.Hash,hash,StringComparison.OrdinalIgnoreCase) && string.Equals(r.Difficulty,difficulty,StringComparison.OrdinalIgnoreCase) && string.Equals(r.Mode,mode,StringComparison.OrdinalIgnoreCase))sources.Add(r);
                sources.Sort(delegate(HumanRecording a,HumanRecording b){return b.Accuracy.CompareTo(a.Accuracy);});
                if(sources.Count==0){handle.Status="No exact-map human run; using learned pattern motion.";return handle;}
                ThreadPool.QueueUserWorkItem(delegate
                {
                    // Several quick map selections must not decode several
                    // full recordings concurrently. A superseded queued load
                    // has no consumer, so discard it before opening its file.
                    lock(loadGate)
                    {
                        lock(gate){HumanRunHandle current;if(!runs.TryGetValue(key,out current) || !Object.ReferenceEquals(current,handle))return;}
                        foreach(var r in sources)try
                        {
                            var replay=HumanReplayLibrary.Read(r.Path,waitForIdle);HumanMotionTraining.RequireEligible(replay,r.Path);
                            if(replay.Frames.Count>HumanMotionTraining.MaximumLearningPoseSamples)
                                throw new System.IO.InvalidDataException("Full recording exceeds the "+HumanMotionTraining.MaximumLearningPoseSamples.ToString("N0")+" tracking-frame budget; using learned pattern motion.");
                            string identity=HumanMotionTraining.Digest(replay.PlayerId+"|"+replay.Timestamp+"|"+replay.Hash+"|"+replay.Difficulty+"|"+replay.Mode+"|"+replay.Score);
                            if(identity!=r.Identity)throw new System.IO.InvalidDataException("The indexed human recording changed.");
                            var tape=HumanTape.FromReplay(replay,r.Identity,waitForIdle);
                            lock(gate)
                            {
                                HumanRunHandle current;if(!runs.TryGetValue(key,out current) || !Object.ReferenceEquals(current,handle))return;
                                handle.Tape=tape;TrimRetainedRuns(key);
                            }
                            handle.Status="Full human run: "+(r.Accuracy*100).ToString("0.00")+"%";return;
                        }
                        catch(Exception e){if(warning!=null)warning("Human recording: "+e.Message);}
                        handle.Status="Matching recording unavailable; using learned pattern motion.";
                    }
                });return handle;
            }
        }
        private static void TrimRetainedRuns(string keep)
        {
            HumanRunHandle newest;
            if(runs.TryGetValue(keep,out newest) && newest.Tape!=null && newest.Tape.Times.Length>HumanMotionTraining.MaximumLearningPoseSamples)
            {newest.Tape=null;newest.Status="Full recording exceeds the tracking budget; using learned pattern motion.";}
            long count=0;foreach(var h in runs.Values)if(h.Tape!=null)count+=h.Tape.Times.Length;
            while(count>HumanMotionTraining.MaximumLearningPoseSamples && order.Count>0)
            {
                string oldest=order.Dequeue();HumanRunHandle h;
                if(oldest==keep){order.Enqueue(oldest);break;}
                if(runs.TryGetValue(oldest,out h)){if(h.Tape!=null)count-=h.Tape.Times.Length;runs.Remove(oldest);}
            }
        }
    }
    // A single controller chooses motion for the head and BOTH hands. Pattern
    // context, outgoing derivatives and source sequence condition each choice.
    public sealed class HumanMotionGraph
    {
        private sealed class Span
        {
            internal double Start,End,SourceEnd;internal int Source;internal HumanPhase Phase;
            internal HumanEventAlignment Alignment;
            internal readonly MotionPhrase[] Paths={new MotionPhrase(),new MotionPhrase(),new MotionPhrase()};
            internal readonly MotionTransition[] Settles=new MotionTransition[3];
            internal readonly MotionTransition[] PreRolls=new MotionTransition[3];
        }
        private readonly HumanMotionModel model;private readonly HumanChartNote[] chart;
        private readonly HumanTape[] examples;
        private readonly HumanEventAlignment.PreparedSource[] sourceEvents;
        private readonly HumanRunHandle handle;private readonly List<HumanRegion> regions;
        private readonly List<Span> spans=new List<Span>();private readonly Queue<int> recent=new Queue<int>();
        private readonly Dictionary<HumanRegion,Span> gestures=new Dictionary<HumanRegion,Span>();
        private readonly HashSet<int> usedNonPlayingSources=new HashSet<int>();
        private readonly int effort;private HumanTape exact,examined;private MotionPhrase timeWarp;
        private double exactSwitch=double.PositiveInfinity;private readonly MotionTransition[] switchCurves=new MotionTransition[3];
        private Func<double,int,PhraseState> switchPrevious;
        private bool frameKnown;private double frameTime;
        public int Searches,Choices,ExactSamples,GraphSamples,Revision;public bool ExactMap {get{return exact!=null;}}
        public string Status {get{return handle==null ? "Learned motion graph" : handle.Status;}}
        public string PreparationIdentity {get{return (model==null ? "no-human-library" : model.Fingerprint+"|"+model.TrainingFingerprint+"|"+model.ContextWeight.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+"|"+model.BoundaryWeight.ToString("R",System.Globalization.CultureInfo.InvariantCulture))+"|"+(handle==null ? "no-exact-run" : handle.Tape==null ? handle.Status : handle.Tape.Recording);}}
        public HumanMotionGraph(HumanMotionModel model,HumanChartNote[] chart,HumanRunHandle handle,int effort)
        {
            this.model=model;this.chart=chart;this.handle=handle;this.effort=effort;
            examples=new HumanTape[model==null ? 0 : model.Examples.Count];sourceEvents=new HumanEventAlignment.PreparedSource[examples.Length];
            double last=chart.Length==0 ? 0 : chart[chart.Length-1].Time;
            regions=HumanMotionRegions.Build(chart,-3,last+120);
            // The learnt phase labels stay unchanged. Playback reserves the
            // same preparation lead used after breaks, so an opening pose
            // never has to jump into an unrelated playing pose in 180 ms.
            if(chart.Length>0)for(int i=0;i+1<regions.Count;i++)
                if(regions[i].Phase==HumanPhase.Opening && regions[i+1].Phase==HumanPhase.Playing)
                {double boundary=Math.Max(regions[i].Start,Math.Min(regions[i].End,chart[0].Time-.65));regions[i].End=boundary;regions[i+1].Start=boundary;break;}
        }
        private HumanTape ExampleTape(int index)
        {return examples[index] ?? (examples[index]=HumanTape.FromExample(model.Examples[index]));}
        public HumanPhase Phase(double time)
        {foreach(var r in regions)if(time>=r.Start && time<r.End)return r.Phase;return time<0 ? HumanPhase.Opening : HumanPhase.Ending;}
        // Playback owns this clock. Sampling a future contact must never move
        // the adoption boundary or evict motion that is still on screen.
        public void BeginFrame(double time){frameTime=time;frameKnown=true;TryAdopt(time);}
        public void PrepareUntil(double time)
        {
            // Keep the playback epoch at the beginning while preparing. This
            // prevents future look-ahead from evicting routes not yet displayed.
            BeginFrame(0);Sample(time,0);
        }
        private static PhraseState Rest(double time,int joint)
        {
            var s=new PhraseState{Time=time,Grip=joint==0 ? new MotionVector(0,1.7,0) : new MotionVector(joint==1 ? -.3 : .3,1.2,.28)};
            if(joint>0)s.Rotation=MotionRotation.Exp(new MotionVector(.55,0,0));return s;
        }
        public PhraseState Sample(double time,int joint)
        {
            if(!frameKnown)TryAdopt(time);
            if(exact!=null)
            {
                ExactSamples++;if(time<exactSwitch)return time<exactSwitch-.24 && switchPrevious!=null ? switchPrevious(time,joint) : switchCurves[joint].Sample(time);
                return ExactSample(time,joint);
            }
            GraphSamples++;return GraphSample(time,joint);
        }
        private void TryAdopt(double time)
        {
            if(exact==null && handle!=null && handle.Tape!=null && !Object.ReferenceEquals(examined,handle.Tape))
            {
                examined=handle.Tape;var warp=Align(handle.Tape,chart);
                if(warp!=null)
                {
                    exact=handle.Tape;timeWarp=warp;
                    if(spans.Count==0)exactSwitch=double.NegativeInfinity;
                    else
                    {
                        double adoption=frameKnown ? frameTime : EarliestCachedTime(time);
                        exactSwitch=adoption+.24;
                        switchPrevious=CaptureGraph(adoption-.75,adoption);
                        for(int j=0;j<3;j++){var a=switchPrevious(adoption,j);var b=ExactSample(exactSwitch,j);switchCurves[j]=new MotionTransition(a,b);}
                    }
                    Revision++;
                }
                else handle.Status="Replay/chart mismatch; using learned pattern motion.";
            }
        }
        private double EarliestCachedTime(double requested)
        {return spans.Count==0 ? Math.Min(0,requested) : spans[0].Start;}
        private PhraseState ExactSample(double time,int joint)
        {return SampleExact(exact,timeWarp,time,joint);}
        private static PhraseState SampleExact(HumanTape exact,MotionPhrase timeWarp,double time,int joint)
        {
            PhraseState clock=timeWarp.Sample(time);var s=exact.Sample(clock.Grip.X,joint);
            double speed=clock.Velocity.X;
            // Extend the clock at either end instead of freezing openings and
            // the captured post-song gesture at the first/last note anchor.
            if(time<=timeWarp.Knots[0].Time){clock.Grip.X=time+timeWarp.Knots[0].Grip.X-timeWarp.Knots[0].Time;speed=1;s=exact.Sample(clock.Grip.X,joint);}
            else if(time>=timeWarp.Knots[timeWarp.Knots.Count-1].Time){var k=timeWarp.Knots[timeWarp.Knots.Count-1];clock.Grip.X=time+k.Grip.X-k.Time;speed=1;s=exact.Sample(clock.Grip.X,joint);}
            s.Acceleration=s.Acceleration*(speed*speed)+s.Velocity*clock.Acceleration.X;s.Velocity*=speed;
            s.AngularAcceleration=s.AngularAcceleration*(speed*speed)+s.AngularVelocity*clock.Acceleration.X;s.AngularVelocity*=speed;
            s.Time=time;s.HumanSource=0;s.HumanGripWeight=s.HumanWristWeight=1;return s;
        }
        // A plan retains its source recording and route references. Later
        // graph look-ahead or adoption of a newly loaded exact recording must
        // not change the teacher beneath its existing contact corrections.
        public Func<double,int,PhraseState> Capture(double start,double end)
        {
            if(end<start)throw new ArgumentException("Motion capture interval is reversed.");
            if(!frameKnown)TryAdopt(start);
            if(exact==null)return CaptureGraph(start,end);
            HumanTape recording=exact;MotionPhrase clock=timeWarp;double boundary=exactSwitch;
            var transitions=(MotionTransition[])switchCurves.Clone();var previous=switchPrevious;
            return delegate(double t,int j)
            {if(t<boundary)return t<boundary-.24 && previous!=null ? previous(t,j) : transitions[j].Sample(t);return SampleExact(recording,clock,t,j);};
        }
        public Func<double,PhraseState> Capture(double start,double end,int joint)
        {var all=Capture(start,end);return delegate(double t){return all(t,joint);};}
        private Func<double,int,PhraseState> CaptureGraph(double start,double end)
        {
            if(model==null || model.Examples.Count==0)return delegate(double t,int j){return Rest(t,j);};
            GraphSample(start,0);GraphSample(end,0);
            // A three-second contact plan must not retain every span prepared
            // for a whole song. Include nearby boundary-probe context while
            // freezing only this plan's interval; the graph still owns its
            // complete prepared playback and all requested samples are exact.
            double from=start-1,to=end+1;var frozen=new List<Span>();
            foreach(var s in spans)if(s.End>=from && s.Start<=to)frozen.Add(s);
            foreach(var s in gestures.Values)if(s.End>=from && s.Start<=to && !frozen.Contains(s))frozen.Add(s);
            if(frozen.Count==0)frozen.Add(spans[spans.Count-1]);
            frozen.Sort(delegate(Span a,Span b){return a.Start.CompareTo(b.Start);});
            foreach(var s in frozen)if(s.Phase==HumanPhase.Ending || s.Phase==HumanPhase.Celebration)
                for(int j=0;j<3;j++)EndingSettle(s,j);
            var first=frozen[0];var preRoll=new MotionTransition[3];for(int j=0;j<3;j++)preRoll[j]=PreRoll(first,j);
            return delegate(double t,int j)
            {
                PhraseState value;
                if(t<first.Start)value=preRoll[j].Sample(t);
                else
                {
                    Span chosen=frozen[frozen.Count-1];
                    foreach(var s in frozen)if(t>=s.Start && t<s.End){chosen=s;break;}
                    value=t>=chosen.End && (chosen.Phase==HumanPhase.Ending || chosen.Phase==HumanPhase.Celebration)
                        ? chosen.Settles[j].Sample(Math.Min(t,chosen.End+.60)) : chosen.Paths[j].Sample(t);
                }
                // Every selected path/settle sample already owns a fresh pose.
                // Keep that caller-owned result instead of cloning it again.
                value.Time=t;return value;
            };
        }
        public MotionVector ObservedDotDirection(double time,int hand)
        {
            if(exact==null)return new MotionVector();int first=HumanContext.Lower(exact.Notes,time-.16);
            HumanChartNote best=null;double error=.16;
            for(int i=first;i<exact.Notes.Length && exact.Notes[i].Time<=time+.16;i++)
            {var n=exact.Notes[i];double d=Math.Abs(n.Time-time);if(n.Hand==hand && n.Direction==8 && d<error){best=n;error=d;}}
            if(best==null)return new MotionVector();var v=best.ObservedCutDirection;v.Z=0;return v.Unit;
        }
        public static MotionPhrase Align(HumanTape tape,IList<HumanChartNote> chart)
        {
            var pairs=new List<PhraseState>();int cursor=0,matched=0;
            foreach(var n in chart)
            {
                while(cursor<tape.Notes.Length && tape.Notes[cursor].Time<n.Time-.16)cursor++;
                HumanChartNote best=null;double distance=.16;
                for(int i=cursor;i<tape.Notes.Length && tape.Notes[i].Time<n.Time+.16;i++)
                {var h=tape.Notes[i];double d=Math.Abs(h.Time-n.Time);if(h.Hand==n.Hand && h.Lane==n.Lane && h.Layer==n.Layer && (n.Direction==8 || h.Direction==n.Direction) && d<distance){best=h;distance=d;}}
                if(best==null)continue;matched++;
                if(pairs.Count>0 && n.Time-pairs[pairs.Count-1].Time<.006){var prior=pairs[pairs.Count-1];prior.Grip.X=(prior.Grip.X+best.Time)*.5;continue;}
                pairs.Add(new PhraseState{Time=n.Time,Grip=new MotionVector(best.Time,0,0)});
            }
            if(chart.Count<2 || matched<chart.Count*.90 || pairs.Count<2)return null;
            var warp=new MotionPhrase();
            for(int i=0;i<pairs.Count;i++)
            {
                var s=pairs[i];double left=i==0 ? 1 : (s.Grip.X-pairs[i-1].Grip.X)/(s.Time-pairs[i-1].Time),right=i+1==pairs.Count ? 1 : (pairs[i+1].Grip.X-s.Grip.X)/(pairs[i+1].Time-s.Time);
                if(left<.6 || left>1.6 || right<.6 || right>1.6)return null;
                s.Velocity=new MotionVector(2*left*right/(left+right),0,0);warp.Knots.Add(s);
            }
            return warp;
        }
        private PhraseState GraphSample(double time,int joint)
        {
            if(model==null || model.Examples.Count==0)return Rest(time,joint);
            foreach(var gesture in gestures.Values)if(time>=gesture.Start && time<gesture.End)return gesture.Paths[joint].Sample(time);
            foreach(var s in spans)if(time>=s.Start && time<s.End)return s.Paths[joint].Sample(time);
            double epoch=frameKnown ? Math.Max(0,frameTime) : 0;
            if(spans.Count==0 && time<epoch){GraphSample(epoch,joint);return BeforeFirst(time,joint);}
            if(spans.Count>0 && time<spans[0].Start)return BeforeFirst(time,joint);
            double start=spans.Count==0 ? epoch : spans[spans.Count-1].End;
            while(start<=time)
            {
                HumanPhase phase=Phase(start);HumanRegion region=null;foreach(var r in regions)if(start>=r.Start && start<r.End){region=r;break;}
                Span savedGesture;
                if(region!=null && gestures.TryGetValue(region,out savedGesture))
                {spans.Add(savedGesture);start=savedGesture.End;continue;}
                // One captured ending/celebration per run, then hold its last
                // relaxed pose. A victory gesture must never loop endlessly.
                if((phase==HumanPhase.Ending || phase==HumanPhase.Celebration) && spans.Count>0 && spans[spans.Count-1].Phase==phase)
                {
                    var last=spans[spans.Count-1];
                    var hold=EndingSettle(last,joint).Sample(Math.Min(time,last.End+.60));hold.Time=time;return hold;
                }
                double duration=phase==HumanPhase.Playing ? 1.25 : 2.0;
                if(region!=null)duration=Math.Min(duration,region.End-start);duration=Math.Max(.1,duration);
                double[] context=HumanContext.Describe(chart,start,duration,phase);
                Span prior=spans.Count==0 ? null : spans[spans.Count-1];HumanEventAlignment alignment;
                int selected=Select(phase,context,prior,start,duration,out alignment);
                if(selected<0)
                {
                    // Missing demonstrations are an idle interval, not a
                    // reason to restart graph generation at the opening on
                    // every future request or borrow a different phase.
                    var idle=new Span{Start=start,End=phase==HumanPhase.Playing ? Math.Min(start+.35,region==null ? start+duration : region.End) : region==null ? start+duration : region.End,Source=-1,Phase=phase};
                    for(int j=0;j<3;j++)
                    {
                        var a=prior==null ? Rest(start,j) : prior.Paths[j].Sample(start);a.HumanSource=-1;a.HumanGripWeight=a.HumanWristWeight=0;var b=a.Copy();
                        b.Time=Math.Min(idle.End,start+.60);b.Grip+=a.Velocity.Limited(.5)*.05;
                        b.Rotation=MotionRotation.Exp(a.AngularVelocity.Limited(1.5)*.05)*a.Rotation;
                        b.Velocity=b.Acceleration=b.AngularVelocity=b.AngularAcceleration=new MotionVector();
                        var settle=new MotionTransition(a,b);var held=b.Copy();idle.Paths[j].Knots.Add(a);idle.Paths[j].Knots.Add(b);
                        idle.Paths[j].Evaluator=delegate(double t){if(t<b.Time)return settle.Sample(t);var s=held.Copy();s.Time=t;return s;};
                    }
                    spans.Add(idle);if(region!=null && phase!=HumanPhase.Playing)gestures[region]=idle;start=idle.End;continue;
                }
                var e=model.Examples[selected];duration=alignment==null ? Math.Min(e.Duration,region==null ? duration : Math.Max(.02,region.End-start)) : alignment.DestinationEnd-start;var tape=ExampleTape(selected);double rate=1;
                bool oneGesture=phase!=HumanPhase.Playing;
                double spanEnd=start+duration;
                if(oneGesture)
                {
                    // Each non-playing region owns one captured gesture. Play it
                    // once at recorded speed, crop if notes arrive early,
                    // then settle until the next note preparation region.
                    spanEnd=region==null ? spanEnd : region.End;
                    duration=Math.Min(e.Duration,Math.Max(.02,spanEnd-start));rate=1;
                }
                var span=new Span{Start=start,End=spanEnd,SourceEnd=alignment==null ? duration : alignment.SourceEnd,Alignment=alignment,Source=selected,Phase=phase};
                for(int j=0;j<3;j++)
                {
                    PhraseState seed=prior==null ? null : prior.Paths[j].Sample(start);
                    // Aligned paths evaluate the original recording continuously.
                    // Only their endpoint metadata is needed by MotionPhrase.
                    int points=alignment==null ? 128 : 1;
                    for(int p=0;p<=points;p++)
                    {
                        double t=start+duration*p/points;var s=alignment==null ? tape.Sample(duration*p/points*rate,j) : alignment.Sample(tape,t,j);s.Time=t;s.Velocity*=rate;s.Acceleration*=rate*rate;s.AngularVelocity*=rate;s.AngularAcceleration*=rate*rate;s.HumanSource=selected;s.HumanGripWeight=s.HumanWristWeight=1;
                        span.Paths[j].Knots.Add(s);
                    }
                    if(alignment!=null)
                    {
                        // Keep the original continuous recording and clock;
                        // resampling a longer destination span into 129 targets
                        // would discard sub-frame wrist/contact context.
                        int capturedJoint=j;var clock=alignment;int source=selected;
                        span.Paths[j].Evaluator=delegate(double t){var s=clock.Sample(tape,t,capturedJoint);s.HumanSource=source;s.HumanGripWeight=s.HumanWristWeight=1;return s;};
                    }
                    if(seed!=null)
                    {
                        seed.Time=start;double joinDuration=JoinDuration(phase,prior,start,duration);
                        double joinEnd=start+joinDuration;var recordedPath=span.Paths[j];
                        var target=recordedPath.Sample(joinEnd);var bridge=new MotionTransition(seed,target);
                        var joined=new MotionPhrase();joined.Knots.AddRange(recordedPath.Knots);
                        joined.Evaluator=delegate(double t){return t<joinEnd ? bridge.Sample(t) : recordedPath.Sample(t);};span.Paths[j]=joined;
                    }
                    if(oneGesture && spanEnd>start+duration+.001)
                    {
                        var captured=span.Paths[j];var a=captured.Sample(start+duration);var b=a.Copy();
                        b.Time=Math.Min(spanEnd,a.Time+.60);b.Grip+=a.Velocity.Limited(.5)*.05;
                        b.Rotation=MotionRotation.Exp(a.AngularVelocity.Limited(1.5)*.05)*a.Rotation;
                        b.Velocity=b.Acceleration=b.AngularVelocity=b.AngularAcceleration=new MotionVector();
                        var settle=new MotionTransition(a,b);var held=b.Copy();
                        var once=new MotionPhrase();once.Knots.AddRange(captured.Knots);
                        once.Evaluator=delegate(double t){if(t<=a.Time)return captured.Sample(t);if(t<b.Time)return settle.Sample(t);var s=held.Copy();s.Time=t;return s;};span.Paths[j]=once;
                    }
                }
                spans.Add(span);
                if(oneGesture){usedNonPlayingSources.Add(selected);if(region!=null)gestures[region]=span;}
                // Retain a time horizon, not eight clips: short source fragments
                // otherwise let a future planning request evict the motion that
                // is currently displayed, causing it to be selected again.
                double eviction=frameKnown ? Math.Min(span.End-8,frameTime-1) : span.End-8;
                while(spans.Count>1 && spans[0].End<eviction)spans.RemoveAt(0);
                recent.Enqueue(selected);while(recent.Count>8)recent.Dequeue();Choices++;start=span.End;
            }
            return spans[spans.Count-1].Paths[joint].Sample(time);
        }
        private PhraseState BeforeFirst(double time,int joint)
        {
            // Reach and shoulder derivatives deliberately probe just before
            // the planning interval. They must not clear/reselect the graph:
            // every already-published evaluator still refers to this graph.
            var span=spans[0];
            var s=PreRoll(span,joint).Sample(time);s.Time=time;return s;
        }
        private static MotionTransition PreRoll(Span span,int joint)
        {
            if(span.PreRolls[joint]==null)
            {
                var b=span.Paths[joint].Sample(span.Start);var a=b.Copy();a.Time=span.Start-.30;
                a.Grip-=b.Velocity.Limited(.5)*.05;a.Rotation=MotionRotation.Exp(b.AngularVelocity.Limited(1.5)*-.05)*b.Rotation;
                a.Velocity=a.Acceleration=a.AngularVelocity=a.AngularAcceleration=new MotionVector();span.PreRolls[joint]=new MotionTransition(a,b);
            }
            return span.PreRolls[joint];
        }
        private static MotionTransition EndingSettle(Span span,int joint)
        {
            if(span.Settles[joint]==null)
            {
                var a=span.Paths[joint].Sample(span.End);var b=a.Copy();a.Time=span.End;b.Time=span.End+.60;
                b.Grip+=a.Velocity.Limited(.8)*.08;b.Rotation=MotionRotation.Exp(a.AngularVelocity.Limited(2)*.08)*a.Rotation;
                b.Velocity=b.Acceleration=b.AngularVelocity=b.AngularAcceleration=new MotionVector();span.Settles[joint]=new MotionTransition(a,b);
            }
            return span.Settles[joint];
        }
        private static double Rate(HumanMotionExample e,double duration)
        {
            // The contact solver owns note timing and cut speed. Retrieval
            // must not accelerate every 1.25-second source into one second.
            // Short phase remainders crop the source at its natural clock.
            return 1;
        }
        private double JoinDuration(HumanPhase phase,Span prior,double start,double duration)
        {
            double join=Math.Min(.24,duration*.3);
            if(phase==HumanPhase.Playing && (prior.Phase==HumanPhase.Opening || prior.Phase==HumanPhase.Break))join=Math.Min(.50,duration*.6);
            if(phase==HumanPhase.Playing){int next=HumanContext.Lower(chart,start+.001);if(next<chart.Length)join=Math.Min(join,Math.Max(.001,chart[next].Time-start-.004));}
            return join;
        }
        private bool FeasibleJoin(HumanEventAlignment alignment,HumanTape tape,PhraseState[] outgoing,Span prior,double start)
        {
            if(outgoing==null)return true;
            double finish=start+JoinDuration(HumanPhase.Playing,prior,start,alignment.DestinationEnd-start);
            for(int j=0;j<3;j++)
            {
                var bridge=new MotionTransition(outgoing[j],alignment.Sample(tape,finish,j));
                int probes=Math.Max(4,(int)Math.Ceiling((finish-start)*240));
                for(int p=0;p<=probes;p++){var s=bridge.Sample(start+(finish-start)*p/probes);if(s.Velocity.Length>(j==0 ? 3 : 14) || s.AngularVelocity.Length>(j==0 ? 6 : 66))return false;}
            }
            return true;
        }
        private int Select(HumanPhase phase,double[] context,Span prior,double start,double duration,out HumanEventAlignment chosenAlignment)
        {
            chosenAlignment=null;
            int limit=effort==0 ? 2 : effort==1 ? 6 : 12;var candidates=new List<KeyValuePair<int,double>>();
            var alignments=new Dictionary<int,HumanEventAlignment>();
            var targetEvents=phase==HumanPhase.Playing ? HumanEventAlignment.PrepareTarget(chart,start,start+duration) : null;
            PhraseState[] outgoing=null;if(prior!=null){outgoing=new PhraseState[3];for(int j=0;j<3;j++)outgoing[j]=prior.Paths[j].Sample(start);}
            for(int i=0;i<model.Examples.Count;i++)
            {
                var e=model.Examples[i];bool ending=phase==HumanPhase.Ending && e.Phase==HumanPhase.Celebration;
                if(e.Phase!=phase && !ending)continue;double cost=model.ContextWeight*HumanMotionModel.Distance(context,e.Context)-1e-9*Math.Log(e.Count+1.0);
                if(phase!=HumanPhase.Playing && usedNonPlayingSources.Contains(i))continue;
                if(phase==HumanPhase.Playing)
                {
                    double minimum=0;
                    if(prior!=null && prior.Source>=0)
                    {var outgoingExample=model.Examples[prior.Source];if(outgoingExample.Recording==e.Recording && outgoingExample.Sequence+1==e.Sequence)minimum=Math.Max(0,outgoingExample.StartTime+prior.SourceEnd-e.StartTime);}
                    var tape=ExampleTape(i);
                    var source=sourceEvents[i] ?? (sourceEvents[i]=HumanEventAlignment.PrepareSource(e,tape));
                    var alignment=HumanEventAlignment.Match(e,tape,chart,start,start+duration,minimum,source,targetEvents);
                    if(alignment==null)continue;
                    alignments[i]=alignment;cost+=alignment.Cost;
                }
                if(prior!=null)
                {
                    if(phase==HumanPhase.Playing){var predicted=new PhraseState[3];var tape=ExampleTape(i);for(int j=0;j<3;j++)predicted[j]=alignments[i].Sample(tape,start,j);cost+=model.BoundaryWeight*HumanMotionModel.BoundaryDistance(predicted,outgoing);}
                    else cost+=model.BoundaryWeight*HumanMotionModel.BoundaryDistance(e,outgoing,Rate(e,duration));
                }
                foreach(int used in recent)if(i==used)cost+=.012;
                if(prior!=null && prior.Source>=0 && model.Examples[prior.Source].Recording==e.Recording && model.Examples[prior.Source].Sequence+1==e.Sequence)cost-=.015;
                candidates.Add(new KeyValuePair<int,double>(i,cost));
            }
            candidates.Sort(delegate(KeyValuePair<int,double> a,KeyValuePair<int,double>b){return a.Value.CompareTo(b.Value);});
            double best=double.MaxValue;int choice=-1;
            for(int k=0;k<Math.Min(limit,candidates.Count);k++)
            {
                var c=candidates[k];var tape=ExampleTape(c.Key);double cost=c.Value;
                if(phase==HumanPhase.Playing && (!alignments[c.Key].PreservesTrainingDomain(tape) || !FeasibleJoin(alignments[c.Key],tape,outgoing,prior,start)))continue;
                if(prior!=null)for(int j=0;j<3;j++)
                {var a=prior.Paths[j].Sample(start);var b=phase==HumanPhase.Playing ? alignments[c.Key].Sample(tape,start,j) : tape.Sample(0,j);cost+=(a.Grip-b.Grip).Length*.10+MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length*.05+(a.Velocity-b.Velocity).Length*.006+(a.AngularVelocity-b.AngularVelocity).Length*.002;}
                Searches++;if(cost<best){best=cost;choice=c.Key;}
            }
            if(choice>=0)alignments.TryGetValue(choice,out chosenAlignment);
            return choice;
        }
    }
}
