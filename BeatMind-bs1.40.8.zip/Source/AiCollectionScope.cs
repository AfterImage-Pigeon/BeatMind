using System;
using UnityEngine.Scripting;
namespace SaberMind
{
    // The game's DisableGCWhileEnabled component turns collection off in its
    // gameplay scene. Human motion training and planning allocate managed
    // curves there, even while the song clock is paused. Let those discarded
    // curves be collected while the AI owns the scene, then restore the game's
    // original setting when that session stops.
    internal sealed class AiCollectionScope : IDisposable
    {
        private GarbageCollector.Mode previous;
        private bool changed;
        private bool disposed;
        private bool playback,sliced,inProgress;
        private readonly Func<long> heapBytes;
        private readonly Action fullCollection;
        private GarbageCollector.Mode ownedMode=GarbageCollector.Mode.Enabled;
        private int lastFrame=-1;
        private long baselineBytes;
        private double nextCollection;
        private double nextHeapCheck;
        internal const long DeferredPlaybackBudget=512L*1048576;
        internal bool NeedsStoppedCollection;
        internal long PeakDeferredPlaybackBytes;
        internal int StoppedMaintenanceCollections;
        internal double PeakCollectionMilliseconds;
        internal double PeakPlaybackCollectionMilliseconds;
        internal int PlaybackFullCollections;
        internal AiCollectionScope(Func<long> heapBytes=null,Action fullCollection=null)
        {
            this.heapBytes=heapBytes ?? delegate{return GC.GetTotalMemory(false);};
            this.fullCollection=fullCollection ?? delegate{GC.Collect();};
            previous=GarbageCollector.GCMode;EnsureEnabled();
            Plugin.Log.Info("AI managed-memory collection: "+previous+" -> "+GarbageCollector.GCMode+
                "; incremental="+GarbageCollector.isIncremental+"; managed memory "+(GC.GetTotalMemory(false)/1048576)+" MB.");
        }
        internal void EnsureEnabled()
        {
            if(disposed)return;
            var desired=playback ? GarbageCollector.Mode.Manual : GarbageCollector.Mode.Enabled;
            if(GarbageCollector.GCMode==desired)return;
            // A scene component may run OnEnable after Session construction.
            // Capture that latest vanilla policy before overriding it too.
            if(!changed || GarbageCollector.GCMode!=ownedMode)previous=GarbageCollector.GCMode;
            changed=true;ownedMode=desired;GarbageCollector.GCMode=desired;
            Plugin.Log.Info("AI managed-memory mode: "+previous+" -> "+desired+".");
        }
        internal void PreparePlayback()
        {
            // Discard training/initial-plan temporaries while audio is held.
            // A non-incremental player cannot time-slice a collection later.
            if(disposed || GarbageCollector.isIncremental)return;
            EnsureEnabled();CollectFull();
        }
        internal void CollectWithStoppedClock(bool clockStopped)
        {
            if(!clockStopped)throw new InvalidOperationException("Full playback collection requires a stopped song clock.");
            if(disposed)return;
            playback=false;sliced=false;EnsureEnabled();CollectFull();
            NeedsStoppedCollection=false;StoppedMaintenanceCollections++;
        }
        private void CollectFull()
        {
            long start=System.Diagnostics.Stopwatch.GetTimestamp();fullCollection();
            double ms=(System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency;
            PeakCollectionMilliseconds=Math.Max(PeakCollectionMilliseconds,ms);
            if(playback){PlaybackFullCollections++;PeakPlaybackCollectionMilliseconds=Math.Max(PeakPlaybackCollectionMilliseconds,ms);}
            baselineBytes=heapBytes();
        }
        internal void Tick(int frame,double realTime,bool playing,bool quietWindow=false)
        {
            if(disposed || frame==lastFrame)return;lastFrame=frame;
            bool useSlices=playing && GarbageCollector.isIncremental;
            if(playback!=playing || sliced!=useSlices)
            {
                bool wasPlaying=playback;playback=playing;sliced=useSlices;
                if(wasPlaying && !playing && !GarbageCollector.isIncremental){EnsureEnabled();CollectFull();NeedsStoppedCollection=false;}
                baselineBytes=heapBytes();nextCollection=nextHeapCheck=realTime;
            }
            EnsureEnabled();if(!playback)return;
            if(!sliced)
            {
                // A note-free break still renders the game. The v21 trace
                // proved full collections here caused 190-209 ms frame stalls.
                // Defer normal collection to a real pause/results/training.
                // Keep a bounded emergency budget; Session stops the audio
                // clock before servicing that request, preserving cut timing.
                if(realTime<nextHeapCheck)return;nextHeapCheck=realTime+.5;
                long growth=Math.Max(0,heapBytes()-baselineBytes);
                PeakDeferredPlaybackBytes=Math.Max(PeakDeferredPlaybackBytes,growth);
                if(growth>=DeferredPlaybackBudget)NeedsStoppedCollection=true;
                return;
            }
            // Manual does not mean collection is disabled. Finish each cycle
            // in measured half-millisecond native steps, once per rendered
            // frame, instead of letting heap pressure request a full pass.
            if(!inProgress && realTime<nextCollection && heapBytes()<baselineBytes+8*1048576)return;
            long start=System.Diagnostics.Stopwatch.GetTimestamp();
            inProgress=GarbageCollector.CollectIncremental(500000);
            double ms=(System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency;
            PeakCollectionMilliseconds=Math.Max(PeakCollectionMilliseconds,ms);
            PeakPlaybackCollectionMilliseconds=Math.Max(PeakPlaybackCollectionMilliseconds,ms);
            if(!inProgress){baselineBytes=heapBytes();nextCollection=realTime+2;}
        }
        public void Dispose()
        {
            if(disposed)return;disposed=true;
            // A later explicit policy change belongs to its caller. Restore
            // only the Enabled setting this lease actually owns.
            if(changed && GarbageCollector.GCMode==ownedMode)
                GarbageCollector.GCMode=previous;
        }
    }
}
