using System;
using UnityEngine;
using UnityEngine.UI;

namespace SaberMind
{
    // The pre-song page displays measured offline work. Gameplay uses the
    // normal scene/camera after this page is dismissed.
    internal sealed class TrainingView : IDisposable
    {
        private readonly BodyRig body;
        private readonly bool learning, simulated, watching;
        private readonly string title, model;
        private Camera main;
        private GameObject canvasObject;
        private GameObject hudObject;
        private Text progress, details, hudText;
        private string gameplayStatus = "BeatMind Human";
        private bool freeCamera;
        private bool followHead;
        private float freeYaw, freePitch;
        private Vector3 freePosition;
        private int lastInputFrame=-1;
        private Font font;
        private int originalMask;
        private readonly int overlayLayer;
        private bool posing, disposed;
        private bool paused;
        private Vector3 savedPosition;
        private Quaternion savedRotation;
        private Matrix4x4 savedView;
        private bool preSong;
        internal void SetPaused(bool value)
        {
            paused = value;
            if (paused) RestorePose();
            if (canvasObject != null) canvasObject.SetActive(!paused);
            if (hudObject != null) hudObject.SetActive(!paused);
        }
        internal TrainingView(BodyRig body, bool learning, bool watching, string song, ModelProfile profile, bool simulated)
        {
            this.body = body; this.learning = learning; this.watching=watching; this.simulated = simulated || watching;
            followHead=this.simulated;
            title = "LEARNING " + song.ToUpperInvariant(); model = profile.Name;
            overlayLayer = VisualLayers.FindUnused(body.VisualLayer);
            Camera.onPreCull += BeforeCamera; Camera.onPostRender += AfterCamera;
        }
        internal void Tick(int completed, int count)
        {
            if (disposed) return;
            if (main == null)
            {
                main = Camera.main;
                if (main == null) return;
                originalMask = main.cullingMask;
                main.cullingMask = (originalMask | (1 << overlayLayer)) & ~(1 << body.VisualLayer);
            }
            if (preSong && canvasObject == null) CreateOverlay();
            if (!Settings.Current.ShowGameplayHud && hudObject!=null)
            { UnityEngine.Object.Destroy(hudObject);hudObject=null;hudText=null; }
            if (!preSong && Settings.Current.ShowGameplayHud && hudObject==null) CreateHud();
            // Live Play & learn / Play learned expose the same desktop viewing
            // controls as replay watching. These change rendering only.
            if (!paused && !preSong && lastInputFrame!=Time.frameCount)
            {
                lastInputFrame=Time.frameCount;
                // FPFC can keep the original stereo camera enabled. The key
                // controls our render pose, so stereo is not an input gate.
                if(Input.GetKeyDown(KeyCode.F6))
                {
                    freeCamera=followHead;followHead=!followHead;
                    if(freeCamera)
                    { freePosition=body.Head.position; freeYaw=body.Head.eulerAngles.y;freePitch=Mathf.Clamp(Mathf.DeltaAngle(0,body.Head.eulerAngles.x),-85,85); }
                    Plugin.Log.Info("F6 camera: "+(freeCamera ? "mouse/free" : "AI head")+"; stereo="+main.stereoEnabled);
                }
                if(freeCamera)
                {
                    freeYaw+=Input.GetAxisRaw("Mouse X")*2f;
                    freePitch=Mathf.Clamp(freePitch-Input.GetAxisRaw("Mouse Y")*2f,-85,85);
                    Quaternion look=Quaternion.Euler(freePitch,freeYaw,0);
                    Vector3 travel=new Vector3((Input.GetKey(KeyCode.D)?1:0)-(Input.GetKey(KeyCode.A)?1:0),
                        (Input.GetKey(KeyCode.E)?1:0)-(Input.GetKey(KeyCode.Q)?1:0),
                        (Input.GetKey(KeyCode.W)?1:0)-(Input.GetKey(KeyCode.S)?1:0));
                    freePosition+=look*Vector3.ClampMagnitude(travel,1)*(Input.GetKey(KeyCode.LeftShift)?6:3)*Time.unscaledDeltaTime;
                }
            }
            if(hudObject!=null && !preSong)
            {
                Vector3 head=freeCamera ? freePosition : followHead ? body.Head.position : main.transform.position;
                Quaternion facing=freeCamera ? Quaternion.Euler(freePitch,freeYaw,0) : followHead ? body.Head.rotation : main.transform.rotation;
                hudObject.transform.SetPositionAndRotation(head+facing*(Vector3.forward*.80f+
                    (Settings.Current.HudOnRight ? Vector3.right : Vector3.left)*.29f+Vector3.up*.23f),facing);
                hudText.text=gameplayStatus+(freeCamera ? " | Mouse: WASD/QE, F6 AI head" : " | F6: "+(followHead ? "mouse camera" : "AI head"));
            }
            if (preSong && progress != null)
            {
                Vector3 head = simulated ? body.Head.position : main.transform.position;
                Quaternion facing = simulated ? body.Head.rotation : main.transform.rotation;
                canvasObject.transform.SetPositionAndRotation(head + facing * Vector3.forward * .75f, facing);
            }
        }
        internal void BeginPreSong()
        {
            if (!learning) return;
            preSong = true;
            if (main == null) Tick(0,0);
            if (main == null) return;
            if (canvasObject == null) CreateOverlay();
        }
        internal void UpdatePreSongStatus(PreSongStatus status)
        {
            if (progress == null || status == null) return;
            progress.text = status.Percent + "% DONE";
            details.text = !Settings.Current.ShowTrainingDetails ? "F8: manual control | UNRANKED" : model + " | " + status.Phase + "\nPass " + status.Pass + " | "
                + status.SimulatedSpeed + " | Confidence " + status.Confidence
                + "\nSections " + status.Sections + " | Patterns flagged " + status.Patterns
                + " | Readiness " + status.Readiness + "\nF8: manual control | UNRANKED";
        }
        internal void SetGameplayStatus(string value) { gameplayStatus=value; }
        internal void EndPreSong()
        {
            preSong = false;
            if (canvasObject != null) UnityEngine.Object.Destroy(canvasObject);
            canvasObject = null; progress = details = null;
        }
        private void CreateOverlay()
        {
            canvasObject = new GameObject("BeatMind Human learning display", typeof(RectTransform), typeof(Canvas));
            canvasObject.layer = overlayLayer;
            Canvas canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = main; canvas.sortingOrder = 32700;
            RectTransform root = (RectTransform)canvasObject.transform;
            root.sizeDelta = new Vector2(1600, 1000); root.localScale = Vector3.one * (.0009f*Settings.Current.HudScale);
            RectTransform background = Element("Black background", root, new Vector2(.5f,.5f), new Vector2(12000,12000), Vector2.zero);
            background.gameObject.AddComponent<Image>().color = Color.black;
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            Label("Title", root, title, new Vector2(0, 130), new Vector2(1450, 170), 50);
            progress = Label("Progress", root, "0% DONE", new Vector2(0, 5), new Vector2(1200,120), 65);
            details = Label("Training status", root, "Analyzing map...", new Vector2(0, -165), new Vector2(1450,290), 27);
            SetPaused(paused);
        }
        private void CreateHud()
        {
            hudObject=new GameObject("BeatMind Human compact HUD",typeof(RectTransform),typeof(Canvas));
            hudObject.layer=overlayLayer;
            Canvas canvas=hudObject.GetComponent<Canvas>();canvas.renderMode=RenderMode.WorldSpace;
            canvas.worldCamera=main;canvas.sortingOrder=32699;
            RectTransform root=(RectTransform)hudObject.transform;
            root.sizeDelta=new Vector2(620,76);root.localScale=Vector3.one*(.0009f*Settings.Current.HudScale);
            RectTransform backing=Element("HUD background",root,new Vector2(.5f,.5f),new Vector2(620,76),Vector2.zero);
            backing.gameObject.AddComponent<Image>().color=new Color(0,0,0,Settings.Current.HudOpacity*.65f);
            if(font==null) font=Resources.GetBuiltinResource<Font>("Arial.ttf");
            hudText=Label("HUD status",root,gameplayStatus,Vector2.zero,new Vector2(594,66),26);
            hudText.alignment=TextAnchor.MiddleLeft;
            hudText.color=new Color(1,1,1,Settings.Current.HudOpacity);
            SetPaused(paused);
        }
        private RectTransform Element(string name, RectTransform parent, Vector2 anchor, Vector2 size, Vector2 position)
        {
            var obj = new GameObject(name, typeof(RectTransform)); obj.layer = overlayLayer;
            RectTransform rect = (RectTransform)obj.transform; rect.SetParent(parent, false);
            rect.anchorMin = rect.anchorMax = anchor; rect.sizeDelta = size; rect.anchoredPosition = position;
            return rect;
        }
        private Text Label(string name, RectTransform parent, string value, Vector2 position, Vector2 size, int fontSize)
        {
            Text text = Element(name, parent, new Vector2(.5f,.5f), size, position).gameObject.AddComponent<Text>();
            text.font = font; text.text = value; text.fontSize = fontSize; text.color = Color.white;
            text.alignment = TextAnchor.MiddleCenter; text.supportRichText = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap; text.verticalOverflow = VerticalWrapMode.Truncate;
            return text;
        }
        private void BeforeCamera(Camera camera)
        {
            if (disposed || paused || camera != main || !(followHead || freeCamera) || body.Head == null || posing) return;
            savedPosition = camera.transform.position; savedRotation = camera.transform.rotation;
            savedView = camera.worldToCameraMatrix; posing = true;
            Vector3 position=freeCamera ? freePosition : body.Head.position;
            Quaternion rotation=freeCamera ? Quaternion.Euler(freePitch,freeYaw,0) : body.Head.rotation;
            camera.transform.SetPositionAndRotation(position,rotation);
            camera.worldToCameraMatrix = View(position,rotation);
            if (camera.stereoEnabled)
            {
                float half = Mathf.Clamp(camera.stereoSeparation * .5f, .025f, .04f);
                camera.SetStereoViewMatrix(Camera.StereoscopicEye.Left, View(position - rotation*Vector3.right * half, rotation));
                camera.SetStereoViewMatrix(Camera.StereoscopicEye.Right, View(position + rotation*Vector3.right * half, rotation));
            }
        }
        private static Matrix4x4 View(Vector3 position, Quaternion rotation)
        { return Matrix4x4.Scale(new Vector3(1,1,-1)) * Matrix4x4.TRS(position, rotation, Vector3.one).inverse; }
        private void AfterCamera(Camera camera) { if (camera == main) RestorePose(); }
        private void RestorePose()
        {
            if (!posing || main == null) return;
            main.transform.SetPositionAndRotation(savedPosition, savedRotation);
            main.worldToCameraMatrix = savedView; main.ResetWorldToCameraMatrix(); main.ResetStereoViewMatrices(); posing = false;
        }
        public void Dispose()
        {
            if (disposed) return; disposed = true;
            Camera.onPreCull -= BeforeCamera; Camera.onPostRender -= AfterCamera; RestorePose();
            if (main != null) main.cullingMask = originalMask;
            EndPreSong();
            if(hudObject!=null) UnityEngine.Object.Destroy(hudObject);
        }
    }
}

