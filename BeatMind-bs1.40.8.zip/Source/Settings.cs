using System;
using System.IO;
using Newtonsoft.Json;

namespace SaberMind
{
    internal static class Settings
    {
        internal static BodySettings Current = new BodySettings();
        internal static int TrainingTargetPercent { get { return AutoRestartPolicy.NormalizeTargetPercent(Current.TrainToAccuracyPercent); } }
        private static string PathName { get { return Path.Combine(IPA.Utilities.UnityGame.UserDataPath, "AIPlayAndLearn", "Settings.json"); } }
        internal static void Load()
        {
            try
            {
                if (File.Exists(PathName)) Current = JsonConvert.DeserializeObject<BodySettings>(File.ReadAllText(PathName)) ?? new BodySettings();
                Current.Normalize();
                Current.TrainToAccuracyPercent = TrainingTargetPercent;
            }
            catch (Exception e) { Plugin.Log.Warn("Settings could not be read; defaults used: " + e.Message); }
        }
        internal static void Save()
        {
            try
            {
                Current.Normalize(); Current.TrainToAccuracyPercent = TrainingTargetPercent;
                Directory.CreateDirectory(Path.GetDirectoryName(PathName));
                File.WriteAllText(PathName + ".tmp", JsonConvert.SerializeObject(Current, Formatting.Indented));
                if (File.Exists(PathName)) File.Replace(PathName + ".tmp", PathName, PathName + ".bak");
                else File.Move(PathName + ".tmp", PathName);
            }
            catch (Exception e) { Plugin.Log.Warn("Settings save failed: " + e.Message); }
        }
    }
}
