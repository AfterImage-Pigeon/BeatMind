using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Collections;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;

namespace SaberMind
{
    internal sealed class TrackedNote
    {
        internal NoteController Controller;
        internal NoteData Data;
        internal string Key;
        internal int Variant;
        internal double ScheduledHit;
        internal bool HasScheduledHit;
        internal double HitTime { get { return HasScheduledHit ? ScheduledHit : Time+Policy.Variants[Variant].Offset; } }
        internal float Time;
        internal int Color;
        internal bool Resolved;
        internal bool AwaitingScore;
        internal float Style;
        internal Vector3 Center, Direction, Forward;
        internal bool HasPose;
        internal NoteMemory Timing;
        internal BehaviorChoice Behavior;
        internal BehaviorMemory BehaviorData;
        internal int MapIndex, MotionSamples;
        internal int LastPoseFrame=-1;
        internal double MotionQuality;
        internal Vector3 Plan;
        internal bool Planned;
        internal float Spacing = .5f;
        internal float LocalNps;
        internal MotionPattern Pattern;
    }

    internal sealed class Hand
    {
        internal Saber Saber;
        internal Vector3 OriginalLocalPosition, LocalAxis, LocalContact, LocalGrip, LocalBladeTop, LocalBladeBottom;
        internal Quaternion OriginalLocalRotation;
        internal TrackedNote Target;
        internal Vector3 LastPosition;
        internal Quaternion LastRotation;
        internal bool HasPose;
        internal Vector3 LastVelocity;
        internal float PeakSpeed, PeakAngularSpeed;
        internal Vector3 AngularVelocity;
        internal Quaternion LastAim;
        internal bool HasAim;
        internal Vector3 LastAcceleration, AngularAcceleration;
        internal Vector3 GripPosition, GripVelocity, GripAcceleration;
        internal float Tempo;
        internal float BreakStrength;
        internal MotionAxis TempoState;
        internal float LastWristTargetDelta;
        internal Vector3 LastWristFeed;
        internal bool TargetChanged, RouteChanged, ContactFitChanged;
        internal bool ContactGeometryChanged;
        internal double LastMotionSongTime=double.NaN;
        internal int LastCutMapIndex=-1;
        internal double LastCutSongTime=double.NaN;
        internal float LastTraceTime = float.NegativeInfinity;
        internal int LastMotionFrame = -1;
        internal MotionPhrase Phrase;
        internal ReplayPlanJob PendingPlan;
        internal bool PendingDeferred;
        internal int PendingRevision=-1;
        internal double PendingStart,PendingHandoff,PendingSetupMilliseconds,PeakPlanSliceMilliseconds;
        internal int MotionRevision=-1;
        internal PhraseState Desired;
        internal readonly MotionImitationMetrics ImitationMetrics=new MotionImitationMetrics();
        internal int ImitationCandidates;
        internal int PhraseId,Replans,CandidateEvaluations,CorrectionReversals;
        internal double PlanMilliseconds,PeakPlanMilliseconds;
        internal Vector3 LastCorrection,LastTip,LastGripAcceleration;
        internal float PeakTipSpeed,PeakGripJerk,TipSpeed,GripJerk,AngularJerk;
        internal double TipTravel,GripTravel;
        internal float PeakAcceleration, PeakJerk, PeakAngularAcceleration, PeakAngularJerk, PeakTargetStep;
    }

    internal sealed class Session
    {
        internal static volatile Session Current;
        internal static bool BotWasUsed;
        internal static LevelCompletionResults BotResult;
        internal static bool AutoRestartRequested;
        internal static string AutoRestartStatus;
        private static int autoRestartStreak;
        private static string autoRestartKey;
        private sealed class RunSetup
        {
            internal string gameMode;
            internal BeatmapKey beatmapKey;
            internal BeatmapLevel beatmapLevel;
            internal GameplayModifiers gameplayModifiers;
            internal PracticeSettings practiceSettings;
        }
        private static RunSetup prepared;
        private static PlayerSpecificSettings playerSettings;
        private readonly Dictionary<NoteController, TrackedNote> notes = new Dictionary<NoteController, TrackedNote>();
        private readonly Dictionary<NoteData, TrackedNote> notesByData = new Dictionary<NoteData, TrackedNote>();
        private readonly Dictionary<int, TrackedNote> notesByIndex = new Dictionary<int, TrackedNote>();
        private readonly Dictionary<Saber, Hand> hands = new Dictionary<Saber, Hand>();
        private readonly AudioTimeSyncController clock;
        private readonly UnityEngine.Object owner;
        private readonly SaberManager ownedSabers;
        private readonly BeatmapObjectManager ownedNotes;
        private readonly bool multiplayer;
        internal bool Multiplayer { get { return multiplayer; } }
        internal bool OwnsOwner(UnityEngine.Object other) {return owner==other;}
        internal bool OwnsSaber(Saber other) {return !Multiplayer || ownedSabers!=null && (other==ownedSabers.leftSaber || other==ownedSabers.rightSaber);}
        internal bool OwnsPlayer(PlayerTransforms other) {return !Multiplayer || player==other;}
        internal bool OwnsNotes(BeatmapObjectManager other) {return !Multiplayer || object.ReferenceEquals(ownedNotes,other);}
        private readonly LevelMemory memory;
        private readonly bool learning;
        private readonly bool watching;
        private readonly BestReplay bestReplay;
        private readonly BestReplay recording;
        private float lastReplayFrame = float.NegativeInfinity;
        private readonly string song;
        private readonly PlayerTransforms player;
        private readonly ScoreController scorer;
        private readonly PauseController pause;
        private volatile bool paused;
        private bool recorded;
        private volatile bool songStarted;
        private readonly ModelProfile profile;
        private readonly ModelMemory modelMemory;
        private readonly LevelMemory generalMemory;
        private readonly ModelMemory generalModel;
        private readonly BodyRig body;
        private HumanMotionModel motionLibrary;
        private HumanRunHandle motionRun;
        private bool motionSourceCaptured;
        private readonly TrainingView view;
        private readonly AiCollectionScope collection;
        private PreSongTrainer pretraining;
        private readonly List<NoteData> mapNotes = new List<NoteData>();
        private readonly List<ObstacleData> mapWalls = new List<ObstacleData>();
        private readonly Dictionary<string, int> mapIndices = new Dictionary<string, int>();
        private readonly Dictionary<string, int> mapContactIndices = new Dictionary<string, int>();
        private readonly int totalNotes, maximumScore;
        private int completedNotes, lastTickFrame = -1, focusCursor;
        private float breakStrength;
        private float lastSongTime = float.NaN;
        private readonly BehaviorChoice baseline = new BehaviorChoice();
        private Vector3 lastForward = Vector3.forward;
        private int good, bad, missed;
        private int badDirection,badSpeed,badSaber,badEarly;
        private int scoredCuts, scoreTotal, scorePossible;
        private int armClampFrames, bodyClampFrames;
        private float furthestRequestedReach;
        private bool dirty;
        private bool generalDirty;
        private bool learnedRealCut;
        private readonly SaberTrace trace = new SaberTrace();
        private readonly FrameStallTrace frameStalls = new FrameStallTrace();
        private static readonly FieldInfo BladeTop = AccessTools.Field(typeof(Saber), "_saberBladeTopTransform");
        private static readonly FieldInfo BladeBottom = AccessTools.Field(typeof(Saber), "_saberBladeBottomTransform");
        private static readonly FieldInfo GripTransform = AccessTools.Field(typeof(Saber), "_handleTransform");
        private static readonly FieldInfo NoteMovementField = AccessTools.Field(typeof(NoteController), "_noteMovement");
        private static readonly FieldInfo JumpField = AccessTools.Field(typeof(NoteMovement), "_jump");
        private static readonly FieldInfo JumpProviderField = AccessTools.Field(typeof(NoteJump), "_variableMovementDataProvider");
        private static readonly FieldInfo JumpStartOffsetField = AccessTools.Field(typeof(NoteJump), "_startOffset");
        private static readonly FieldInfo JumpEndOffsetField = AccessTools.Field(typeof(NoteJump), "_endOffset");
        private static readonly FieldInfo JumpGravityBaseField = AccessTools.Field(typeof(NoteJump), "_gravityBase");
        private static readonly FieldInfo JumpEndDistanceField = AccessTools.Field(typeof(NoteJump), "_endDistanceOffset");

        private Session(UnityEngine.Object owner, AudioTimeSyncController clock, LevelMemory memory, bool learning, bool watching, string song, IReadonlyBeatmapData map,
            ModelProfile selected=null,PlayerTransforms localPlayer=null,ScoreController localScore=null,SaberManager localSabers=null,BeatmapObjectManager localNotes=null)
        {
            this.owner = owner; this.clock = clock; this.memory = memory; this.learning = learning; this.watching=watching; this.song = song;
            ownedSabers=localSabers;ownedNotes=localNotes;multiplayer=!object.ReferenceEquals(localSabers,null);
            player = Multiplayer ? localPlayer : UnityEngine.Object.FindObjectOfType<PlayerTransforms>();
            scorer = Multiplayer ? localScore : UnityEngine.Object.FindObjectOfType<ScoreController>();
            pause = Multiplayer ? null : UnityEngine.Object.FindObjectOfType<PauseController>();
            profile = selected??ModelProfile.Find(Settings.Current.Model); modelMemory = memory.ForModel(ModelKey(profile, Settings.Current));
            try { bestReplay=Plugin.Replays.Load(memory.Identity,ModelKey(profile,Settings.Current)); }
            catch(Exception error) { Plugin.Log.Warn("Best replay unavailable: "+error.Message); }
            if(watching && bestReplay==null) throw new InvalidOperationException("No completed best replay exists for this level and model yet.");
            if(!watching) recording=new BestReplay { Identity=memory.Identity,Model=ModelKey(profile,Settings.Current) };
            try { generalMemory=Plugin.Store.Load("SaberMind|general-v1"); }
            catch(Exception error)
            {
                Plugin.Log.Warn("General skill memory unavailable; using built-in motion: "+error.Message);
                generalMemory=new LevelMemory { Identity="SaberMind|general-v1" };
            }
            generalModel=generalMemory.ForModel(ModelKey(profile,Settings.Current));
            var walls = new List<ObstacleData>();
            float start = prepared.practiceSettings == null ? float.NegativeInfinity : prepared.practiceSettings.startSongTime;
            foreach (BeatmapDataItem item in map.allBeatmapDataItems)
            {
                NoteData note = item as NoteData;
                if (note != null && (int)note.colorType >= 0 && (int)note.colorType <= 1 && note.time >= start) mapNotes.Add(note);
                ObstacleData wall = item as ObstacleData; if (wall != null) walls.Add(wall);
            }
            mapNotes.Sort(delegate(NoteData a, NoteData b) { return a.time.CompareTo(b.time); });
            walls.Sort(delegate(ObstacleData a, ObstacleData b) { return a.time.CompareTo(b.time); });
            mapWalls.AddRange(walls);
            for (int i = 0; i < mapNotes.Count; i++)
            {mapIndices[NoteKey(mapNotes[i])] = i;mapContactIndices[ContactKey(mapNotes[i])]=i;}
            totalNotes = mapNotes.Count; maximumScore = ScoreModel.ComputeMaxMultipliedScoreForBeatmap(map);
            // The chart's vertical coordinates are measured from the level
            // floor. A room-space tracking-origin Y offset must not lift the
            // simulated shoulders above the notes.
            Transform trackingOrigin = player == null ? null : (Transform)AccessTools.Field(typeof(PlayerTransforms), "_originTransform").GetValue(player);
            Vector3 head = trackingOrigin == null ? new Vector3(0, Settings.Current.Height, 0)
                : new Vector3(trackingOrigin.position.x, Settings.Current.Height, trackingOrigin.position.z);
            Vector3 forward = trackingOrigin == null ? Vector3.forward : trackingOrigin.forward;
            body = new BodyRig(head, forward, Settings.Current, profile, walls);
            body.Motion=NewMotionGraph();
            if(!watching) PrepareContactSchedule();
            try { view = new TrainingView(body, learning, watching, song, profile, Settings.Current.SimulatedCamera); }
            catch { body.Dispose(); throw; }
            if (pause != null) { pause.didPauseEvent += Paused; pause.didResumeEvent += Resumed; }
            if(Plugin.Host!=null)Plugin.Host.SuspendReplayCollection();
            collection=new AiCollectionScope();
        }

        internal static string ModelKey(ModelProfile model, BodySettings settings)
        {
            return model.Name + "|body-v1|" + settings.Height.ToString("R", CultureInfo.InvariantCulture)
                + "|" + settings.ShoulderWidth.ToString("R", CultureInfo.InvariantCulture) + "|" + settings.UpperArm.ToString("R", CultureInfo.InvariantCulture)
                + "|" + settings.Forearm.ToString("R", CultureInfo.InvariantCulture) + "|" + settings.Hand.ToString("R", CultureInfo.InvariantCulture)
                + "|" + settings.Torso.ToString("R", CultureInfo.InvariantCulture);
        }
        internal static string Identity(BeatmapKey key, GameplayModifiers modifiers, PlayerSpecificSettings settings, PracticeSettings practice)
        {
            return key.levelId + "|" + key.beatmapCharacteristic.serializedName + "|" + key.difficulty + "|motion-v4|"
                + JsonConvert.SerializeObject(modifiers) + "|left=" + (settings != null && settings.leftHanded)
                + "|practice=" + (practice == null ? "normal" : practice.songSpeedMul.ToString("R", CultureInfo.InvariantCulture)
                    + "|start=" + practice.startSongTime.ToString("R", CultureInfo.InvariantCulture));
        }
        private static string NoteKey(NoteData data)
        { return data.time.ToString("R", CultureInfo.InvariantCulture) + ":" + data.lineIndex + ":" + (int)data.noteLineLayer
            + ":" + (int)data.colorType + ":" + (int)data.cutDirection + ":" + (int)data.gameplayType; }
        private static string ContactKey(NoteData data)
        {return data.time.ToString("R",CultureInfo.InvariantCulture)+":"+data.lineIndex+":"+(int)data.noteLineLayer+
            ":"+(int)data.colorType+":"+(int)data.gameplayType;}
        internal string KeyFor(NoteData data) { return NoteKey(data); }
        internal IList<NoteData> MapNotes { get { return mapNotes; } }
        internal bool NoArrows { get {return prepared!=null && prepared.gameplayModifiers!=null && prepared.gameplayModifiers.noArrows;} }
        internal List<ObstacleData> MapWalls { get { return mapWalls; } }
        internal ModelProfile Profile { get { return profile; } }
        internal ModelMemory Learned { get { return modelMemory; } }
        internal BodyRig Body { get { return body; } }
        internal HumanMotionGraph NewMotionGraph()
        {
            var chart=new HumanChartNote[mapNotes.Count];
            for(int i=0;i<chart.Length;i++){var n=mapNotes[i];chart[i]=new HumanChartNote{Id=i,Time=n.time,Hand=(int)n.colorType,Lane=n.lineIndex,Layer=(int)n.noteLineLayer,Direction=(int)n.cutDirection};}
            if(!motionSourceCaptured)
            {
                motionLibrary=Settings.Current.UseHumanReplayStyle ? Plugin.HumanMotion : null;
                string hash=prepared.beatmapKey.levelId;var match=System.Text.RegularExpressions.Regex.Match(hash,"[0-9a-fA-F]{40}");if(match.Success)hash=match.Value;
                motionRun=HumanReplayPreparation.Request(motionLibrary,hash,prepared.beatmapKey.difficulty.ToString(),prepared.beatmapKey.beatmapCharacteristic.serializedName,delegate(string message){Plugin.Log.Warn(message);},Plugin.WaitForReplayIdle);
                motionSourceCaptured=true;
            }
            return new HumanMotionGraph(motionLibrary,chart,motionRun,profile.Index);
        }
        internal static bool ActiveSongPlaying {get {var session=Current;return session!=null && session.songStarted && !session.paused;}}
        internal LevelMemory Memory { get { return memory; } }
        internal float PracticeStart { get { return prepared.practiceSettings == null ? 0 : prepared.practiceSettings.startSongTime; } }
        internal void MarkPretrained() { dirty = true; }
        private void SavePretrained()
        {
            if(!dirty) return;
            try { Plugin.Store.Save(memory); }
            catch(Exception error) { Plugin.Log.Warn("Pre-song plan save delayed: "+error.Message); }
        }
        internal BehaviorChoice KnownBehavior(NoteData data, int index)
        {
            BehaviorMemory local=modelMemory.Behavior(PatternContext(data,index,NoteKey(data)),false);
            BehaviorMemory prior=local.Visits>0 ? local : generalModel.Behavior(GeneralContext(data,index),false);
            return BehaviorOptimizer.Choose(prior,profile,false,"");
        }
        internal int KnownVariant(NoteData data)
        {
            NoteMemory local=KnownTiming(data);
            foreach(int count in local.Trials) if(count>0) return Policy.Choose(local,false);
            return Policy.Choose(generalModel.Note(GeneralContext(data,IndexFor(data)),null,false),false);
        }
        internal NoteMemory KnownTiming(NoteData data)
        {
            NoteMemory legacy;memory.Notes.TryGetValue(NoteKey(data),out legacy);
            return modelMemory.Note(NoteKey(data),legacy,false);
        }
        private int IndexFor(NoteData data)
        {
            int index;if(mapIndices.TryGetValue(NoteKey(data),out index)) return index;
            // A modifier may replace the live arrow with Any while the chart
            // preview still has its original arrow. Preserve chart identity.
            if(NoArrows && mapContactIndices.TryGetValue(ContactKey(data),out index)) return index;
            if(NoArrows) for(int i=0;i<mapNotes.Count;i++)
            {
                NoteData chart=mapNotes[i];if(chart.time>data.time+.001f) break;
                if(Mathf.Abs(chart.time-data.time)<.001f && chart.lineIndex==data.lineIndex &&
                    chart.noteLineLayer==data.noteLineLayer && chart.colorType==data.colorType && chart.gameplayType==data.gameplayType) return i;
            }
            return -1;
        }
        internal bool HasTimingEvidence(NoteData data)
        {
            NoteMemory legacy; memory.Notes.TryGetValue(NoteKey(data),out legacy);
            NoteMemory note=modelMemory.Note(NoteKey(data),legacy,false);
            foreach(int trials in note.Trials) if(trials>0) return true;
            NoteMemory shared=generalModel.Note(GeneralContext(data,IndexFor(data)),null,false);
            foreach(int trials in shared.Trials) if(trials>0) return true;
            return false;
        }
        private string GeneralContext(NoteData data,int index)
        {
            int previousDirection=-1, gap=5;
            if(index>=0)
                for(int i=index-1;i>=0;i--) if(mapNotes[i].colorType==data.colorType)
                {
                    previousDirection=(int)mapNotes[i].cutDirection;
                    gap=Mathf.Clamp(Mathf.RoundToInt((data.time-mapNotes[i].time)*8),0,12);
                    break;
                }
            return (int)data.colorType+":"+(int)data.cutDirection+":"+previousDirection+":"+gap+
                ":"+data.lineIndex+":"+(int)data.noteLineLayer;
        }
        internal Hand PracticeHand(int color, BodyRig rig)
        {
            foreach (Saber saber in UnityEngine.Object.FindObjectsOfType<Saber>())
            {
                if ((int)saber.saberType != color) continue;
                Transform top=(Transform)BladeTop.GetValue(saber), bottom=(Transform)BladeBottom.GetValue(saber);
                if (top==null || bottom==null) continue;
                Vector3 localTop=saber.transform.InverseTransformPoint(top.position);
                Vector3 localBottom=saber.transform.InverseTransformPoint(bottom.position);
                Vector3 grip=saber.transform.InverseTransformPoint(((Transform)GripTransform.GetValue(saber)).position);
                Quaternion rotation=saber.transform.rotation;
                Vector3 handPosition=rig.Hands[color].position;
                rig.ConfigureSaber(color,grip);rig.SeedArm(color,handPosition,rotation,(localTop-localBottom).normalized,baseline);
                handPosition=rig.Hands[color].position;
                return new Hand { LocalAxis=(localTop-localBottom).normalized,LocalContact=Vector3.Lerp(localBottom,localTop,.65f),
                    LocalBladeTop=localTop,LocalBladeBottom=localBottom,LocalGrip=grip,
                    LastPosition=handPosition-rotation*grip,LastRotation=rotation,GripPosition=handPosition,LastTip=handPosition+rotation*(localTop-grip),HasPose=true };
            }
            throw new InvalidOperationException("Saber geometry is unavailable for physical practice.");
        }

        internal static void Prepare(StandardLevelScenesTransitionSetupDataSO setup, PlayerSpecificSettings settings)
        {
            BotWasUsed = false;
            BotResult = null;
            prepared = new RunSetup {gameMode=setup.gameMode,beatmapKey=setup.beatmapKey,beatmapLevel=setup.beatmapLevel,
                gameplayModifiers=setup.gameplayModifiers,practiceSettings=setup.practiceSettings};
            playerSettings = settings;
            if (Plugin.Host != null && Plugin.Host.Menu.Enabled && setup.gameMode == "Solo")
                BS_Utils.Gameplay.ScoreSubmission.DisableSubmission(Plugin.Id);
        }

        internal static void Begin(StandardLevelGameplayManager owner, AudioTimeSyncController clock, IReadonlyBeatmapData map)
        {
            Stop("Previous attempt ended");
            if (Plugin.Host == null || !Plugin.Host.Menu.Enabled || prepared == null || prepared.gameMode != "Solo") return;
            BeatmapKey key = prepared.beatmapKey;
            string characteristic = key.beatmapCharacteristic.serializedName;
            if (characteristic != "Standard" && characteristic != "NoArrows" && characteristic != "OneSaber")
            {
                Plugin.Host.Menu.SetStatus("BeatMind supports Standard, No Arrows and One Saber.");
                return;
            }
            try
            {
                // Block before taking control, including restart attempts.
                BS_Utils.Gameplay.ScoreSubmission.ProlongedDisableSubmission(Plugin.Id);
                BS_Utils.Gameplay.ScoreSubmission.DisableSubmission(Plugin.Id);
                string prefix = key.levelId + "|" + characteristic + "|" + key.difficulty;
                string context = "|" + JsonConvert.SerializeObject(prepared.gameplayModifiers)
                    + "|left=" + (playerSettings != null && playerSettings.leftHanded)
                    + "|practice=" + (prepared.practiceSettings == null ? "normal" : prepared.practiceSettings.songSpeedMul.ToString("R", CultureInfo.InvariantCulture));
                string identity = Identity(key, prepared.gameplayModifiers, playerSettings, prepared.practiceSettings);
                LevelMemory memory = Plugin.Store.Load(identity);
                if (memory.Attempts == 0 && memory.Notes.Count == 0)
                {
                    LevelMemory previous = Plugin.Store.Load(prefix + "|motion-v3" + context);
                    if (previous.Notes.Count == 0) previous = Plugin.Store.Load(prefix + "|motion-v2" + context);
                    if (previous.Notes.Count == 0) previous = Plugin.Store.Load(prefix + "|policy-v1" + context);
                    ImportTimingHints(previous, memory);
                }
                if (map == null) throw new InvalidOperationException("The loaded beatmap is unavailable.");
                Current = new Session(owner, clock, memory, Plugin.Host.Menu.Learning, Plugin.Host.Menu.Watching,
                    prepared.beatmapLevel.songName, map);
                Plugin.Host.ClearAutoRestartQueue();
                BotWasUsed = true;
                Plugin.BotReplayStarted();
                string goalKey=identity+"|"+Current.profile.Name+"|"+Current.learning+"|goal="+Settings.TrainingTargetPercent;
                if(autoRestartKey!=goalKey) {autoRestartKey=goalKey;autoRestartStreak=0;}
                AutoRestartRequested=false;
                Plugin.Host.Menu.SetStatus(Current.watching ? "Watching the best recorded run of "+Current.song :
                    "Playing " + Current.song + " - attempt " + (memory.Attempts + 1));
                Plugin.Log.Info("Bot starting " + identity + "; learning=" + Current.learning + "; score submission disabled.");
                // Any notes instantiated before the gameplay manager's Start are included.
                foreach (NoteController note in UnityEngine.Object.FindObjectsOfType<NoteController>()) Current.Add(note);
            }
            catch (Exception error)
            {
                Stop("Start error");
                Plugin.Log.Error("Bot did not start: " + error);
                Plugin.Host.Menu.SetStatus("BeatMind could not start: "+error.Message);
                Current = null;
            }
        }

        internal static void EnterMultiplayer()
        {Stop("Entering multiplayer");CancelAutoRestart();prepared=null;BotWasUsed=false;BotResult=null;}

        internal static void BeginMultiplayer(MultiplayerLocalActivePlayerFacade owner,GameplayCoreSceneSetupData setup,
            AudioTimeSyncController clock,PlayerTransforms player,ScoreController scorer,SaberManager sabers,BeatmapObjectManager notes,ModelProfile model)
        {
            Stop("Previous attempt ended");CancelAutoRestart();
            if(!MultiplayerIntegration.CanPlay)return;
            string characteristic=setup.beatmapKey.beatmapCharacteristic.serializedName;
            if(characteristic!="Standard" && characteristic!="NoArrows" && characteristic!="OneSaber")
                throw new InvalidOperationException("Companion supports Standard, No Arrows and One Saber.");
            prepared=new RunSetup {gameMode="Multiplayer",beatmapKey=setup.beatmapKey,beatmapLevel=setup.beatmapLevel,
                gameplayModifiers=setup.gameplayModifiers,practiceSettings=setup.practiceSettings};
            playerSettings=setup.playerSpecificSettings;
            BS_Utils.Gameplay.ScoreSubmission.ProlongedDisableSubmission(Plugin.Id);
            BS_Utils.Gameplay.ScoreSubmission.DisableSubmission(Plugin.Id);
            LevelMemory memory=Plugin.Store.Load(Identity(setup.beatmapKey,setup.gameplayModifiers,playerSettings,setup.practiceSettings));
            Current=new Session(owner,clock,memory,true,false,setup.beatmapLevel.songName,setup.transformedBeatmapData,model,player,scorer,sabers,notes);
            // Native StartGameplay has started the authoritative song clock.
            // No solo coroutine hold, accelerated training or auto-restart.
            Current.songStarted=true;BotWasUsed=true;BotResult=null;Plugin.BotReplayStarted();
            var active=AccessTools.Field(typeof(BeatmapObjectManager),"_allBeatmapObjects").GetValue(notes) as IEnumerable<IBeatmapObjectController>;
            if(active!=null)foreach(IBeatmapObjectController item in active){NoteController note=item as NoteController;if(note!=null)Current.Add(note);}
            if(Plugin.Host!=null)Plugin.Host.Menu.SetStatus("Private multiplayer: "+setup.beatmapLevel.songName+" / "+model.Name+". Unranked; real-time learning.");
        }

        internal static IEnumerator DelaySongStart(IEnumerator original)
        {
            // The first yield is the game's scene-transition wait. The loaded
            // beatmap and scene camera are available when that wait completes,
            // while the original coroutine has not started audio or callbacks.
            bool first = true;
            while (original.MoveNext())
            {
                yield return original.Current;
                if (!first) continue;
                first = false;
                Session session = Current;
                if(session!=null)session.collection.EnsureEnabled();
                if (session == null || session.Multiplayer || session.watching) continue;
                // The audio component starts in Playing state. Hold its clock
                // while this coroutine waits; StartSong seeks and resumes it.
                session.clock.Pause();
                bool available=true;
                try { if(session.learning)session.pretraining=new PreSongTrainer(session);session.view.BeginPreSong(); }
                catch(Exception error) { available=false;Plugin.Log.Error("Pre-song setup stopped: " + error); }
                try
                {
                    while(available && Current==session && session.pretraining!=null && !session.pretraining.Done)
                    {
                        try
                        {
                            session.pretraining.Tick();
                            session.view.UpdatePreSongStatus(session.pretraining.Status);
                        }
                        catch(Exception error)
                        {
                            Plugin.Log.Error("Pre-song practice stopped: " + error);
                            if(Plugin.Host!=null)Plugin.Host.Menu.SetStatus("Pre-song practice unavailable; playing with saved learning.");
                            break;
                        }
                        yield return null;
                    }
                    // Resolve the unchanged replay graph before audio starts.
                    // Pattern retrieval used to run inside saber updates, where
                    // even a single 20-30ms search dropped several VR frames.
                    double end=session.mapNotes.Count==0 ? 1 : session.mapNotes[session.mapNotes.Count-1].time+5;
                    double time=session.PracticeStart;
                    while(available && Current==session && time<=end)
                    {
                        long slice=System.Diagnostics.Stopwatch.GetTimestamp();
                        do
                        {
                            session.body.Motion.PrepareUntil(time);time+=1;
                        } while(time<=end && System.Diagnostics.Stopwatch.GetTimestamp()-slice<System.Diagnostics.Stopwatch.Frequency/350);
                        session.view.UpdatePreSongStatus(new PreSongStatus{Percent=(int)(100*Math.Min(1,(time-session.PracticeStart)/Math.Max(1,end-session.PracticeStart))),Phase="Preparing continuous playback...",Pass="playback preparation",SimulatedSpeed="cached motion",Confidence="saved learning",Readiness="preparing"});
                        yield return null;
                    }
                }
                finally
                {
                    if(session.pretraining!=null && session.pretraining.Done) session.SavePretrained();
                    if (session.pretraining != null) session.pretraining.Dispose();
                    session.pretraining = null;
                    session.view.EndPreSong();
                    if (Current == session){session.ApplyPretrainedPlans();session.collection.PreparePlayback();}
                }
            }
            if(Current!=null) Current.songStarted=true;
        }

        internal static void EndOwner(StandardLevelGameplayManager owner)
        {
            if (Current != null && Current.owner == owner) Stop("Attempt ended");
        }

        internal static void CancelAutoRestart()
        {AutoRestartRequested=false;AutoRestartStatus=null;autoRestartStreak=0;autoRestartKey=null;}

        internal static void ReviewAutoRestart(LevelCompletionResults result)
        {
            AutoRestartRequested=false;
            AutoRestartStatus=null;
            Session current=Current;
            if(current==null || current.Multiplayer || current.watching || !Settings.Current.AutoRestartGoal95 || Plugin.Host==null || !Plugin.Host.Menu.Enabled) return;
            if(result==null || result.levelEndAction!=LevelCompletionResults.LevelEndAction.None)
            {CancelAutoRestart();return;}
            if(prepared.practiceSettings!=null || current.maximumScore<=0 || current.scorer==null)
            {CancelAutoRestart();Plugin.Log.Info("Auto-restart skipped: full-level accuracy unavailable.");return;}
            double accuracy=result.levelEndStateType==LevelCompletionResults.LevelEndStateType.Cleared
                ? (double)current.scorer.multipliedScore/current.maximumScore : 0;
            GoalStep step=AutoRestartPolicy.Evaluate(autoRestartStreak,accuracy,true,Settings.TrainingTargetPercent);
            if(!step.Restart && !step.Reached)
            {CancelAutoRestart();Plugin.Log.Warn("Auto-restart skipped: invalid measured accuracy.");return;}
            autoRestartStreak=step.Streak;
            AutoRestartRequested=step.Restart;
            AutoRestartStatus=AutoRestartPolicy.Status(step,accuracy,Settings.TrainingTargetPercent);
            Plugin.Log.Info("Auto-restart goal: "+AutoRestartStatus);
            if(step.Reached) autoRestartKey=null;
        }

        internal static void Stop(string reason)
        {
            Session current = Current;
            Current = null;
            if (current == null) return;
            try
            {
            foreach(var hand in current.hands.Values)if(hand.PendingPlan!=null){hand.PendingPlan.Dispose();hand.PendingPlan=null;}
            Plugin.BotReplayEnded();
            if (current.pause != null) { current.pause.didPauseEvent -= current.Paused; current.pause.didResumeEvent -= current.Resumed; }
            // Restore camera and tracked-head control before any disk IO can fail.
            try { current.view.Dispose(); }
            catch (Exception error) { Plugin.Log.Warn("View cleanup: " + error.Message); }
            if (current.pretraining != null) { current.pretraining.Dispose(); current.pretraining = null; }
            if (current.player != null) current.player.ClearHeadPositionOverride();
            current.body.Dispose();
            try { current.trace.Save(); }
            catch (Exception error) { Plugin.Log.Warn("Saber trace save failed: " + error.Message); }
            try
            {
                var reports=new List<object>();
                foreach(Hand h in current.hands.Values) reports.Add(new {hand=h.Saber==null ? -1 : (int)h.Saber.saberType,
                    samples=h.ImitationMetrics.Samples,seconds=h.ImitationMetrics.MotionSeconds,
                    gripActiveSeconds=h.ImitationMetrics.GripSeconds,wristActiveSeconds=h.ImitationMetrics.WristSeconds,
                    meanGripWeight=h.ImitationMetrics.MeanGripWeight,meanWristWeight=h.ImitationMetrics.MeanWristWeight,
                    recordedSources=h.ImitationMetrics.DistinctSources,candidatesTested=h.ImitationCandidates});
                string directory=System.IO.Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","Traces");
                System.IO.Directory.CreateDirectory(directory);
                System.IO.File.WriteAllText(System.IO.Path.Combine(directory,"BeatMind-imitation-last-run.json"),
                    JsonConvert.SerializeObject(new {song=current.song,model=current.profile.Name,styleEnabled=Settings.Current.UseHumanReplayStyle,
                        motionLoaded=Plugin.HumanMotion!=null,simulatedHeadCamera=Settings.Current.SimulatedCamera,hands=reports},Formatting.Indented));
                Plugin.Log.Info("Actual saber imitation: "+JsonConvert.SerializeObject(reports));
            }
            catch(Exception error) {Plugin.Log.Warn("Imitation diagnostics: "+error.Message);}
            if (current.learning)
            {
                foreach (TrackedNote note in current.notesByData.Values)
                {
                    if (!note.AwaitingScore) continue;
                    // A completed cut without its scoring callback is not a
                    // measured score. Keep prior evidence instead of guessing.
                    note.AwaitingScore = false;
                    current.dirty = true;
                }
            }
            foreach (Hand hand in current.hands.Values)
            {
                if (hand.Saber == null) continue;
                hand.Saber.transform.localPosition = hand.OriginalLocalPosition;
                hand.Saber.transform.localRotation = hand.OriginalLocalRotation;
            }
            if(current.generalDirty)
            {
                try { Plugin.Store.Save(current.generalMemory); }
                catch(Exception error) { Plugin.Log.Warn("Could not save general skills: "+error.Message); }
            }
            if (current.dirty)
            {
                if (current.learnedRealCut) current.memory.Attempts++;
                current.memory.LastGood = current.good;
                current.memory.LastBad = current.bad;
                current.memory.LastMissed = current.missed;
                current.memory.BestGood = Math.Max(current.memory.BestGood, current.good);
                try { Plugin.Store.Save(current.memory); }
                catch (Exception error)
                {
                    Plugin.Log.Error("Could not save learning: " + error);
                    if (Plugin.Host != null) Plugin.Host.Menu.SetStatus("Learning save failed. Check the log and disk space.");
                    return;
                }
            }
            string average = current.scorePossible > 0
                ? " Avg cut " + Math.Round(115.0 * current.scoreTotal / current.scorePossible) + "/115."
                : "";
            string status = reason + ": " + current.good + " good, " + current.bad + " bad, " + current.missed + " missed." + average
                + (current.learning && current.dirty ? " Learning saved." : "");
            Plugin.Log.Info(status);
            Plugin.Log.Info("Bad-cut diagnostics: wrong direction="+current.badDirection+
                "; insufficient speed="+current.badSpeed+"; wrong saber="+current.badSaber+
                "; early="+current.badEarly+". A cut may have multiple reasons.");
            Plugin.Log.Info("Motion diagnostics: furthest requested hand reach "
                + current.furthestRequestedReach.ToString("0.00", CultureInfo.InvariantCulture)
                + "m; arm-limited frames " + current.armClampFrames
                + "; body-limited frames " + current.bodyClampFrames + ".");
            foreach (Hand hand in current.hands.Values)
            {
                Plugin.Log.Info("Saber motion: peak hand speed " + hand.PeakSpeed.ToString("0.0", CultureInfo.InvariantCulture)
                    + "m/s; peak turn " + hand.PeakAngularSpeed.ToString("0", CultureInfo.InvariantCulture)
                    + "deg/s; no contact-time warps.");
                Plugin.Log.Info("Motion continuity: measured hand acceleration " + hand.PeakAcceleration.ToString("0.0",CultureInfo.InvariantCulture)
                    + "m/s^2; hand jerk " + hand.PeakJerk.ToString("0",CultureInfo.InvariantCulture)
                    + "m/s^3; wrist acceleration " + hand.PeakAngularAcceleration.ToString("0",CultureInfo.InvariantCulture)
                    + "deg/s^2; wrist jerk " + hand.PeakAngularJerk.ToString("0",CultureInfo.InvariantCulture)
                    + "deg/s^3; maximum target error " + hand.PeakTargetStep.ToString("0.000",CultureInfo.InvariantCulture) + "m.");
            }
            foreach(Hand h in current.hands.Values)
                Plugin.Log.Info("Phrase motion: plans="+h.Replans+"; candidates="+h.CandidateEvaluations+
                    "; tip speed="+h.PeakTipSpeed.ToString("0.0",CultureInfo.InvariantCulture)+
                    "m/s; tip/grip travel="+(h.TipTravel/Math.Max(.001,h.GripTravel)).ToString("0.00",CultureInfo.InvariantCulture)+
                    "; grip jerk="+h.PeakGripJerk.ToString("0",CultureInfo.InvariantCulture)+
                    "; correction reversals="+h.CorrectionReversals+
                    "; mean plan ms="+(h.PlanMilliseconds/Math.Max(1,h.Replans)).ToString("0.00",CultureInfo.InvariantCulture)+
                    "; peak plan ms="+h.PeakPlanMilliseconds.ToString("0.00",CultureInfo.InvariantCulture)+
                    "; peak planning slice ms="+h.PeakPlanSliceMilliseconds.ToString("0.00",CultureInfo.InvariantCulture));
            Plugin.Log.Info("Arm motor peaks: " + current.body.PeakJointSpeed.ToString("0",CultureInfo.InvariantCulture)
                + "deg/s; " + current.body.PeakJointAcceleration.ToString("0",CultureInfo.InvariantCulture)
                + "deg/s^2; " + current.body.PeakJointJerk.ToString("0",CultureInfo.InvariantCulture) + "deg/s^3.");
            Plugin.Log.Info("AI peak memory collection ms="+current.collection.PeakCollectionMilliseconds.ToString("0.00",CultureInfo.InvariantCulture));
            Plugin.Log.Info("AI playback memory collection: full cycles="+current.collection.PlaybackFullCollections+"; peak ms="+current.collection.PeakPlaybackCollectionMilliseconds.ToString("0.00",CultureInfo.InvariantCulture));
            Plugin.Log.Info("AI deferred memory: peak growth MB="+(current.collection.PeakDeferredPlaybackBytes/1048576)+"; stopped-clock safety collections="+current.collection.StoppedMaintenanceCollections);
            Plugin.Log.Info(current.frameStalls.Summary());
            if (Plugin.Host != null) Plugin.Host.Menu.SetStatus(status);
            if (Plugin.Host != null) Plugin.Host.Menu.InvalidatePredictions();
            }
            finally { current.collection.Dispose(); }
        }

        internal void Add(NoteController note)
        {
            if (note == null || note.noteData == null || !note.gameObject.activeInHierarchy || notes.ContainsKey(note)) return;
            NoteData data = note.noteData;
            int color = (int)data.colorType;
            if (color < 0 || color > 1) return; // Bombs are never intentional targets.
            TrackedNote tracked=MovementNote(data);
            tracked.Controller=note;notes[note]=tracked;
        }
        private TrackedNote MovementNote(NoteData data)
        {
            TrackedNote existing;
            if(notesByData.TryGetValue(data,out existing)) return existing;
            int color=(int)data.colorType;
            string key = NoteKey(data);
            int mapIndex=IndexFor(data);
            if(mapIndex>=0) key=NoteKey(mapNotes[mapIndex]);
            if (mapIndex >= 0 && notesByIndex.TryGetValue(mapIndex, out existing))
            {
                // A spawned controller can carry a different NoteData instance than
                // the chart preview. Both must keep the same planned contact.
                notesByData[data] = existing;
                return existing;
            }
            NoteMemory legacy; memory.Notes.TryGetValue(key, out legacy);
            NoteMemory timing = modelMemory.Note(key, legacy, learning);
            string context = PatternContext(data, mapIndex, key);
            BehaviorMemory behavior = modelMemory.Behavior(context, learning);
            // Keep existing successful contact controls. New movement learning
            // is supervised imitation of human replay transitions; it no longer
            // tries low/high body and wrist settings after live cut rewards.
            BehaviorChoice chosen=BehaviorOptimizer.Choose(behavior,profile,false,context);
            if(behavior.Visits==0 && profile.Dimensions>0)
            {
                BehaviorChoice prior=BehaviorOptimizer.Choose(
                    generalModel.Behavior(GeneralContext(data,mapIndex),false),profile,false,context);
                for(int axis=0;axis<profile.Dimensions;axis++)
                    if(axis!=chosen.Axis) chosen.Values[axis]=prior.Values[axis];
            }
            TrackedNote tracked = new TrackedNote {
                Data=data, Key = key, Time = data.time, Color = color,
                Timing = timing, BehaviorData = behavior, MapIndex = mapIndex,
                Behavior = chosen,
                Variant = Policy.Choose(timing, learning,Settings.Current.TrainToAccuracyPercent/100.0), Style = 0
            };
            ApplyPretrainedPlan(tracked);
            ApplyBestDecision(tracked);
            if (mapIndex >= 0)
            {
                float spacing=1.2f;
                for (int i=mapIndex-1;i>=0;i--) if ((int)mapNotes[i].colorType==color)
                { spacing=Mathf.Min(spacing,Mathf.Max(.04f,data.time-mapNotes[i].time)); break; }
                for (int i=mapIndex+1;i<mapNotes.Count;i++) if ((int)mapNotes[i].colorType==color)
                { spacing=Mathf.Min(spacing,Mathf.Max(.04f,mapNotes[i].time-data.time)); break; }
                tracked.Spacing=spacing;
                tracked.LocalNps=LocalNotesPerSecond(mapNotes,mapIndex);
                tracked.Pattern=DotFlow.Pattern(mapNotes,mapIndex,NoArrows);
            }
            notesByData[data] = tracked;
            if (mapIndex >= 0) notesByIndex[mapIndex] = tracked;
            Vector3 origin=body.Origin;
            Quaternion mapRotation=Quaternion.AngleAxis(data.rotation,Vector3.up);
            tracked.Center=origin+mapRotation*(body.MapPoint(data.lineIndex,(int)data.noteLineLayer)-origin);
            tracked.Forward=mapRotation*body.Forward;
            Vector3 right=Vector3.Cross(Vector3.up,tracked.Forward);
            tracked.Direction=Quaternion.AngleAxis(data.cutDirectionAngleOffset,tracked.Forward)*
                (mapIndex>=0 ? DotFlow.Direction(mapNotes,mapIndex,right,NoArrows) : PreSongTrainer.CutDirection(data.cutDirection,right));
            tracked.HasPose=true;
            return tracked;
        }

        // Count both colors in a full one-second chart window. At the start
        // and end, slide the window inward rather than undercounting streams.
        internal static float LocalNotesPerSecond(IList<NoteData> chart,int index)
        {
            if(chart==null || index<0 || index>=chart.Count) return 0;
            float latest=chart[chart.Count-1].time;
            float start=Mathf.Clamp(chart[index].time-.5f,0,Mathf.Max(0,latest-1));
            int count=0;
            for(int i=index;i>=0 && chart[i].time>=start;i--) count++;
            for(int i=index+1;i<chart.Count && chart[i].time<start+1;i++) count++;
            return count;
        }
        private void ApplyPretrainedPlans()
        {
            foreach(TrackedNote note in notesByIndex.Values)
            {
                note.Plan=Vector3.zero; note.Planned=false;
                ApplyPretrainedPlan(note);
                ApplyBestDecision(note);
            }
            PrepareContactSchedule();
        }
        private void PrepareContactSchedule()
        {
            var ordered=new List<TrackedNote>(mapNotes.Count);
            foreach(NoteData data in mapNotes)ordered.Add(MovementNote(data));
            ResolveContactSchedule(ordered);
        }
        internal static void ResolveContactSchedule(IList<TrackedNote> ordered)
        {
            var times=new double[ordered.Count];var hands=new int[ordered.Count];var offsets=new double[ordered.Count];
            for(int i=0;i<ordered.Count;i++)
            {times[i]=ordered[i].Time;hands[i]=ordered[i].Color;offsets[i]=Policy.Variants[ordered[i].Variant].Offset;}
            var hits=CutSchedule.Resolve(times,hands,offsets);
            for(int i=0;i<ordered.Count;i++){ordered[i].ScheduledHit=hits[i];ordered[i].HasScheduledHit=true;}
        }
        internal void ApplyBestDecision(TrackedNote note)
        {
            if(!learning || bestReplay==null || bestReplay.Decisions==null || note.MapIndex<0) return;
            // Keep most successful choices from the best full run. Rotate an
            // exploration slot through the chart on each new attempt so real
            // cut feedback can still find a better run.
            if((note.MapIndex+memory.Attempts)%5==0) return;
            ReplayChoice choice;
            if(!bestReplay.Decisions.TryGetValue(note.Key,out choice) || choice==null || !choice.Good || choice.CutScore<95 ||
                choice.Variant<0 || choice.Variant>=Policy.Variants.Length) return;
            if(note.Timing!=null && !Policy.ReuseReplayStroke(note.Timing,choice.Variant,Settings.Current.TrainToAccuracyPercent/100.0))return;
            note.Variant=choice.Variant;
            if(choice.Behavior!=null && choice.Behavior.Length==note.Behavior.Values.Length)
            { note.Behavior.Values=(float[])choice.Behavior.Clone(); note.Behavior.Axis=-1; }
        }
        private void ApplyPretrainedPlan(TrackedNote tracked)
        {
            PretrainedPlan saved;
            if (modelMemory.Pretrained != null && modelMemory.Pretrained.TryGetValue(tracked.Key,out saved)
                && saved != null && saved.Validations > 0 && saved.Confidence >= .35f)
            {
                bool measured=false;
                foreach(int trials in tracked.Timing.Trials) if(trials>0) { measured=true;break; }
                if(learning && !measured && saved.Variant>=0 && saved.Variant<Policy.Variants.Length)
                    tracked.Variant=saved.Variant;
                if(saved.Variant<0 || saved.Variant==tracked.Variant)
                {
                    tracked.Plan = saved.MotionVersion==2 ? new Vector3(0,0,Mathf.Clamp(saved.Z,-.06f,.06f)) : Vector3.zero;
                    tracked.Planned = true;
                }
            }
        }

        internal void Remove(NoteController note)
        {
            if (note == null) return;
            TrackedNote tracked;
            if (notes.TryGetValue(note, out tracked) && tracked.Controller == note)
                tracked.Controller = null;
            notes.Remove(note);
        }

        private string PatternContext(NoteData data, int index, string key)
        {
            if (profile.Dimensions < 8 || index < 0) return key;
            // Recurring patterns share movement feedback; note timing stays specific
            // to this exact note. Only the advanced models generalize this way.
            string context = "pattern:" + (int)data.colorType + ":" + (int)data.cutDirection;
            NoteData previous = data;
            for (int i = index + 1, found = 0; i < mapNotes.Count && found < profile.LookAhead - 1; i++)
            {
                NoteData next = mapNotes[i]; if (next.colorType != data.colorType) continue;
                float gap = next.time - previous.time;
                if (gap > 1.6f) break;
                context += "/" + (int)next.cutDirection + ":" + Mathf.Clamp(Mathf.RoundToInt(gap * 8),0,12)
                    + ":" + Math.Sign(next.lineIndex - previous.lineIndex) + ":" + Math.Sign((int)next.noteLineLayer - (int)previous.noteLineLayer);
                previous = next; found++;
            }
            return context;
        }
        internal void Tick()
        {
            if(!songStarted || paused || clock==null){frameStalls.Reset();TickCore();return;}
            if(lastTickFrame==Time.frameCount){TickCore();return;}
            long start=System.Diagnostics.Stopwatch.GetTimestamp();
            frameStalls.Begin(Time.frameCount,start,System.Diagnostics.Stopwatch.Frequency,clock.songTime,GC.CollectionCount(0));
            try{TickCore();}
            finally{frameStalls.TickDuration((System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency);}
        }
        private void TickCore()
        {
            collection.EnsureEnabled();
            if(!songStarted) { collection.Tick(Time.frameCount,Time.unscaledTime,false);view.Tick(0,0); return; }
            if (clock == null || lastTickFrame == Time.frameCount) return;
            lastTickFrame = Time.frameCount;
            float now = clock.songTime;
            int memoryCursor=focusCursor;while(memoryCursor<mapNotes.Count && mapNotes[memoryCursor].time<now)memoryCursor++;
            double lastEvent=memoryCursor==0 ? double.NegativeInfinity : mapNotes[memoryCursor-1].time;
            double nextEvent=memoryCursor==mapNotes.Count ? double.PositiveInfinity : mapNotes[memoryCursor].time;
            long collectionStart=System.Diagnostics.Stopwatch.GetTimestamp();
            collection.Tick(Time.frameCount,Time.unscaledTime,!paused,now-lastEvent>.4 && nextEvent-now>.55);
            if(!paused && collection.NeedsStoppedCollection)
            {
                // Rare high memory pressure, not the old two-second timer.
                // Full GC never consumes a live song interval or skips notes.
                clock.Pause();
                try{collection.CollectWithStoppedClock(true);}
                finally{clock.Resume();}
            }
            frameStalls.CollectionDuration((System.Diagnostics.Stopwatch.GetTimestamp()-collectionStart)*1000.0/System.Diagnostics.Stopwatch.Frequency);
            float delta = float.IsNaN(lastSongTime) ? .016f : Mathf.Clamp(now - lastSongTime, 0, .05f);
            lastSongTime = now;
            if (delta > 0 && !paused)
            {
                if(watching)
                {
                    ReplayPose pose=bestReplay.Pose(now,0);
                    if(pose!=null) body.Head.SetPositionAndRotation(new Vector3(pose.X,pose.Y,pose.Z),
                        new Quaternion(pose.Qx,pose.Qy,pose.Qz,pose.Qw));
                    body.ApplyPlayerPose(player);
                    view.SetGameplayStatus("Watching best run | " + (bestReplay.Result.RawScore*100.0/bestReplay.Result.Maximum)
                        .ToString("0.00",CultureInfo.InvariantCulture)+"%");
                    view.Tick(completedNotes,totalNotes);
                    return;
                }
                while (focusCursor < mapNotes.Count && mapNotes[focusCursor].time < now - .03f) focusCursor++;
                double previous = focusCursor == 0 ? double.NegativeInfinity : mapNotes[focusCursor-1].time;
                double next = focusCursor == mapNotes.Count ? double.PositiveInfinity : mapNotes[focusCursor].time;
                breakStrength=(float)BreakTiming.Strength(now,previous,next);
                Vector3 focus = Vector3.zero; float weight = 0; BehaviorChoice behavior = baseline;
                for (int i = focusCursor, count = 0; i < mapNotes.Count && count < profile.LookAhead; i++, count++)
                {
                    NoteData note = mapNotes[i]; float ahead = note.time - now;
                    if (ahead > 1.6f) break;
                    float w = 1f / (1 + count + Mathf.Max(0, ahead) * 2);
                    TrackedNote tracked;
                    Vector3 center = body.MapPoint(note.lineIndex, (int)note.noteLineLayer);
                    if (notesByData.TryGetValue(note, out tracked))
                    { if (tracked.HasPose) center = tracked.Center; if (count == 0) behavior = tracked.Behavior; }
                    focus += center * w; weight += w;
                }
                if (weight == 0) focus = body.Head.position + body.Forward * 2; else focus /= weight;
                body.Tick(now, focus, behavior, Mathf.Clamp(Time.deltaTime,.001f,.05f),breakStrength);
                body.ApplyPlayerPose(player);
                view.SetGameplayStatus(profile.Name+" | "+completedNotes+"/"+totalNotes+
                    (breakStrength>.5f ? " | break" : "")+
                    (bestReplay==null ? "" : " | best "+(bestReplay.Result.RawScore*100.0/bestReplay.Result.Maximum)
                        .ToString("0.0",CultureInfo.InvariantCulture)+"%"));
            }
            view.Tick(completedNotes, totalNotes);
        }
        private void Paused()
        {
            frameStalls.Reset();
            paused = true; view.SetPaused(true);
            if (player != null) player.ClearHeadPositionOverride();
            foreach (Hand hand in hands.Values)
            {
                if (hand.Saber == null) continue;
                hand.Saber.transform.localPosition = hand.OriginalLocalPosition;
                hand.Saber.transform.localRotation = hand.OriginalLocalRotation;
            }
        }
        private void Resumed()
        {
            paused = false; view.SetPaused(false); lastSongTime = clock.songTime;
            foreach (Hand hand in hands.Values)
            {
                if (hand.Saber == null) continue;
                hand.LastPosition = hand.Saber.transform.position; hand.LastRotation = hand.Saber.transform.rotation;
                hand.LastMotionSongTime=double.NaN;
                hand.LastCutMapIndex=-1;hand.LastCutSongTime=double.NaN;
                hand.LastVelocity = hand.AngularVelocity = Vector3.zero; hand.Target = null;
                hand.HasAim = false; hand.Phrase=null;hand.Desired=null;
                hand.LastAcceleration=hand.AngularAcceleration=hand.GripVelocity=hand.GripAcceleration=Vector3.zero;
                hand.GripPosition=hand.LastPosition+hand.LastRotation*hand.LocalGrip;
                body.SeedArm((int)hand.Saber.saberType,hand.GripPosition,hand.LastRotation,hand.LocalAxis,baseline);
            }
        }
        internal void ApplyBody() { if (songStarted && !paused) body.ApplyPlayerPose(player); }
        internal void CaptureResult(LevelCompletionResults result)
        {
            if (recorded || watching || result == null || result.levelEndStateType != LevelCompletionResults.LevelEndStateType.Cleared) return;
            // Practice starts part-way through a chart. Until an exact compatible
            // denominator is available, don't turn those results into predictions.
            if (prepared.practiceSettings != null || scorer == null) return;
            // BS Utils intentionally negates the result object's raw score as
            // submission insurance. Read the real live scorer without undoing it.
            var measured=new MeasuredRun { Score = scorer.modifiedScore, RawScore = scorer.multipliedScore,
                Maximum = maximumScore, Good = result.goodCutsCount, Bad = result.badCutsCount,
                Missed = result.missedCount, Training = learning, Completed = true };
            modelMemory.Record(measured);
            if(recording!=null)
            {
                recording.Result=measured;
                try
                {
                    if(Plugin.Replays.SaveIfBetter(recording))
                        Plugin.Log.Info("New best measured replay retained: "+measured.RawScore+" raw points.");
                }
                catch(Exception error) { Plugin.Log.Warn("Best replay save failed: "+error.Message); }
            }
            dirty = true;
            recorded = true;
        }
        internal void RecordFrame()
        {
            if(recording==null || !songStarted || paused || clock==null) return;
            float now=clock.songTime;
            if(now<0 || now-lastReplayFrame<1f/120 || recording.Frames.Count>=200000) return;
            var frame=new ReplayFrame { Time=now,Head=CapturePose(body.Head.position,body.Head.rotation) };
            foreach(Hand hand in hands.Values)
            {
                if(!hand.HasPose || hand.Saber==null) continue;
                ReplayPose pose=CapturePose(hand.LastPosition,hand.LastRotation);
                if((int)hand.Saber.saberType==0) frame.Left=pose; else frame.Right=pose;
            }
            if(frame.Left==null && frame.Right==null) return;
            recording.Frames.Add(frame);lastReplayFrame=now;
        }
        private static ReplayPose CapturePose(Vector3 p,Quaternion q)
        { return new ReplayPose {X=p.x,Y=p.y,Z=p.z,Qx=q.x,Qy=q.y,Qz=q.z,Qw=q.w}; }
        private void Learn(TrackedNote note, double reward)
        {
            if (!learning) return;
            learnedRealCut=true;
            Policy.Observe(note.Timing, note.Variant, reward);
            if(note.Data!=null)
            {
                string context=GeneralContext(note.Data,note.MapIndex);
                Policy.Observe(generalModel.Note(context,null,true),note.Variant,reward);
                generalDirty=true;
            }
            dirty = true;
        }

        internal void Observe(NoteController note, bool cut, NoteCutInfo info)
        {
            TrackedNote target;
            if (!notes.TryGetValue(note, out target) || target.Resolved) return;
            target.Resolved = true;
            if(cut && clock!=null)
                foreach(Hand hand in hands.Values)
                    if(hand.Saber!=null && hand.Saber.saberType==info.saberType)
                    {hand.LastCutMapIndex=target.MapIndex;hand.LastCutSongTime=clock.songTime;}
            bool success = cut && info.allIsOK;
            if(recording!=null && target.Key!=null)
                recording.Decisions[target.Key]=new ReplayChoice {Variant=target.Variant,
                    Behavior=target.Behavior==null || target.Behavior.Values==null ? null : (float[])target.Behavior.Values.Clone(),
                    Good=success};
            if (success) good++; else if (cut) bad++; else missed++;
            if(cut && !success)
            {
                if(!info.directionOK) badDirection++;
                if(!info.speedOK) badSpeed++;
                if(!info.saberTypeOK) badSaber++;
                if(info.wasCutTooSoon) badEarly++;
                if(bad<=12) Plugin.Log.Info("Bad cut note="+target.MapIndex+
                    "; dirOK="+info.directionOK+"; speedOK="+info.speedOK+
                    "; saberOK="+info.saberTypeOK+"; early="+info.wasCutTooSoon+
                    "; cut angle="+info.cutAngle.ToString("0",CultureInfo.InvariantCulture)+
                    "; arrow deviation="+info.cutDirDeviation.ToString("0",CultureInfo.InvariantCulture)+
                    "; speed="+info.saberSpeed.ToString("0.0",CultureInfo.InvariantCulture)+
                    "; local NPS="+target.LocalNps.ToString("0",CultureInfo.InvariantCulture));
            }
            if (success)
            {
                target.AwaitingScore = true;
            }
            else { Learn(target, 0); completedNotes++; }
        }

        internal void ObserveScore(NoteData data, int score, int possible)
        {
            TrackedNote target;
            if (data == null || !notesByData.TryGetValue(data, out target) || !target.AwaitingScore) return;
            target.AwaitingScore = false;
            completedNotes++;
            if (possible > 0)
            {
                scoredCuts++;
                scoreTotal += Math.Max(0, Math.Min(possible, score));
                scorePossible += possible;
            }
            ReplayChoice replayChoice;
            if(recording!=null && recording.Decisions.TryGetValue(target.Key,out replayChoice) && replayChoice!=null)
                replayChoice.CutScore=score;
            if (learning && possible>0)
            {
                double reward = Math.Max(0, Math.Min(1, (double)score / possible));
                Learn(target, reward);
            }
        }

        internal void Move(Saber saber)
        {
            if (!songStarted || paused || clock == null || saber == null || !OwnsSaber(saber) || !saber.gameObject.activeInHierarchy) return;
            Tick();
            long start=System.Diagnostics.Stopwatch.GetTimestamp();
            try{MoveCore(saber);}
            finally{frameStalls.MoveDuration((System.Diagnostics.Stopwatch.GetTimestamp()-start)*1000.0/System.Diagnostics.Stopwatch.Frequency);}
        }
        private void MoveCore(Saber saber)
        {
            if (clock.lastFrameDeltaSongTime <= 0) return;
            int color=(int)saber.saberType; Hand hand;
            if(!hands.TryGetValue(saber,out hand))
            {
                Transform top=(Transform)BladeTop.GetValue(saber),bottom=(Transform)BladeBottom.GetValue(saber);
                Vector3 localTop=saber.transform.InverseTransformPoint(top.position),localBottom=saber.transform.InverseTransformPoint(bottom.position);
                hand=new Hand {Saber=saber,OriginalLocalPosition=saber.transform.localPosition,OriginalLocalRotation=saber.transform.localRotation,
                    LocalAxis=(localTop-localBottom).normalized,LocalBladeTop=localTop,LocalBladeBottom=localBottom,
                    LocalContact=Vector3.Lerp(localBottom,localTop,.65f),LocalGrip=saber.transform.InverseTransformPoint(((Transform)GripTransform.GetValue(saber)).position),
                    LastPosition=saber.transform.position,LastRotation=saber.transform.rotation,HasPose=true};
                hands[saber]=hand;body.ConfigureSaber(color,hand.LocalGrip);
                hand.GripPosition=hand.LastPosition+hand.LastRotation*hand.LocalGrip;
                body.SeedArm(color,hand.GripPosition,hand.LastRotation,hand.LocalAxis,baseline);
                // Seed from the actual FK endpoint so first-frame derivatives do
                // not include the initial IK projection as hand acceleration.
                hand.GripPosition=body.Hands[color].position;
                hand.LastPosition=hand.GripPosition-hand.LastRotation*hand.LocalGrip;
                hand.LastTip=hand.LastPosition+hand.LastRotation*hand.LocalBladeTop;
            }
            if(hand.LastMotionFrame==Time.frameCount)
            {saber.OverridePositionAndRotation(hand.LastPosition,hand.LastRotation);return;}
            hand.LastMotionFrame=Time.frameCount;
            float now=clock.songTime;TrackedNote target=null;
            if(watching)
            {
                ReplayPose pose=bestReplay.Pose(now,color+1);
                if(pose!=null)
                {
                    hand.LastPosition=new Vector3(pose.X,pose.Y,pose.Z);
                    hand.LastRotation=new Quaternion(pose.Qx,pose.Qy,pose.Qz,pose.Qw);
                    body.Hands[color].SetPositionAndRotation(hand.LastPosition+hand.LastRotation*hand.LocalGrip,hand.LastRotation);
                    saber.OverridePositionAndRotation(hand.LastPosition,hand.LastRotation);
                }
                return;
            }
            hand.BreakStrength=breakStrength;
            foreach(TrackedNote note in notes.Values)
            {
                if(note.Resolved || note.Color!=color || note.Controller==null || note.Controller.dissolving) continue;
                double hit=note.HitTime;
                if(hit<now-.14f || hit>now+1.6f) continue;
                if(target==null || note.Time<target.Time) target=note;
            }
            if(hand.Target!=target) {hand.Target=target;hand.TargetChanged=true;}
            if(body.Motion!=null && hand.MotionRevision!=body.Motion.Revision)hand.ContactGeometryChanged=true;
            RefreshLiveGeometry(hand,now,color);
            if(MovementPlanner.NeedsPlan(hand,now,body,true))
            {
                var future=new List<TrackedNote>();
                for(int i=Mathf.Max(0,focusCursor-2);i<mapNotes.Count;i++)
                {
                    NoteData data=mapNotes[i];if((int)data.colorType!=color) continue;
                    if(data.time>now+3f) break;
                    TrackedNote note=MovementNote(data);if(note.Resolved) continue;
                    if(note.HitTime<now-.03f)continue;
                    if(note.Controller!=null) UpdatePose(note);
                    future.Add(note);if(future.Count>=64) break;
                }
                MovementPlanner.Plan(hand,body,color,now,future,profile,true);
            }
            MovementPlanner.Advance(hand,body,now);
            Vector3 position;Quaternion rotation;
            MovementPlanner.Sample(hand,now,out position,out rotation);
            SetPose(hand,position,rotation,0,2100,target);
        }

        private void RefreshLiveGeometry(Hand hand,float now,int color)
        {
            // A spawned controller arrives after approximate map contacts have
            // often been planned. Compare the new native pose with committed
            // geometry, rather than comparing two copies of the stale proxy.
            foreach(TrackedNote note in notes.Values)
            {
                if(note.Resolved || note.Color!=color || note.Controller==null || note.Controller.dissolving)continue;
                double hit=note.HitTime;
                if(hit<now-.14 || hit>now+3)continue;
                UpdatePose(note);
                if(hand.Phrase==null || hit>hand.Phrase.RefreshTime)continue;
                PhraseState contact=hand.Phrase.Contact(note.MapIndex);
                if(ContactGeometry.Changed(contact,hit,MovementPlanner.V(note.Center),MovementPlanner.V(note.Direction),now))
                    hand.ContactGeometryChanged=true;
            }
        }

        private TrackedNote NextVisual(TrackedNote current,int color,float now)
        {
            TrackedNote next=null;
            foreach(TrackedNote note in notes.Values)
            {
                if(note.Resolved || note.Color!=color || note.Controller==null || note.Controller.dissolving) continue;
                if(current!=null && note.Time<=current.Time+.0001f) continue;
                if(note.Time<=now || note.Time>now+3f) continue;
                if(next==null || note.Time<next.Time) next=note;
            }
            return next;
        }

        private void UpdatePose(TrackedNote note)
        {
            if (note.Resolved || note.Controller == null) return;
            if(note.LastPoseFrame==Time.frameCount)return;
            note.LastPoseFrame=Time.frameCount;
            Transform visual = note.Controller.noteTransform;
            NoteMovement movement = NoteMovementField == null ? null
                : (NoteMovement)NoteMovementField.GetValue(note.Controller);
            NoteJump jump = movement == null || JumpField == null ? null
                : (NoteJump)JumpField.GetValue(movement);
            Vector3 localHit = note.Controller.beatPos;
            if (jump != null && JumpProviderField != null && JumpStartOffsetField != null
                && JumpEndOffsetField != null && JumpGravityBaseField != null)
            {
                IVariableMovementDataProvider provider =
                    (IVariableMovementDataProvider)JumpProviderField.GetValue(jump);
                if (provider != null && provider.halfJumpDuration > .001f)
                {
                    Vector3 start = provider.moveEndPosition + (Vector3)JumpStartOffsetField.GetValue(jump);
                    Vector3 end = provider.jumpEndPosition + (Vector3)JumpEndOffsetField.GetValue(jump);
                    float half = provider.halfJumpDuration;
                    float gravity = provider.CalculateCurrentNoteJumpGravity((float)JumpGravityBaseField.GetValue(jump));
                    // Contacts retain their learned timing offset. Predict the
                    // cube at that actual contact time rather than using the
                    // nominal midpoint: 20 ms at 20 m/s is a 40 cm difference.
                    double offset=note.HitTime-note.Time;
                    double endDistance=JumpEndDistanceField==null ? 0 : (float)JumpEndDistanceField.GetValue(jump);
                    localHit=MovementPlanner.V(ContactGeometry.JumpCenter(MovementPlanner.V(start),MovementPlanner.V(end),half,gravity,offset,endDistance));
                }
            }
            Transform parent = jump == null ? null : jump.transform.parent;
            Vector3 hitPoint=note.Controller.worldRotation*localHit;
            Vector3 worldHit=parent==null ? hitPoint : parent.TransformPoint(hitPoint);
            // Use the actual jump transform as the current reference. Its
            // movement data can lag one update behind the rendered cube.
            Vector3 visualOffset=jump==null ? Vector3.zero : visual.position-jump.transform.position;
            note.Center=jump==null ? visual.position : worldHit+visualOffset;
            note.Forward = (parent==null ? note.Controller.worldRotation : parent.rotation*note.Controller.worldRotation) * Vector3.forward;
            // The cube's transform includes visual animation. Its local down
            // is not a reliable instruction for every arrow. Use the actual
            // cut-direction metadata in the live level frame, as in training.
            Vector3 right=Vector3.Cross(Vector3.up,note.Forward);
            note.Direction=Quaternion.AngleAxis(note.Controller.noteData.cutDirectionAngleOffset,note.Forward)
                *(note.MapIndex>=0 ? DotFlow.Direction(mapNotes,note.MapIndex,right,NoArrows)
                    : PreSongTrainer.CutDirection(note.Controller.noteData.cutDirection,right));
            note.Direction.Normalize();
            note.HasPose = true;
            lastForward = note.Forward;
        }

        private float Rhythm(TrackedNote note)
        { return 1-Mathf.SmoothStep(0,1,Mathf.InverseLerp(.13f,.65f,note.Spacing/Mathf.Max(.25f,clock.timeScale))); }
        internal float FollowDuration(TrackedNote target,TrackedNote next)
        { return Mathf.Clamp(target.Spacing*.30f*target.Behavior.Follow,.018f,.16f); }

        private void SetPose(Hand hand, Vector3 position, Quaternion rotation, float maxSpeed, float maxDegrees, TrackedNote preview = null)
        {
            int color = (int)hand.Saber.saberType;
            float now=clock.songTime;
            float delta=(float)MotionSampling.Delta(now,hand.LastMotionSongTime,clock.lastFrameDeltaSongTime);
            hand.LastMotionSongTime=now;
            SimulatePose(hand,body,color,preview ?? hand.Target,position,rotation,
                delta,maxDegrees,now,true);
        }
        internal void SimulatePose(Hand hand, BodyRig rig, int color, TrackedNote motionNote,
            Vector3 position, Quaternion rotation, float delta, float maxDegrees, float songTime, bool live)
        {
            BehaviorChoice behavior = motionNote == null ? baseline : motionNote.Behavior;
            MotionContinuity.Advance(ref hand.TempoState,motionNote==null ? 0 : Rhythm(motionNote),delta,14,3,20,250);
            hand.Tempo=Mathf.Clamp01((float)hand.TempoState.Position);
            Vector3 requestedGrip = position + rotation * hand.LocalGrip;
            if (live) furthestRequestedReach = Mathf.Max(furthestRequestedReach, Vector3.Distance(requestedGrip, rig.Shoulders[color].position));
            hand.PeakTargetStep=Mathf.Max(hand.PeakTargetStep,Vector3.Distance(position,hand.LastPosition));
            Vector3 physicalGrip=rig.AdvanceArm(color,requestedGrip,hand.LastRotation,hand.LocalAxis,behavior,hand.Tempo,delta);
            float reachError = rig.LastReachError;
            if (live && reachError > .001f) armClampFrames++;
            // Publish the articulated player's physically reachable endpoint.
            Vector3 gripPosition=physicalGrip;
            Vector3 gripVelocity=(gripPosition-hand.GripPosition)/delta;
            hand.GripAcceleration=(gripVelocity-hand.GripVelocity)/delta;
            hand.GripJerk=(hand.GripAcceleration-hand.LastGripAcceleration).magnitude/delta;
            hand.PeakGripJerk=Mathf.Max(hand.PeakGripJerk,hand.GripJerk);
            hand.LastGripAcceleration=hand.GripAcceleration;
            hand.GripTravel+=Vector3.Distance(gripPosition,hand.GripPosition);
            hand.GripVelocity=gripVelocity; hand.GripPosition=gripPosition;
            Quaternion wristRequest=rotation;
            Quaternion anatomicalWrist=rig.WristTarget(color, rotation, hand.LocalAxis);
            if(Multiplayer)rotation=anatomicalWrist;
            float wristError = rig.LastWristError;
            if (live && wristError > .001f) bodyClampFrames++;
            Vector3 correction=RotationVector(rotation*Quaternion.Inverse(hand.LastRotation));
            if(correction.magnitude>5 && hand.LastCorrection.magnitude>5 && Vector3.Dot(correction.normalized,hand.LastCorrection.normalized)<-.5f)
                hand.CorrectionReversals++;
            hand.LastCorrection=correction;
            Vector3 previousAngularAcceleration=hand.AngularAcceleration;
            Vector3 previousAngularVelocity=hand.AngularVelocity;
            hand.AngularVelocity=correction/delta;
            hand.AngularAcceleration=(hand.AngularVelocity-previousAngularVelocity)/delta;
            hand.LastWristTargetDelta=hand.HasAim ? Quaternion.Angle(rotation,hand.LastAim) : 0;
            hand.LastWristFeed=hand.Desired==null ? Vector3.zero : MovementPlanner.V(hand.Desired.AngularVelocity)*(180/Mathf.PI);
            hand.LastAim=rotation;hand.HasAim=true;
            Quaternion limitedRotation = rotation;
            rig.ApplyWrist(color,limitedRotation);
            Vector3 limitedPosition = gripPosition-limitedRotation*hand.LocalGrip;
            Vector3 tip=limitedPosition+limitedRotation*hand.LocalBladeTop;
            hand.TipSpeed=Vector3.Distance(tip,hand.LastTip)/delta;
            hand.PeakTipSpeed=Mathf.Max(hand.PeakTipSpeed,hand.TipSpeed);
            hand.TipTravel+=Vector3.Distance(tip,hand.LastTip);hand.LastTip=tip;
            hand.AngularJerk=(hand.AngularAcceleration-previousAngularAcceleration).magnitude/delta;
            if (live) hand.Saber.OverridePositionAndRotation(limitedPosition, limitedRotation);
            Vector3 actualVelocity = (limitedPosition - hand.LastPosition) / delta;
            Vector3 actualAcceleration=(actualVelocity-hand.LastVelocity)/delta;
            float acceleration=actualAcceleration.magnitude;
            hand.PeakJerk=Mathf.Max(hand.PeakJerk,(actualAcceleration-hand.LastAcceleration).magnitude/delta);
            hand.PeakAcceleration=Mathf.Max(hand.PeakAcceleration,acceleration);
            hand.PeakAngularAcceleration=Mathf.Max(hand.PeakAngularAcceleration,hand.AngularAcceleration.magnitude);
            hand.PeakAngularJerk=Mathf.Max(hand.PeakAngularJerk,(hand.AngularAcceleration-previousAngularAcceleration).magnitude/delta);
            if (hand.Target != null)
            {
                double quality = 1.0 / (1 + acceleration / 350f + reachError * 12 + wristError * 2
                    + Mathf.Max(0, actualVelocity.magnitude - 8) * .2f);
                hand.Target.MotionSamples++; hand.Target.MotionQuality += quality;
            }
            hand.PeakSpeed = Mathf.Max(hand.PeakSpeed, Vector3.Distance(limitedPosition, hand.LastPosition) / delta);
            hand.PeakAngularSpeed = Mathf.Max(hand.PeakAngularSpeed,
                Quaternion.Angle(limitedRotation, hand.LastRotation) / delta);
            float saberAngle=Quaternion.Angle(limitedRotation,hand.LastRotation);
            hand.LastVelocity = actualVelocity;
            hand.LastAcceleration=actualAcceleration;
            hand.LastPosition = limitedPosition; hand.LastRotation = limitedRotation; hand.HasPose = true;
            if(live && !watching && hand.Desired!=null)
                hand.ImitationMetrics.Observe(hand.Desired,delta);
            if (live && (songTime-hand.LastTraceTime >= (Settings.Current.DebugMotionTrace ? .008f : .1f)
                || Settings.Current.DebugMotionTrace && (hand.GripVelocity.magnitude>12 || hand.AngularVelocity.magnitude>6000
                    || hand.TargetChanged || hand.RouteChanged || hand.ContactFitChanged)))
            {
                TrackedNote next=NextVisual(motionNote,color,songTime);
                Vector3 noteCenter=motionNote==null ? Vector3.zero : motionNote.Center;
                Vector3 visualCenter=motionNote==null || motionNote.Controller==null
                    ? Vector3.zero : motionNote.Controller.noteTransform.position;
                trace.Record(color,songTime,motionNote,next,hand,requestedGrip,gripPosition,
                    saberAngle,Quaternion.Angle(wristRequest,rotation),
                    Quaternion.Angle(wristRequest,limitedRotation),BladeDistance(motionNote,limitedPosition,limitedRotation,hand),
                    Vector3.Distance(physicalGrip,requestedGrip),reachError,wristError,
                    noteCenter,visualCenter,rig.Shoulders[color].position,delta,null);
                hand.LastTraceTime=songTime;
            }
            hand.TargetChanged=hand.RouteChanged=hand.ContactFitChanged=false;
        }

        private static float BladeDistance(TrackedNote note,Vector3 position,Quaternion rotation,Hand hand)
        {
            if(note==null || !note.HasPose) return -1;
            Vector3 bottom=position+rotation*hand.LocalBladeBottom;
            Vector3 blade=rotation*(hand.LocalBladeTop-hand.LocalBladeBottom);
            float fraction=Mathf.Clamp01(Vector3.Dot(note.Center-bottom,blade)/Mathf.Max(.00001f,blade.sqrMagnitude));
            return Vector3.Distance(note.Center,bottom+blade*fraction);
        }

        private static Vector3 RotationVector(Quaternion rotation)
        {
            if (rotation.w < 0) rotation = new Quaternion(-rotation.x,-rotation.y,-rotation.z,-rotation.w);
            float angle; Vector3 axis; rotation.ToAngleAxis(out angle, out axis);
            return angle < .001f || float.IsNaN(axis.x) ? Vector3.zero : axis * angle;
        }
        internal static Vector3 AngularDifference(Quaternion later, Quaternion earlier)
        { return RotationVector(later * Quaternion.Inverse(earlier)); }

        private static void ImportTimingHints(LevelMemory previous, LevelMemory current)
        {
            if (previous == null || previous.Notes == null || previous.Notes.Count == 0) return;
            int imported = 0;
            foreach (KeyValuePair<string, NoteMemory> pair in previous.Notes)
            {
                NoteMemory old = pair.Value;
                old.Normalize();
                int best = -1;
                double bestMean = -1;
                for (int i = 0; i < Policy.Variants.Length; i++)
                {
                    if (old.Trials[i] == 0) continue;
                    double mean = old.Rewards[i] / old.Trials[i];
                    if (mean > bestMean) { bestMean = mean; best = i; }
                }
                if (best < 0) continue;
                NoteMemory hint = current.Get(pair.Key);
                hint.Trials[best] = 1;
                hint.Rewards[best] = Math.Min(.80, Math.Max(.20, bestMean * .80));
                imported++;
            }
            if (imported > 0) Plugin.Log.Info("Imported " + imported + " timing hints into the human motion model.");
        }
    }
}
