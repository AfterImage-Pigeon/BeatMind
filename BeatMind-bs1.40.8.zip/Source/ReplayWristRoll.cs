using System;
namespace SaberMind
{
    // A scored sweep owns blade direction; the demonstration still owns axial
    // wrist roll. Freeze one ordered source window so refreshes cannot resample
    // unrelated poses. This modifier is C2 zero at contact and both boundaries.
    public sealed class ReplayWristRoll
    {
        private struct Curve
        {
            internal double A,B,C,D,E,F;
            internal Curve(double a,double v,double acc,double b,double bv,double ba,double dt)
            {
                A=a;B=v*dt;C=acc*dt*dt*.5;
                double p=b-A-B-C,q=bv*dt-B-2*C,r=ba*dt*dt-2*C;
                D=10*p-4*q+r*.5;E=-15*p+7*q-r;F=6*p-3*q+r*.5;
            }
            internal void Sample(double u,double dt,out double p,out double v,out double a)
            {p=A+u*(B+u*(C+u*(D+u*(E+u*F))));v=(B+u*(2*C+u*(3*D+u*(4*E+u*5*F))))/dt;a=(2*C+u*(6*D+u*(12*E+u*20*F)))/(dt*dt);}
        }
        private readonly Curve[] curves;
        private readonly double start,contact,end,step;
        private readonly MotionVector blade;
        private ReplayWristRoll(double start,double contact,double end,MotionVector blade,double[] values)
        {
            this.start=start;this.contact=contact;this.end=end;this.blade=blade;step=(end-start)/(values.Length-1);
            var v=new double[values.Length];var a=new double[values.Length];
            for(int i=1;i+1<values.Length;i++){v[i]=(values[i+1]-values[i-1])/(2*step);a[i]=(values[i+1]-2*values[i]+values[i-1])/(step*step);}
            curves=new Curve[values.Length-1];for(int i=0;i<curves.Length;i++)curves[i]=new Curve(values[i],v[i],a[i],values[i+1],v[i+1],a[i+1],step);
        }
        internal static ReplayWristRoll Capture(Func<double,PhraseState> teacher,PhraseState contact,MotionVector blade,bool continuous=false)
        {
            double start=contact.SwingStart,end=contact.SwingEnd;
            if(end-start<.006 || contact.Time-start<.001 || end-contact.Time<.001)return null;
            if(continuous)return CaptureContinuous(teacher,contact,blade);
            const int points=17;var values=new double[points];var reference=teacher(contact.Time);
            double max=0;int source=reference.HumanSource;var inverse=reference.Rotation.Unit.Inverse;
            for(int i=0;i<points;i++)
            {
                var s=teacher(start+(end-start)*i/(points-1));if(s.HumanSource!=source)return null;
                var relative=(inverse*s.Rotation.Unit).Unit;
                double z=MotionVector.Dot(relative.Vector,blade),w=relative.W;
                if(z*z+w*w<1e-6)return null; // Twist is undefined at a half-turn swing.
                double angle=2*Math.Atan2(z,w);
                while(angle>Math.PI)angle-=2*Math.PI;while(angle<-Math.PI)angle+=2*Math.PI;
                if(i>0){while(angle-values[i-1]>Math.PI)angle-=2*Math.PI;while(angle-values[i-1]<-Math.PI)angle+=2*Math.PI;}
                values[i]=angle;max=Math.Max(max,Math.Abs(angle));
            }
            if(max<1e-6)return null;
            return new ReplayWristRoll(start,contact.Time,end,blade,values);
        }
        private static ReplayWristRoll CaptureContinuous(Func<double,PhraseState> teacher,PhraseState contact,MotionVector blade)
        {
            // A finite swing/twist quaternion decomposition becomes singular
            // when the demonstration swings through a half turn. Its twist
            // can whip around even though the measured wrist is slow. Integrate
            // the actual angular velocity about the current blade instead;
            // this is well defined through every legitimate swing orientation.
            const int points=17;double start=contact.SwingStart,end=contact.SwingEnd,dt=(end-start)/(points-1);
            var reference=teacher(contact.Time);var values=new double[points];var rates=new double[points];
            for(int i=0;i<points;i++)
            {
                var s=teacher(start+dt*i);if(s.HumanSource!=reference.HumanSource)return null;
                rates[i]=MotionVector.Dot(s.AngularVelocity,s.Rotation.Rotate(blade));
                if(i==0)continue;
                var mid=teacher(start+dt*(i-.5));if(mid.HumanSource!=reference.HumanSource)return null;
                double middle=MotionVector.Dot(mid.AngularVelocity,mid.Rotation.Rotate(blade));
                values[i]=values[i-1]+dt*(rates[i-1]+4*middle+rates[i])/6;
            }
            double u=(contact.Time-start)/dt;int k=Math.Min(points-2,(int)u);double origin=values[k]+(values[k+1]-values[k])*(u-k),maximum=0;
            for(int i=0;i<points;i++){values[i]-=origin;maximum=Math.Max(maximum,Math.Abs(values[i]));}
            if(maximum<1e-6)return null;
            return new ReplayWristRoll(start,contact.Time,end,blade,values);
        }
        internal void Apply(PhraseState s)
        {
            if(s.Time<=start || s.Time>=end || s.Time==contact)return;
            int i=Math.Min(curves.Length-1,(int)((s.Time-start)/step));double p,v,a;
            curves[i].Sample((s.Time-start-i*step)/step,step,out p,out v,out a);
            double span=s.Time<contact ? contact-start : end-contact;
            double u=s.Time<contact ? (s.Time-start)/span : (s.Time-contact)/span;
            double x=u*(1-u),dx=1-2*u;
            double weight=64*x*x*x,rate=192*x*x*dx/span,acc=(384*x*dx*dx-384*x*x)/(span*span);
            double roll=p*weight,rv=v*weight+p*rate,ra=a*weight+2*v*rate+p*acc;
            var axis=s.Rotation.Rotate(blade);var added=axis*rv;
            s.AngularAcceleration+=axis*ra+MotionVector.Cross(s.AngularVelocity,added);
            s.AngularVelocity+=added;s.Rotation=(s.Rotation*MotionRotation.Exp(blade*roll)).Unit;
        }
    }
}
