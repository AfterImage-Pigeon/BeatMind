using System;
using System.Collections.Generic;
namespace SaberMind
{
    // Retimes a continuous rotation, never individual target quaternions.
    // Every contact keeps its source time; the clock is C2 and strictly
    // increasing. Sparse opening/break gestures keep their original clock.
    public sealed class ReplayWristClock
    {
        private struct Knot {internal double Time,Source,Rate;internal Knot(double t,double s,double r){Time=t;Source=s;Rate=r;}}
        private readonly List<Knot> knots=new List<Knot>();
        public ReplayWristClock(double start,double end,IList<PhraseState> contacts,double scale)
        {
            knots.Add(new Knot(start,start,1));double previous=start;
            foreach(var contact in contacts)
            {
                if(contact.Time<=start || contact.Time>=end)continue;
                if(contact.Time-previous>.72)
                {Add(previous+.36,1);Add(contact.Time-.36,1);}
                double factor=scale/Math.Max(1,contact.WristSpeedScale);
                if(Finite(contact.SwingStart) && contact.SwingStart>previous && contact.SwingStart<contact.Time)
                    Add(contact.Time-(contact.Time-contact.SwingStart)/factor,contact.SwingStart,factor);
                Add(contact.Time,contact.Time,factor);
                if(Finite(contact.SwingEnd) && contact.SwingEnd>contact.Time && contact.SwingEnd<end)
                {Add(contact.Time+(contact.SwingEnd-contact.Time)/factor,contact.SwingEnd,factor);previous=contact.SwingEnd;}
                else previous=contact.Time;
            }
            if(end-previous>.36)Add(previous+.36,1);
            Add(end,1);
        }
        private static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
        private void Add(double t,double rate){Add(t,t,rate);}
        private void Add(double t,double source,double rate)
        {
            rate=MotionPhrase.Clamp(rate,1,1.5);int i=knots.Count;
            while(i>0 && knots[i-1].Time>t)i--;
            if(i>0 && Math.Abs(knots[i-1].Time-t)<1e-8){var k=knots[i-1];k.Rate=rate;knots[i-1]=k;return;}
            if(i<knots.Count && Math.Abs(knots[i].Time-t)<1e-8){var k=knots[i];k.Rate=rate;knots[i]=k;return;}
            knots.Insert(i,new Knot(t,source,rate));
        }
        public void Map(double time,out double source,out double rate,out double acceleration)
        {
            source=time;rate=1;acceleration=0;
            if(time<=knots[0].Time || time>=knots[knots.Count-1].Time)return;
            int lo=0,hi=knots.Count-1;while(lo+1<hi){int mid=(lo+hi)/2;if(knots[mid].Time<=time)lo=mid;else hi=mid;}
            var left=knots[lo];var right=knots[hi];double length=right.Time-left.Time,travel=right.Source-left.Source;
            if(left.Rate==1 && right.Rate==1 && left.Source==left.Time && right.Source==right.Time)return;
            // Integrate a smooth, nonnegative velocity rather than fitting
            // independent source-time poses. Even a tiny preparation join
            // cannot make this clock reverse or overshoot a sequence boundary.
            double ramp=Math.Min(length*.25,travel/(Math.Max(1e-12,left.Rate+right.Rate)*2));
            if(ramp<1e-12){source=left.Source+travel*(time-left.Time)/length;rate=travel/length;return;}
            double cruise=(travel-ramp*(left.Rate+right.Rate)*.5)/(length-ramp),offset=time-left.Time;
            if(offset<ramp)
            {double u=offset/ramp;source=left.Source+ramp*(left.Rate*u+(cruise-left.Rate)*Integral(u));rate=left.Rate+(cruise-left.Rate)*Smooth(u);acceleration=(cruise-left.Rate)*Slope(u)/ramp;}
            else if(offset>length-ramp)
            {double u=(offset-length+ramp)/ramp;source=right.Source-ramp*(cruise+right.Rate)*.5+ramp*(cruise*u+(right.Rate-cruise)*Integral(u));rate=cruise+(right.Rate-cruise)*Smooth(u);acceleration=(right.Rate-cruise)*Slope(u)/ramp;}
            else{source=left.Source+ramp*(left.Rate+cruise)*.5+(offset-ramp)*cruise;rate=cruise;}
        }
        private static double Smooth(double u){return u*u*u*(10+u*(-15+6*u));}
        private static double Slope(double u){return 30*u*u*(1-u)*(1-u);}
        private static double Integral(double u){return u*u*u*u*(2.5+u*(-3+u));}
        public double Unmap(double source)
        {
            if(source<=knots[0].Time || source>=knots[knots.Count-1].Time)return source;
            double lo=knots[0].Time,hi=knots[knots.Count-1].Time;
            for(int i=0;i<45;i++){double mid=(lo+hi)*.5,s,r,a;Map(mid,out s,out r,out a);if(s<source)lo=mid;else hi=mid;}
            return (lo+hi)*.5;
        }
        public static void Apply(MotionPhrase path,double scale)
        {
            if(scale<=1 || path.Knots.Count<2)return;
            var contacts=new List<PhraseState>();foreach(var k in path.Knots)if(k.Id>=0)contacts.Add(k.Copy());
            if(contacts.Count==0)return;
            var clock=new ReplayWristClock(path.Knots[0].Time,path.Knots[path.Knots.Count-1].Time,contacts,scale);
            var original=path.Evaluator;var wristOriginal=path.WristEvaluator ?? original;
            path.Evaluator=delegate(double time)
            {
                double source,rate,acceleration;clock.Map(time,out source,out rate,out acceleration);
                var s=original(time);if(source==time && rate==1 && acceleration==0)return s;
                var wrist=source==time ? s : wristOriginal(source);
                s.Rotation=wrist.Rotation;s.AngularAcceleration=wrist.AngularAcceleration*(rate*rate)+wrist.AngularVelocity*acceleration;
                s.AngularVelocity=wrist.AngularVelocity*rate;return s;
            };
            path.WristEvaluator=delegate(double time)
            {
                double source,rate,acceleration;clock.Map(time,out source,out rate,out acceleration);
                var wrist=wristOriginal(source);
                if(source==time && rate==1 && acceleration==0)return wrist;
                wrist.Time=time;
                wrist.AngularAcceleration=wrist.AngularAcceleration*(rate*rate)+wrist.AngularVelocity*acceleration;
                wrist.AngularVelocity=wrist.AngularVelocity*rate;return wrist;
            };
            foreach(var old in contacts)
            {
                var c=path.Contact(old.Id);var wrist=path.Sample(c.Time);
                c.WristSource=old.WristSpeedScale<=1 ? new ContactWristSource(old) : old.WristSource;
                c.AngularVelocity=wrist.AngularVelocity;c.AngularAcceleration=wrist.AngularAcceleration;c.WristSpeedScale=scale;
                if(Finite(c.SwingStart))c.SwingStart=clock.Unmap(c.SwingStart);
                if(Finite(c.SwingPeak))c.SwingPeak=clock.Unmap(c.SwingPeak);
                if(Finite(c.SwingEnd))c.SwingEnd=clock.Unmap(c.SwingEnd);
                if(Finite(c.ScoringReleaseEnd))c.ScoringReleaseEnd=clock.Unmap(c.ScoringReleaseEnd);
                if(Finite(c.ScoringPrepStart))c.ScoringPrepStart=clock.Unmap(c.ScoringPrepStart);
            }
        }
    }
}
