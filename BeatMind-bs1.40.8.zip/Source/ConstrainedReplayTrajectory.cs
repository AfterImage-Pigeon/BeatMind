using System;
using System.Collections.Generic;
namespace SaberMind
{
    // Constraints are a smooth coordinate transformation of the entire human
    // recording. The measured trajectory remains present at EVERY instant.
    // Matching derivatives makes each cut, transition and replan C2 continuous.
    public static class ConstrainedReplayTrajectory
    {
        private sealed class Hit{internal PhraseState Human,Pose;internal PhraseNote Note;internal WristSwing Swing;internal bool ReleaseRevised;}
        public static MotionPhrase Build(PhraseState seed,IList<PhraseNote> notes,PhraseGeometry g,Func<double,PhraseState> teacher,int budget,double horizon)
        {var result=new MotionPhrase();foreach(int step in Prepare(result,seed,notes,g,teacher,budget,horizon)){}return result;}
        public static IEnumerable<int> Prepare(MotionPhrase result,PhraseState seed,IList<PhraseNote> notes,PhraseGeometry g,Func<double,PhraseState> teacher,int budget,double horizon)
        {
            double end=seed.Time+Math.Max(.5,Math.Min(3.5,horizon));
            var hits=new List<Hit>();PhraseState previous=seed;
            if(g.StableFastGrip)for(int i=0;i<notes.Count;i++)
            {
                var n=notes[i];if(!CutSafety.StrokeFor(n).Dense)continue;
                // Center the wrist's reach on the upcoming pattern rather
                // than freezing an unrelated replay grip above/below all its
                // blocks. Contact fitting still owns the exact reachable pose.
                MotionVector low=n.Center,high=n.Center;
                for(int j=i;j<notes.Count && notes[j].Time<=n.Time+.4;j++)
                {Expand(notes[j].Center,ref low,ref high);foreach(var extra in notes[j].OtherCenters)Expand(extra,ref low,ref high);}
                var center=(low+high)*.5;var forward=n.Forward.Unit;double spread=0;
                for(int j=i;j<notes.Count && notes[j].Time<=n.Time+.4;j++)
                {spread=Math.Max(spread,Lateral(notes[j].Center-center,forward));foreach(var extra in notes[j].OtherCenters)spread=Math.Max(spread,Lateral(extra-center,forward));}
                double blade=(g.Top-g.Bottom).Length*.96;
                double depth=Math.Sqrt(Math.Max(blade*blade-spread*spread,blade*blade*.04));
                n.PivotHint=center-forward*depth;n.HasPivotHint=true;yield return 0;
            }
            foreach(var n in notes)
            {
                if(n.Time<=seed.Time+.004 || n.Time>=end-.025)continue;
                var human=teacher(n.Time);int tested;var contact=ReplayMotor.FitContact(human,n,g,previous,budget,out tested);
                result.CandidateEvaluations+=tested;hits.Add(new Hit{Human=human,Pose=contact,Note=n});previous=contact;
                yield return 0;
            }
            // Optimize contacts as a connected phrase. A short chord must not
            // select two individually valid but incompatible hand pivots.
            for(int pass=0;pass<2;pass++)
            {
                for(int i=hits.Count-1;i>=0;i--)
                {
                    var h=hits[i];h.Note.Next=i+1<hits.Count ? hits[i+1].Note : null;h.Note.NextPose=i+1<hits.Count ? hits[i+1].Pose : null;
                    int tested;h.Pose=ReplayMotor.FitContact(h.Human,h.Note,g,i==0 ? seed : hits[i-1].Pose,budget,out tested);result.CandidateEvaluations+=tested;
                    yield return 0;
                }
                for(int i=0;i<hits.Count;i++)
                {var h=hits[i];int tested;h.Pose=ReplayMotor.FitContact(h.Human,h.Note,g,i==0 ? seed : hits[i-1].Pose,budget,out tested);result.CandidateEvaluations+=tested;yield return 0;}
            }
            for(int i=0;i<hits.Count;i++)
            {
                var hit=hits[i];double before=hit.Pose.Time-(i==0 ? seed.Time : hits[i-1].Pose.Time);
                double after=i+1<hits.Count ? hits[i+1].Pose.Time-hit.Pose.Time : end-hit.Pose.Time;
                double half=Math.Min(CutSafety.StrokeFor(hit.Note).HalfSwing,Math.Min(before*.45,after*.45));
                if((half>.004 || HumanMotionModel.Finite(hit.Pose.SwingStart)) && (g.ScoredHumanSwings || StationaryWrist(hit,half,teacher)))PrepareSwing(hit,g,before,after,teacher);
                yield return 0;
            }
            if(g.ScoredHumanSwings && g.StableFastGrip)foreach(int step in FitFastCadence(hits,seed,g))yield return step;
            // Repeated cuts need time to return; alternating cuts can share
            // their low/high turnaround. Reserve a feasible recovery before
            // publishing preparation windows, rather than discovering that
            // the entire wrist has to whip back in a few milliseconds.
            for(int i=0;i+1<hits.Count;i++)
            {
                var left=hits[i];var right=hits[i+1];if(left.Swing==null || right.Swing==null || right.Pose.Time-left.Pose.Time>.8)continue;
                if(g.ScoredHumanSwings && left.Pose.SwingEnd>=right.Pose.Time-.002)
                {
                    // A committed future release can outlive a newly exposed
                    // close contact (reproduced at a 14 ms gap). That virtual
                    // end knot used to sort past the hit and silently drop it.
                    // Keep both exact contacts. Only the still-future release
                    // shortens; approach/contact jets remain unchanged because
                    // this scored envelope peaks at contact.
                    left.Pose.SwingEnd=left.Pose.Time+(right.Pose.Time-left.Pose.Time)*.45;
                    SetSwingPeak(left.Pose);left.ReleaseRevised=true;left.Pose.WristRoll=null;
                    left.Swing=new WristSwing(left.Pose);
                }
                // Use the existing physical speed bound, leaving a margin for
                // sampling. A repeated cut can legitimately recover faster
                // than its scored contact; shrinking every such follow-through
                // to match contact speed would lose scored swing angle.
                double limit=120*Math.Max(left.Pose.WristSpeedScale,right.Pose.WristSpeedScale);
                for(int step=0;step<18;step++)
                {
                    double duration=right.Pose.SwingStart-left.Pose.SwingEnd;
                    double turn=RecoveryTurn(left,right,left.Swing.Sample(left.Pose.SwingEnd),right.Swing.Sample(right.Pose.SwingStart),g.ScoredHumanSwings && g.StableFastGrip).Length;
                    if(duration>.005 && turn*1.875/duration<=limit)break;
                    bool changed=false;
                    if(left.Note.Committed==null && left.Pose.SwingEnd-left.Pose.Time>.012)
                    {left.Pose.SwingEnd=left.Pose.Time+(left.Pose.SwingEnd-left.Pose.Time)*.8;SetSwingPeak(left.Pose);left.Swing=new WristSwing(left.Pose);left.Pose.AngularAcceleration=left.Swing.Sample(left.Pose.Time).AngularAcceleration;changed=true;}
                    if(right.Note.Committed==null && right.Pose.Time-right.Pose.SwingStart>.018)
                    {right.Pose.SwingStart=right.Pose.Time-(right.Pose.Time-right.Pose.SwingStart)*.93;SetSwingPeak(right.Pose);right.Swing=new WristSwing(right.Pose);right.Pose.AngularAcceleration=right.Swing.Sample(right.Pose.Time).AngularAcceleration;changed=true;}
                    yield return 0;if(!changed)break;
                }
            }
            if(g.ScoredHumanSwings)foreach(var hit in hits)
            {
                if(hit.Swing==null)continue;
                hit.Pose.ScoringPrepStart=hit.Pose.SwingStart;hit.Pose.ScoringReleaseEnd=hit.Pose.SwingEnd;
                // Freeze roll after cadence/recovery has finalized the clock.
                // Committed strokes retain the same immutable demonstration.
                if(hit.Note.Committed==null || hit.ReleaseRevised)hit.Pose.WristRoll=ReplayWristRoll.Capture(teacher,hit.Pose,(g.Top-g.Bottom).Unit,g.StableFastGrip);
                hit.Swing=new WristSwing(hit.Pose);yield return 0;
            }
            result.Knots.Add(seed.Copy());
            for(int i=0;i<hits.Count;i++)
            {
                yield return 0;
                var hit=hits[i];double gap=hit.Pose.Time-(i==0 ? seed.Time : hits[i-1].Pose.Time);
                double half=CutSafety.StrokeFor(hit.Note).HalfSwing;
                half=Math.Min(half,Math.Min(gap*.45,(i+1<hits.Count ? hits[i+1].Pose.Time-hit.Pose.Time : end-hit.Pose.Time)*.45));
                if(hit.Swing!=null)
                {
                    // Cadence supplies preparation time. A committed contact
                    // retains its original envelope even when a new seed is
                    // only milliseconds away from the cut.
                    Add(result,SwingSide(hit,hit.Pose.SwingStart,g,teacher));
                    Add(result,hit.Pose);
                    Add(result,SwingSide(hit,hit.Pose.SwingEnd,g,teacher));
                    continue;
                }
                if(i==0 && gap>.10 || i>0 && gap>.8)
                {
                    double span=Math.Min(.23,Math.Max(.065,hit.Note.Stroke*2.5*hit.Note.Anticipation));span=Math.Min(span,gap*.42);
                    var prep=Side(hit,-span,g,teacher);Add(result,prep);
                }
                Add(result,hit.Pose);
                if(i+1<hits.Count && hits[i+1].Pose.Time-hit.Pose.Time<=.8)
                {
                    var next=hits[i+1];double interval=next.Pose.Time-hit.Pose.Time;
                    // Close stacks / chains and repeated same-direction cuts
                    // belong to one continuous stroke, without a new reversal.
                    if(interval>=.075 && MotionVector.Dot(hit.Note.Direction,next.Note.Direction)<.40)
                        Add(result,Turn(hit,next,g,teacher));
                }
                else
                {
                    double span=Math.Min(.16,Math.Max(.04,hit.Note.Stroke*1.6*hit.Note.Recovery));
                    span=Math.Min(span,i+1<hits.Count ? (hits[i+1].Pose.Time-hit.Pose.Time)*.30 : (end-hit.Pose.Time)*.45);
                    Add(result,Side(hit,span,g,teacher));
                }
            }
            var last=Project(teacher(end),g);last.Time=end;Add(result,last);
            var correction=new MotionPhrase();
            foreach(var wanted in result.Knots)
            {
                var unconstrained=Unproject(wanted,g);
                var human=teacher(wanted.Time);MotionRotation q=wanted.Rotation*human.Rotation.Inverse;
                MotionVector w=q.Rotate(human.AngularVelocity),a=q.Rotate(human.AngularAcceleration);
                var c=new PhraseState{Time=wanted.Time,Grip=unconstrained.Grip-human.Grip,Velocity=unconstrained.Velocity-human.Velocity,Acceleration=unconstrained.Acceleration-human.Acceleration,Rotation=q,
                    AngularVelocity=wanted.AngularVelocity-w,AngularAcceleration=wanted.AngularAcceleration-a-MotionVector.Cross(wanted.AngularVelocity-w,w),WristSpeedScale=wanted.WristSpeedScale};
                if(wanted!=result.Knots[0]){c.Acceleration=new MotionVector();c.AngularAcceleration=new MotionVector();} correction.Knots.Add(c);
                yield return 0;
            }
            // Corrections alter a continuous demonstration; their endpoint
            // derivatives must not create a second, large swing across a long
            // note-free interval. Local C2 edges reach the exact contact jets,
            // while the middle is bounded by the required correction travel.
            var correctionEdges=new List<MotionTransition>();
            for(int i=0;i+1<correction.Knots.Count;i++){correctionEdges.Add(new MotionTransition(correction.Knots[i],correction.Knots[i+1]));yield return 0;}
            correction.Evaluator=delegate(double t)
            {
                if(t<=correction.Knots[0].Time)return correction.Knots[0].Copy();
                int lastCorrection=correction.Knots.Count-1;if(t>=correction.Knots[lastCorrection].Time)return correction.Knots[lastCorrection].Copy();
                int lo=0,hi=lastCorrection;while(lo+1<hi){int mid=(lo+hi)/2;if(correction.Knots[mid].Time<=t)lo=mid;else hi=mid;}
                return correctionEdges[lo].Sample(t);
            };
            result.RefreshTime=end-.30;
            result.Evaluator=delegate(double t)
            {
                if(t<=seed.Time)return seed.Copy();
                var h=teacher(t);var c=correction.Sample(t);var s=h.Copy();s.Time=t;s.WristSpeedScale=Math.Max(h.WristSpeedScale,c.WristSpeedScale);
                s.Grip=h.Grip+c.Grip;s.Velocity=h.Velocity+c.Velocity;s.Acceleration=h.Acceleration+c.Acceleration;
                MotionVector w=c.Rotation.Rotate(h.AngularVelocity);
                s.Rotation=c.Rotation*h.Rotation;s.AngularVelocity=c.AngularVelocity+w;
                s.AngularAcceleration=c.AngularAcceleration+c.Rotation.Rotate(h.AngularAcceleration)+MotionVector.Cross(c.AngularVelocity,w);
                s.HumanGripWeight=h.HumanGripWeight;s.HumanWristWeight=h.HumanWristWeight;
                return ProjectOwned(s,g);
            };
            ApplySwings(result,hits,seed.Time);
            if(g.StableFastGrip)foreach(int step in HoldFastGrips(result,hits,g))yield return step;
            // Certify the final connected wrist, not an intermediate curve
            // that a subsequent wrist join can silently overwrite.
            if(g.ScoredHumanSwings && g.StableFastGrip)ConnectWrists(result,hits,true);
            if(g.ScoredHumanSwings && g.StableFastGrip)foreach(int step in ConnectFastContacts(result,hits,seed,g))yield return step;
            foreach(int step in Certify(result,seed,g,teacher,end))yield return step;
            if(!g.ScoredHumanSwings || !g.StableFastGrip)ConnectWrists(result,hits);
        }
        private static void Expand(MotionVector p,ref MotionVector low,ref MotionVector high)
        {low=new MotionVector(Math.Min(low.X,p.X),Math.Min(low.Y,p.Y),Math.Min(low.Z,p.Z));high=new MotionVector(Math.Max(high.X,p.X),Math.Max(high.Y,p.Y),Math.Max(high.Z,p.Z));}
        private static double Lateral(MotionVector p,MotionVector forward){return (p-forward*MotionVector.Dot(p,forward)).Length;}
        private static IEnumerable<int> FitFastCadence(List<Hit> hits,PhraseState seed,PhraseGeometry g)
        {
            // Optimize the scored angular jets as a pair, before publishing
            // either envelope. A maximum-angle speed boost that ignores the
            // contact frames can overshoot behind the player in a short tech
            // transition. Keep the proven contact-speed band as a floor.
            double facing=Math.Cos(WristMotionLimits.MaximumPitchRadians);
            for(int pass=0;pass<14;pass++)
            {
                bool changed=false;
                for(int i=0;i+1<hits.Count;i++)
                {
                    var a=hits[i];var b=hits[i+1];double gap=b.Pose.Time-a.Pose.Time;if(gap>.12 || gap<=.004)continue;
                    var link=new ContactWristLink(a.Pose,b.Pose);bool safe=true;
                    for(int p=0;p<=48;p++)
                    {MotionRotation rotation;MotionVector velocity;link.Inspect(a.Pose.Time+gap*p/48,out rotation,out velocity);yield return 0;if(velocity.Length>180 || MotionVector.Dot(rotation.Rotate((g.Top-g.Bottom).Unit),g.Forward.Unit)<facing){safe=false;break;}}
                    if(safe)continue;
                    foreach(var hit in new[]{a,b})
                    {
                        var pose=hit.Pose;
                        // An already visible shared curve owns its endpoint.
                        if(pose.IncomingWrist!=null && pose.IncomingWrist.Start<=seed.Time && pose.IncomingWrist.Matches(pose,true))continue;
                        if(hit.Note.Committed!=null && pose.SwingStart<=seed.Time)continue;
                        double floor=CutSafety.StrokeFor(hit.Note).Speed*MotionPhrase.Clamp(hit.Note.Wrist,.97,1.03),speed=pose.AngularVelocity.Length;
                        double next=Math.Max(floor,speed*.94);if(next>=speed-1e-7)continue;
                        pose.AngularVelocity=pose.AngularVelocity.Unit*next;pose.AngularAcceleration=new MotionVector();hit.Swing=new WristSwing(pose);changed=true;
                    }
                }
                if(!changed)yield break;
            }
        }
        private static bool StationaryWrist(Hit hit,double half,Func<double,PhraseState> teacher)
        {
            if(hit.Human.HumanWristWeight>0 || hit.Human.AngularVelocity.Length>.01)return false;
            var a=teacher(hit.Pose.Time-half);var b=teacher(hit.Pose.Time+half);
            return a.HumanWristWeight<=0 && b.HumanWristWeight<=0 && a.AngularVelocity.Length<=.01 && b.AngularVelocity.Length<=.01 && MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length<.001;
        }
        private static void PrepareSwing(Hit hit,PhraseGeometry g,double before,double after,Func<double,PhraseState> teacher)
        {
            var pose=hit.Pose;double scale=Math.Max(1,pose.WristSpeedScale),speed=pose.AngularVelocity.Length/scale;
            if(!HumanMotionModel.Finite(pose.SwingStart) || !HumanMotionModel.Finite(pose.SwingEnd))
            {
                var profile=CutSafety.StrokeFor(hit.Note);
                var axis=pose.AngularVelocity.Unit;var blade=pose.Rotation.Rotate((g.Top-g.Bottom).Unit);
                var aim=-hit.Note.Direction;var projected=blade-axis*MotionVector.Dot(axis,blade);
                double toward=Math.Atan2(-MotionVector.Dot(MotionVector.Cross(axis,blade),aim),MotionVector.Dot(projected,aim));
                if(toward<0)toward+=2*Math.PI;
                double angle=profile.Dense ? 80*Math.PI/180 : MotionPhrase.Clamp(toward,100*Math.PI/180,117*Math.PI/180);
                double prep=Math.Min(2*angle/Math.Max(1,speed),Math.Max(.006,before*.48));
                double release=Math.Min(2*(profile.Dense ? 48 : 64)*Math.PI/180/Math.Max(1,speed),Math.Max(.006,after*.45));
                pose.SwingStart=pose.Time-prep/scale;pose.SwingEnd=pose.Time+release/scale;SetSwingPeak(pose);
            }
            if(g.ScoredHumanSwings && hit.Note.Committed==null)
            {
                // Raise cadence only when the available beat interval cannot
                // contain the requested scored arc at the 0.9.9 contact pace.
                var profile=CutSafety.StrokeFor(hit.Note);
                double prepBudget=Math.Max(.006,before*.48),releaseBudget=Math.Max(.006,after*.45);
                double wantedBefore=(profile.Dense ? 80 : 100)*Math.PI/180,wantedAfter=(profile.Dense && !g.StableFastGrip ? 48 : 64)*Math.PI/180;
                double required=Math.Max(2*wantedBefore/prepBudget,2*wantedAfter/releaseBudget);
                double chosen=Math.Max(pose.AngularVelocity.Length,Math.Min(120*scale,required));
                pose.AngularVelocity=pose.AngularVelocity.Unit*chosen;
                pose.SwingStart=pose.Time-Math.Min(prepBudget,2*wantedBefore/chosen);
                pose.SwingEnd=pose.Time+Math.Min(releaseBudget,2*wantedAfter/chosen);
                pose.SwingPeak=pose.Time;
                pose.ScoringPrepStart=pose.SwingStart;pose.ScoringReleaseEnd=pose.SwingEnd;
            }
            hit.Swing=new WristSwing(pose);
            // Preserve the exact fitted contact speed, with the acceleration
            // supplied by the same continuous pre-peak / release envelope.
            pose.AngularAcceleration=hit.Swing.Sample(pose.Time).AngularAcceleration;
        }
        private static void SetSwingPeak(PhraseState pose)
        {pose.SwingPeak=pose.SteadyWristMotion ? pose.Time : pose.Time-Math.Min(.008/Math.Max(1,pose.WristSpeedScale),Math.Min((pose.Time-pose.SwingStart)*.08,(pose.SwingEnd-pose.Time)*.10));}
        private static PhraseState SwingSide(Hit hit,double time,PhraseGeometry g,Func<double,PhraseState> teacher)
        {
            var s=Side(hit,time-hit.Pose.Time,g,teacher);var wrist=hit.Swing.Sample(time);
            s.Rotation=wrist.Rotation;s.AngularVelocity=wrist.AngularVelocity;s.AngularAcceleration=wrist.AngularAcceleration;s.WristSpeedScale=hit.Pose.WristSpeedScale;return s;
        }
        private static void ApplySwings(MotionPhrase path,List<Hit> hits,double start)
        {
            var swings=new List<WristSwing>();foreach(var hit in hits)if(hit.Swing!=null)swings.Add(hit.Swing);
            if(swings.Count==0)return;var original=path.Evaluator;
            path.Evaluator=delegate(double time)
            {
                var s=original(time);if(time<=start)return s;
                foreach(var swing in swings)if(time>=swing.Start && time<=swing.End)
                {var wrist=swing.Sample(time);s.Rotation=wrist.Rotation;s.AngularVelocity=wrist.AngularVelocity;s.AngularAcceleration=wrist.AngularAcceleration;s.WristSpeedScale=wrist.WristSpeedScale;break;}
                return s;
            };
        }
        private sealed class GripRun
        {
            internal double Start,End;
            internal readonly List<double> Times=new List<double>();
            internal readonly List<ReachTransition> Curves=new List<ReachTransition>();
            internal PhraseState Sample(double t)
            {int lo=0,hi=Curves.Count;while(lo+1<hi){int mid=(lo+hi)/2;if(Times[mid]<=t)lo=mid;else hi=mid;}return Curves[lo].SampleGrip(t);}
        }
        private static IEnumerable<int> ConnectFastContacts(MotionPhrase path,List<Hit> hits,PhraseState seed,PhraseGeometry g)
        {
            var links=new List<ContactWristLink>();
            if(hits.Count>0)
            {var incoming=hits[0].Pose.IncomingWrist;if(incoming!=null && incoming.Matches(hits[0].Pose,true))links.Add(incoming);}
            for(int i=0;i+1<hits.Count;i++)
            {
                var a=hits[i].Pose;var b=hits[i+1].Pose;double gap=b.Time-a.Time;
                if(gap>.12 || gap<=.004)continue;
                var link=a.OutgoingWrist;
                if(link==null || !link.Matches(a,false) || !link.Matches(b,true))link=new ContactWristLink(a,b);
                bool safe=true;double limit=180*Math.Max(a.WristSpeedScale,b.WristSpeedScale);
                for(int p=0;p<=64;p++)
                {MotionRotation rotation;MotionVector velocity;link.Inspect(a.Time+gap*p/64,out rotation,out velocity);if(velocity.Length>limit){safe=false;break;}yield return 0;}
                if(!safe)continue;
                a.OutgoingWrist=link;b.IncomingWrist=link;links.Add(link);
                // The connected curve owns release to its first turnaround.
                // Retain the contact envelope for the outermost stream edges.
                a.ScoringReleaseEnd=a.Time+gap*.5;b.ScoringPrepStart=a.ScoringReleaseEnd;
            }
            if(links.Count==0)yield break;var original=path.Evaluator;
            path.Evaluator=delegate(double t)
            {
                var s=original(t);if(t<=seed.Time)return s;
                foreach(var link in links)if(t>=link.Start && t<=link.End)
                {var w=link.Sample(t);s.Rotation=w.Rotation;s.AngularVelocity=w.AngularVelocity;s.AngularAcceleration=w.AngularAcceleration;break;}return s;
            };
        }
        private static IEnumerable<int> HoldFastGrips(MotionPhrase path,List<Hit> hits,PhraseGeometry g)
        {
            var original=path.Evaluator;var runs=new List<GripRun>();
            for(int i=0;i<hits.Count;i++)
            {
                if(!CutSafety.StrokeFor(hits[i].Note).Dense)continue;
                int first=i;while(i+1<hits.Count && CutSafety.StrokeFor(hits[i+1].Note).Dense && hits[i+1].Pose.Time-hits[i].Pose.Time<=.4)i++;
                var a=hits[first];var b=hits[i];double previous=first==0 ? path.Knots[0].Time : hits[first-1].Pose.Time;
                double start=first==0 && a.Pose.Time-previous<=.4 ? previous : Math.Max(previous+.002,a.Pose.Time-.20);
                double end=Math.Min(path.Knots[path.Knots.Count-1].Time,b.Pose.SwingEnd);
                if(!HumanMotionModel.Finite(end))end=b.Pose.Time+.035;
                if(i+1<hits.Count)end=Math.Min(end,(b.Pose.Time+hits[i+1].Pose.Time)*.5);
                var run=new GripRun{Start=start,End=end};var left=original(start);
                for(int k=first;k<=i;k++)
                {
                    var right=hits[k].Pose.Copy();if(right.Time<=left.Time+.000001)continue;
                    run.Times.Add(left.Time);run.Curves.Add(new ReachTransition(Unproject(left,g),Unproject(right,g),g));left=right;yield return 0;
                }
                if(end>left.Time+.000001)
                {var right=left.Copy();right.Time=end;run.Times.Add(left.Time);run.Curves.Add(new ReachTransition(Unproject(left,g),Unproject(right,g),g));yield return 0;}
                // Rejoin the measured grip with matching position and jets.
                // No per-frame tracking offset is mixed into a fast wrist arc.
                double rejoin=Math.Min(path.Knots[path.Knots.Count-1].Time,end+.20);
                if(i+1<hits.Count)rejoin=Math.Min(rejoin,hits[i+1].Pose.Time-.002);
                if(i+1<hits.Count && CutSafety.StrokeFor(hits[i+1].Note).Dense)rejoin=Math.Min(rejoin,hits[i+1].Pose.Time-.20);
                if(rejoin>end+.000001)
                {left=run.Sample(end);var right=original(rejoin);run.Times.Add(end);run.Curves.Add(new ReachTransition(Unproject(Project(left,g),g),Unproject(right,g),g));run.End=rejoin;yield return 0;}
                if(run.Curves.Count>0)runs.Add(run);
            }
            if(runs.Count==0)yield break;
            path.Evaluator=delegate(double t)
            {
                var s=original(t);foreach(var run in runs)if(t>=run.Start && t<=run.End)
                {var grip=run.Sample(t);s.Grip=grip.Grip;s.Velocity=grip.Velocity;s.Acceleration=grip.Acceleration;return ProjectOwned(s,g);}return s;
            };
        }
        // One fixed-pivot scalar SO(3) stroke. Velocity and acceleration come
        // from this analytic curve, not independent per-frame smoothing. Its
        // peak is just before contact; contact q / angular speed stay exact.
        private sealed class WristSwing
        {
            internal readonly double Start,Peak,End;
            private readonly double time,speed,peakSpeed,up,down,atContact;
            private readonly double scale;
            private readonly ReplayWristRoll roll;
            private readonly MotionVector axis;private readonly MotionRotation contact;
            internal WristSwing(PhraseState pose)
            {
                Start=pose.SwingStart;Peak=pose.SwingPeak;End=pose.SwingEnd;time=pose.Time;scale=pose.WristSpeedScale;roll=pose.WristRoll;
                speed=pose.AngularVelocity.Length;axis=pose.AngularVelocity.Unit;contact=pose.Rotation;
                up=Math.Max(.001,Peak-Start);down=Math.Max(.001,End-Peak);
                double u=MotionPhrase.Clamp((time-Peak)/down,0,1);
                peakSpeed=speed/Math.Max(.001,1-Smooth(u));atContact=peakSpeed*down*IntegralRelease(u);
            }
            internal PhraseState Sample(double t)
            {
                double angle,rate,acc;
                if(t<Peak)
                {double u=MotionPhrase.Clamp((t-Start)/up,0,1);angle=peakSpeed*up*(IntegralRise(u)-.5)-atContact;rate=peakSpeed*Smooth(u);acc=peakSpeed*Slope(u)/up;}
                else
                {double u=MotionPhrase.Clamp((t-Peak)/down,0,1);angle=peakSpeed*down*IntegralRelease(u)-atContact;rate=peakSpeed*(1-Smooth(u));acc=-peakSpeed*Slope(u)/down;}
                var s=new PhraseState{Time=t,Rotation=MotionRotation.Exp(axis*angle)*contact,AngularVelocity=axis*rate,AngularAcceleration=axis*acc,WristSpeedScale=scale};
                if(roll!=null)roll.Apply(s);return s;
            }
            private static double Smooth(double u){return u*u*u*(10+u*(-15+6*u));}
            private static double Slope(double u){return 30*u*u*(1-u)*(1-u);}
            private static double IntegralRise(double u){return u*u*u*u*(2.5+u*(-3+u));}
            private static double IntegralRelease(double u){return u-IntegralRise(u);}
        }
        private sealed class WristJoin{internal double Start,End;internal MotionTransition Curve;internal ContactWristLink Owned;}
        private static MotionVector RecoveryTurn(Hit left,Hit right,PhraseState from,PhraseState to,bool directed)
        {
            var turn=MotionRotation.Log(to.Rotation*from.Rotation.Inverse);
            if(!directed || left.Swing==null || right.Swing==null || MotionVector.Dot(left.Note.Direction,right.Note.Direction)<.95)return turn;
            var stroke=(left.Pose.AngularVelocity.Unit+right.Pose.AngularVelocity.Unit).Unit;
            // Two cuts in the same direction need a return stroke. Once the
            // scored release + next preparation straddle a half turn, the
            // principal log can choose to continue cutting around the circle.
            // Select the equivalent reverse branch before fitting the curve.
            if(turn.Length>1e-6 && MotionVector.Dot(turn.Unit,stroke)>.5)turn-=turn.Unit*(2*Math.PI);
            return turn;
        }
        private static void ConnectWrists(MotionPhrase path,List<Hit> hits,bool directed=false)
        {
            var joins=new List<WristJoin>();var original=path.Evaluator;
            // A replan begins inside an outgoing recovery, after the previous
            // cut has left the upcoming-note list. Omitting that seed restored
            // the old replay/offset blend exactly where the visible loop began.
            if(hits.Count>0 && hits[0].Pose.Time-path.Knots[0].Time<=.8)
            {
                var first=hits[0];var retained=first.Pose.IncomingWrist;
                var prep=first.Swing==null ? null : first.Swing.Sample(first.Pose.SwingStart);if(prep!=null)prep.Id=first.Pose.Id;
                if(directed && retained!=null && retained.IsRecovery && prep!=null && retained.Matches(prep,true))
                    joins.Add(new WristJoin{Start=retained.Start,End=retained.End,Owned=retained});
                else
                {
                double half=CutSafety.StrokeFor(hits[0].Note).HalfSwing;
                double start=path.Knots[0].Time+half,end=hits[0].Swing==null ? hits[0].Pose.Time-half : hits[0].Pose.SwingStart;
                if(end>start+.004)joins.Add(new WristJoin{Start=start,End=end,Curve=new MotionTransition(original(start),original(end),true,.015)});
                }
            }
            for(int i=0;i+1<hits.Count;i++)
            {
                var left=hits[i];var right=hits[i+1];
                if(right.Pose.Time-left.Pose.Time>.8)continue;
                double start=left.Swing==null ? left.Pose.Time+CutSafety.StrokeFor(left.Note).HalfSwing : left.Pose.SwingEnd;
                double end=right.Swing==null ? right.Pose.Time-CutSafety.StrokeFor(right.Note).HalfSwing : right.Pose.SwingStart;
                if(end<=start+.004)continue;
                var from=original(start);var to=original(end);var turn=RecoveryTurn(left,right,from,to,directed);
                if(directed && left.Swing!=null && right.Swing!=null && MotionVector.Dot(left.Note.Direction,right.Note.Direction)>=.95)
                {
                    from.Id=left.Pose.Id;to.Id=right.Pose.Id;var owned=left.Pose.OutgoingWrist;
                    if(owned==null || !owned.IsRecovery || !owned.Matches(from,false) || !owned.Matches(to,true))owned=new ContactWristLink(from,to,turn);
                    left.Pose.OutgoingWrist=owned;right.Pose.IncomingWrist=owned;
                    joins.Add(new WristJoin{Start=start,End=end,Owned=owned});
                }
                else joins.Add(new WristJoin{Start=start,End=end,Curve=new MotionTransition(from,to,true,.015)});
            }
            if(joins.Count==0)return;
            path.Evaluator=delegate(double t)
            {
                var s=original(t);if(t<=joins[0].Start)return s;
                int lo=0,hi=joins.Count;while(lo+1<hi){int mid=(lo+hi)/2;if(joins[mid].Start<=t)lo=mid;else hi=mid;}
                var j=joins[lo];if(t>=j.End)return s;
                // Scored wrist frames and their measured endpoint jets own the
                // handoff. Composing a second moving replay/offset frame here
                // could add a full recovery turn. The recorded grip, cut times,
                // cut orientations, wrist speed and break gestures remain.
                var wrist=j.Owned!=null ? j.Owned.Sample(t) : j.Curve.SampleWrist(t);s.Rotation=wrist.Rotation;s.AngularVelocity=wrist.AngularVelocity;s.AngularAcceleration=wrist.AngularAcceleration;s.WristSpeedScale=wrist.WristSpeedScale;return s;
            };
        }
        // Measured micro-acceleration is matched over a short boundary, not
        // extrapolated across a quarter-second recovery. This preserves C2
        // contact/route handoffs without amplifying tracker-scale impulses.
        private sealed class Repair
        {internal double Start,End,InEnd,OutStart;internal ReachTransition In,Out;internal Func<double,PhraseState> ContactRoute;}
        private static readonly double[] SafetyProbes={.02,.08,.125,.25,.375,.50,.625,.75,.875,.92,.98};
        private static IEnumerable<int> Certify(MotionPhrase path,PhraseState seed,PhraseGeometry g,Func<double,PhraseState> teacher,double end)
        {
            // Certify the curve rather than clamping independent display
            // frames. Only incompatible transitions receive a local repair;
            // ordinary accurate contacts keep their planned motion.
            var repairs=new List<Repair>();
            for(int k=0;k+1<path.Knots.Count;k++)
            {
                double a=path.Knots[k].Time,b=path.Knots[k+1].Time;bool invalid=false;
                foreach(double phase in SafetyProbes){var state=path.Sample(a+(b-a)*phase);yield return 0;if(UnsafeGripRoute(state,g)){invalid=true;break;}}
                // A long note-free interval still contains recorded tracking
                // samples. Eleven evenly spaced probes can miss a brief spike
                // between those samples; inspect at the actual high-FPS song
                // cadence as well, without changing the cut speed policy.
                if(!invalid)for(double t=a+1.0/240;t<b;t+=1.0/240)
                {var state=path.Sample(t);yield return 0;if(UnsafeGripRoute(state,g)){invalid=true;break;}}
                if(!invalid)continue;
                double begin=Math.Max(seed.Time,a-.25),finish=Math.Min(end,b+.25);
                if(repairs.Count>0 && begin<=repairs[repairs.Count-1].End+.10)repairs[repairs.Count-1].End=Math.Max(finish,repairs[repairs.Count-1].End);
                else repairs.Add(new Repair{Start=begin,End=finish});
            }
            if(repairs.Count==0)yield break;
            var original=path.Evaluator;
            foreach(var r in repairs)
            {
                while(r.Start>seed.Time+.03 && UnsafeBoundary(original(r.Start)))r.Start=Math.Max(seed.Time,r.Start-.03);
                while(r.End<end-.03 && UnsafeBoundary(original(r.End)))r.End=Math.Min(end,r.End+.03);
            }
            // Expanding unsafe boundaries can overlap an adjacent repair.
            // Merge again before constructing joins; never switch abruptly
            // from the first bridge to the middle of a later one.
            for(int i=1;i<repairs.Count;i++)if(repairs[i].Start<=repairs[i-1].End+.10)
            {repairs[i-1].End=Math.Max(repairs[i-1].End,repairs[i].End);repairs.RemoveAt(i--);}
            path.StabilityFallbacks=repairs.Count;
            foreach(var r in repairs)
            {
                double maximum=(r.End-r.Start)*.45,half=Math.Min(.24,maximum);
                for(int attempt=0;attempt<6;attempt++)
                {
                    r.InEnd=r.Start+half;r.OutStart=r.End-half;
                    var a=Unproject(original(r.Start),g);var b=teacher(r.InEnd);r.In=new ReachTransition(a,b,g);
                    var c=teacher(r.OutStart);var d=Unproject(original(r.End),g);r.Out=new ReachTransition(c,d,g);
                    yield return 0;
                    if(!FastJoin(r.In,r.Start,r.InEnd,g) && !FastJoin(r.Out,r.OutStart,r.End,g) || half>=maximum-.001)break;
                    half=Math.Min(maximum,half+.06);
                }
                // A safe source detour is not necessarily a scored stroke.
                // The previous fallback returned teacher(t) through the middle
                // and silently discarded fitted notes inside the repair window.
                // Retain those contacts when a reachable continuous join passes
                // the same speed/reach checks as the original trajectory.
                foreach(int step in ContactRepair(path,r,original,g))yield return step;
            }
            path.Evaluator=delegate(double t)
            {
                if(t<=seed.Time)return seed.Copy();
                foreach(var r in repairs)if(t>=r.Start && t<=r.End)
                {PhraseState repaired=r.ContactRoute!=null ? r.ContactRoute(t) : t<r.InEnd ? r.In.Sample(t) : t>r.OutStart ? r.Out.Sample(t) : teacher(t);repaired=Project(repaired,g);
                    // A reach/grip repair must not substitute a different
                    // wrist stroke and then persist the old scored clock.
                    if(g.ScoredHumanSwings && g.StableFastGrip){var wrist=original(t);repaired.Rotation=wrist.Rotation;repaired.AngularVelocity=wrist.AngularVelocity;repaired.AngularAcceleration=wrist.AngularAcceleration;}
                    repaired.RepairStage=t<r.InEnd ? 2 : t>r.OutStart ? 3 : 1;return repaired;}
                return original(t);
            };
            // Persist the pose actually published, so handoffs cannot restore
            // an individually fitted but physically incompatible contact.
            for(int i=1;i<path.Knots.Count;i++)if(path.Knots[i].Id>=0)
            {var old=path.Knots[i];var actual=path.Evaluator(old.Time);actual.Id=old.Id;actual.TargetCenter=old.TargetCenter;actual.TargetDirection=old.TargetDirection;actual.SwingStart=old.SwingStart;actual.SwingPeak=old.SwingPeak;actual.SwingEnd=old.SwingEnd;actual.WristSpeedScale=old.WristSpeedScale;actual.SteadyWristMotion=old.SteadyWristMotion;actual.WristRoll=old.WristRoll;actual.IncomingWrist=old.IncomingWrist;actual.OutgoingWrist=old.OutgoingWrist;actual.ScoringPrepStart=old.ScoringPrepStart;actual.ScoringReleaseEnd=old.ScoringReleaseEnd;actual.LimitedContact=old.LimitedContact;foreach(var r in repairs)if(old.Time>=r.Start && old.Time<=r.End && r.ContactRoute==null)actual.LimitedContact=true;path.Knots[i]=actual;}
        }
        private static IEnumerable<int> ContactRepair(MotionPhrase path,Repair repair,Func<double,PhraseState> original,PhraseGeometry g)
        {
            var anchors=new List<PhraseState>();anchors.Add(Unproject(original(repair.Start),g));
            var contacts=new List<PhraseState>();
            foreach(var pose in path.Knots)if(pose.Id>=0 && pose.Time>repair.Start+.004 && pose.Time<repair.End-.004 && !pose.LimitedContact)contacts.Add(pose);
            if(contacts.Count==0)yield break;
            var curves=new List<ReachTransition>();
            foreach(var contact in contacts)
            {
                var a=anchors[anchors.Count-1];var b=Unproject(contact,g);var curve=new ReachTransition(a,b,g);
                int count=Math.Max(16,(int)Math.Ceiling((b.Time-a.Time)*240));bool safe=true;
                for(int p=0;p<=count;p++)
                {var s=Project(g.ScoredHumanSwings && g.StableFastGrip ? curve.SampleGrip(a.Time+(b.Time-a.Time)*p/count) : curve.Sample(a.Time+(b.Time-a.Time)*p/count),g);yield return 0;if(UnsafeGripRoute(s,g)){safe=false;break;}}
                // An incompatible pair used to discard EVERY cut in a repair
                // window and return an idle teacher through a dense stream.
                // Keep reachable continuous contacts; skip only the offending
                // anchor and try the next one from the last validated state.
                if(safe){curves.Add(curve);anchors.Add(b);}
            }
            var finish=Unproject(original(repair.End),g);
            while(anchors.Count>1)
            {
                var a=anchors[anchors.Count-1];var curve=new ReachTransition(a,finish,g);bool safe=true;
                int count=Math.Max(16,(int)Math.Ceiling((finish.Time-a.Time)*240));
                for(int p=0;p<=count;p++)
                {var s=Project(g.ScoredHumanSwings && g.StableFastGrip ? curve.SampleGrip(a.Time+(finish.Time-a.Time)*p/count) : curve.Sample(a.Time+(finish.Time-a.Time)*p/count),g);yield return 0;if(UnsafeGripRoute(s,g)){safe=false;break;}}
                if(safe){curves.Add(curve);anchors.Add(finish);break;}
                anchors.RemoveAt(anchors.Count-1);curves.RemoveAt(curves.Count-1);
            }
            foreach(var contact in contacts)
            {bool kept=false;foreach(var anchor in anchors)if(anchor.Id==contact.Id){kept=true;break;}if(!kept)contact.LimitedContact=true;}
            if(anchors.Count>1)repair.ContactRoute=delegate(double t){int i=0;while(i+1<curves.Count && t>anchors[i+1].Time)i++;return curves[i].Sample(t);};
        }
        private static bool UnsafeBoundary(PhraseState s)
        {return s.MinimumReachAdjusted || s.Velocity.Length>15 || s.AngularVelocity.Length>100*Math.Max(1,s.WristSpeedScale) || s.Acceleration.Length>350 || s.AngularAcceleration.Length>2500*Math.Max(1,s.WristSpeedScale*s.WristSpeedScale);}
        private static bool UnsafeGripRoute(PhraseState s,PhraseGeometry g)
        {
            // The independently certified scored wrist is retained verbatim.
            // Testing a repair's unused rotation used to throw away reachable
            // grip contacts and substitute replay travel through the stream.
            return s.MinimumReachAdjusted || s.Velocity.Length>18 || !(g.ScoredHumanSwings && g.StableFastGrip) && s.AngularVelocity.Length>125*Math.Max(1,s.WristSpeedScale);
        }
        private static bool FastJoin(ReachTransition curve,double start,double end,PhraseGeometry g)
        {for(int i=1;i<32;i++)if(Project(curve.Sample(start+(end-start)*i/32),g).Velocity.Length>17.5)return true;return false;}
        private static void Add(MotionPhrase route,PhraseState s)
        {if(route.Knots.Count==0 || s.Time-route.Knots[route.Knots.Count-1].Time>.002)route.Knots.Add(s);}
        private static MotionVector Shoulder(PhraseGeometry g,double t){return g.ShoulderAt==null ? g.Shoulder : g.ShoulderAt(t);}
        // Analytic radial barrier. Its value and first/second derivatives join
        // the unmodified path exactly. It cannot teleport a projected hand or
        // introduce an independently smoothed position/rotation target.
        public static PhraseState Project(PhraseState input,PhraseGeometry g)
        {
            return ProjectOwned(input.Copy(),g);
        }
        private static PhraseState ProjectOwned(PhraseState s,PhraseGeometry g)
        {
            MotionVector shoulder=Shoulder(g,s.Time),p=s.Grip-shoulder;
            double r=p.Length,threshold=g.Reach*.985,span=g.Reach-threshold;
            bool inner=g.MinimumReach>0 && r<g.MinimumReach*1.04;
            s.MinimumReachAdjusted=inner;
            if(!inner && r<=threshold)return s;
            if(r<1e-8){s.Grip=shoulder+g.Forward.Unit*g.MinimumReach;s.Velocity=s.Acceleration=new MotionVector();return s;}
            if(inner){threshold=g.MinimumReach*1.04;span=threshold-g.MinimumReach;}
            MotionVector sv=new MotionVector(),sa=new MotionVector();
            if(g.ShoulderAt!=null)
            {const double e=.002;MotionVector left=Shoulder(g,s.Time-e),right=Shoulder(g,s.Time+e);sv=(right-left)/(2*e);sa=(right+left-shoulder*2)/(e*e);}
            MotionVector v=s.Velocity-sv,a=s.Acceleration-sa;
            double rd=MotionVector.Dot(p,v)/r,rdd=(MotionVector.Dot(v,v)+MotionVector.Dot(p,a)-rd*rd)/r;
            double tanh=Math.Tanh((r-threshold)/span),m=threshold+span*tanh,md=1-tanh*tanh,mdd=-2*tanh*md/span;
            double f=m/r,fr=md/r-m/(r*r),frr=mdd/r-2*md/(r*r)+2*m/(r*r*r),fd=fr*rd,fdd=frr*rd*rd+fr*rdd;
            s.Grip=shoulder+p*f;s.Velocity=sv+v*f+p*fd;s.Acceleration=sa+a*f+v*(2*fd)+p*fdd;return s;
        }
        // Published contacts/seeds are already in the radial constraint's
        // output space. Fit corrections and repair joins in its preimage so
        // the final projection is applied once. Reprojecting an endpoint had
        // moved it by millimetres on the very next frame, despite C2 splines.
        public static PhraseState Unproject(PhraseState input,PhraseGeometry g)
        {
            var s=input.Copy();MotionVector shoulder=Shoulder(g,s.Time),p=s.Grip-shoulder;double r=p.Length;
            double threshold=g.Reach*.985,span=g.Reach-threshold;
            bool inner=g.MinimumReach>0 && r<g.MinimumReach*1.04;
            if(!inner && r<=threshold || r<1e-8)return s;
            if(inner){threshold=g.MinimumReach*1.04;span=threshold-g.MinimumReach;}
            double u=MotionPhrase.Clamp((r-threshold)/span,-1+1e-10,1-1e-10);
            double m=threshold+span*.5*Math.Log((1+u)/(1-u)),md=1/(1-u*u),mdd=2*u*md*md/span;
            MotionVector sv=new MotionVector(),sa=new MotionVector();
            if(g.ShoulderAt!=null)
            {const double e=.002;var left=Shoulder(g,s.Time-e);var right=Shoulder(g,s.Time+e);sv=(right-left)/(2*e);sa=(right+left-shoulder*2)/(e*e);}
            var v=s.Velocity-sv;var a=s.Acceleration-sa;
            double rd=MotionVector.Dot(p,v)/r,rdd=(MotionVector.Dot(v,v)+MotionVector.Dot(p,a)-rd*rd)/r;
            double f=m/r,fr=md/r-m/(r*r),frr=mdd/r-2*md/(r*r)+2*m/(r*r*r),fd=fr*rd,fdd=frr*rd*rd+fr*rdd;
            s.Grip=shoulder+p*f;s.Velocity=sv+v*f+p*fd;s.Acceleration=sa+a*f+v*(2*fd)+p*fdd;return s;
        }
        private static PhraseState Side(Hit hit,double dt,PhraseGeometry g,Func<double,PhraseState> teacher)
        {
            var s=teacher(hit.Pose.Time+dt).Copy();s.Time=hit.Pose.Time+dt;s.Id=-1;
            MotionRotation delta=hit.Pose.Rotation*hit.Human.Rotation.Inverse;
            s.Grip+=hit.Pose.Grip-hit.Human.Grip;s.Rotation=delta*s.Rotation;s.AngularVelocity=delta.Rotate(s.AngularVelocity);s.AngularAcceleration=delta.Rotate(s.AngularAcceleration);
            // The recorded swing already contains its preparation and release.
            // Forcing universal 102/60 degree arcs over it added another swing
            // and a reversal. Carry the same fitted contact displacement and
            // wrist offset through the actual recorded approach instead.
            return Project(s,g);
        }
        private static PhraseState Turn(Hit left,Hit right,PhraseGeometry g,Func<double,PhraseState> teacher)
        {
            double gap=right.Pose.Time-left.Pose.Time,t=left.Pose.Time+gap*.5;
            var s=teacher(t).Copy();s.Time=t;s.Id=-1;
            MotionVector a=left.Pose.Grip-left.Human.Grip,b=right.Pose.Grip-right.Human.Grip;
            s.Grip+=(a+b)*.5;s.Velocity+=(b-a)/gap;
            MotionRotation l=left.Pose.Rotation*left.Human.Rotation.Inverse,r=right.Pose.Rotation*right.Human.Rotation.Inverse;
            MotionVector turn=MotionRotation.Log(r*l.Inverse);MotionRotation delta=MotionRotation.Exp(turn*.5)*l;
            s.Rotation=delta*s.Rotation;s.AngularVelocity=delta.Rotate(s.AngularVelocity)+turn/gap;
            s.AngularAcceleration=delta.Rotate(s.AngularAcceleration)+MotionVector.Cross(turn/gap,delta.Rotate(teacher(t).AngularVelocity));
            return Project(s,g);
        }
    }
}
