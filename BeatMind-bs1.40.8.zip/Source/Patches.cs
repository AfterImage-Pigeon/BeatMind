using System;
using System.Collections;
using HarmonyLib;
using UnityEngine;
using TMPro;

namespace SaberMind
{
    [HarmonyPatch(typeof(StandardLevelScenesTransitionSetupDataSO), "InitAndSetupScenes")]
    internal static class PreparePatch
    {
        private static void Prefix(StandardLevelScenesTransitionSetupDataSO __instance, PlayerSpecificSettings playerSpecificSettings)
        { Session.Prepare(__instance, playerSpecificSettings); }
    }

    [HarmonyPatch(typeof(StandardLevelGameplayManager), "Start")]
    internal static class BeginPatch
    {
        private static void Prefix(StandardLevelGameplayManager __instance, AudioTimeSyncController ____audioTimeSyncController, IReadonlyBeatmapData ____beatmapData)
        { Session.Begin(__instance, ____audioTimeSyncController, ____beatmapData); }
        private static void Postfix(ref IEnumerator __result)
        { if (Session.Current != null) __result = Session.DelaySongStart(__result); }
    }

    [HarmonyPatch(typeof(StandardLevelGameplayManager), "OnDestroy")]
    internal static class EndPatch
    {
        private static void Prefix(StandardLevelGameplayManager __instance) { Session.EndOwner(__instance); }
    }

    [HarmonyPatch(typeof(StandardLevelScenesTransitionSetupDataSO), "Finish")]
    internal static class FinishPatch
    {
        [HarmonyPriority(Priority.First)]
        private static void Prefix(LevelCompletionResults levelCompletionResults)
        {
            if (!Session.BotWasUsed) return;
            Session.BotResult = levelCompletionResults;
            BS_Utils.Gameplay.ScoreSubmission.DisableSubmission(Plugin.Id);
            if (Session.Current == null) return;
            try
            {
                Session.ReviewAutoRestart(levelCompletionResults);
                Session.Current.CaptureResult(levelCompletionResults);
            }
            finally
            {
                Session.Stop("Attempt finished");
                if(Plugin.Host!=null && Session.AutoRestartStatus!=null)
                    Plugin.Host.Menu.SetStatus(Session.AutoRestartStatus);
            }
        }
    }

    [HarmonyPatch(typeof(ResultsViewController), "SetDataToUI")]
    internal static class ResultsDisplayPatch
    {
        // BS Utils appends its notice on every redraw, while another results
        // mod reads the intentionally negative insurance score as a percent.
        // Correct only the view; never change the guarded result or submission.
        [HarmonyPriority(Priority.Last)]
        private static void Postfix(ResultsViewController __instance,LevelCompletionResults ____levelCompletionResults,
            GameObject ____clearedBannerGo,TextMeshProUGUI ____rankText,TextMeshProUGUI ____scoreText)
        {
            LevelCompletionResults result=____levelCompletionResults;
            if(result==null || !object.ReferenceEquals(result,Session.BotResult)) return;
            if(Plugin.Host!=null) Plugin.Host.QueueAutoRestart(__instance,result);
            if(result.levelEndStateType!=LevelCompletionResults.LevelEndStateType.Cleared) return;
            if(____clearedBannerGo!=null)
            {
                HMUI.CurvedTextMeshPro banner=____clearedBannerGo.GetComponentInChildren<HMUI.CurvedTextMeshPro>(true);
                if(banner!=null) banner.text=ResultsText.RemoveRepeatedWarning(banner.text);
            }
            if(____rankText!=null) ____rankText.text=ResultsText.PositiveRank(____rankText.text,result.multipliedScore<0);
            if(____scoreText!=null) ____scoreText.text=ScoreFormatter.Format(System.Math.Max(0,result.modifiedScore));
        }
    }

    [HarmonyPatch(typeof(BeatmapObjectManager), "AddSpawnedNoteController")]
    internal static class SpawnPatch
    {
        private static void Postfix(BeatmapObjectManager __instance,NoteController noteController)
        { if (Session.Current != null && Session.Current.OwnsNotes(__instance)) Session.Current.Add(noteController); }
    }

    [HarmonyPatch(typeof(BeatmapObjectManager), "Despawn", new Type[] { typeof(NoteController) })]
    internal static class DespawnPatch
    {
        private static void Prefix(BeatmapObjectManager __instance,NoteController noteController)
        { if (Session.Current != null && Session.Current.OwnsNotes(__instance)) Session.Current.Remove(noteController); }
    }

    [HarmonyPatch(typeof(BeatmapObjectManager), "HandleNoteControllerNoteWasCut")]
    internal static class CutPatch
    {
        private static void Prefix(BeatmapObjectManager __instance,NoteController noteController, ref NoteCutInfo noteCutInfo)
        { if (Session.Current != null && Session.Current.OwnsNotes(__instance)) Session.Current.Observe(noteController, true, noteCutInfo); }
    }

    [HarmonyPatch(typeof(BeatmapObjectManager), "HandleNoteControllerNoteWasMissed")]
    internal static class MissPatch
    {
        private static void Prefix(BeatmapObjectManager __instance,NoteController noteController)
        { if (Session.Current != null && Session.Current.OwnsNotes(__instance)) Session.Current.Observe(noteController, false, default(NoteCutInfo)); }
    }

    [HarmonyPatch(typeof(CutScoreBuffer), "HandleSaberSwingRatingCounterDidFinish")]
    internal static class CutScorePatch
    {
        private static void Postfix(CutScoreBuffer __instance)
        {
            if (Session.Current != null)
                Session.Current.ObserveScore(__instance.noteCutInfo.noteData, __instance.cutScore, __instance.maxPossibleCutScore);
        }
    }

    [HarmonyPatch(typeof(Saber), "ManualUpdate")]
    internal static class SaberPatch
    {
        [HarmonyPriority(Priority.Last)]
        private static void Prefix(Saber __instance)
        {
            if (Session.Current == null || !Session.Current.OwnsSaber(__instance)) return;
            try { Session.Current.Move(__instance); }
            catch (Exception error)
            {
                Plugin.Log.Error("Bot control stopped: " + error);
                Session.Stop("Control error; check the game log");
            }
        }
    }

    [HarmonyPatch(typeof(GameEnergyCounter), "ProcessEnergyChange")]
    internal static class NoFailPatch
    {
        private static void Prefix(ref float energyChange)
        { if (Session.Current != null && !Session.Current.Multiplayer && energyChange < 0) energyChange = 0; }
    }

    [HarmonyPatch(typeof(PlayerTransforms), "Update")]
    internal static class BodyPosePatch
    {
        private static void Postfix(PlayerTransforms __instance)
        {
            if (Session.Current == null || !Session.Current.OwnsPlayer(__instance)) return;
            try { Session.Current.ApplyBody(); }
            catch (Exception error) { Plugin.Log.Error("Body control stopped: " + error); Session.Stop("Body control error"); }
        }
    }
}
