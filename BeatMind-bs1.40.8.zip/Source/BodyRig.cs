using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
namespace SaberMind
{
    internal static class VisualLayers
    {
        internal static int FindUnused(int excluded)
        {bool[] used=new bool[32];foreach(var t in UnityEngine.Object.FindObjectsOfType<Transform>())used[t.gameObject.layer]=true;for(int i=31;i>=16;i--)if(i!=excluded && !used[i] && string.IsNullOrEmpty(LayerMask.LayerToName(i)))return i;throw new InvalidOperationException("No free training render layer.");}
    }
    internal sealed class BodyRig : IDisposable
    {
        internal readonly GameObject Root;internal readonly Transform Head,Torso;
        internal readonly Transform[] Shoulders=new Transform[2],UpperArms=new Transform[2],Elbows=new Transform[2],Forearms=new Transform[2],Wrists=new Transform[2],Hands=new Transform[2];
        internal readonly BodySettings Proportions;internal readonly int VisualLayer;
        private readonly Vector3 origin,forward,right;private readonly Quaternion basis;
        private readonly List<ObstacleData> walls;
        private readonly Dictionary<ObstacleData,Vector3> wallOffsets=new Dictionary<ObstacleData,Vector3>();
        private readonly Vector3[] poles=new Vector3[2],gripSockets=new Vector3[2];
        internal void ConfigureSaber(int color,Vector3 socket){gripSockets[color]=socket;}
        private readonly Vector3[] previousJointVelocity=new Vector3[2],previousJointAcceleration=new Vector3[2];
        internal HumanMotionGraph Motion;
        internal float PeakJointSpeed,PeakJointAcceleration,PeakJointJerk,LastReachError,LastWristError;
        internal Vector3 Origin{get{return origin;}}internal Vector3 Forward{get{return forward;}}
        internal float Reach{get{return (float)JointGeometry.Distance(Proportions.UpperArm,Proportions.Forearm+Proportions.Hand,168);}}
        internal float MinimumReach{get{return (float)JointGeometry.Distance(Proportions.UpperArm,Proportions.Forearm+Proportions.Hand,25);}}
        internal Vector3 MapPoint(int lane,int layer){return origin+right*((lane-1.5f)*.6f)+Vector3.up*(.85f+layer*.6f)+forward*.45f;}
        internal BodyRig(Vector3 initialHead,Vector3 facing,BodySettings settings,ModelProfile model,List<ObstacleData> obstacles)
        {
            Proportions=settings;walls=obstacles;forward=Vector3.ProjectOnPlane(facing,Vector3.up).normalized;if(forward.sqrMagnitude<.01f)forward=Vector3.forward;
            right=Vector3.Cross(Vector3.up,forward);basis=Quaternion.LookRotation(forward);origin=initialHead-Vector3.up*settings.Height;
            VisualLayer=VisualLayers.FindUnused(-1);Root=new GameObject("BeatMind invisible articulated player");Head=Joint("Head",Root.transform);Torso=Joint("Torso",Root.transform);
            for(int i=0;i<2;i++)
            {string name=i==0 ? "Left " : "Right ";Shoulders[i]=Joint(name+"shoulder",Torso);UpperArms[i]=Joint(name+"upper arm",Shoulders[i]);Elbows[i]=Joint(name+"elbow",UpperArms[i]);Forearms[i]=Joint(name+"forearm",Elbows[i]);Wrists[i]=Joint(name+"wrist",Forearms[i]);Hands[i]=Joint(name+"hand",Wrists[i]);poles[i]=right*(i==0 ? -1 : 1)-Vector3.up*.5f-forward*.15f;}
            // The hierarchy contains transforms only. No white debug mesh,
            // primitive, line renderer, collider or body material is created.
            Tick(0,initialHead+forward*2,new BehaviorChoice(),.016f);
            for(int i=0;i<2;i++)SeedArm(i,Shoulders[i].position+forward*.30f-Vector3.up*.20f,basis,Vector3.forward,new BehaviorChoice());
        }
        private Transform Joint(string name,Transform parent){var obj=new GameObject(name);obj.transform.SetParent(parent,false);return obj.transform;}
        internal PhraseState HumanPose(double time,int joint)
        {
            PhraseState s=Motion==null ? new PhraseState{Time=time,Grip=joint==0 ? new MotionVector(0,1.7,0) : new MotionVector(joint==1 ? -.3 : .3,1.2,.28),Rotation=joint==0 ? MotionRotation.Identity : MotionRotation.Exp(new MotionVector(.55,0,0))} : Motion.Sample(time,joint);
            return MapHumanPose(s,joint,Proportions.Height/1.7f,MovementPlanner.Q(basis),MovementPlanner.V(origin),gripSockets);
        }
        private static PhraseState MapHumanPose(PhraseState input,int joint,float scale,MotionRotation q,MotionVector originPoint,Vector3[] sockets)
        {
            // Graph/tape samples are caller-owned. Mapping that same pose
            // avoids cloning every head/hand sample and derivative probe.
            var s=input;
            s.Grip=originPoint+q.Rotate(s.Grip*scale);s.Velocity=q.Rotate(s.Velocity*scale);s.Acceleration=q.Rotate(s.Acceleration*scale);s.Rotation=q*s.Rotation;s.AngularVelocity=q.Rotate(s.AngularVelocity);s.AngularAcceleration=q.Rotate(s.AngularAcceleration);
            if(joint>0)
            {
                MotionVector offset=s.Rotation.Rotate(MovementPlanner.V(sockets[joint-1]));
                s.Grip+=offset;s.Velocity+=MotionVector.Cross(s.AngularVelocity,offset);
                s.Acceleration+=MotionVector.Cross(s.AngularAcceleration,offset)+MotionVector.Cross(s.AngularVelocity,MotionVector.Cross(s.AngularVelocity,offset));
            }
            return s;
        }
        internal Func<double,int,PhraseState> CaptureHuman(double start,double end)
        {
            var source=Motion==null ? null : Motion.Capture(start,end);float scale=Proportions.Height/1.7f;
            MotionRotation q=MovementPlanner.Q(basis);MotionVector originPoint=MovementPlanner.V(origin);var sockets=(Vector3[])gripSockets.Clone();
            return delegate(double time,int joint)
            {
                var s=source==null ? new PhraseState{Time=time,Grip=joint==0 ? new MotionVector(0,1.7,0) : new MotionVector(joint==1 ? -.3 : .3,1.2,.28),Rotation=joint==0 ? MotionRotation.Identity : MotionRotation.Exp(new MotionVector(.55,0,0))} : source(time,joint);
                return MapHumanPose(s,joint,scale,q,originPoint,sockets);
            };
        }
        private Vector3 HeadAt(double time,Func<double,int,PhraseState> captured=null)
        {
            Vector3 measured=MovementPlanner.V((captured==null ? HumanPose(time,0) : captured(time,0)).Grip);Vector3 shift=Vector3.zero;
            foreach(var wall in walls)
            {
                if(time<wall.time-.80 || time>wall.time+wall.duration+.35)continue;
                Vector3 offset;
                if(!wallOffsets.TryGetValue(wall,out offset))
                {
                    Vector3 future=MovementPlanner.V((captured==null ? HumanPose(wall.time+.05,0) : captured(wall.time+.05,0)).Grip)-origin;
                    float sourceX=Vector3.Dot(future,right),height=future.y,left=(wall.lineIndex-2)*.60f,edge=left+wall.width*.60f,bottom=.60f+(int)wall.lineLayer*.60f,top=bottom+wall.height*.60f;
                    offset=Vector3.zero;
                    if(sourceX+.18f>left && sourceX-.18f<edge && height+.10f>bottom && height-.20f<top)
                    {
                        float toLeft=left-.24f-sourceX,toRight=edge+.24f-sourceX;
                        float dx=Mathf.Abs(toLeft)<Mathf.Abs(toRight) ? toLeft : toRight;
                        float crouch=Mathf.Min(0,bottom-.16f-height);
                        bool canCrouch=height+crouch>.82f;
                        offset=canCrouch && Mathf.Abs(crouch)<Mathf.Abs(dx) ? Vector3.up*crouch : right*dx;
                    }
                    wallOffsets[wall]=offset;
                }
                double enter=Smooth((time-(wall.time-.80))/.62),leave=Smooth((wall.time+wall.duration+.35-time)/.35);
                shift+=offset*(float)(enter*leave);
            }
            return measured+shift;
        }
        private static double Smooth(double u){u=MotionPhrase.Clamp(u,0,1);return u*u*u*(10+u*(-15+6*u));}
        internal Vector3 ShoulderAt(double time,int color,Func<double,int,PhraseState> captured=null)
        {
            var head=captured==null ? HumanPose(time,0) : captured(time,0);Quaternion rotation=MovementPlanner.Q(head.Rotation);
            Vector3 gaze=Vector3.ProjectOnPlane(rotation*Vector3.forward,Vector3.up).normalized;
            if(gaze.sqrMagnitude<.01f)gaze=forward;
            Quaternion torso=Quaternion.LookRotation(Vector3.Slerp(forward,gaze,.28f));
            return HeadAt(time,captured)-Vector3.up*.23f+forward*.025f+torso*Vector3.right*(color==0 ? -1 : 1)*(Proportions.ShoulderWidth*.5f);
        }
        internal void Tick(float songTime,Vector3 focus,BehaviorChoice behavior,float delta,float breakStrength=0)
        {
            if(Motion!=null)Motion.BeginFrame(songTime);
            var pose=HumanPose(songTime,0);Head.SetPositionAndRotation(HeadAt(songTime),MovementPlanner.Q(pose.Rotation));
            Vector3 left=ShoulderAt(songTime,0),rightShoulder=ShoulderAt(songTime,1),center=(left+rightShoulder)*.5f;
            Vector3 lateral=(rightShoulder-left).normalized,torsoForward=Vector3.Cross(lateral,Vector3.up).normalized;
            // Torso/shoulders are inferred from tracked head/hands, while the
            // recorded camera retains its real tilt, lean and gaze.
            Vector3 handCenter=MovementPlanner.V((HumanPose(songTime,1).Grip+HumanPose(songTime,2).Grip)*.5);
            Vector3 lean=Vector3.ClampMagnitude(Vector3.ProjectOnPlane(handCenter-center,Vector3.up)*.12f,.055f);
            Quaternion torsoRotation=Quaternion.LookRotation(torsoForward,(Vector3.up+lean).normalized);
            Torso.SetPositionAndRotation(center-Vector3.up*(Proportions.Torso*.5f),torsoRotation);
            for(int i=0;i<2;i++)Shoulders[i].SetPositionAndRotation(i==0 ? left : rightShoulder,torsoRotation);
        }
        internal void SeedArm(int color,Vector3 grip,Quaternion rotation,Vector3 axis,BehaviorChoice behavior){PublishArm(color,grip,rotation);}
        internal Vector3 AdvanceArm(int color,Vector3 target,Quaternion wrist,Vector3 axis,BehaviorChoice behavior,float tempo,float delta)
        {
            Quaternion before=UpperArms[color].rotation;Vector3 result=PublishArm(color,target,wrist);
            Vector3 velocity=JointMotion.Log(UpperArms[color].rotation*Quaternion.Inverse(before))/Mathf.Max(.001f,delta);
            Vector3 acceleration=(velocity-previousJointVelocity[color])/Mathf.Max(.001f,delta);
            PeakJointSpeed=Mathf.Max(PeakJointSpeed,velocity.magnitude);PeakJointAcceleration=Mathf.Max(PeakJointAcceleration,acceleration.magnitude);PeakJointJerk=Mathf.Max(PeakJointJerk,(acceleration-previousJointAcceleration[color]).magnitude/Mathf.Max(.001f,delta));
            previousJointVelocity[color]=velocity;previousJointAcceleration[color]=acceleration;return result;
        }
        private Vector3 PublishArm(int color,Vector3 requested,Quaternion rotation)
        {
            Vector3 shoulder=Shoulders[color].position,v=requested-shoulder;float a=Proportions.UpperArm,b=Proportions.Forearm+Proportions.Hand;
            float distance=Mathf.Clamp(v.magnitude,MinimumReach,Reach);Vector3 direction=v.sqrMagnitude<.0001f ? forward : v.normalized;
            Vector3 hand=shoulder+direction*distance;LastReachError=Vector3.Distance(hand,requested);
            Vector3 pole=Vector3.ProjectOnPlane(poles[color],direction).normalized;
            if(pole.sqrMagnitude<.001f)pole=Vector3.ProjectOnPlane(right*(color==0 ? -1 : 1)-Vector3.up*.5f,direction).normalized;
            poles[color]=pole;float along=(a*a-b*b+distance*distance)/(2*distance),height=Mathf.Sqrt(Mathf.Max(0,a*a-along*along));
            Vector3 elbow=shoulder+direction*along+pole*height,upper=(elbow-shoulder).normalized,lower=(hand-elbow).normalized;
            UpperArms[color].SetPositionAndRotation(shoulder,Quaternion.LookRotation(upper,pole));Elbows[color].position=elbow;
            Forearms[color].SetPositionAndRotation(elbow,Quaternion.LookRotation(lower,pole));Wrists[color].SetPositionAndRotation(elbow+lower*Proportions.Forearm,rotation);Hands[color].SetPositionAndRotation(hand,rotation);return hand;
        }
        internal Quaternion WristTarget(int color,Quaternion rotation,Vector3 localAxis)
        {
            float angle=Vector3.Angle(Forearms[color].forward,rotation*localAxis);LastWristError=Mathf.Max(0,angle-155)/25;
            // A planned scoring contact takes precedence over a soft inferred
            // elbow/wrist estimate; tracking doesn't measure human elbows.
            return rotation;
        }
        internal void ApplyWrist(int color,Quaternion rotation){Wrists[color].rotation=rotation;Hands[color].rotation=rotation;}
        private static readonly FieldInfo HeadTransform = AccessTools.Field(typeof(PlayerTransforms), "_headTransform");
        private static readonly FieldInfo OriginParent = AccessTools.Field(typeof(PlayerTransforms), "_originParentTransform");
        private static readonly FieldInfo UseParent = AccessTools.Field(typeof(PlayerTransforms), "_useOriginParentTransformForPseudoLocalCalculations");
        private static readonly Dictionary<string, FieldInfo> PoseFields = new Dictionary<string, FieldInfo>();
        private static void Field(PlayerTransforms player, string name, object value)
        {
            FieldInfo f;
            if (!PoseFields.TryGetValue(name, out f)) { f = AccessTools.Field(typeof(PlayerTransforms), name); PoseFields[name] = f; }
            if (f != null) f.SetValue(player, value);
        }
        internal void ApplyPlayerPose(PlayerTransforms player)
        {
            if (player == null) return;
            player.OverrideHeadPos(Head.position);
            Transform tracking = (Transform)HeadTransform.GetValue(player);
            Transform parent = (bool)UseParent.GetValue(player) ? (Transform)OriginParent.GetValue(player) : tracking.parent;
            Vector3 local = parent == null ? Head.position : parent.InverseTransformPoint(Head.position);
            Quaternion localRotation = parent == null ? Head.rotation : Quaternion.Inverse(parent.rotation) * Head.rotation;
            Field(player, "_headWorldRot", Head.rotation); Field(player, "_headPseudoLocalPos", local);
            Field(player, "_headPseudoLocalRot", localRotation); Field(player, "_headPseudoLocalZOnlyPos", new Vector3(0, 0, local.z));
            for (int i = 0; i < 2; i++)
            {
                string sideName = i == 0 ? "_leftHand" : "_rightHand";
                Field(player, sideName + "PseudoLocalPos", parent == null ? Hands[i].position : parent.InverseTransformPoint(Hands[i].position));
                Field(player, sideName + "PseudoLocalRot", parent == null ? Hands[i].rotation : Quaternion.Inverse(parent.rotation) * Hands[i].rotation);
            }
        }
        public void Dispose(){if(Root!=null)UnityEngine.Object.Destroy(Root);}
    }
}
