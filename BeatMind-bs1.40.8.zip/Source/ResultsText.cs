using System;

namespace SaberMind
{
    // Pure results-screen formatting; the score-submission guard remains intact.
    public static class ResultsText
    {
        public static string RemoveRepeatedWarning(string text)
        {
            if(String.IsNullOrEmpty(text)) return text;
            int marker=text.IndexOf("Score Submission Disabled by:",StringComparison.OrdinalIgnoreCase);
            if(marker<0) return text;
            int start=text.LastIndexOf("<color=#ff0000ff>",marker,StringComparison.OrdinalIgnoreCase);
            if(start<0) start=text.LastIndexOf("<size=50%>",marker,StringComparison.OrdinalIgnoreCase);
            if(start<0) start=marker;
            return text.Substring(0,start).TrimEnd();
        }

        public static string PositiveRank(string text,bool insuranceNegatedScore)
        {
            if(!insuranceNegatedScore || String.IsNullOrEmpty(text)) return text;
            // SongPlayHistory may append a score difference computed from the
            // negative insurance value. Hide that misleading second line.
            int newline=text.IndexOf('\n');
            if(newline>=0) text=text.Substring(0,newline);
            for(int i=0;i+1<text.Length;i++)
            {
                if(text[i]!='-' || !Char.IsDigit(text[i+1])) continue;
                if(text.LastIndexOf('<',i)>text.LastIndexOf('>',i)) continue;
                return text.Remove(i,1);
            }
            return text;
        }
    }
}
