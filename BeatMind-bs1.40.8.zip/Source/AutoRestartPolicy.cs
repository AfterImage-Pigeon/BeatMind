using System;
using System.Globalization;

namespace SaberMind
{
    public struct GoalStep
    {
        public int Streak;
        public bool Restart,Reached;
    }

    public static class AutoRestartPolicy
    {
        public const double TargetAccuracy=.95;
        public const int DefaultTargetPercent=95;
        public const int RequiredStreak=3;
        public static readonly int[] TargetPercentOptions={90,92,95,97,98,99,100};

        public static int NormalizeTargetPercent(int targetPercent)
        {
            foreach(int option in TargetPercentOptions) if(targetPercent==option) return option;
            return DefaultTargetPercent;
        }

        public static GoalStep Evaluate(int previousStreak,double measuredAccuracy,bool eligibleAttempt)
        { return Evaluate(previousStreak,measuredAccuracy,eligibleAttempt,DefaultTargetPercent); }

        public static GoalStep Evaluate(int previousStreak,double measuredAccuracy,bool eligibleAttempt,int targetPercent)
        {
            if(!eligibleAttempt || Double.IsNaN(measuredAccuracy) || Double.IsInfinity(measuredAccuracy)
                || measuredAccuracy<0 || measuredAccuracy>1.01)
                return new GoalStep();
            double target=NormalizeTargetPercent(targetPercent)/100.0;
            int streak=measuredAccuracy>=target ? Math.Min(RequiredStreak,Math.Max(0,previousStreak)+1) : 0;
            return new GoalStep {Streak=streak,Reached=streak>=RequiredStreak,Restart=streak<RequiredStreak};
        }

        public static string Status(GoalStep step,double measuredAccuracy,int targetPercent)
        {
            string goal=NormalizeTargetPercent(targetPercent).ToString(CultureInfo.InvariantCulture)+"%";
            return step.Reached
                ? goal+" reached in "+RequiredStreak+" consecutive runs. Auto-restart stopped."
                : "Accuracy "+(measuredAccuracy*100).ToString("0.00",CultureInfo.InvariantCulture)
                    +"%; target "+goal+"; streak "+step.Streak+"/"+RequiredStreak+". Auto-restarting.";
        }
    }
}
