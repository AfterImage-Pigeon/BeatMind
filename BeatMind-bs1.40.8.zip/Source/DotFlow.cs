using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace SaberMind
{
    internal static class DotFlow
    {
        private sealed class CachedChart
        {
            internal int Count;
            internal PatternAnalysis Normal,NoArrows;
        }
        private static readonly ConditionalWeakTable<object,CachedChart> Cache=new ConditionalWeakTable<object,CachedChart>();

        private static PatternAnalysis For(IList<NoteData> chart,bool noArrows)
        {
            CachedChart cached;
            if(!Cache.TryGetValue(chart,out cached) || cached.Count!=chart.Count)
            {
                Cache.Remove(chart);cached=new CachedChart {Count=chart.Count};Cache.Add(chart,cached);
            }
            PatternAnalysis saved=noArrows ? cached.NoArrows : cached.Normal;
            if(saved!=null) return saved;
            var events=new List<PatternEvent>(chart.Count);
            for(int i=0;i<chart.Count;i++)
            {
                NoteData note=chart[i];
                Vector3 direction=PreSongTrainer.CutDirection(note.cutDirection,Vector3.right);
                direction=Quaternion.AngleAxis(note.cutDirectionAngleOffset,Vector3.forward)*direction;
                events.Add(new PatternEvent {Time=note.time,Hand=(int)note.colorType,Lane=note.lineIndex,
                    Layer=(int)note.noteLineLayer,Dot=noArrows || note.cutDirection==NoteCutDirection.Any,
                    HasDirectionHint=noArrows && note.cutDirection!=NoteCutDirection.Any,
                    Direction=new PlanarStroke(direction.x,direction.y)});
            }
            var analysis=PatternFlow.Analyze(events);
            if(noArrows) cached.NoArrows=analysis;else cached.Normal=analysis;
            return analysis;
        }

        internal static Vector3 Direction(IList<NoteData> chart,int index,Vector3 right,bool noArrows=false)
        {
            NoteData note=chart[index];
            if(!noArrows && note.cutDirection!=NoteCutDirection.Any)
                return PreSongTrainer.CutDirection(note.cutDirection,right);
            PlanarStroke resolved=For(chart,noArrows).Directions[index];
            // Callers apply this note's angle offset after Direction. Undo it
            // here so a dot reverses the preceding actual cut, even on tech
            // maps with custom arrow angles; do not rotate the alternation twice.
            double angle=-note.cutDirectionAngleOffset*Math.PI/180;
            double x=resolved.X*Math.Cos(angle)-resolved.Y*Math.Sin(angle);
            double y=resolved.X*Math.Sin(angle)+resolved.Y*Math.Cos(angle);
            return (right*(float)x+Vector3.up*(float)y).normalized;
        }

        internal static MotionPattern Pattern(IList<NoteData> chart,int index,bool noArrows=false)
        { return For(chart,noArrows).Patterns[index]; }
    }
}
