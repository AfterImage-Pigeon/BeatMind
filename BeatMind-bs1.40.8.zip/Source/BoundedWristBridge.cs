using System;

namespace SaberMind
{
    // A C2 wrist connector in bounded blade coordinates. A quintic Bezier
    // stays in the pitch/side rectangle when every control lies inside it.
    // Endpoint jets are retained; an infeasible control polygon is rejected.
    public sealed class BoundedWristBridge
    {
        public const double MinimumPitchDegrees=-40,MaximumPitchDegrees=100;
        public const double MinimumSideDegrees=-45,MaximumSideDegrees=45;
        public readonly double Start,End;
        public readonly bool Safe;
        private readonly double duration;
        private readonly MotionVector right,up,localBlade;
        private readonly MotionRotation alignment;
        private readonly ScalarCurve pitch,side,roll,gripX,gripY,gripZ;
        private readonly double humanGrip,humanWrist,wristScale;
        private readonly int source;

        private struct Coordinate
        {
            internal double Pitch,Side,Roll,PitchRate,SideRate,RollRate,PitchAcceleration,SideAcceleration,RollAcceleration;
        }
        private struct ScalarCurve
        {
            private readonly double c0,c1,c2,c3,c4,c5,duration;
            internal ScalarCurve(double a,double av,double aa,double b,double bv,double ba,double length)
            {
                duration=length;c0=a;c1=a+av*length/5;c2=a+av*length*2/5+aa*length*length/20;
                c5=b;c4=b-bv*length/5;c3=b-bv*length*2/5+ba*length*length/20;
            }
            internal bool Within(double minimum,double maximum)
            {return In(c0,minimum,maximum) && In(c1,minimum,maximum) && In(c2,minimum,maximum) && In(c3,minimum,maximum) && In(c4,minimum,maximum) && In(c5,minimum,maximum);}
            private static bool In(double value,double minimum,double maximum)
            // Quaternion decomposition can differ by a few ulps at an exact
            // rectangle corner. This only tolerates numerical error; it never
            // changes the curve controls, endpoint velocities or accelerations.
            {return !double.IsNaN(value) && !double.IsInfinity(value) && value>=minimum-1e-12 && value<=maximum+1e-12;}
            internal void Sample(double u,out double value,out double rate,out double acceleration)
            {
                double v=1-u,u2=u*u,u3=u2*u,u4=u3*u,u5=u4*u,v2=v*v,v3=v2*v,v4=v3*v,v5=v4*v;
                value=c0*v5+5*c1*u*v4+10*c2*u2*v3+10*c3*u3*v2+5*c4*u4*v+c5*u5;
                rate=5*((c1-c0)*v4+4*(c2-c1)*u*v3+6*(c3-c2)*u2*v2+4*(c4-c3)*u3*v+(c5-c4)*u4)/duration;
                acceleration=20*((c2-2*c1+c0)*v3+3*(c3-2*c2+c1)*u*v2+3*(c4-2*c3+c2)*u2*v+(c5-2*c4+c3)*u3)/(duration*duration);
            }
        }

        public BoundedWristBridge(PhraseState a,PhraseState b,PhraseGeometry geometry)
        {
            if(a==null || b==null || geometry==null)throw new ArgumentNullException("Wrist bridge endpoints and geometry are required.");
            if(!Finite(a.Time) || !Finite(b.Time) || b.Time<=a.Time)throw new ArgumentException("Wrist bridge endpoint times must be finite and increasing.");
            Start=a.Time;End=b.Time;duration=End-Start;up=new MotionVector(0,1,0);
            var forward=new MotionVector(geometry.Forward.X,0,geometry.Forward.Z).Unit;
            if(forward.Length<.5)forward=new MotionVector(0,0,1);
            right=MotionVector.Cross(up,forward).Unit;localBlade=(geometry.Top-geometry.Bottom).Unit;
            if(localBlade.Length<.5)throw new ArgumentException("Wrist bridge requires a nonzero local blade axis.");
            alignment=MotionRotation.FromTo(localBlade,forward,up);
            Coordinate left=Decompose(a,forward),last=Decompose(b,forward);
            last.Roll=left.Roll+Wrap(last.Roll-left.Roll);
            pitch=new ScalarCurve(left.Pitch,left.PitchRate,left.PitchAcceleration,last.Pitch,last.PitchRate,last.PitchAcceleration,duration);
            side=new ScalarCurve(left.Side,left.SideRate,left.SideAcceleration,last.Side,last.SideRate,last.SideAcceleration,duration);
            roll=new ScalarCurve(left.Roll,left.RollRate,left.RollAcceleration,last.Roll,last.RollRate,last.RollAcceleration,duration);
            gripX=new ScalarCurve(a.Grip.X,a.Velocity.X,a.Acceleration.X,b.Grip.X,b.Velocity.X,b.Acceleration.X,duration);
            gripY=new ScalarCurve(a.Grip.Y,a.Velocity.Y,a.Acceleration.Y,b.Grip.Y,b.Velocity.Y,b.Acceleration.Y,duration);
            gripZ=new ScalarCurve(a.Grip.Z,a.Velocity.Z,a.Acceleration.Z,b.Grip.Z,b.Velocity.Z,b.Acceleration.Z,duration);
            const double radians=Math.PI/180;
            Safe=pitch.Within(MinimumPitchDegrees*radians,MaximumPitchDegrees*radians) && side.Within(MinimumSideDegrees*radians,MaximumSideDegrees*radians);
            humanGrip=Math.Min(a.HumanGripWeight,b.HumanGripWeight);humanWrist=Math.Min(a.HumanWristWeight,b.HumanWristWeight);source=b.HumanSource;wristScale=Math.Max(a.WristSpeedScale,b.WristSpeedScale);
        }

        private Coordinate Decompose(PhraseState state,MotionVector forward)
        {
            var rotation=state.Rotation.Unit;var blade=rotation.Rotate(localBlade);
            var velocity=MotionVector.Cross(state.AngularVelocity,blade);
            var acceleration=MotionVector.Cross(state.AngularAcceleration,blade)+MotionVector.Cross(state.AngularVelocity,velocity);
            double x=MotionVector.Dot(blade,right),y=MotionVector.Dot(blade,up),z=MotionVector.Dot(blade,forward);
            double xd=MotionVector.Dot(velocity,right),yd=MotionVector.Dot(velocity,up),zd=MotionVector.Dot(velocity,forward);
            double xdd=MotionVector.Dot(acceleration,right),ydd=MotionVector.Dot(acceleration,up),zdd=MotionVector.Dot(acceleration,forward);
            double radius2=y*y+z*z,radius=Math.Sqrt(radius2),turn=z*yd-y*zd;
            var c=new Coordinate{Pitch=Math.Atan2(y,z),Side=Math.Asin(Math.Max(-1,Math.Min(1,x)))};
            c.PitchRate=turn/radius2;c.PitchAcceleration=(z*ydd-y*zdd)/radius2-2*turn*(y*yd+z*zd)/(radius2*radius2);
            c.SideRate=xd/radius;c.SideAcceleration=xdd/radius+x*xd*xd/(radius2*radius);
            var pitchRotation=MotionRotation.Exp(right*(-c.Pitch));var rotatedUp=pitchRotation.Rotate(up);
            var canonical=pitchRotation*MotionRotation.Exp(up*c.Side)*alignment;
            var relative=canonical.Inverse*rotation;
            c.Roll=Wrap(2*Math.Atan2(MotionVector.Dot(relative.Vector,localBlade),relative.W));
            var pitchVelocity=right*(-c.PitchRate);var sideVelocity=rotatedUp*c.SideRate;
            c.RollRate=MotionVector.Dot(state.AngularVelocity-pitchVelocity-sideVelocity,blade);
            c.RollAcceleration=MotionVector.Dot(state.AngularAcceleration-right*(-c.PitchAcceleration)-rotatedUp*c.SideAcceleration-MotionVector.Cross(pitchVelocity,sideVelocity),blade);
            return c;
        }

        // Speed-only feasibility probes need neither a pose allocation nor
        // grip/rotation reconstruction. This is the exact transported-axis
        // norm used by Sample, including the pitch/roll cross term.
        public double AngularSpeed(double time)
        {
            double u=Math.Max(0,Math.Min(1,(time-Start)/duration));
            double value,pd,pdd,s,sd,sdd,rd,rdd;
            pitch.Sample(u,out value,out pd,out pdd);side.Sample(u,out s,out sd,out sdd);roll.Sample(u,out value,out rd,out rdd);
            return Math.Sqrt(Math.Max(0,pd*pd+sd*sd+rd*rd-2*pd*rd*Math.Sin(s)));
        }
        public PhraseState Sample(double time)
        {
            double u=Math.Max(0,Math.Min(1,(time-Start)/duration));
            double p,pd,pdd,s,sd,sdd,r,rd,rdd,x,xd,xdd,y,yd,ydd,z,zd,zdd;
            pitch.Sample(u,out p,out pd,out pdd);side.Sample(u,out s,out sd,out sdd);roll.Sample(u,out r,out rd,out rdd);
            gripX.Sample(u,out x,out xd,out xdd);gripY.Sample(u,out y,out yd,out ydd);gripZ.Sample(u,out z,out zd,out zdd);
            var pitchRotation=MotionRotation.Exp(right*(-p));var rotatedUp=pitchRotation.Rotate(up);
            var canonical=pitchRotation*MotionRotation.Exp(up*s)*alignment;
            var blade=canonical.Rotate(localBlade);var wp=right*(-pd);var ws=rotatedUp*sd;var wr=blade*rd;
            return new PhraseState{Time=time,Grip=new MotionVector(x,y,z),Velocity=new MotionVector(xd,yd,zd),Acceleration=new MotionVector(xdd,ydd,zdd),
                Rotation=(canonical*MotionRotation.Exp(localBlade*r)).Unit,AngularVelocity=wp+ws+wr,
                AngularAcceleration=right*(-pdd)+rotatedUp*sdd+MotionVector.Cross(wp,ws)+blade*rdd+MotionVector.Cross(wp+ws,wr),
                HumanGripWeight=humanGrip,HumanWristWeight=humanWrist,HumanSource=source,WristSpeedScale=wristScale};
        }

        private static double Wrap(double angle)
        {while(angle>Math.PI)angle-=2*Math.PI;while(angle<=-Math.PI)angle+=2*Math.PI;return angle;}
        private static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
    }
}
