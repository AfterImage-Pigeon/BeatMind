using System;
using System.Collections.Generic;
using UnityEngine;

namespace SaberMind
{
    internal sealed class MultiplayerSocial : IDisposable
    {
        private readonly BodyRig body;
        private readonly BehaviorChoice behavior=new BehaviorChoice();
        private readonly DeliberateWaveDetector[] waves={new DeliberateWaveDetector(),new DeliberateWaveDetector()};
        private readonly Quaternion[] wristRotations={Quaternion.identity,Quaternion.identity};
        private readonly Vector3[] wristVelocity=new Vector3[2],wristAcceleration=new Vector3[2];
        private float nextObserve,waveStart=-100;
        private int lastFrame=-1;
        internal MultiplayerSocial(MenuPlayerController controller,int model)
        {
            Vector3 head=controller.headPos;head.y=Settings.Current.Height;
            Vector3 facing=Vector3.ProjectOnPlane(controller.headRot*Vector3.forward,Vector3.up).normalized;
            if(facing.sqrMagnitude<.01f)facing=Vector3.forward;
            body=new BodyRig(head,facing,Settings.Current,ModelProfile.All[model],new List<ObstacleData>());
            for(int i=0;i<2;i++)wristRotations[i]=body.Hands[i].rotation;
        }
        internal void Publish(INodePoseSyncStateManager poses,IConnectedPlayer human,int model)
        {
            if(poses.localState==null || Time.frameCount==lastFrame)return;lastFrame=Time.frameCount;
            float now=Time.unscaledTime;
            if(model==2 && human!=null && now>=nextObserve)
            {
                nextObserve=now+.05f;
                var remote=poses.GetSyncStateForPlayer(human);
                if(remote!=null)
                {
                    Vector3 head=remote.GetState(NodePoseSyncState.NodePose.Head,poses.syncTime-60).position;
                    for(int i=0;i<2;i++)
                    {
                        Vector3 hand=remote.GetState(i==0?NodePoseSyncState.NodePose.LeftController:NodePoseSyncState.NodePose.RightController,poses.syncTime-60).position;
                        if(waves[i].Sample(now,head.y,hand.y,hand.x))
                        {waveStart=now;Plugin.Log.Info("SaberMind Model 3: measured deliberate wave; one coordinated response.");break;}
                    }
                }
            }
            float phase=now-waveStart;
            float blend=phase<0 || phase>2.8f ? 0 : phase<.5f ? Mathf.SmoothStep(0,1,phase/.5f)
                : phase>2.3f ? Mathf.SmoothStep(1,0,(phase-2.3f)/.5f) : 1;
            float delta=Mathf.Clamp(Time.deltaTime,.001f,.05f);
            // Stable posture is the default. The same body/arm motors perform
            // the raised-hand gesture, including bounded wrist rotation.
            body.Tick(now,body.Origin+body.Forward*2+Vector3.up*Settings.Current.Height,behavior,delta);
            Vector3 right=Vector3.Cross(Vector3.up,body.Forward);
            for(int i=0;i<2;i++)
            {
                Vector3 resting=body.Shoulders[i].position+body.Forward*.32f-Vector3.up*.23f;
                Vector3 raised=body.Shoulders[i].position+body.Forward*.28f+Vector3.up*.14f+right*(.085f*Mathf.Sin(phase*11));
                Vector3 target=i==1?Vector3.Lerp(resting,raised,blend):resting;
                Quaternion wrist=Quaternion.LookRotation(body.Forward,Vector3.up);
                if(i==1)wrist=Quaternion.AngleAxis(blend*Mathf.Sin(phase*11)*12,body.Forward)*wrist;
                body.AdvanceArm(i,target,wristRotations[i],Vector3.forward,behavior,0,delta);
                Quaternion anatomical=body.WristTarget(i,wrist,Vector3.forward);
                wristRotations[i]=JointMotion.Advance(wristRotations[i],anatomical,ref wristVelocity[i],ref wristAcceleration[i],
                    Vector3.zero,Vector3.zero,delta,14,450,3500,60000);
                body.ApplyWrist(i,wristRotations[i]);
            }
            // Native sync buffers retain their normal delta/full-packet rates
            // and interpolation. Publish three final poses, never trajectory points.
            poses.localState.SetState(NodePoseSyncState.NodePose.Head,new PoseSerializable(body.Head.position,body.Head.rotation));
            poses.localState.SetState(NodePoseSyncState.NodePose.LeftController,new PoseSerializable(body.Hands[0].position,body.Hands[0].rotation));
            poses.localState.SetState(NodePoseSyncState.NodePose.RightController,new PoseSerializable(body.Hands[1].position,body.Hands[1].rotation));
        }
        public void Dispose(){body.Dispose();}
    }
}
