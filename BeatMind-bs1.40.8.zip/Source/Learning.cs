using System;
using System.Collections.Generic;

namespace SaberMind
{
    public static class FlowPath
    {
        public static float Ease(float value)
        {
            value = Math.Max(0, Math.Min(1, value));
            return value * value * value * (value * (value * 6 - 15) + 10);
        }
        public static float DenseArcScale(float sameHandSpacing)
        { return .60f + .40f * Ease((sameHandSpacing - .07f) / .23f); }
    }
    public sealed class StrokeVariant
    {
        public readonly float Offset,HalfDuration;
        public StrokeVariant(float offset,float halfDuration)
        {Offset=offset;HalfDuration=halfDuration;}
    }
    public sealed class NoteMemory
    {
        public int[] Trials = new int[Policy.Variants.Length];
        public double[] Rewards = new double[Policy.Variants.Length];
        public void Normalize()
        {
            if (Trials == null || Trials.Length != Policy.Variants.Length) Trials = new int[Policy.Variants.Length];
            if (Rewards == null || Rewards.Length != Policy.Variants.Length) Rewards = new double[Policy.Variants.Length];
            for (int i = 0; i < Trials.Length; i++)
            {
                Trials[i] = Math.Max(0, Math.Min(1000000, Trials[i]));
                if (double.IsNaN(Rewards[i]) || double.IsInfinity(Rewards[i])) Rewards[i] = 0;
                Rewards[i] = Math.Max(0, Math.Min(Trials[i], Rewards[i]));
            }
        }
    }

    public sealed class LevelMemory
    {
        public int Format = 1;
        public string Identity;
        public int Attempts;
        public int LastGood;
        public int LastBad;
        public int LastMissed;
        public int BestGood;
        public Dictionary<string, NoteMemory> Notes = new Dictionary<string, NoteMemory>();
        public Dictionary<string, ModelMemory> Models = new Dictionary<string, ModelMemory>();
        public ModelMemory ForModel(string model)
        {
            if (Models == null) Models = new Dictionary<string, ModelMemory>();
            ModelMemory value;
            if (!Models.TryGetValue(model, out value) || value == null) Models[model] = value = new ModelMemory();
            return value;
        }
        public NoteMemory Get(string key)
        {
            if (Notes == null) Notes = new Dictionary<string, NoteMemory>();
            NoteMemory note;
            if (!Notes.TryGetValue(key, out note) || note == null) Notes[key] = note = new NoteMemory();
            note.Normalize();
            return note;
        }
    }

    public static class Policy
    {
        public static readonly StrokeVariant[] Variants = {
            new StrokeVariant(0, .065f), new StrokeVariant(-.020f, .065f),
            new StrokeVariant(.020f, .065f), new StrokeVariant(0, .045f),
            new StrokeVariant(-.035f, .045f), new StrokeVariant(.035f, .045f),
            new StrokeVariant(0, .090f), new StrokeVariant(-.020f, .090f),
            new StrokeVariant(.020f, .090f)
        };

        public static int Choose(NoteMemory note, bool learn)
        { return Choose(note,learn,.92); }
        public static int Choose(NoteMemory note, bool learn, double targetAccuracy)
        {
            note.Normalize();
            int best = 0, total = 0;
            double bestMean = -1;
            for (int i = 0; i < Variants.Length; i++)
            {
                total += note.Trials[i];
                double mean = note.Trials[i] == 0 ? -1 : note.Rewards[i] / note.Trials[i];
                if (mean > bestMean) { bestMean = mean; best = i; }
            }
            if (!learn) return best;
            // Keep a consistently clean stroke. Explore alternatives for weak notes.
            if (bestMean >= Math.Max(.80,Math.Min(1,targetAccuracy)) && note.Trials[best] >= 2) return best;
            for (int i = 0; i < Variants.Length; i++) if (note.Trials[i] == 0) return i;
            double bestBound = double.NegativeInfinity;
            for (int i = 0; i < Variants.Length; i++)
            {
                double bound = note.Rewards[i] / note.Trials[i]
                    + .25 * Math.Sqrt(2 * Math.Log(total + 1) / note.Trials[i]);
                if (bound > bestBound) { bestBound = bound; best = i; }
            }
            return best;
        }

        // A best whole-run replay is a useful starting point, but may not
        // override newer evidence that its stroke scores below the target.
        public static bool ReuseReplayStroke(NoteMemory note,int variant,double targetAccuracy)
        {
            if(variant<0 || variant>=Variants.Length)return false;
            note.Normalize();int total=0;foreach(int n in note.Trials)total+=n;
            if(total==0)return true;
            if(note.Trials[variant]<2)return false;
            double mean=note.Rewards[variant]/note.Trials[variant];
            int best=Choose(note,false);
            return mean>=Math.Max(.80,Math.Min(1,targetAccuracy)) && mean+1e-9>=note.Rewards[best]/Math.Max(1,note.Trials[best]);
        }

        public static void Observe(NoteMemory note, int variant, double reward)
        {
            if (variant < 0 || variant >= Variants.Length) throw new ArgumentOutOfRangeException("variant");
            if (double.IsNaN(reward) || double.IsInfinity(reward)) throw new ArgumentOutOfRangeException("reward");
            note.Normalize();
            if (note.Trials[variant] >= 1000000) { note.Trials[variant] /= 2; note.Rewards[variant] /= 2; }
            note.Trials[variant]++;
            note.Rewards[variant] += Math.Max(0, Math.Min(1, reward));
        }
    }
}
