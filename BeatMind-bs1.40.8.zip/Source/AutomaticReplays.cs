using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace SaberMind
{
    public sealed class BotReplayWindow {public long Start,End;}
    public sealed class AutomaticReplays
    {
        private readonly string supplied,recordings,statePath;
        private readonly object sync=new object();
        private readonly List<BotReplayWindow> windows=new List<BotReplayWindow>();
        private BotReplayWindow active;
        private string revision;
        public AutomaticReplays(string manualFolder,string recordingFolder,string state)
        {
            supplied=manualFolder;recordings=recordingFolder;statePath=state;
            foreach(string candidate in new[]{statePath,statePath+".bak"})
            {
                if(!File.Exists(candidate)) continue;
                try {var saved=JsonConvert.DeserializeObject<List<BotReplayWindow>>(File.ReadAllText(candidate));
                    if(saved!=null) {foreach(var w in saved) if(w!=null && w.Start>0 && w.End>=w.Start) windows.Add(w);break;}}
                catch(IOException) {} catch(JsonException) {}
            }
        }
        public void BeginBot(DateTime utc)
        {lock(sync) {active=new BotReplayWindow {Start=utc.AddSeconds(-3).Ticks,End=utc.AddSeconds(30).Ticks};windows.Add(active);Save();}}
        public void CheckpointBot(DateTime utc)
        {lock(sync) {if(active!=null) {active.End=utc.AddSeconds(30).Ticks;Save();}}}
        public void EndBot(DateTime utc)
        {lock(sync) {if(active!=null) {active.End=utc.AddSeconds(30).Ticks;active=null;Save();}}}
        private void Save()
        {
            // Keep durable provenance across restarts and F8 takeover. Originals
            // are neither moved nor deleted; the learner simply skips AI runs.
            Directory.CreateDirectory(Path.GetDirectoryName(statePath));
            File.WriteAllText(statePath+".tmp",JsonConvert.SerializeObject(windows));
            if(File.Exists(statePath)) File.Replace(statePath+".tmp",statePath,statePath+".bak");else File.Move(statePath+".tmp",statePath);
        }
        public string[] Collect(bool automatic,DateTime utc)
        {
            var paths=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(string folder in automatic ? new[]{supplied,recordings} : new[]{supplied})
            {
                if(!Directory.Exists(folder)) continue;
                string[] files=Directory.GetFiles(folder,"*.bsor",SearchOption.TopDirectoryOnly);Array.Sort(files,StringComparer.OrdinalIgnoreCase);
                foreach(string path in files)
                {
                    try
                    {
                        long length,ticks;ReplayFileAccess.Metadata(path,out length,out ticks);
                        if(ticks>utc.AddSeconds(-3).Ticks) continue;
                        // BeatLeader filenames include recording start UTC. A
                        // bot's file may finish writing after its run has ended.
                        string name=Path.GetFileNameWithoutExtension(path);int dash=name.LastIndexOf('-');long stamp,recorded=0;
                        if(dash>=0 && long.TryParse(name.Substring(dash+1),out stamp) && stamp>1000000000 && stamp<3000000000)
                            recorded=new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddSeconds(stamp).Ticks;
                        bool bot=false;lock(sync) foreach(var w in windows) if((ticks>=w.Start && ticks<=w.End) || (recorded>=w.Start && recorded<=w.End)) {bot=true;break;}
                        if(bot) continue;
                        // A recording manually copied from the automatic folder
                        // is one example source, rather than two identical runs.
                        string key=Path.GetFileName(path)+"|"+length;
                        if(seen.Add(key)) paths.Add(path);
                    }
                    catch(IOException) {} catch(UnauthorizedAccessException) {}
                }
            }
            paths.Sort(StringComparer.OrdinalIgnoreCase);return paths.ToArray();
        }
        internal static string SourceRevision(string[] paths)
        {
            var keys=new List<string>();
            foreach(string path in paths) {long bytes,ticks;ReplayFileAccess.Metadata(path,out bytes,out ticks);keys.Add(path+"|"+bytes+"|"+ticks);}
            return string.Join(";",keys.ToArray());
        }
        internal void Observe(string observedRevision)
        {revision=observedRevision;}
        public bool Changed(bool automatic,DateTime utc)
        {
            string next=SourceRevision(Collect(automatic,utc));if(next==revision) return false;revision=next;return true;
        }
    }
}
