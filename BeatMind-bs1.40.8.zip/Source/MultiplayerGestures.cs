using System;

namespace SaberMind
{
    // Consume measured remote controller motion; never initiate a wave at random.
    public sealed class DeliberateWaveDetector
    {
        private double lastTime=double.NaN,start,turnX,lastX,nextAllowed;
        private int direction,reversals;
        public void Reset(){lastTime=double.NaN;direction=reversals=0;}
        public bool Sample(double time,double headY,double handY,double handX)
        {
            if(double.IsNaN(time) || double.IsInfinity(time) || double.IsNaN(headY) || double.IsNaN(handY) ||
                double.IsNaN(handX) || double.IsInfinity(handX) || handY<headY-.18 || time<nextAllowed)
            {Reset();return false;}
            if(double.IsNaN(lastTime) || time<=lastTime || time-lastTime>.25 || time-start>2)
            {start=lastTime=time;turnX=lastX=handX;direction=reversals=0;return false;}
            lastTime=time;double change=handX-lastX;
            if(Math.Abs(change)<.006)return false;
            int moving=change>0?1:-1;
            if(direction==0)direction=moving;
            else if(moving!=direction && Math.Abs(lastX-turnX)>=.08)
            {
                reversals++;turnX=lastX;direction=moving;
                if(reversals>=2 && time-start>=.35){nextAllowed=time+8;Reset();return true;}
            }
            lastX=handX;return false;
        }
    }
}
