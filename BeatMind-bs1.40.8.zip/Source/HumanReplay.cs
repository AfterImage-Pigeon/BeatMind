using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
namespace SaberMind {
    public static class HumanReplayLibrary {
        public const long MaximumFileBytes = 128L * 1024 * 1024;
        private const int MaximumFrames=1200000, RetainedFrames=180000, MaximumNotes=250000;
        internal sealed class Replay
        {
            internal string PlayerId,Timestamp,Hash,Difficulty,Mode;
            internal int Score;
            internal double StartTime,FailTime,PracticeSpeed;
            internal readonly List<Frame> Frames = new List<Frame>();
            internal readonly List<Note> Notes = new List<Note>();
        }
        internal sealed class Frame
        {
            internal double Time;
            internal Pose Head, Left, Right;
            internal Pose Hand(int hand) { return hand == 0 ? Left : Right; }
        }
        internal struct Pose
        {
            internal MotionVector Position;
            internal MotionRotation Rotation;
            internal bool Valid;
        }
        internal sealed class Note
        {
            internal double Time,SpawnTime,Score,TimeDeviation;
            internal int Hand, Lane, Layer, Direction,ScoringType;
            internal bool Good;
            internal MotionVector CutDirection,CutPoint;
        }
        // BSOR v1's documented little-endian info/frames/notes sections:
        // https://github.com/BeatLeader/BS-Open-Replay
        // Later optional extension sections are deliberately not interpreted.
        internal static Replay Read(string path)
        {return Read(path,null);}
        internal static Replay Read(string path,Action waitForIdle)
        {
            var result = new Replay();
            using (var stream = ReplayFileAccess.OpenRead(path))
            using (var reader = new BinaryReader(stream, Encoding.UTF8))
            {
                if (stream.Length < 16 || stream.Length > MaximumFileBytes) throw new InvalidDataException("Invalid replay size.");
                if (reader.ReadInt32() != 0x442d3d69 || reader.ReadByte() != 1) throw new InvalidDataException("Expected a BSOR v1 replay.");
                RequireSection(reader, 0);
                string mod = ReadString(reader);
                ReadString(reader); result.Timestamp=ReadString(reader); result.PlayerId=ReadString(reader);
                string player = ReadString(reader);
                ReadString(reader); ReadString(reader); ReadString(reader); ReadString(reader);
                result.Hash=ReadString(reader); ReadString(reader); ReadString(reader); result.Difficulty=ReadString(reader);
                result.Score=reader.ReadInt32(); result.Mode=ReadString(reader); ReadString(reader);
                string modifiers = ReadString(reader);
                reader.ReadSingle(); reader.ReadBoolean(); reader.ReadSingle();
                result.StartTime=reader.ReadSingle(); result.FailTime=reader.ReadSingle();
                double speed = reader.ReadSingle();
                result.PracticeSpeed=speed;
                // BeatLeader stores zero here for ordinary non-practice runs.
                if (!Finite(speed) || speed < 0 || speed > 3) throw new InvalidDataException("Invalid replay song speed.");
                // Explicit labels are rejected; an arbitrary BSOR cannot prove
                // human authorship, so callers must select a trusted recording.
                string identity = (mod + " " + player + " " + modifiers).ToLowerInvariant();
                if (identity.Contains("sabermind") || identity.Contains("beatgpt") || identity.Contains("beatmind") || identity.Contains("autoplay"))
                    throw new InvalidDataException("This replay identifies automated play.");
                RequireSection(reader, 1);
                int frames = ReadCount(reader, MaximumFrames, 92);
                int stride = Math.Max(1, (frames + RetainedFrames - 1) / RetainedFrames);
                double last = Double.NegativeInfinity;
                for (int i = 0; i < frames; i++)
                {
                    if(waitForIdle!=null && (i&255)==0)waitForIdle();
                    double time = reader.ReadSingle(); reader.ReadInt32();
                    Pose head = ReadPose(reader), left = ReadPose(reader), right = ReadPose(reader);
                    if ((i % stride != 0 && i != frames - 1) || !Finite(time) || time < -30 || time > 21600 ||
                        time <= last || !head.Valid || !left.Valid || !right.Valid) continue;
                    result.Frames.Add(new Frame { Time = time, Head = head, Left = left, Right = right }); last = time;
                }
                RequireSection(reader, 2);
                int notes = ReadCount(reader, MaximumNotes, 16);
                for (int i = 0; i < notes; i++)
                {
                    if(waitForIdle!=null && (i&255)==0)waitForIdle();
                    int id = reader.ReadInt32(); double time = reader.ReadSingle(); double spawn=reader.ReadSingle(); int type = reader.ReadInt32();
                    if (type < 0 || type > 3) throw new InvalidDataException("Unsupported replay note event.");
                    var note = new Note { Time = time,SpawnTime=spawn, Hand = id / 10 % 10, Lane = id / 1000 % 10, Layer = id / 100 % 10, Direction = id % 10,ScoringType=id/10000-2 };
                    if (type == 0 || type == 1)
                    {
                        bool fast = reader.ReadBoolean(), direction = reader.ReadBoolean(), saber = reader.ReadBoolean(), early = reader.ReadBoolean();
                        double cutSpeed = reader.ReadSingle(); note.CutDirection = ReadVector(reader);
                        int hand = reader.ReadInt32(); note.TimeDeviation=reader.ReadSingle(); reader.ReadSingle();
                        note.CutPoint=ReadVector(reader); ReadVector(reader);
                        double distance = reader.ReadSingle(); reader.ReadSingle();
                        double before = reader.ReadSingle(), after = reader.ReadSingle();
                        note.Score = 70 * MotionPhrase.Clamp(before,0,1) + 30 * MotionPhrase.Clamp(after,0,1) + 15 * (1-MotionPhrase.Clamp(distance/.3,0,1));
                        note.Good = type == 0 && fast && direction && saber && !early && hand == note.Hand &&
                            Finite(cutSpeed) && cutSpeed >= 1 && cutSpeed <= 100 && Finite(distance) && distance >= 0 && distance <= .18 &&
                            Finite(before) && before >= .75 && Finite(after) && after >= .65 && ValidVector(note.CutDirection) && note.CutDirection.Length > .1;
                    }
                    if (Finite(spawn) && spawn>=-30 && spawn<=21600 && Finite(time) && time >= -30 && time <= 21600 && note.Hand >= 0 && note.Hand < 2 && note.Lane < 4 && note.Layer < 3)
                        result.Notes.Add(note);
                }
            }
            result.Notes.Sort(delegate(Note a, Note b) { return a.Time.CompareTo(b.Time); });
            if (result.Frames.Count < 100) throw new InvalidDataException("Too few valid tracking frames.");
            return result;
        }

        private static string ReadString(BinaryReader reader)
        {
            int length = reader.ReadInt32();
            if (length < 0 || length > 16384 || length > reader.BaseStream.Length - reader.BaseStream.Position)
                throw new InvalidDataException("Invalid replay string length.");
            byte[] value = reader.ReadBytes(length);
            if (value.Length != length) throw new EndOfStreamException();
            return Encoding.UTF8.GetString(value);
        }
        private static int ReadCount(BinaryReader reader, int limit, int minimumBytes)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > limit || (long)count * minimumBytes > reader.BaseStream.Length - reader.BaseStream.Position)
                throw new InvalidDataException("Invalid replay section length.");
            return count;
        }
        private static void RequireSection(BinaryReader reader, byte section)
        { if (reader.ReadByte() != section) throw new InvalidDataException("Unsupported replay section order."); }
        private static MotionVector ReadVector(BinaryReader reader)
        { return new MotionVector(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()); }
        private static Pose ReadPose(BinaryReader reader)
        {
            MotionVector p = ReadVector(reader);
            var q = new MotionRotation(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
            double n = q.Length;
            bool valid = ValidVector(p) && p.Length <= 100 && Finite(n) && n >= .5 && n <= 1.5;
            return new Pose { Position = p, Rotation = valid ? q.Unit : MotionRotation.Identity, Valid = valid };
        }
        private static bool Finite(double x) { return !Double.IsNaN(x) && !Double.IsInfinity(x); }
        private static bool ValidVector(MotionVector v) { return Finite(v.X) && Finite(v.Y) && Finite(v.Z); }


    }
}
