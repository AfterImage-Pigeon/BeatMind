using System;
using System.Collections.Generic;

namespace SaberMind
{
    // Learned offsets are requests, not permission to reverse chart order.
    // Project each request into its own temporal slot. A stack shares a slot
    // and one median contact time; the other hand remains independent.
    public static class CutSchedule
    {
        private sealed class Group
        {
            internal double Time;
            internal readonly List<int> Notes=new List<int>();
        }
        public static double[] Resolve(double[] times,int[] hands,double[] offsets)
        {
            if(times==null || hands==null || offsets==null || times.Length!=hands.Length || times.Length!=offsets.Length)
                throw new ArgumentException("Contact schedule inputs must have matching lengths.");
            var result=new double[times.Length];
            for(int i=0;i<times.Length;i++)
            {
                if(double.IsNaN(times[i]) || double.IsInfinity(times[i]) || double.IsNaN(offsets[i]) || double.IsInfinity(offsets[i]))
                    throw new ArgumentException("Contact times must be finite.");
                result[i]=times[i]+offsets[i];
            }
            for(int hand=0;hand<2;hand++)
            {
                var order=new List<int>();for(int i=0;i<times.Length;i++)if(hands[i]==hand)order.Add(i);
                order.Sort(delegate(int a,int b){int comparison=times[a].CompareTo(times[b]);return comparison==0 ? a.CompareTo(b) : comparison;});
                var groups=new List<Group>();
                foreach(int i in order)
                {
                    Group g=groups.Count==0 ? null : groups[groups.Count-1];
                    // Same chart timestamp, not merely nearby learned hits.
                    if(g==null || times[i]!=g.Time){g=new Group{Time=times[i]};groups.Add(g);}
                    g.Notes.Add(i);
                }
                for(int k=0;k<groups.Count;k++)
                {
                    Group g=groups[k];var requested=new double[g.Notes.Count];
                    for(int j=0;j<requested.Length;j++)requested[j]=offsets[g.Notes[j]];
                    Array.Sort(requested);int middle=requested.Length/2;
                    double offset=requested.Length%2==0 ? (requested[middle-1]+requested[middle])*.5 : requested[middle];
                    // Retain at least half of each distinct chart gap for the
                    // outgoing wrist transition. Merely preventing reversal
                    // left the reproduced up/down pair too close to reach.
                    double low=k==0 ? double.NegativeInfinity : -.25*(g.Time-groups[k-1].Time);
                    double high=k+1==groups.Count ? double.PositiveInfinity : .25*(groups[k+1].Time-g.Time);
                    double hit=g.Time+Math.Max(low,Math.Min(high,offset));
                    foreach(int i in g.Notes)result[i]=hit;
                }
            }
            return result;
        }
        public static bool MergeContact(double chartTime,double previousChartTime,double hit,double previousHit,bool chainSegment=false)
        {
            // Nearby distinct arrows must retain their own direction/identity.
            return chartTime==previousChartTime && hit==previousHit ||
                chainSegment && chartTime>previousChartTime && chartTime-previousChartTime<.012 && hit>=previousHit && hit-previousHit<.012;
        }
    }
}
