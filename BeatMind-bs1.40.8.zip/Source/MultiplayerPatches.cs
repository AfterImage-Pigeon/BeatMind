using HarmonyLib;

namespace SaberMind
{
    [HarmonyPatch(typeof(MultiplayerLevelScenesTransitionSetupDataSO),"Init")]
    internal static class MultiplayerBoundaryPatch
    {private static void Prefix(){Session.EnterMultiplayer();}}
    [HarmonyPatch(typeof(CreateServerViewController),"DidActivate")]
    internal static class MultiplayerMenuPatch
    {
        private static void Postfix(CreateServerViewController __instance)
        {
            if(MultiplayerIntegration.Companion)return;
            try {MultiplayerMenu menu=__instance.GetComponent<MultiplayerMenu>()??__instance.gameObject.AddComponent<MultiplayerMenu>();menu.Show(__instance);}
            catch(System.Exception e){Plugin.Log.Error("SaberMind create-server panel: "+e);}
        }
    }
    [HarmonyPatch(typeof(CreateServerViewController),"ApplyAndGetData")]
    internal static class PrivateCreateFormPatch
    {private static void Postfix(ref CreateServerFormData __result){MultiplayerIntegration.Creating(ref __result);}}
    [HarmonyPatch(typeof(MultiplayerLobbyConnectionController),MethodType.Constructor)]
    internal static class LobbyControllerPatch
    {private static void Postfix(MultiplayerLobbyConnectionController __instance){MultiplayerIntegration.Attach(__instance);}}
    [HarmonyPatch(typeof(MultiplayerLobbyConnectionController),"ConnectToParty")]
    internal static class CompanionJoinPatch
    {private static bool Prefix(string serverCode){return MultiplayerIntegration.JoinAllowed(serverCode);}}
    [HarmonyPatch(typeof(MultiplayerLobbyConnectionController),"ConnectToMatchmaking")]
    internal static class CompanionPublicMatchPatch
    {private static bool Prefix(){return !MultiplayerIntegration.Companion;}}
    [HarmonyPatch(typeof(MultiplayerLobbyConnectionController),"ConnectToServer")]
    internal static class CompanionOtherServerPatch
    {private static bool Prefix(){return !MultiplayerIntegration.Companion;}}
    [HarmonyPatch(typeof(MultiplayerLobbyConnectionController),"CreateParty")]
    internal static class CompanionCreatePatch
    {private static bool Prefix(){return !MultiplayerIntegration.Companion;}}
    [HarmonyPatch(typeof(PlatformAuthenticationTokenProvider),MethodType.Constructor,new[] {typeof(IPlatformUserModel),typeof(UserInfo)})]
    internal static class CompanionAuthenticationPatch
    {private static void Postfix(PlatformAuthenticationTokenProvider __instance){MultiplayerIntegration.AuthenticationReady(__instance);}}
    [HarmonyPatch(typeof(PlatformAuthenticationTokenProvider),"get_userName")]
    internal static class CompanionDisplayNamePatch
    {private static void Postfix(PlatformAuthenticationTokenProvider __instance,ref string __result){MultiplayerIntegration.Alias(__instance,ref __result);}}
    [HarmonyPatch(typeof(MultiplayerLocalActiveClient),"Start")]
    internal static class CompanionClientPatch
    {private static void Postfix(MultiplayerLocalActiveClient __instance,PlayerTransforms ____playerTransforms,
        AudioTimeSyncController ____audioTimeSyncController,BeatmapObjectManager ____beatmapObjectManager,IScoreController ____scoreController)
        {MultiplayerIntegration.LocalClient(__instance,____playerTransforms,____audioTimeSyncController,____beatmapObjectManager,____scoreController);}}
    [HarmonyPatch(typeof(MultiplayerLocalActivePlayerGameplayManager),"Start")]
    internal static class CompanionSabersPatch
    {private static void Postfix(SaberManager ____saberManager){MultiplayerIntegration.LocalSabers(____saberManager);}}
    [HarmonyPatch(typeof(MultiplayerController),"StartGameplay")]
    internal static class CompanionStartPatch
    {private static void Postfix(MultiplayerPlayersManager ____playersManager,GameplayCoreSceneSetupData ____sceneSetupData)
        {MultiplayerIntegration.StartGameplay(____playersManager.activeLocalPlayerFacade,____sceneSetupData);}}
    [HarmonyPatch(typeof(MultiplayerLocalActiveClient),"LateUpdate")]
    internal static class CompanionPosePublisherPatch
    {private static void Prefix(PlayerTransforms ____playerTransforms)
        {if(Session.Current==null || !Session.Current.Multiplayer || !Session.Current.OwnsPlayer(____playerTransforms))return;
            try{Session.Current.ApplyBody();}catch(System.Exception e){Plugin.Log.Error("Companion body pose: "+e);Session.Stop("Companion pose error");}}}
    [HarmonyPatch(typeof(MultiplayerLocalActivePlayerFacade),"ReportPlayerDidFinish")]
    internal static class CompanionFinishPatch
    {private static void Prefix(MultiplayerLocalActivePlayerFacade __instance,MultiplayerLevelCompletionResults results){MultiplayerIntegration.Finished(__instance,results);}}
    [HarmonyPatch(typeof(MultiplayerLocalActiveClient),"OnDestroy")]
    internal static class CompanionClientEndPatch
    {private static void Prefix(MultiplayerLocalActiveClient __instance){MultiplayerIntegration.LocalClientDestroyed(__instance);}}
    [HarmonyPatch(typeof(MultiplayerLobbyController),"ActivateMultiplayerLobby")]
    internal static class CompanionLobbyActivePatch
    {private static void Postfix(){MultiplayerIntegration.LobbyActive(true);}}
    [HarmonyPatch(typeof(MultiplayerLobbyController),"DeactivateMultiplayerLobby")]
    internal static class CompanionLobbyInactivePatch
    {private static void Prefix(){MultiplayerIntegration.LobbyActive(false);}}
    [HarmonyPatch(typeof(MultiplayerMenuClient),"LateUpdate")]
    internal static class CompanionLobbyPosePatch
    {private static void Postfix(MenuPlayerController ____menuPlayerController,INodePoseSyncStateManager ____nodePoseSyncStateManager)
        {MultiplayerIntegration.PublishLobby(____menuPlayerController,____nodePoseSyncStateManager);}}
}
