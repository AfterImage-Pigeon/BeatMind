using System;
using System.Collections.Generic;
namespace SaberMind
{
    // A local arm detour, used only when a Cartesian handoff would pass
    // through the shoulder. Projecting a near-zero radius onto a minimum
    // reach sphere amplifies velocity; plan an arc around that sphere instead.
    public sealed class ReachTransition
    {
        private readonly MotionTransition ordinary;
        private readonly MotionTransition radius,direction;
        private readonly PhraseGeometry geometry;
        private readonly bool spherical;
        public ReachTransition(PhraseState a,PhraseState b,PhraseGeometry g) : this(a,b,g,false){}
        public ReachTransition(PhraseState a,PhraseState b,PhraseGeometry g,bool force)
        {
            geometry=g;ordinary=new MotionTransition(a,b);
            spherical=force;
            for(int i=1;i<16;i++)
            {double t=a.Time+(b.Time-a.Time)*i/16;if((ordinary.SampleGrip(t).Grip-Shoulder(t)).Length<g.MinimumReach*1.10){spherical=true;break;}}
            if(!spherical)return;
            var ra=Radial(a);var rb=Radial(b);radius=new MotionTransition(ra,rb);
            var da=Direction(a);var db=Direction(b);
            var forward=g.Forward.Length>.5 ? g.Forward.Unit : new MotionVector(0,0,1);
            // Transport the incoming frame. Two independently constructed
            // direction frames can contain an unrelated twist near the back
            // pole even when the physical hand directions are close.
            db.Rotation=MotionRotation.FromTo(da.Rotation.Rotate(forward),db.Rotation.Rotate(forward),new MotionVector(g.Color==0 ? -1 : 1,-.5,0))*da.Rotation;
            direction=new MotionTransition(da,db);
        }
        private MotionVector Shoulder(double t){return geometry.ShoulderAt==null ? geometry.Shoulder : geometry.ShoulderAt(t);}
        private void ShoulderJets(double t,out MotionVector v,out MotionVector a)
        {
            v=a=new MotionVector();if(geometry.ShoulderAt==null)return;
            const double e=.002;var left=Shoulder(t-e);var middle=Shoulder(t);var right=Shoulder(t+e);
            v=(right-left)/(2*e);a=(right+left-middle*2)/(e*e);
        }
        private PhraseState Radial(PhraseState s)
        {
            MotionVector sv,sa;ShoulderJets(s.Time,out sv,out sa);var p=s.Grip-Shoulder(s.Time);var v=s.Velocity-sv;var a=s.Acceleration-sa;
            double r=Math.Max(1e-6,p.Length),rd=MotionVector.Dot(p,v)/r,rdd=(MotionVector.Dot(v,v)+MotionVector.Dot(p,a)-rd*rd)/r;
            return new PhraseState{Time=s.Time,Grip=new MotionVector(r,0,0),Velocity=new MotionVector(rd,0,0),Acceleration=new MotionVector(rdd,0,0)};
        }
        private PhraseState Direction(PhraseState s)
        {
            MotionVector sv,sa;ShoulderJets(s.Time,out sv,out sa);var p=s.Grip-Shoulder(s.Time);var v=s.Velocity-sv;var a=s.Acceleration-sa;
            double r=Math.Max(1e-6,p.Length),rd=MotionVector.Dot(p,v)/r;
            var w=MotionVector.Cross(p,v)/(r*r);var alpha=MotionVector.Cross(p,a)/(r*r)-w*(2*rd/r);
            var forward=geometry.Forward.Length>.5 ? geometry.Forward.Unit : new MotionVector(0,0,1);
            var pole=new MotionVector(geometry.Color==0 ? -1 : 1,-.5,0);
            return new PhraseState{Time=s.Time,Rotation=MotionRotation.FromTo(forward,p.Unit,pole),AngularVelocity=w,AngularAcceleration=alpha};
        }
        public PhraseState Sample(double t)
        {return Sample(t,null);}
        // The spherical detour changes only grip coordinates. Its wrist is
        // exactly the ordinary transition, including both angular jets.
        public PhraseState SampleWrist(double t){return ordinary.SampleWrist(t);}
        // Grip-run playback already has its separately owned wrist curve.
        // Avoid reconstructing a rotation that it immediately discards.
        public PhraseState SampleGrip(double t){return spherical ? Sample(t) : ordinary.SampleGrip(t);}
        public PhraseState Sample(double t,PhraseState radiusSource)
        {
            var s=ordinary.Sample(t);if(!spherical)return s;
            // Recorded arm motion may tuck toward the shoulder and extend
            // again. Connecting only its endpoint radii replaced that tuck
            // with a large orbit. A source detour changes direction only:
            // retain the original radius and its measured derivatives.
            var r=radiusSource==null ? radius.Sample(t) : Radial(radiusSource);var q=direction.Sample(t);double distance=r.Grip.X,velocity=r.Velocity.X,acceleration=r.Acceleration.X;
            double minimum=geometry.MinimumReach*(radiusSource==null ? 1 : 1.05);
            double threshold=geometry.MinimumReach*(radiusSource==null ? 1.04 : 1.09),span=threshold-minimum;
            if(distance<threshold && span>0)
            {double u=Math.Tanh((distance-threshold)/span),d=1-u*u;distance=threshold+span*u;acceleration=acceleration*d-2*u*d/span*velocity*velocity;velocity*=d;}
            MotionVector sv,sa;ShoulderJets(t,out sv,out sa);
            var forward=geometry.Forward.Length>.5 ? geometry.Forward.Unit : new MotionVector(0,0,1);
            var axis=q.Rotation.Rotate(forward);var tangent=MotionVector.Cross(q.AngularVelocity,axis);
            s.Grip=Shoulder(t)+axis*distance;s.Velocity=sv+axis*velocity+tangent*distance;
            s.Acceleration=sa+axis*acceleration+tangent*(2*velocity)+(MotionVector.Cross(q.AngularAcceleration,axis)+MotionVector.Cross(q.AngularVelocity,tangent))*distance;
            return s;
        }
    }
    public static class ReachTeacher
    {
        private sealed class Window{internal double Start,End;internal ReachTransition Arc;}
        public static Func<double,PhraseState> Adapt(Func<double,PhraseState> source,PhraseGeometry g,double start,double end)
        {Func<double,PhraseState> result=null;foreach(int step in Prepare(source,g,start,end,delegate(Func<double,PhraseState> ready){result=ready;})){}return result;}
        public static IEnumerable<int> Prepare(Func<double,PhraseState> source,PhraseGeometry g,double start,double end,Action<Func<double,PhraseState>> publish)
        {
            if(g.MinimumReach<=0){publish(source);yield break;}
            var windows=new List<Window>();double boundary=g.MinimumReach*1.12;
            Func<double,double> radius=delegate(double t){return (source(t).Grip-(g.ShoulderAt==null ? g.Shoulder : g.ShoulderAt(t))).Length;};
            for(double t=start-.12;t<=end+.12;t+=.01)
            {
                yield return 0;
                if(radius(t)>=boundary)continue;
                double a=t-.08,b=t+.08;
                while(a>start-.60 && radius(a)<boundary)a-=.02;
                while(b<end+.60 && radius(b)<boundary)b+=.02;
                if(windows.Count>0 && a<=windows[windows.Count-1].End+.08)windows[windows.Count-1].End=Math.Max(b,windows[windows.Count-1].End);
                else windows.Add(new Window{Start=a,End=b});
                t=b-.01;
            }
            // A shoulder detour is itself a published path. Certifying only
            // the contact correction could fall back to a detour whose moving
            // spherical radius amplified the hand speed. Expand only that
            // local window until the projected arc is safe; wrist timing and
            // recorded motion outside the window remain untouched.
            for(int attempt=0;attempt<10;attempt++)
            {
                bool expanded=false;
                foreach(var w in windows)
                {
                    w.Arc=new ReachTransition(ConstrainedReplayTrajectory.Project(source(w.Start),g),ConstrainedReplayTrajectory.Project(source(w.End),g),g,true);
                    yield return 0;
                    bool fast=false;
                    for(double t=w.Start;t<=w.End;t+=1.0/240)
                    {var arc=ConstrainedReplayTrajectory.Project(w.Arc.Sample(t,source(t)),g);yield return 0;if(arc.Velocity.Length>17.25){fast=true;break;}}
                    if(!fast || attempt==9)continue;
                    w.Start-=.04;w.End+=.04;
                    while(radius(w.Start)<boundary && w.Start>start-1.10)w.Start-=.02;
                    while(radius(w.End)<boundary && w.End<end+1.10)w.End+=.02;
                    expanded=true;
                }
                if(!expanded)break;
                for(int i=1;i<windows.Count;i++)if(windows[i].Start<=windows[i-1].End+.08)
                {windows[i-1].End=Math.Max(windows[i-1].End,windows[i].End);windows.RemoveAt(i--);}
            }
            if(windows.Count==0){publish(source);yield break;}
            publish(delegate(double t)
            {
                var s=source(t);foreach(var w in windows)if(t>w.Start && t<w.End)
                {var arc=w.Arc.Sample(t,s);s=s.Copy();s.Grip=arc.Grip;s.Velocity=arc.Velocity;s.Acceleration=arc.Acceleration;break;}return s;
            });
        }
    }
}
