using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace SaberMind
{
    // Human replay filenames often include player, song, hash and date. Some
    // exceed Framework's old 260-character limit even in the standard folder.
    internal static class ReplayFileAccess
    {
        // Cache decoding used to honor the idle gate only BETWEEN files.
        // A model/file already being decoded could continue allocating for
        // an entire song. Check inside the compressed input/output stream.
        internal sealed class IdleStream : Stream
        {
            private readonly Stream inner;
            private readonly Action waitForIdle;
            internal IdleStream(Stream inner,Action waitForIdle){this.inner=inner;this.waitForIdle=waitForIdle;}
            public override bool CanRead{get{return inner.CanRead;}}
            public override bool CanSeek{get{return inner.CanSeek;}}
            public override bool CanWrite{get{return inner.CanWrite;}}
            public override long Length{get{return inner.Length;}}
            public override long Position{get{return inner.Position;}set{inner.Position=value;}}
            public override void Flush(){if(waitForIdle!=null)waitForIdle();inner.Flush();}
            public override int Read(byte[] buffer,int offset,int count){if(waitForIdle!=null)waitForIdle();return inner.Read(buffer,offset,count);}
            public override void Write(byte[] buffer,int offset,int count){if(waitForIdle!=null)waitForIdle();inner.Write(buffer,offset,count);}
            public override long Seek(long offset,SeekOrigin origin){return inner.Seek(offset,origin);}
            public override void SetLength(long value){inner.SetLength(value);}
            protected override void Dispose(bool disposing){if(disposing)inner.Dispose();base.Dispose(disposing);}
        }
        [StructLayout(LayoutKind.Sequential)]
        private struct Attributes
        {internal uint Flags,CreationLow,CreationHigh,AccessLow,AccessHigh,WriteLow,WriteHigh,SizeHigh,SizeLow;}
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
        private static extern bool GetFileAttributesExW(string path,int level,out Attributes data);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
        private static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
        private static string Native(string path) {return path.StartsWith(@"\\?\") ? path : path.StartsWith(@"\\") ? @"\\?\UNC\"+path.Substring(2) : @"\\?\"+(Path.IsPathRooted(path) ? path : Path.GetFullPath(path));}
        internal static void Metadata(string path,out long length,out long ticks)
        {
            if(path.Length<245) {var f=new FileInfo(path);length=f.Length;ticks=f.LastWriteTimeUtc.Ticks;return;}
            Attributes a;if(!GetFileAttributesExW(Native(path),0,out a)) throw new IOException("Cannot inspect replay.",new Win32Exception(Marshal.GetLastWin32Error()));
            length=((long)a.SizeHigh<<32)|a.SizeLow;ticks=DateTime.FromFileTimeUtc(((long)a.WriteHigh<<32)|a.WriteLow).Ticks;
        }
        internal static FileStream OpenRead(string path)
        {
            if(path.Length<245) return new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);
            SafeFileHandle handle=CreateFileW(Native(path),0x80000000,1,IntPtr.Zero,3,0x08000000,IntPtr.Zero);
            if(handle.IsInvalid) {int error=Marshal.GetLastWin32Error();handle.Dispose();throw new IOException("Cannot open replay.",new Win32Exception(error));}
            try {return new FileStream(handle,FileAccess.Read);}catch {handle.Dispose();throw;}
        }
    }
}

