using System;
using System.Globalization;
using System.Text;
namespace SaberMind
{
    // Bounded diagnostics only. No file IO, formatting or allocations during
    // playback. Frame gaps include engine/render time outside this mod; they
    // must not be interpreted as CPU time consumed by the AI.
    internal sealed class FrameStallTrace
    {
        internal struct Stall
        {internal double SongTime,GapMilliseconds,TickMilliseconds,MoveMilliseconds,CollectionMilliseconds;internal int Collections;}
        private readonly Stall[] stalls=new Stall[64];
        private int frame=-1,collections,cursor,count,total;
        private long tick;
        private double songTime,tickMs,moveMs,collectionMs;
        internal int Count{get{return count;}}
        internal int Total{get{return total;}}
        internal Stall At(int index){return stalls[(cursor-count+index+stalls.Length)%stalls.Length];}
        internal void Reset(){frame=-1;}
        internal void Begin(int nextFrame,long now,long frequency,double song,int gcCount)
        {
            if(nextFrame==frame)return;
            if(frame>=0)
            {
                double gap=(now-tick)*1000.0/frequency;
                if(gap>25)
                {
                    stalls[cursor]=new Stall{SongTime=songTime,GapMilliseconds=gap,TickMilliseconds=tickMs,MoveMilliseconds=moveMs,CollectionMilliseconds=collectionMs,Collections=Math.Max(0,gcCount-collections)};
                    cursor=(cursor+1)%stalls.Length;count=Math.Min(count+1,stalls.Length);total++;
                }
            }
            frame=nextFrame;tick=now;collections=gcCount;songTime=song;tickMs=moveMs=collectionMs=0;
        }
        internal void TickDuration(double ms){tickMs+=ms;}
        internal void MoveDuration(double ms){moveMs+=ms;}
        internal void CollectionDuration(double ms){collectionMs+=ms;}
        internal string Summary()
        {
            var b=new StringBuilder("AI frame-gap trace: total="+total+"; retained="+count+"; gaps include engine/render time outside AI.\n");
            for(int i=0;i<count;i++)
            {
                var s=At(i);b.AppendFormat(CultureInfo.InvariantCulture,"t={0:0.000}s gap={1:0.00}ms AI tick={2:0.00}ms sabers={3:0.00}ms explicit GC={4:0.00}ms GC cycles={5}\n",s.SongTime,s.GapMilliseconds,s.TickMilliseconds,s.MoveMilliseconds,s.CollectionMilliseconds,s.Collections);
            }
            return b.ToString();
        }
    }
}
