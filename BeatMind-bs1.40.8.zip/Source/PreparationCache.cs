using System;
using System.Collections.Generic;

namespace SaberMind
{
    // Cached geometric validation is never turned into actual cut evidence.
    // The caller hashes all trajectory inputs and stamps only completed passes.
    public static class PreparationCache
    {
        public static bool Reusable(IList<PretrainedPlan> plans,string signature,double threshold)
        {
            if(string.IsNullOrEmpty(signature) || plans==null || plans.Count==0)return false;
            double quality=0;
            foreach(var p in plans)
            {
                if(p==null || p.MotionVersion!=2 || p.Validations<1 || p.PreparationSignature!=signature ||
                    float.IsNaN(p.Confidence) || float.IsInfinity(p.Confidence) || p.Confidence<.35f || p.Confidence>1 ||
                    p.Variant<0 || p.Variant>=Policy.Variants.Length)return false;
                quality+=p.Confidence;
            }
            return quality/plans.Count>=threshold;
        }
    }
}
