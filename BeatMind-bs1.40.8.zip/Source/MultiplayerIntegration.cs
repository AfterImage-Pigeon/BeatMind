using System;
using System.IO;
using System.Reflection;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;

namespace SaberMind
{
    // Native networking owns authentication, map/countdown, avatar interpolation
    // and scoring. This adapter never creates a synthetic IConnectedPlayer.
    internal static class MultiplayerIntegration
    {
        internal static event Action StatusChanged;
        internal static string Status="Requires a separate Beat Saber client/account. Enable to prepare a private invite.";
        internal static bool Companion {get;private set;}
        private static string invitePath;
        private static PrivateBotInvite invite;
        private static PlatformAuthenticationTokenProvider authentication;
        private static MultiplayerLobbyConnectionController lobby;
        private static IMultiplayerSessionManager network;
        private static IUnifiedNetworkPlayerModel model;
        private static bool pendingHost,joined;
        private static bool lobbyActive;
        private static float joinAt;
        private static MultiplayerSocial social;
        private static float nextPoll;
        private static string lastError;
        private static readonly FieldInfo LobbyNetwork=AccessTools.Field(typeof(MultiplayerLobbyConnectionController),"_multiplayerSessionManager");
        private static readonly FieldInfo LobbyModel=AccessTools.Field(typeof(MultiplayerLobbyConnectionController),"_unifiedNetworkPlayerModel");
        private static MultiplayerLocalActiveClient client;
        private static PlayerTransforms player;
        private static ScoreController scorer;
        private static AudioTimeSyncController clock;
        private static BeatmapObjectManager notes;
        private static SaberManager sabers;
        internal static bool CanPlay
        {
            get
            {
                try
                {
                if(!Companion || invite==null || network==null || model==null || network.localPlayer==null)return false;
                int humans=0;string humanId=null;
                // The dedicated server can own the transport connection. The
                // session's participant list contains real "player" peers;
                // verify the invited human there, not the server's identity.
                var peers=network.connectedPlayers;
                for(int i=0;i<peers.Count;i++) {IConnectedPlayer p=peers[i];if(!p.isMe && p.isConnected)
                    {humans++;if(p.userId==invite.HostUserId)humanId=p.userId;}}
                GameplayServerConfiguration c=model.configuration;
                return joined && !network.isSpectating && network.localPlayer.HasState("player") && network.localPlayer.userName=="SaberMind" &&
                    string.Equals(model.code,invite.Code,StringComparison.OrdinalIgnoreCase) &&
                    MultiplayerPolicy.MayControl(Companion,invite,network.localPlayer.userId,humanId,
                        network.isConnected,c.discoveryPolicy!=DiscoveryPolicy.Public,c.maxPlayerCount,humans,DateTime.UtcNow);
                }
                catch(Exception e){if(lastError!=e.Message){lastError=e.Message;Plugin.Log.Warn("Companion connection proof: "+e.Message);}return false;}
            }
        }
        internal static void Initialize()
        {
            Companion=false;invite=null;invitePath=Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","SaberMindPrivateInvite.json");
            string[] args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length;i++)
            {
                if(args[i]=="--sabermind-companion")Companion=true;
                if(args[i]=="--sabermind-invite" && i+1<args.Length)invitePath=Path.GetFullPath(args[++i]);
            }
            if(Companion){ReadInvite();SetStatus("Companion mode: join the invited private lobby using its normal server code.");}
            Plugin.Log.Info("SaberMind multiplayer architecture: "+(Companion?"separate authenticated companion client":"host invitation only")+"; no extra local network identity.");
        }
        internal static void AuthenticationReady(PlatformAuthenticationTokenProvider provider){authentication=provider;}
        internal static void Alias(PlatformAuthenticationTokenProvider provider,ref string name)
        {
            authentication=provider;
            // Change only this explicitly opted-in companion's display alias.
            // User ID, platform, tickets and authentication implementation stay native.
            if(MultiplayerPolicy.MayUseCompanionIdentity(Companion,invite,provider.hashedUserId,DateTime.UtcNow))name="SaberMind";
        }
        internal static void Attach(MultiplayerLobbyConnectionController controller)
        {
            if(object.ReferenceEquals(lobby,controller))return;
            if(lobby!=null){RevokeInvite();ClearGameplay();joined=pendingHost=false;}
            Detach();lobby=controller;nextPoll=0;
        }
        private static void BindNetwork()
        {
            if(lobby==null)return;
            model=LobbyModel.GetValue(lobby) as IUnifiedNetworkPlayerModel;
            IMultiplayerSessionManager next=LobbyNetwork.GetValue(lobby) as IMultiplayerSessionManager;
            if(object.ReferenceEquals(network,next))return;
            Unsubscribe();network=next;
            if(network!=null){network.disconnectedEvent+=Disconnected;network.playerDisconnectedEvent+=PlayerLeft;network.connectionFailedEvent+=Failed;}
        }
        internal static bool JoinAllowed(string code)
        {
            if(!Companion)return true;
            ReadInvite();BindNetwork();
            string id=authentication==null?null:authentication.hashedUserId;
            bool allowed=MultiplayerPolicy.MayJoin(Companion,invite,id,code,DateTime.UtcNow);
            if(!allowed)SetStatus("Companion join refused: use a valid private invite and a different signed-in account.");
            else {joined=true;joinAt=Time.unscaledTime;Plugin.Log.Info("SaberMind companion: ordinary authenticated private-code join requested.");}
            return allowed;
        }
        internal static void Creating(ref CreateServerFormData data)
        {
            if(Companion || !Settings.Current.MultiplayerJoinEnabled){pendingHost=false;return;}
            // OFF passes the entire native form through untouched.
            data.netDiscoverable=false;data.maxPlayers=2;pendingHost=true;invite=null;
            SetStatus("Creating private 1v1 lobby. Waiting for the native server code...");
        }
        internal static void HostOptionsChanged()
        {
            if(Companion)return;
            if(!Settings.Current.MultiplayerJoinEnabled){pendingHost=false;RevokeInvite();}
            else if(pendingHost && network!=null && network.isConnected)PublishInvite();
        }
        internal static void Tick()
        {
            if(Time.unscaledTime<nextPoll)return;nextPoll=Time.unscaledTime+.5f;
            try
            {
                BindNetwork();
                if(Companion)
                {
                    string oldNonce=invite==null?null:invite.Nonce;ReadInvite();
                    if(joined && (!MultiplayerPolicy.ValidInvite(invite,DateTime.UtcNow) || oldNonce!=invite.Nonce))
                    {LeaveCompanion("Private invite ended or replaced");return;}
                    if(joined && network!=null && network.isConnected)
                    {
                        // Native connection and remote identity events arrive in
                        // separate callbacks. Never take control during this grace
                        // period; allow the invited host's metadata to arrive.
                        if(!CanPlay){if(Time.unscaledTime-joinAt<10)return;LeaveCompanion("Connected lobby does not match the invited private host/account/name");return;}
                        SetStatus("SaberMind connected as a separate player. Model "+(invite.Model+1)+".");
                    }
                }
                else if(pendingHost && Settings.Current.MultiplayerJoinEnabled && network!=null && network.isConnected)PublishInvite();
            }
            catch(Exception e){if(lastError!=e.Message){lastError=e.Message;Plugin.Log.Warn("SaberMind multiplayer: "+e);}SetStatus("Multiplayer setup unavailable; see log.");}
        }
        private static void PublishInvite()
        {
            if(model==null || network.localPlayer==null || !model.localPlayerIsPartyOwner || string.IsNullOrEmpty(model.code))return;
            GameplayServerConfiguration c=model.configuration;
            if(c.discoveryPolicy==DiscoveryPolicy.Public || c.maxPlayerCount!=2){SetStatus("SaberMind supports private 2-player lobbies only.");return;}
            if(invite!=null && invite.Enabled && invite.Code==model.code && invite.HostUserId==network.localPlayer.userId && invite.Model==Settings.Current.MultiplayerModel)return;
            DateTime now=DateTime.UtcNow;
            invite=new PrivateBotInvite {Enabled=true,PrivateLobby=true,Code=model.code,HostUserId=network.localPlayer.userId,
                Model=Settings.Current.MultiplayerModel,Nonce=invite==null?Guid.NewGuid().ToString("N"):invite.Nonce,
                CreatedUtc=now,ExpiresUtc=now.AddHours(10)};
            WriteInvite();SetStatus("Private invite ready. Join from a separate signed-in client/account. See PRIVATE-MULTIPLAYER.md.");
            Plugin.Log.Info("SaberMind private invite prepared; model="+(invite.Model+1)+". Native human player unchanged.");
        }
        private static void ReadInvite()
        {
            try {if(!File.Exists(invitePath) || new FileInfo(invitePath).Length>16384){invite=null;return;}
                invite=JsonConvert.DeserializeObject<PrivateBotInvite>(File.ReadAllText(invitePath));}
            catch(Exception e){invite=null;if(lastError!=e.Message){lastError=e.Message;Plugin.Log.Warn("Private invite read: "+e.Message);}}
        }
        private static void WriteInvite()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(invitePath));
            File.WriteAllText(invitePath+".tmp",JsonConvert.SerializeObject(invite,Formatting.Indented));
            if(File.Exists(invitePath))File.Replace(invitePath+".tmp",invitePath,null);else File.Move(invitePath+".tmp",invitePath);
        }
        private static void RevokeInvite()
        {if(invite==null || !invite.Enabled || Companion)return;invite.Enabled=false;try {WriteInvite();}catch(Exception e){Plugin.Log.Warn("Private invite revoke: "+e.Message);}}
        private static void SetStatus(string value){if(Status==value)return;Status=value;if(StatusChanged!=null)StatusChanged();}
        private static void Failed(ConnectionFailedReason reason)
        {joined=false;pendingHost=false;RevokeInvite();ClearGameplay();SetStatus("SaberMind connection failed: "+reason);}
        private static void Disconnected(DisconnectedReason reason)
        {joined=false;pendingHost=false;RevokeInvite();ClearGameplay();SetStatus("Private lobby ended: "+reason);Plugin.Log.Info("SaberMind multiplayer disconnect/cleanup: "+reason);}
        private static void PlayerLeft(IConnectedPlayer peer)
        {if(Companion && invite!=null && peer.userId==invite.HostUserId)LeaveCompanion("Human host left");}
        private static void LeaveCompanion(string reason)
        {joined=false;ClearGameplay();SetStatus(reason);Plugin.Log.Info("SaberMind companion stopped: "+reason);if(network!=null && network.isConnectingOrConnected)network.Disconnect();}
        internal static void LocalClient(MultiplayerLocalActiveClient active,PlayerTransforms transforms,AudioTimeSyncController audio,BeatmapObjectManager objects,IScoreController score)
        {if(!Companion)return;client=active;player=transforms;clock=audio;notes=objects;scorer=score as ScoreController;}
        internal static void LocalSabers(SaberManager manager){if(Companion)sabers=manager;}
        internal static void StartGameplay(MultiplayerLocalActivePlayerFacade owner,GameplayCoreSceneSetupData setup)
        {
            if(!CanPlay)return;
            try
            {
                if(owner==null || client==null || clock==null || notes==null || sabers==null || player==null || scorer==null || setup==null || setup.transformedBeatmapData==null)
                    throw new InvalidOperationException("Native local gameplay bindings are incomplete.");
                Session.BeginMultiplayer(owner,setup,clock,player,scorer,sabers,notes,ModelProfile.All[invite.Model]);
                Plugin.Log.Info("SaberMind native map/song synchronized; real collisions + score events; native pose publisher uses final transforms.");
            }
            catch(Exception e){Session.Stop("Companion start error");Plugin.Log.Error("SaberMind multiplayer gameplay: "+e);}
        }
        internal static void Finished(MultiplayerLocalActivePlayerFacade owner,MultiplayerLevelCompletionResults result)
        {
            Session current=Session.Current;
            if(current==null || !current.Multiplayer || !current.OwnsOwner(owner))return;
            try {current.CaptureResult(result==null?null:result.levelCompletionResults);}
            finally {Session.Stop("Private multiplayer attempt finished");Plugin.Log.Info("SaberMind real multiplayer result retained; no auto-restart or fabricated score.");}
        }
        internal static void LocalClientDestroyed(MultiplayerLocalActiveClient active)
        {if(client==active)ClearGameplay();}
        internal static void LobbyActive(bool active)
        {lobbyActive=active;if(!active)StopSocial();}
        internal static void PublishLobby(MenuPlayerController controller,INodePoseSyncStateManager poses)
        {
            if(!lobbyActive || !CanPlay || Session.Current!=null || client!=null){StopSocial();return;}
            try
            {
                if(social==null)social=new MultiplayerSocial(controller,invite.Model);
                IConnectedPlayer human=null;var peers=network.connectedPlayers;
                for(int i=0;i<peers.Count;i++) {IConnectedPlayer p=peers[i];if(!p.isMe && p.userId==invite.HostUserId){human=p;break;}}
                social.Publish(poses,human,invite.Model);
            }
            catch(Exception e){StopSocial();if(lastError!=e.Message){lastError=e.Message;Plugin.Log.Warn("SaberMind lobby pose: "+e);}}
        }
        private static void StopSocial(){if(social!=null){social.Dispose();social=null;}}
        private static void ClearGameplay()
        {StopSocial();if(Session.Current!=null && Session.Current.Multiplayer)Session.Stop("Multiplayer cleanup");client=null;player=null;clock=null;notes=null;scorer=null;sabers=null;}
        private static void Unsubscribe()
        {if(network!=null){network.disconnectedEvent-=Disconnected;network.playerDisconnectedEvent-=PlayerLeft;network.connectionFailedEvent-=Failed;}}
        private static void Detach(){Unsubscribe();network=null;model=null;lobby=null;}
        internal static void Shutdown()
        {RevokeInvite();if(Companion && joined)LeaveCompanion("Companion shut down");ClearGameplay();Detach();joined=pendingHost=false;
            foreach(MultiplayerMenu menu in Resources.FindObjectsOfTypeAll<MultiplayerMenu>()){menu.DisposePanel();UnityEngine.Object.Destroy(menu);}StatusChanged=null;authentication=null;}
    }
}
