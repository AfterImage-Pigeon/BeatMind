using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace SaberMind
{
    // A bounded diagnostic of recent samples plus the worst motion
    // events from the whole run. Disk IO happens only at session teardown.
    internal sealed class SaberTrace
    {
        private const int CapacityPerHand=450;
        private sealed class Spike { internal float Time,Severity;internal string Row; }
        private readonly Queue<string>[] rows={new Queue<string>(),new Queue<string>()};
        private readonly List<Spike> spikes=new List<Spike>();
        private static string F(float value) { return value.ToString("0.####",CultureInfo.InvariantCulture); }
        private static string F(double value) { return value.ToString("0.####",CultureInfo.InvariantCulture); }
        private static string V(Vector3 value) { return F(value.x)+","+F(value.y)+","+F(value.z); }
        private static string M(MotionVector value) { return F((float)value.X)+","+F((float)value.Y)+","+F((float)value.Z); }
        private static string Q(MotionRotation value) { return F((float)value.X)+","+F((float)value.Y)+","+F((float)value.Z)+","+F((float)value.W); }
        private static string Q(Quaternion value) { return F(value.x)+","+F(value.y)+","+F(value.z)+","+F(value.w); }
        private static string Id(TrackedNote note) { return note==null ? "" : note.Key; }
        private static string Hit(TrackedNote note)
        { return note==null ? "" : F(note.HitTime); }
        internal void Record(int color,float time,TrackedNote current,TrackedNote next,Hand hand,
            Vector3 requestedGrip,Vector3 actualGrip,float saberAngle,float wristProjectionAngle,
            float wristTrackingAngle,float bladeContactError,float bodyGripError,
            float reachError,float wristError,Vector3 noteCenter,Vector3 visualCenter,Vector3 shoulder,
            float sampleDeltaSongTime,PhraseState teacher)
        {
            if(color<0 || color>1) return;
            string row=F(time)+","+color+","+Id(current)+","+Hit(current)+","+Id(next)+","+Hit(next)
                +","+(hand.TargetChanged ? "1":"0")+","+V(requestedGrip)+","+V(actualGrip)
                +","+F(saberAngle)+","+F(hand.LastWristTargetDelta)+","+V(hand.LastWristFeed)
                +","+F(wristProjectionAngle)+","+F(wristTrackingAngle)+","+F(bladeContactError)+","+F(bodyGripError)
                +","+F(wristError)+","+F(reachError)
                +","+V(noteCenter)+","+V(visualCenter)+","+V(shoulder)
                +","+V(hand.GripVelocity)+","+V(hand.GripAcceleration)
                +","+(hand.RouteChanged ? "1":"0")+","+(hand.ContactFitChanged ? "1":"0")
                +","+F(hand.GripVelocity.magnitude)+","+F(hand.TipSpeed)
                +","+F((float)(hand.TipTravel/Math.Max(.001,hand.GripTravel)))
                +","+F(hand.GripJerk)+","+F(hand.AngularVelocity.magnitude)
                +","+F(hand.AngularAcceleration.magnitude)+","+F(hand.AngularJerk)
                +","+hand.PhraseId+","+hand.Replans+","+hand.CandidateEvaluations
                +","+hand.CorrectionReversals+","+F(hand.Phrase==null ? 0 : (float)hand.Phrase.Cost)
                +","+(hand.Desired==null ? -1 : hand.Desired.HumanSource)
                +","+F(hand.Desired==null ? 0 : (float)hand.Desired.HumanGripWeight)
                +","+F(hand.Desired==null ? 0 : (float)hand.Desired.HumanWristWeight)+","+hand.ImitationCandidates+","+(hand.Phrase==null ? 0 : hand.Phrase.StabilityFallbacks);
            PhraseState desired=hand.Desired ?? new PhraseState();teacher=teacher ?? new PhraseState();
            if(hand.Phrase!=null)teacher=hand.Phrase.TeacherAt(time,false) ?? teacher;
            PhraseState adapted=hand.Phrase==null ? teacher : hand.Phrase.TeacherAt(time,true) ?? teacher;
            row+=","+F(sampleDeltaSongTime)+","+desired.RepairStage+","+M(desired.Velocity)+","+M(desired.Acceleration)
                +","+M(desired.AngularVelocity)+","+M(desired.AngularAcceleration)+","+M(teacher.Grip)
                +","+M(teacher.Velocity)+","+M(teacher.Acceleration)+","+M(teacher.AngularVelocity)+","+M(teacher.AngularAcceleration);
            Quaternion command=hand.LastRotation;
            Vector3 finalPosition=hand.Saber.transform.position;Quaternion finalRotation=hand.Saber.transform.rotation;
            row+=","+Q(teacher.Rotation)+","+M(adapted.Grip)+","+Q(adapted.Rotation)+","+Q(desired.Rotation)
                +","+V(hand.LastPosition)+","+Q(command)+","+V(finalPosition)+","+Q(finalRotation)
                +","+V(finalPosition+finalRotation*hand.LocalBladeBottom)+","+V(finalPosition+finalRotation*hand.LocalBladeTop)
                +","+V(hand.LocalGrip)+","+F((float)(MotionRotation.Log(desired.Rotation*teacher.Rotation.Inverse).Length*180/Math.PI))
                +","+F(Quaternion.Angle(command,finalRotation));
            Queue<string> handRows=rows[color];
            handRows.Enqueue(row);
            while(handRows.Count>CapacityPerHand) handRows.Dequeue();
            float severity=Mathf.Max(hand.GripVelocity.magnitude/12f,hand.AngularVelocity.magnitude/6000f);
            if(severity>=1)
            {
                if(spikes.Count<128) spikes.Add(new Spike {Time=time,Severity=severity,Row=row});
                else
                {
                    int weakest=0;
                    for(int i=1;i<spikes.Count;i++) if(spikes[i].Severity<spikes[weakest].Severity) weakest=i;
                    if(severity>spikes[weakest].Severity) spikes[weakest]=new Spike {Time=time,Severity=severity,Row=row};
                }
            }
        }
        internal void Save()
        {
            if(rows[0].Count==0 && rows[1].Count==0) return;
            string directory=Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","Traces");
            Directory.CreateDirectory(directory);
            string path=Path.Combine(directory,"SaberMind-last-run.csv");
            var output=new StringBuilder();
            string header="song_time,hand,current_note_id,current_hit,next_note_id,next_hit,target_changed,requested_grip_x,requested_grip_y,requested_grip_z,actual_grip_x,actual_grip_y,actual_grip_z,saber_frame_angle_deg,wrist_target_delta_deg,wrist_feed_x_deg_s,wrist_feed_y_deg_s,wrist_feed_z_deg_s,wrist_projection_deg,wrist_tracking_deg,blade_contact_error_m,body_grip_error_m,wrist_constraint_error,reach_error_m,note_center_x,note_center_y,note_center_z,visual_center_x,visual_center_y,visual_center_z,shoulder_x,shoulder_y,shoulder_z,hand_velocity_x,hand_velocity_y,hand_velocity_z,hand_acceleration_x,hand_acceleration_y,hand_acceleration_z,route_changed,contact_fit_changed,grip_speed_m_s,tip_speed_m_s,tip_grip_travel_ratio,grip_jerk_m_s3,wrist_speed_deg_s,wrist_acceleration_deg_s2,wrist_jerk_deg_s3,phrase_id,replans,candidate_evaluations,correction_reversals,plan_cost";
            header+=",human_source,human_grip_weight,human_wrist_weight,imitation_candidates_tested,local_stability_repairs";
            header+=",sample_delta_song_s,repair_stage,planned_velocity_x_song_m_s,planned_velocity_y_song_m_s,planned_velocity_z_song_m_s,planned_acceleration_x_song_m_s2,planned_acceleration_y_song_m_s2,planned_acceleration_z_song_m_s2,planned_angular_velocity_x_song_rad_s,planned_angular_velocity_y_song_rad_s,planned_angular_velocity_z_song_rad_s,planned_angular_acceleration_x_song_rad_s2,planned_angular_acceleration_y_song_rad_s2,planned_angular_acceleration_z_song_rad_s2,teacher_grip_x,teacher_grip_y,teacher_grip_z,teacher_velocity_x_song_m_s,teacher_velocity_y_song_m_s,teacher_velocity_z_song_m_s,teacher_acceleration_x_song_m_s2,teacher_acceleration_y_song_m_s2,teacher_acceleration_z_song_m_s2,teacher_angular_velocity_x_song_rad_s,teacher_angular_velocity_y_song_rad_s,teacher_angular_velocity_z_song_rad_s,teacher_angular_acceleration_x_song_rad_s2,teacher_angular_acceleration_y_song_rad_s2,teacher_angular_acceleration_z_song_rad_s2";
            header+=",teacher_qx,teacher_qy,teacher_qz,teacher_qw,adapted_grip_x,adapted_grip_y,adapted_grip_z,adapted_qx,adapted_qy,adapted_qz,adapted_qw,planned_qx,planned_qy,planned_qz,planned_qw,controller_root_x,controller_root_y,controller_root_z,controller_qx,controller_qy,controller_qz,controller_qw,final_root_x,final_root_y,final_root_z,final_qx,final_qy,final_qz,final_qw,blade_bottom_x,blade_bottom_y,blade_bottom_z,blade_top_x,blade_top_y,blade_top_z,local_grip_x,local_grip_y,local_grip_z,contact_correction_angle_deg,controller_final_rotation_error_deg";
            output.AppendLine(header);
            foreach(string row in rows[0]) output.AppendLine(row);
            foreach(string row in rows[1]) output.AppendLine(row);
            File.WriteAllText(path,output.ToString(),Encoding.UTF8);
            Plugin.Log.Info("Saber diagnostic trace: "+path);
            spikes.Sort(delegate(Spike a,Spike b){return a.Time.CompareTo(b.Time);});
            var severe=new StringBuilder();severe.AppendLine(header);
            foreach(Spike spike in spikes) severe.AppendLine(spike.Row);
            string spikePath=Path.Combine(directory,"SaberMind-motion-spikes.csv");
            File.WriteAllText(spikePath,severe.ToString(),Encoding.UTF8);
            if(spikes.Count>0) Plugin.Log.Info("Worst measured motion spikes: "+spikePath);
        }
    }
}
