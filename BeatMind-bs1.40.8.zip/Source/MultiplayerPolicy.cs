using System;

namespace SaberMind
{
    // A private invitation is connection metadata, never a platform credential.
    public sealed class PrivateBotInvite
    {
        public int Format=1,Model=1;
        public bool Enabled,PrivateLobby;
        public string Code,HostUserId,Nonce;
        public DateTime CreatedUtc,ExpiresUtc;
    }
    public static class MultiplayerPolicy
    {
        public static bool ValidInvite(PrivateBotInvite invite,DateTime now)
        {
            return invite!=null && invite.Format==1 && invite.Enabled && invite.PrivateLobby &&
                invite.Model>=0 && invite.Model<3 && !string.IsNullOrWhiteSpace(invite.Code) && invite.Code.Length<=32 &&
                !string.IsNullOrWhiteSpace(invite.HostUserId) && !string.IsNullOrWhiteSpace(invite.Nonce) &&
                invite.CreatedUtc<=now.AddMinutes(1) && invite.ExpiresUtc>now &&
                invite.ExpiresUtc>invite.CreatedUtc && invite.ExpiresUtc-invite.CreatedUtc<=TimeSpan.FromHours(12);
        }
        public static bool MayUseCompanionIdentity(bool explicitCompanion,PrivateBotInvite invite,string userId,DateTime now)
        {
            return explicitCompanion && ValidInvite(invite,now) && !string.IsNullOrWhiteSpace(userId) &&
                !string.Equals(invite.HostUserId,userId,StringComparison.Ordinal);
        }
        public static bool MayJoin(bool explicitCompanion,PrivateBotInvite invite,string userId,string code,DateTime now)
        {
            return MayUseCompanionIdentity(explicitCompanion,invite,userId,now) &&
                string.Equals(invite.Code,code,StringComparison.OrdinalIgnoreCase);
        }
        public static bool MayControl(bool explicitCompanion,PrivateBotInvite invite,string localId,string invitedHumanId,
            bool connected,bool privateLobby,int capacity,int remoteHumans,DateTime now)
        {
            return connected && privateLobby && capacity==2 && remoteHumans==1 &&
                MayUseCompanionIdentity(explicitCompanion,invite,localId,now) &&
                string.Equals(invite.HostUserId,invitedHumanId,StringComparison.Ordinal);
        }
    }
}
