using System;
using System.Collections.Generic;
namespace SaberMind
{
    public enum HumanPhase { Playing, Opening, Break, Ending, Celebration }
    public sealed class HumanMotionExample
    {
        public int Count=1,Sequence;
        public HumanPhase Phase;
        public double Duration,Score;
        public double StartTime;
        public string Recording;
        public double[] Context;
        // Full head / left / right poses, in one floor-relative frame. These
        // are recorded movements, not residuals around generated swings.
        public float[] Curve;
        // At the same ordered timestamps: linear velocity/acceleration and
        // world-space angular velocity/acceleration for all three joints.
        // These are derivatives of the timestamped recording, never noise.
        public float[] Kinematics;
        public HumanAnchor[] Anchors;
    }
    public sealed class HumanAnchor { public double Phase,Score;public int Hand,Lane,Layer,Direction; }
    public sealed class HumanRecording
    {
        public string Path,Identity,Hash,Difficulty,Mode;
        public double Accuracy,Start,End;
        public int Frames,Notes;
    }
    public sealed class HumanMotionModel
    {
        public const int Version=9,Points=129,Channels=21,KineticChannels=36,TotalChannels=57,Features=48;
        public int Format=Version,Files,Rejected,Cuts,CachedFiles,Duplicates,Examined,ValidationExamples;
        // One sample is the simultaneous head / left / right state at one
        // timestamp. Whole 129-point excerpts are budgeted, never loose poses.
        public int LearningBudgetVersion,LearningPoseSamples;
        public long AvailableSequences;
        public int OptimizerVersion;
        public double BoundaryWeight,ContextWeight=1;
        public string Fingerprint,TrainingFingerprint;
        public double ContextValidationError,MeanValidationError;
        public List<HumanMotionExample> Examples=new List<HumanMotionExample>();
        public List<HumanRecording> Recordings=new List<HumanRecording>();
        public int[] PhaseCounts=new int[5];
        public bool Valid()
        {
            if(Format!=Version || OptimizerVersion!=4 || !Finite(ContextWeight) || ContextWeight<0 || ContextWeight>10 || !Finite(BoundaryWeight) || BoundaryWeight<0 || BoundaryWeight>8 || Files<1 || Examples==null || Examples.Count==0 || Examples.Count>768 || Recordings==null || Recordings.Count>200000 || PhaseCounts==null || PhaseCounts.Length!=5)return false;
            if(LearningBudgetVersion!=HumanMotionTraining.LearningBudgetVersion || Cuts<1 || Cuts>HumanMotionTraining.MaximumLearningPoseSamples/Points || LearningPoseSamples!=(long)Cuts*Points || AvailableSequences<Cuts)return false;
            long contributions=0,phases=0;foreach(var e in Examples)if(e!=null)contributions+=e.Count;foreach(int p in PhaseCounts){if(p<0)return false;phases+=p;}
            if(contributions!=Cuts || phases!=Cuts)return false;
            foreach(var e in Examples)if(!ValidExample(e))return false;
            foreach(var r in Recordings)if(r==null || string.IsNullOrEmpty(r.Identity) || string.IsNullOrEmpty(r.Path) || !Finite(r.Accuracy) || r.Accuracy<HumanMotionTraining.MinimumReplayAccuracy || r.Accuracy>1.0001 || r.Frames<100 || r.Notes<2)return false;
            return true;
        }
        internal static bool ValidExample(HumanMotionExample e)
        {
            if(e==null || e.Count<1 || (int)e.Phase<0 || (int)e.Phase>4 || !Finite(e.StartTime) || !Finite(e.Duration) || e.Duration<.08 || e.Duration>8 || e.Context==null || e.Context.Length!=Features || e.Curve==null || e.Curve.Length!=Points*Channels || e.Kinematics==null || e.Kinematics.Length!=Points*KineticChannels || e.Anchors==null || e.Anchors.Length>256)return false;
            foreach(double v in e.Context)if(!Finite(v) || Math.Abs(v)>30)return false;
            for(int p=0;p<Points;p++)for(int j=0;j<3;j++)
            {int k=p*Channels+j*7;for(int c=0;c<7;c++)if(!Finite(e.Curve[k+c]) || Math.Abs(e.Curve[k+c])>(c<3 ? 4 : 1.001))return false;
                double norm=0;for(int c=3;c<7;c++)norm+=e.Curve[k+c]*e.Curve[k+c];if(Math.Abs(norm-1)>.015)return false;}
            foreach(float v in e.Kinematics)if(!Finite(v) || Math.Abs(v)>1000000)return false;
            foreach(var n in e.Anchors)if(n==null || !Finite(n.Phase) || n.Phase<0 || n.Phase>1 || n.Hand<0 || n.Hand>1 || n.Lane<0 || n.Lane>3 || n.Layer<0 || n.Layer>2 || n.Direction<0 || n.Direction>8)return false;
            return true;
        }
        public static bool Finite(double x){return !double.IsNaN(x) && !double.IsInfinity(x);}
        public static double Distance(double[] a,double[] b)
        {double sum=0;for(int i=0;i<Features;i++){double d=a[i]-b[i];sum+=d*d*(i<4 ? 2 : i>=44 ? .4 : 1);}return sum/Features;}
        public static double CurveDistance(float[] a,float[] b)
        {double sum=0;for(int p=0;p<Points;p+=16)for(int j=0;j<3;j++){int k=p*Channels+j*7;MotionVector d=Position(a,k)-Position(b,k);double angle=MotionRotation.Log(Rotation(a,k)*Rotation(b,k).Inverse).Length;sum+=d.Length*d.Length*(j==0 ? 8 : 4)+angle*angle*.12;}return sum/27;}
        public static double CurveDistance(HumanMotionExample a,HumanMotionExample b)
        {
            // Compare corresponding times along an ordered trajectory. Keep
            // speed, braking and wrist momentum in physical units; a reversed
            // or differently accelerated sequence cannot match a bag of poses.
            double sum=0;int count=0;
            for(int p=0;p<Points;p+=8)for(int j=0;j<3;j++)
            {
                int k=p*Channels+j*7,d=p*KineticChannels+j*12;
                MotionVector delta=Position(a.Curve,k)-Position(b.Curve,k);
                double angle=MotionRotation.Log(Rotation(a.Curve,k)*Rotation(b.Curve,k).Inverse).Length;
                sum+=delta.Length*delta.Length*(j==0 ? 8 : 4)+angle*angle*.12+JetDistance(a.Kinematics,d,b.Kinematics,d,j);count++;
            }
            return sum/count;
        }
        private static double Robust(MotionVector d,double scale)
        {double n=d.Length/scale;return n<=2 ? n*n : 4*n-4;}
        private static double JetDistance(float[] a,int ka,float[] b,int kb,int joint)
        {
            // Robust acceleration loss prevents one sub-frame tracking impulse
            // from dominating the full sequence; no derivatives are discarded.
            return .25*Robust(Position(a,ka)-Position(b,kb),joint==0 ? .5 : 3)+
                .08*Robust(Position(a,ka+3)-Position(b,kb+3),joint==0 ? 10 : 60)+
                .20*Robust(Position(a,ka+6)-Position(b,kb+6),joint==0 ? 2 : 12)+
                .04*Robust(Position(a,ka+9)-Position(b,kb+9),joint==0 ? 30 : 300);
        }
        public static double BoundaryDistance(HumanMotionExample a,HumanMotionExample b)
        {double sum=BoundaryDistance(a.Curve,b.Curve);for(int j=0;j<3;j++)sum+=JetDistance(a.Kinematics,j*12,b.Kinematics,j*12,j)/3;return sum;}
        public static double BoundaryDistance(HumanMotionExample a,PhraseState[] states,double rate)
        {
            double sum=0;
            for(int j=0;j<3;j++)
            {
                int k=j*12;var s=states[j];MotionVector p=Position(a.Curve,j*7)-s.Grip;
                double angle=MotionRotation.Log(Rotation(a.Curve,j*7)*s.Rotation.Inverse).Length;
                sum+=p.Length*p.Length*4+angle*angle*.12+
                    .25*Robust(Position(a.Kinematics,k)*rate-s.Velocity,j==0 ? .5 : 3)+
                    .08*Robust(Position(a.Kinematics,k+3)*(rate*rate)-s.Acceleration,j==0 ? 10 : 60)+
                    .20*Robust(Position(a.Kinematics,k+6)*rate-s.AngularVelocity,j==0 ? 2 : 12)+
                    .04*Robust(Position(a.Kinematics,k+9)*(rate*rate)-s.AngularAcceleration,j==0 ? 30 : 300);
            }
            return sum/3;
        }
        public static double BoundaryDistance(PhraseState[] predicted,PhraseState[] states)
        {
            double sum=0;
            for(int j=0;j<3;j++)
            {
                var a=predicted[j];var b=states[j];MotionVector p=a.Grip-b.Grip;
                double angle=MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length;
                sum+=p.Length*p.Length*4+angle*angle*.12+.25*Robust(a.Velocity-b.Velocity,j==0 ? .5 : 3)
                    +.08*Robust(a.Acceleration-b.Acceleration,j==0 ? 10 : 60)+.20*Robust(a.AngularVelocity-b.AngularVelocity,j==0 ? 2 : 12)
                    +.04*Robust(a.AngularAcceleration-b.AngularAcceleration,j==0 ? 30 : 300);
            }
            return sum/3;
        }
        internal static MotionVector Position(float[] data,int k){return new MotionVector(data[k],data[k+1],data[k+2]);}
        internal static MotionRotation Rotation(float[] data,int k){return new MotionRotation(data[k+3],data[k+4],data[k+5],data[k+6]).Unit;}
        public static double BoundaryDistance(float[] a,float[] b)
        {double sum=0;for(int j=0;j<3;j++){int k=j*7;MotionVector p=Position(a,k)-Position(b,k);double angle=MotionRotation.Log(Rotation(a,k)*Rotation(b,k).Inverse).Length;sum+=p.Length*p.Length*4+angle*angle*.12;}return sum/3;}
    }
    public sealed class HumanChartNote { public int Id,Hand,Lane,Layer,Direction;public double Time;public MotionVector ObservedCutDirection; }
    public static class HumanContext
    {
        // Both hands' upcoming events describe one shared motion phrase.
        public static double[] Describe(IList<HumanChartNote> notes,double start,double duration,HumanPhase phase)
        {
            var x=new double[48];x[0]=(int)phase;x[1]=Math.Log(Math.Max(.08,duration));
            int first=Lower(notes,start),count=0,left=0,dots=0;double prior=first==0 ? start-2 : notes[first-1].Time;
            x[2]=Math.Min(4,start-prior);x[3]=first<notes.Count ? Math.Min(4,Math.Max(0,notes[first].Time-start)) : 4;
            for(int i=first;i<notes.Count && notes[i].Time<=start+duration;i++){count++;if(notes[i].Hand==0)left++;if(notes[i].Direction==8)dots++;}
            for(int h=0;h<2;h++)
            {int used=0,k=4+h*20;double previous=start;
                for(int i=first;i<notes.Count && used<4;i++)
                {var n=notes[i];if(n.Hand!=h)continue;MotionVector d=Direction(n.Direction);x[k++]=Math.Min(4,Math.Max(0,n.Time-previous));x[k++]=(n.Lane-1.5)*.4;x[k++]=(n.Layer-1)*.5;x[k++]=d.X;x[k++]=d.Y;previous=n.Time;used++;}
                while(used++<4){x[k++]=4;k+=4;}}
            x[44]=Math.Log(1+count/Math.Max(.08,duration));x[45]=count==0 ? 0 : (double)left/count;x[46]=count==0 ? 0 : (double)dots/count;x[47]=first==0 ? 0 : 1;return x;
        }
        public static int Lower(IList<HumanChartNote> notes,double time)
        {int lo=0,hi=notes.Count;while(lo<hi){int m=(lo+hi)/2;if(notes[m].Time<time)lo=m+1;else hi=m;}return lo;}
        public static MotionVector Direction(int d)
        {MotionVector[] a={new MotionVector(0,1,0),new MotionVector(0,-1,0),new MotionVector(-1,0,0),new MotionVector(1,0,0),new MotionVector(-1,1,0).Unit,new MotionVector(1,1,0).Unit,new MotionVector(-1,-1,0).Unit,new MotionVector(1,-1,0).Unit};return d>=0 && d<8 ? a[d] : new MotionVector();}
    }
    public sealed class HumanTape
    {
        public readonly float[] Poses,Jets;public readonly double[] Times;public readonly HumanChartNote[] Notes;
        public readonly string Recording;public readonly double Accuracy;
        public int RepairedFrames;
        public double CaptureScale=1;
        public double RegistrationError;
        public readonly List<double> RepairTimes=new List<double>();
        // Contact fitting revisits the same nearby timestamps for hand, head,
        // shoulder derivatives and reach probes. Keep a bounded interval cache;
        // rebuilding all three joints on every such probe caused GC spikes.
        private const int CurveCacheSlots=8;
        private readonly PhraseCurve[,] cached=new PhraseCurve[CurveCacheSlots,3];
        private readonly int[,] cachedIndices=new int[CurveCacheSlots,3];
        public HumanTape(float[] poses,double[] times,HumanChartNote[] notes,string recording,double accuracy)
            : this(poses,times,notes,recording,accuracy,null){}
        public HumanTape(float[] poses,double[] times,HumanChartNote[] notes,string recording,double accuracy,float[] jets)
        {Poses=poses;Times=times;Notes=notes;Recording=recording;Accuracy=accuracy;Jets=jets;for(int i=0;i<CurveCacheSlots;i++)for(int j=0;j<3;j++)cachedIndices[i,j]=-1;}
        public static HumanTape FromExample(HumanMotionExample e)
        {var times=new double[HumanMotionModel.Points];for(int i=0;i<times.Length;i++)times[i]=e.Duration*i/(times.Length-1);return new HumanTape(e.Curve,times,new HumanChartNote[0],e.Recording,e.Score,e.Kinematics);}
        internal static HumanTape FromReplay(HumanReplayLibrary.Replay replay,string recording)
        {return FromReplay(replay,recording,null);}
        internal static HumanTape FromReplay(HumanReplayLibrary.Replay replay,string recording,Action waitForIdle)
        {
            var frames=replay.Frames;var times=new double[frames.Count];var poses=new float[frames.Count*21];
            // BeatLeader already records in the level/tracking-origin frame.
            // The first head yaw is a glance, not the map's forward direction.
            var registration=ReplayRegistration.Fit(replay);MotionRotation basis=registration.Rotation;
            var heights=new List<double>();for(int i=0;i<frames.Count;i+=Math.Max(1,frames.Count/200))heights.Add(frames[i].Head.Position.Y);
            heights.Sort();double scale=1.7/MotionPhrase.Clamp(heights[heights.Count*3/4]+registration.Translation.Y,1.2,2.3);
            MotionRotation[] last={MotionRotation.Identity,MotionRotation.Identity,MotionRotation.Identity};
            for(int i=0;i<frames.Count;i++)
            {if(waitForIdle!=null && (i&255)==0)waitForIdle();var f=frames[i];times[i]=f.Time;HumanReplayLibrary.Pose[] joints={f.Head,f.Left,f.Right};
                for(int j=0;j<3;j++){MotionVector p=(basis.Rotate(joints[j].Position)+registration.Translation)*scale;MotionRotation q=(basis*joints[j].Rotation).Unit;if(i>0 && MotionRotation.Dot(last[j],q)<0)q=q*-1;last[j]=q;Put(poses,i*21+j*7,p,q);}}
            var notes=new HumanChartNote[replay.Notes.Count];for(int i=0;i<notes.Length;i++){var n=replay.Notes[i];notes[i]=new HumanChartNote{Id=i,Time=n.SpawnTime,Hand=n.Hand,Lane=n.Lane,Layer=n.Layer,Direction=n.Direction,ObservedCutDirection=n.Good ? n.CutDirection : new MotionVector()};}
            Array.Sort(notes,delegate(HumanChartNote a,HumanChartNote b){return a.Time.CompareTo(b.Time);});
            var tape=new HumanTape(poses,times,notes,recording,HumanMotionTraining.Accuracy(replay)){CaptureScale=scale,RegistrationError=registration.Error};tape.RepairTracking(waitForIdle);return tape;
        }
        private void RepairTracking(Action waitForIdle)
        {
            for(int joint=0;joint<3;joint++)for(int i=1;i<Times.Length;i++)
            {
                if(waitForIdle!=null && (i&255)==1)waitForIdle();
                double dt=Times[i]-Times[i-1];int a=(i-1)*21+joint*7,b=i*21+joint*7;
                double speed=joint==0 ? 2.0 : 12.0,angular=joint==0 ? 5.0 : 70.0;
                bool invalid=(HumanMotionModel.Position(Poses,b)-HumanMotionModel.Position(Poses,a)).Length>speed*dt+.0005 ||
                    MotionRotation.Log(HumanMotionModel.Rotation(Poses,b)*HumanMotionModel.Rotation(Poses,a).Inverse).Length>angular*dt+.002 || dt>.15;
                if(!invalid)continue;
                int lo=i-1,hi=i;while(lo>0 && Times[lo]>Times[i]-.10)lo--;while(hi+1<Times.Length && Times[hi]<Times[i]+.12)hi++;
                if(Times[hi]-Times[lo]<.04)continue;
                var left=Frame(lo,joint);var right=Frame(hi,joint);
                if(lo>0){var p=Frame(lo-1,joint);double d=left.Time-p.Time;left.Velocity=((left.Grip-p.Grip)/d).Limited(speed);left.AngularVelocity=(MotionRotation.Log(left.Rotation*p.Rotation.Inverse)/d).Limited(angular);}
                if(hi+1<Times.Length){var n=Frame(hi+1,joint);double d=n.Time-right.Time;right.Velocity=((n.Grip-right.Grip)/d).Limited(speed);right.AngularVelocity=(MotionRotation.Log(n.Rotation*right.Rotation.Inverse)/d).Limited(angular);}
                var bridge=new PhraseCurve(left,right);
                for(int k=lo+1;k<hi;k++){var repaired=bridge.Sample(Times[k]);Put(Poses,k*21+joint*7,repaired.Grip,repaired.Rotation);RepairedFrames++;RepairTimes.Add(Times[k]);}
                i=hi;
            }
            RepairTimes.Sort();for(int i=0;i<CurveCacheSlots;i++)for(int j=0;j<3;j++)cachedIndices[i,j]=-1;
        }
        internal static void Put(float[] data,int k,MotionVector p,MotionRotation q)
        {data[k]=(float)p.X;data[k+1]=(float)p.Y;data[k+2]=(float)p.Z;data[k+3]=(float)q.X;data[k+4]=(float)q.Y;data[k+5]=(float)q.Z;data[k+6]=(float)q.W;}
        internal static void PutJets(float[] data,int k,PhraseState s)
        {MotionVector[] values={s.Velocity,s.Acceleration,s.AngularVelocity,s.AngularAcceleration};for(int i=0;i<4;i++){data[k+i*3]=(float)values[i].X;data[k+i*3+1]=(float)values[i].Y;data[k+i*3+2]=(float)values[i].Z;}}
        private PhraseState Frame(int i,int joint)
        {int k=i*21+joint*7;return new PhraseState{Time=Times[i],Grip=HumanMotionModel.Position(Poses,k),Rotation=HumanMotionModel.Rotation(Poses,k)};}
        private PhraseState Knot(int i,int joint)
        {
            var s=Frame(i,joint);
            if(Jets!=null){int k=i*36+joint*12;s.Velocity=HumanMotionModel.Position(Jets,k);s.Acceleration=HumanMotionModel.Position(Jets,k+3);s.AngularVelocity=HumanMotionModel.Position(Jets,k+6);s.AngularAcceleration=HumanMotionModel.Position(Jets,k+9);return s;}
            int lo=Math.Max(0,i-1),hi=Math.Min(Times.Length-1,i+1);double dt=Times[hi]-Times[lo];if(dt<=0)return s;
            if(lo==i || hi==i)return s;
            // Derivative probes need values, not two temporary heap poses.
            int ak=lo*21+joint*7,bk=hi*21+joint*7;
            var ap=HumanMotionModel.Position(Poses,ak);var bp=HumanMotionModel.Position(Poses,bk);
            var aq=HumanMotionModel.Rotation(Poses,ak);var bq=HumanMotionModel.Rotation(Poses,bk);
            s.Velocity=((bp-ap)/dt).Limited(joint==0 ? 2.5 : 12);s.AngularVelocity=(MotionRotation.Log(bq*aq.Inverse)/dt).Limited(joint==0 ? 5 : 65);
            if(i>0 && i+1<Times.Length)
            {double before=s.Time-Times[lo],after=Times[hi]-s.Time;if(before>.0001 && after>.0001){s.Acceleration=(((bp-s.Grip)/after-(s.Grip-ap)/before)*(2/dt)).Limited(joint==0 ? 20 : 300);s.AngularAcceleration=((MotionRotation.Log(bq*s.Rotation.Inverse)/after-MotionRotation.Log(s.Rotation*aq.Inverse)/before)*(2/dt)).Limited(joint==0 ? 40 : 1800);}}
            return s;
        }
        public PhraseState Sample(double time,int joint)
        {
            if(time<=Times[0]){var s=Jets!=null && time==Times[0] ? Knot(0,joint) : Frame(0,joint);s.Time=time;return s;}
            if(time>=Times[Times.Length-1]){int last=Times.Length-1;var s=Jets!=null && time==Times[last] ? Knot(last,joint) : Frame(last,joint);s.Time=time;return s;}
            int lo=0,hi=Times.Length-1;while(lo+1<hi){int m=(lo+hi)/2;if(Times[m]<=time)lo=m;else hi=m;}
            int slot=lo%CurveCacheSlots;
            if(cachedIndices[slot,joint]!=lo){cached[slot,joint]=new PhraseCurve(Knot(lo,joint),Knot(hi,joint));cachedIndices[slot,joint]=lo;}
            return cached[slot,joint].Sample(time);
        }
    }
    public sealed class MotionImitationMetrics
    {
        private readonly HashSet<int> sources=new HashSet<int>();public int Samples;public double MotionSeconds,GripSeconds,WristSeconds,GripWeightIntegral,WristWeightIntegral;
        public int DistinctSources{get{return sources.Count;}}public double MeanGripWeight{get{return GripWeightIntegral/Math.Max(.0001,MotionSeconds);}}public double MeanWristWeight{get{return WristWeightIntegral/Math.Max(.0001,MotionSeconds);}}
        public void Observe(PhraseState s,double dt){if(s==null || dt<=0)return;dt=Math.Min(dt,.05);Samples++;MotionSeconds+=dt;GripWeightIntegral+=s.HumanGripWeight*dt;WristWeightIntegral+=s.HumanWristWeight*dt;if(s.HumanGripWeight>.04)GripSeconds+=dt;if(s.HumanWristWeight>.04)WristSeconds+=dt;if(s.HumanSource>=0)sources.Add(s.HumanSource);}
    }
}
