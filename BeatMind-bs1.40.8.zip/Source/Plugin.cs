using System;
using System.IO;
using System.Threading;
using HarmonyLib;
using IPA;
using UnityEngine;
using Logger = IPA.Logging.Logger;

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.26")]
[assembly: System.Reflection.AssemblyTitle("BeatMind Human Beta V1.0.0")]

namespace SaberMind
{
    [Plugin(RuntimeOptions.DynamicInit)]
    public sealed class Plugin
    {
        internal const string Id = "BeatMindHumanBeta";
        internal static Logger Log;
        internal static Runtime Host;
        // Preserve previous training when the visible mod and DLL are renamed.
        internal static readonly MemoryStore Store = new MemoryStore(Path.Combine(IPA.Utilities.UnityGame.UserDataPath, "AIPlayAndLearn", "Levels"));
        internal static readonly ReplayStore Replays = new ReplayStore(Path.Combine(IPA.Utilities.UnityGame.UserDataPath, "AIPlayAndLearn", "BestReplays"));
        internal static volatile string HumanReplayStatus="No human replays imported. Add .bsor files and reload.";
        private static int importingHumanReplays;
        internal static volatile HumanMotionModel HumanMotion;
        internal static volatile AutomaticReplays AutomaticHumanReplays;
        private static int pollingHumanReplays;
        internal static bool ReplayLearningBusy{get{return importingHumanReplays!=0;}}
        internal static void WaitForReplayIdle()
        {while(Session.ActiveSongPlaying)Thread.Sleep(25);}
        private static void InitializeReplaySources()
        {
            if(AutomaticHumanReplays!=null) return;
            AutomaticHumanReplays=new AutomaticReplays(Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","HumanReplays"),
                Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"BeatLeader","Replays"),
                Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","BotReplayWindows.json"));
        }
        internal static void BotReplayStarted()
        {try {if(AutomaticHumanReplays!=null) AutomaticHumanReplays.BeginBot(DateTime.UtcNow);}catch(Exception e) {Log.Warn("Replay provenance: "+e.Message);}}
        internal static void BotReplayEnded()
        {try {if(AutomaticHumanReplays!=null) AutomaticHumanReplays.EndBot(DateTime.UtcNow);}catch(Exception e) {Log.Warn("Replay provenance: "+e.Message);}}
        internal static void PollHumanReplays()
        {
            if(AutomaticHumanReplays==null || Interlocked.CompareExchange(ref pollingHumanReplays,1,0)!=0) return;
            bool bot=Session.Current!=null,automatic=Settings.Current.AutoLearnOwnReplays;DateTime utc=DateTime.UtcNow;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    if(bot) {AutomaticHumanReplays.CheckpointBot(utc);return;}
                    if(importingHumanReplays==0 && AutomaticHumanReplays.Changed(automatic,utc)) ReloadHumanReplays();
                }
                catch(Exception e) {Log.Warn("Automatic replay import: "+e.Message);}
                finally {Interlocked.Exchange(ref pollingHumanReplays,0);}
            });
        }
        internal static void ReloadHumanReplays()
        {
            if(Interlocked.CompareExchange(ref importingHumanReplays,1,0)!=0) return;
            HumanReplayStatus="Reading all human replays...";
            string folder=Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","HumanReplays");
            string cache=Path.Combine(IPA.Utilities.UnityGame.UserDataPath,"AIPlayAndLearn","HumanMotionCache");
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    Directory.CreateDirectory(folder);
                    InitializeReplaySources();
                    string[] sources=AutomaticHumanReplays.Collect(Settings.Current.AutoLearnOwnReplays,DateTime.UtcNow);
                    string observedRevision=AutomaticReplays.SourceRevision(sources);
                    HumanMotionModel learned=HumanMotionTraining.LoadFiles(sources,cache,
                        delegate(string status) {HumanReplayStatus=status;},
                        delegate(string message) {Log.Warn("Human replay: "+message);},
                        WaitForReplayIdle,
                        delegate(HumanMotionModel cached){if(HumanMotion==null)HumanMotion=cached;});
                    // Acknowledge exactly the source snapshot this load read.
                    // Files arriving during the load must remain detectable.
                    AutomaticHumanReplays.Observe(observedRevision);
                    if(learned.Valid())
                    {
                        HumanMotion=learned;
                        HumanReplayStatus="Learned "+learned.LearningPoseSamples+" / "+HumanMotionTraining.MaximumLearningPoseSamples+" pose samples in "+learned.Cuts+" continuous excerpts; "+learned.Files+" qualifying replays indexed.";
                        if(learned.Rejected>0) HumanReplayStatus+=" "+learned.Rejected+" unusable; see log.";
                        Log.Info("Motion validation: "+learned.ValidationExamples+" separate-recording examples; contextual error="+learned.ContextValidationError.ToString("F5")+", mean error="+learned.MeanValidationError.ToString("F5"));
                    }
                    else HumanReplayStatus=HumanMotion==null ? "No usable human transitions. Add .bsor files and reload." : "No usable new transitions. Previous motion retained.";
                    Log.Info(HumanReplayStatus);
                }
                catch(Exception error) {HumanReplayStatus="Replay learning failed; previous motion retained.";Log.Warn("Human motion learning: "+error);}
                finally {Interlocked.Exchange(ref importingHumanReplays,0);}
            });
        }
        private Harmony harmony;
        private GameObject root;

        [Init] public Plugin(Logger logger) { Log = logger; }
        [OnEnable] public void Enable()
        {
            if (root != null) return;
            try
            {
                Settings.Load();
                MultiplayerIntegration.Initialize();
                Log.Info("Continuous human motion graph v9: ordered full-body sequences / learned velocity + acceleration + wrist momentum / contact-constrained replay motor.");
                InitializeReplaySources();
                ReloadHumanReplays();
                harmony = new Harmony("local.beatmindhumanbeta");
                harmony.PatchAll(typeof(Plugin).Assembly);
                root = new GameObject(Id);
                UnityEngine.Object.DontDestroyOnLoad(root);
                Host = root.AddComponent<Runtime>();
                Log.Info("BeatMind Human Beta V1.0.0 build 1.0.0.26 ready. Restored pre-song preparation; chronological learned contacts and shared stack timing. Repeated-cut recovery preserved. Human learning requires 93%+ full runs. Solo > Mods > BeatMind; Online > Mods > SaberMind 1v1.");
            }
            catch (Exception error)
            {
                if (harmony != null) harmony.UnpatchSelf();
                Log.Error("BeatMind could not start: " + error);
                throw;
            }
        }
        [OnDisable] public void Disable()
        {
            Session.Stop("Mod disabled");
            MultiplayerIntegration.Shutdown();
            if (Host != null) Host.Shutdown();
            if (harmony != null) harmony.UnpatchSelf();
            if (root != null) UnityEngine.Object.Destroy(root);
            Host = null;
            root = null;
            BS_Utils.Gameplay.ScoreSubmission.RemoveProlongedDisable(Id);
        }
    }
}



