using System;
using System.Collections.Generic;

namespace SaberMind
{
    [Flags]
    internal enum MotionPatternKind
    {
        None=0, Repeated=1, Stream=2, Tech=4, Crossover=8, DotSequence=16
    }

    internal struct PlanarStroke
    {
        internal double X,Y;
        internal PlanarStroke(double x,double y) { X=x;Y=y; }
        internal PlanarStroke Unit
        {
            get { double length=Math.Sqrt(X*X+Y*Y);return length>.00001 ? new PlanarStroke(X/length,Y/length) : new PlanarStroke(0,-1); }
        }
        internal PlanarStroke Reverse { get { return new PlanarStroke(-X,-Y); } }
        internal static double Dot(PlanarStroke a,PlanarStroke b) { return a.X*b.X+a.Y*b.Y; }
    }

    internal sealed class PatternEvent
    {
        internal double Time;
        internal int Hand,Lane,Layer;
        internal bool Dot, HasDirectionHint;
        internal PlanarStroke Direction;
    }

    internal sealed class MotionPattern
    {
        internal MotionPatternKind Kind;
        internal double HandSpacing=1.2, Cadence=1.2, Regularity, Alternation, LateralTravel;
        internal int WindowNotes;
        internal bool Is(MotionPatternKind kind) { return (Kind&kind)!=0; }
    }

    internal sealed class PatternAnalysis
    {
        internal PlanarStroke[] Directions;
        internal MotionPattern[] Patterns;
    }

    // Pure chart analysis, shared by live play and offline practice. No frame
    // state is involved: looking up a future dot cannot advance a hand's phase.
    internal static class PatternFlow
    {
        private const double GroupWindow=.0120001;
        internal static PatternAnalysis Analyze(IList<PatternEvent> chart)
        {
            var result=new PatternAnalysis {Directions=new PlanarStroke[chart.Count],Patterns=new MotionPattern[chart.Count]};
            var hands=new List<int>[] {new List<int>(),new List<int>()};
            for(int i=0;i<chart.Count;i++)
            {
                result.Directions[i]=chart[i].Direction.Unit;
                result.Patterns[i]=new MotionPattern();
                if(chart[i].Hand>=0 && chart[i].Hand<2) hands[chart[i].Hand].Add(i);
            }
            foreach(List<int> hand in hands)
            {
                ResolveDots(chart,hand,result.Directions);
                Classify(chart,hand,result);
            }
            return result;
        }

        private static void ResolveDots(IList<PatternEvent> chart,List<int> hand,PlanarStroke[] resolved)
        {
            var groups=new List<StrokeGroup>();
            for(int start=0;start<hand.Count;)
            {
                int end=start+1;
                double time=chart[hand[start]].Time;
                while(end<hand.Count && chart[hand[end]].Time-time<=GroupWindow) end++;
                var group=new StrokeGroup {Start=start,End=end};
                // Same-hand stacks are one swing. An arrow in that stack
                // constrains its dots too, irrespective of chart ordering.
                for(int n=start;n<end;n++)
                    if(!chart[hand[n]].Dot) { group.Arrow=true;group.Direction=chart[hand[n]].Direction.Unit;break; }
                groups.Add(group);start=end;
            }
            PlanarStroke previous=new PlanarStroke(0,1);bool hasPrevious=false;
            for(int start=0;start<groups.Count;)
            {
                if(groups[start].Arrow)
                {
                    Assign(chart,hand,resolved,groups[start],groups[start].Direction);
                    previous=groups[start].Direction;hasPrevious=true;start++;continue;
                }
                int end=start+1;while(end<groups.Count && !groups[end].Arrow) end++;
                int count=end-start;
                bool hasNext=end<groups.Count && chart[hand[groups[end].Start]].Time-chart[hand[groups[end-1].Start]].Time<=1.6;
                PlanarStroke nextFirst=hasNext ? groups[end].Direction : new PlanarStroke(0,-1);
                if((count&1)!=0) nextFirst=nextFirst.Reverse;
                PlanarStroke initial=hasPrevious ? previous.Reverse : hasNext ? nextFirst : InitialAxis(chart,hand,groups,start,end);
                double startAngle=Math.Atan2(initial.Y,initial.X);
                double difference=hasPrevious && hasNext ? Wrap(Math.Atan2(nextFirst.Y,nextFirst.X)-startAngle) : 0;
                // An upcoming arrow may change the swing plane. Prepare that
                // change across the free-direction run instead of a reset at
                // its last dot. The first dot still reverses the previous cut.
                double maximum=Math.Max(0,count-1)*18*Math.PI/180;
                difference=Math.Max(-maximum,Math.Min(maximum,difference));
                double axisAngle=startAngle;
                for(int p=start;p<end;p++)
                {
                    int phase=p-start;
                    if(hasNext && hasPrevious)
                        axisAngle=startAngle+(count==1 ? 0 : difference*phase/(count-1));
                    else if(!hasNext && phase>0)
                    {
                        PatternEvent here=chart[hand[groups[p].Start]];
                        // The No Arrows modifier can leave original arrow
                        // directions in chart data. Use their plane as a hint,
                        // never their sign: free strokes must still alternate.
                        if(here.HasDirectionHint)
                        {
                            double hint=Math.Atan2(here.Direction.Y,here.Direction.X);
                            double turn=Wrap(hint-axisAngle);
                            if(turn>Math.PI/2) turn-=Math.PI;
                            if(turn< -Math.PI/2) turn+=Math.PI;
                            axisAngle+=Math.Max(-Math.PI/10,Math.Min(Math.PI/10,turn));
                        }
                    }
                    PlanarStroke stroke=new PlanarStroke(Math.Cos(axisAngle),Math.Sin(axisAngle));
                    if((phase&1)!=0) stroke=stroke.Reverse;
                    Assign(chart,hand,resolved,groups[p],stroke);previous=stroke;
                }
                hasPrevious=true;start=end;
            }
        }

        private sealed class StrokeGroup
        { internal int Start,End;internal bool Arrow;internal PlanarStroke Direction; }
        private static double Wrap(double angle)
        { while(angle>Math.PI) angle-=Math.PI*2;while(angle< -Math.PI) angle+=Math.PI*2;return angle; }
        private static PlanarStroke InitialAxis(IList<PatternEvent> chart,List<int> hand,List<StrokeGroup> groups,int start,int end)
        {
            PatternEvent first=chart[hand[groups[start].Start]];
            if(first.HasDirectionHint) return first.Direction.Unit;
            for(int p=start+1;p<end && p<=start+3;p++)
            {
                PatternEvent next=chart[hand[groups[p].Start]];
                if(next.Time-first.Time>.75) break;
                var travel=new PlanarStroke(next.Lane-first.Lane,next.Layer-first.Layer);
                if(travel.X*travel.X+travel.Y*travel.Y>.01) return travel.Unit;
            }
            return new PlanarStroke(0,-1);
        }
        private static void Assign(IList<PatternEvent> chart,List<int> hand,PlanarStroke[] resolved,StrokeGroup group,PlanarStroke stroke)
        {
            for(int n=group.Start;n<group.End;n++)
            { int index=hand[n];resolved[index]=chart[index].Dot ? stroke : chart[index].Direction.Unit; }
        }

        private static void Classify(IList<PatternEvent> chart,List<int> hand,PatternAnalysis result)
        {
            for(int n=0;n<hand.Count;n++)
            {
                int index=hand[n];PatternEvent current=chart[index];MotionPattern pattern=result.Patterns[index];
                if(n>0 && current.Time-chart[hand[n-1]].Time>GroupWindow)
                    pattern.HandSpacing=Math.Min(pattern.HandSpacing,current.Time-chart[hand[n-1]].Time);
                if(n+1<hand.Count && chart[hand[n+1]].Time-current.Time>GroupWindow)
                    pattern.HandSpacing=Math.Min(pattern.HandSpacing,chart[hand[n+1]].Time-current.Time);
                int first=n,last=n;
                while(first>0 && n-first<3 && current.Time-chart[hand[first-1]].Time<=1.8 &&
                    chart[hand[first]].Time-chart[hand[first-1]].Time<=.75) first--;
                while(last+1<hand.Count && last-n<3 && chart[hand[last+1]].Time-current.Time<=1.8 &&
                    chart[hand[last+1]].Time-chart[hand[last]].Time<=.75) last++;
                var gaps=new List<double>();int alternating=0,same=0,turns=0,dots=0,cross=0,wide=0;
                double lateral=0;
                for(int p=first;p<=last;p++)
                {
                    int here=hand[p];PatternEvent note=chart[here];
                    if(note.Dot) dots++;
                    if((note.Hand==0 && note.Lane>=2)||(note.Hand==1 && note.Lane<=1)) cross++;
                    if(p==first) continue;
                    int previous=hand[p-1];double gap=note.Time-chart[previous].Time;
                    if(gap<=GroupWindow) continue;
                    gaps.Add(gap);
                    double dot=PlanarStroke.Dot(result.Directions[here],result.Directions[previous]);
                    if(dot<-.70) alternating++;
                    else if(dot>.85) same++;
                    else turns++;
                    double travel=Math.Abs(note.Lane-chart[previous].Lane);
                    lateral+=travel;if(travel>=2) wide++;
                }
                pattern.WindowNotes=gaps.Count+1;
                if(gaps.Count>0)
                {
                    double sum=0;foreach(double gap in gaps) sum+=gap;
                    pattern.Cadence=sum/gaps.Count;
                    double variance=0;foreach(double gap in gaps) variance+=(gap-pattern.Cadence)*(gap-pattern.Cadence);
                    double deviation=Math.Sqrt(variance/gaps.Count)/Math.Max(.001,pattern.Cadence);
                    pattern.Regularity=Math.Max(0,1-deviation);
                    pattern.Alternation=(double)alternating/gaps.Count;
                    pattern.LateralTravel=lateral/gaps.Count;
                    // Rhythm and geometry are separate. A regular tech stream
                    // can legitimately carry both flags.
                    if(gaps.Count>=3 && pattern.Cadence<=.5 && pattern.Regularity>=.78)
                        pattern.Kind|=MotionPatternKind.Stream;
                    if(gaps.Count>=2 && pattern.Regularity>=.78 &&
                        (alternating>=gaps.Count-1 || same==gaps.Count)) pattern.Kind|=MotionPatternKind.Repeated;
                    if(turns>=2 || wide>=2 || (cross>0 && turns>0) ||
                        (gaps.Count>=3 && pattern.Cadence<.6 && pattern.Regularity<.60))
                        pattern.Kind|=MotionPatternKind.Tech;
                }
                if(cross>0) pattern.Kind|=MotionPatternKind.Crossover;
                if(dots>=2) pattern.Kind|=MotionPatternKind.DotSequence;
            }
        }
    }
}
