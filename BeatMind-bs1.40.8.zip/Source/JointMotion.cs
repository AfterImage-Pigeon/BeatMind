using UnityEngine;

namespace SaberMind
{
    internal static class JointMotion
    {
        internal static Vector3 Log(Quaternion q)
        {
            if (q.w < 0) q = new Quaternion(-q.x,-q.y,-q.z,-q.w);
            float angle; Vector3 axis; q.ToAngleAxis(out angle,out axis);
            return angle < .0001f || float.IsNaN(axis.x) ? Vector3.zero : axis * angle;
        }
        // The private multiplayer lobby's wave response has no song/replay
        // clock. This bounded response is used only there, never for cuts.
        internal static Quaternion Advance(Quaternion current,Quaternion target,ref Vector3 velocity,
            ref Vector3 acceleration,Vector3 feed,Vector3 targetAcceleration,float delta,float frequency,float speed,float accel,float jerk)
        {
            int count=Mathf.Max(1,Mathf.CeilToInt(delta/.003f));float dt=delta/count;
            for(int i=0;i<count;i++)
            {
                Vector3 error=Log(target*Quaternion.Inverse(current));
                Vector3 desired=Vector3.ClampMagnitude(feed+error*(frequency/3),speed);
                Vector3 requested=(desired-velocity)*(3*frequency*frequency)+(Vector3.ClampMagnitude(targetAcceleration,accel)-acceleration)*(3*frequency);
                Vector3 next=Vector3.ClampMagnitude(acceleration+Vector3.ClampMagnitude(requested,jerk)*dt,accel),change=next-acceleration;
                Vector3 travel=velocity*dt+acceleration*(.5f*dt*dt)+change*(dt*dt/6);
                velocity+=acceleration*dt+change*(.5f*dt);acceleration=next;
                if(travel.sqrMagnitude>1e-8f)current=Quaternion.AngleAxis(travel.magnitude,travel.normalized)*current;
            }
            return current;
        }
    }
}
