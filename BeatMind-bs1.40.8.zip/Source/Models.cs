using System;
using System.Collections.Generic;
using System.Globalization;

namespace SaberMind
{
    public static class JointGeometry
    {
        public static double Distance(double upper, double lower, double internalAngleDegrees)
        { return Math.Sqrt(Math.Max(0, upper * upper + lower * lower - 2 * upper * lower * Math.Cos(internalAngleDegrees * Math.PI / 180))); }
    }
    public sealed class ModelProfile
    {
        public readonly string Name;
        public readonly int Index, Dimensions, LookAhead, PlanningSamples;
        public readonly float Realism, MotionWeight;
        private ModelProfile(string name, int index, int dimensions, int lookAhead, int samples, float realism, float weight)
        { Name = name; Index = index; Dimensions = dimensions; LookAhead = lookAhead; PlanningSamples = samples; Realism = realism; MotionWeight = weight; }
        public static readonly ModelProfile[] All = {
            new ModelProfile("Rapid", 0, 0, 2, 3, .80f, 0),
            new ModelProfile("Natural", 1, 5, 4, 6, .90f, 0),
            new ModelProfile("Human Simulation", 2, 12, 8, 9, 1f, 0)
        };
        public static ModelProfile Find(string name)
        { foreach (ModelProfile item in All) if (item.Name == name) return item; return name == "Advanced" ? All[2] : All[1]; }
        public string Description
        { get { return LookAhead + " note lookahead | " + PlanningSamples + " contact candidates | score-first cuts"; } }
    }

    // Timing and speed retain the existing nine-stroke policy. The other controls
    // are independent, measured coordinate experiments, not smoothing presets.
    public sealed class BehaviorMemory
    {
        public int Visits;
        public int[][] Trials;
        public double[][] Rewards;
        public void Normalize(int dimensions)
        {
            if (Trials == null) Trials = new int[dimensions][];
            if (Rewards == null) Rewards = new double[dimensions][];
            if (Trials.Length < dimensions) Array.Resize(ref Trials, dimensions);
            if (Rewards.Length < dimensions) Array.Resize(ref Rewards, dimensions);
            for (int d = 0; d < dimensions; d++)
            {
                if (Trials[d] == null || Trials[d].Length != 3) Trials[d] = new int[3];
                if (Rewards[d] == null || Rewards[d].Length != 3) Rewards[d] = new double[3];
                for (int c = 0; c < 3; c++)
                {
                    Trials[d][c] = Math.Max(0, Math.Min(1000000, Trials[d][c]));
                    double r = Rewards[d][c];
                    Rewards[d][c] = double.IsNaN(r) || double.IsInfinity(r) ? 0 : Math.Max(0, Math.Min(Trials[d][c], r));
                }
            }
            Visits = Math.Max(0, Visits);
        }
    }

    public sealed class BehaviorChoice
    {
        public string Context;
        public int Axis = -1, Option;
        public float[] Values = new float[12];
        private float B(int i)
        { float v=Values==null || i>=Values.Length ? 0 : Values[i];return float.IsNaN(v)||float.IsInfinity(v) ? 0 : Math.Max(-1,Math.Min(1,v)); }
        public float Curve { get { return 1 + B(0) * .35f; } }
        public float Recovery { get { return 1 + B(1) * .18f; } }
        public float Wrist { get { return 1 + B(2) * .35f; } }
        public float Follow { get { return 1 + B(3) * .12f; } }
        public float Momentum { get { return 1 + B(4) * .25f; } }
        public float Anticipation { get { return 1 + B(5) * .22f; } }
        public float Elbow { get { return B(6) * .25f; } }
        public float Lean { get { return 1 + B(7) * .25f; } }
        public float HeadLead { get { return 1 + B(8) * .25f; } }
        public float Shoulder { get { return B(9) * .035f; } }
        public float Torso { get { return 1 + B(10) * .25f; } }
        public float Grip { get { return B(11) * .06f; } }
    }

    public static class BehaviorOptimizer
    {
        private static int Best(BehaviorMemory memory, int axis)
        {
            int best = 1; double score = -1;
            for (int c = 0; c < 3; c++)
            {
                int n = memory.Trials[axis][c];
                double mean = n == 0 ? -1 : memory.Rewards[axis][c] / n;
                if (mean > score) { score = mean; best = c; }
            }
            return best;
        }
        public static BehaviorChoice Choose(BehaviorMemory memory, ModelProfile profile, bool learn, string context)
        {
            var choice = new BehaviorChoice { Context = context };
            if (profile.Dimensions == 0) return choice;
            memory.Normalize(profile.Dimensions);
            for (int d = 0; d < profile.Dimensions; d++) choice.Values[d] = Best(memory, d) - 1;
            if (!learn) return choice;
            int axis = memory.Visits % profile.Dimensions;
            int option = -1;
            // Baseline first, then low and high; every axis receives real trials.
            foreach (int c in new int[] { 1, 0, 2 })
                if (memory.Trials[axis][c] == 0) { option = c; break; }
            if (option < 0)
            {
                double bestBound = double.NegativeInfinity;
                int total = memory.Trials[axis][0] + memory.Trials[axis][1] + memory.Trials[axis][2];
                for (int c = 0; c < 3; c++)
                {
                    double bound = memory.Rewards[axis][c] / memory.Trials[axis][c]
                        + .18 * Math.Sqrt(Math.Log(total + 1) / memory.Trials[axis][c]);
                    if (bound > bestBound) { bestBound = bound; option = c; }
                }
            }
            choice.Axis = axis; choice.Option = option; choice.Values[axis] = option - 1;
            return choice;
        }
        public static void Observe(BehaviorMemory memory, ModelProfile profile, BehaviorChoice choice, double cut, double motionQuality)
        {
            if (choice == null || choice.Axis < 0 || profile.Dimensions == 0) return;
            if (double.IsNaN(cut) || double.IsInfinity(cut)) return;
            memory.Normalize(profile.Dimensions);
            int d = choice.Axis, c = choice.Option;
            if (d >= profile.Dimensions || c < 0 || c > 2) return;
            // Cut score is the only reward. Preserve the argument for existing
            // callers, but never discount a better cut for its visible style.
            double reward = Math.Max(0, Math.Min(1, cut));
            if (memory.Trials[d][c] >= 1000000) { memory.Trials[d][c] /= 2; memory.Rewards[d][c] /= 2; }
            memory.Trials[d][c]++; memory.Rewards[d][c] += reward;
            memory.Visits = (memory.Visits + 1) % 1000000000;
        }
    }

    public sealed class MeasuredRun
    {
        public int Score, RawScore, Maximum, Good, Missed, Bad;
        public bool Training, Completed;
        public double Accuracy;
        public string Utc;
    }
    // Offline geometric practice is kept separate from real cut evidence.
    public sealed class PretrainedPlan
    {
        public string PreparationSignature;
        public int MotionVersion;
        public float X, Y, Z;
        public float Confidence;
        public int Validations;
        public int Variant = -1;
    }
    public sealed class ModelMemory
    {
        public Dictionary<string, NoteMemory> Timing = new Dictionary<string, NoteMemory>();
        public Dictionary<string, BehaviorMemory> Behaviors = new Dictionary<string, BehaviorMemory>();
        public List<MeasuredRun> Runs = new List<MeasuredRun>();
        public Dictionary<string, PretrainedPlan> Pretrained = new Dictionary<string, PretrainedPlan>();
        public NoteMemory Note(string key, NoteMemory legacy, bool create)
        {
            if (Timing == null) Timing = new Dictionary<string, NoteMemory>();
            NoteMemory value;
            if (!Timing.TryGetValue(key, out value) || value == null)
            {
                value = new NoteMemory();
                if (legacy != null) { legacy.Normalize(); value.Trials = (int[])legacy.Trials.Clone(); value.Rewards = (double[])legacy.Rewards.Clone(); }
                if (create) Timing[key] = value;
            }
            value.Normalize(); return value;
        }
        public BehaviorMemory Behavior(string key, bool create)
        {
            if (Behaviors == null) Behaviors = new Dictionary<string, BehaviorMemory>();
            BehaviorMemory value;
            if (!Behaviors.TryGetValue(key, out value) || value == null)
            { value = new BehaviorMemory(); if (create) Behaviors[key] = value; }
            return value;
        }
        public void Record(MeasuredRun run)
        {
            if (!Valid(run)) return;
            run.Accuracy = 100.0 * run.RawScore / run.Maximum;
            run.Utc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
            if (Runs == null) Runs = new List<MeasuredRun>();
            Runs.Add(run); if (Runs.Count > 20) Runs.RemoveAt(0);
        }
        private static bool Valid(MeasuredRun run)
        { return run != null && run.Completed && run.Maximum > 0 && run.Score >= 0 && run.RawScore >= 0 && run.RawScore <= run.Maximum
            && run.Good >= 0 && run.Missed >= 0 && run.Bad >= 0; }
        public string Prediction()
        {
            if (Runs == null || Runs.Count == 0) return "Predicted Score: N/A\nPredicted Accuracy: N/A\nPredicted Misses / Bad Cuts: N/A\nEstimated BeatLeader PP: N/A\nEstimated ScoreSaber PP: N/A\nNo completed measured runs for these settings.";
            double score = 0, accuracy = 0, misses = 0, bad = 0;
            int count = 0;
            foreach (MeasuredRun run in Runs)
            {
                if (!Valid(run)) continue;
                score += run.Score; accuracy += 100.0 * run.RawScore / run.Maximum; misses += run.Missed; bad += run.Bad; count++;
            }
            if (count == 0) return new ModelMemory().Prediction();
            return "Predicted Score: " + Math.Round(score / count).ToString("N0", CultureInfo.InvariantCulture)
                + "\nPredicted Accuracy: " + (accuracy / count).ToString("0.0", CultureInfo.InvariantCulture) + "%"
                + "\nPredicted Misses / Bad Cuts: " + (misses / count).ToString("0.0", CultureInfo.InvariantCulture) + " / " + (bad / count).ToString("0.0", CultureInfo.InvariantCulture)
                + "\nEstimated BeatLeader PP: N/A\nEstimated ScoreSaber PP: N/A"
                + "\nMeasured mean of " + count + " completed runs; no PP rating calculation available.";
        }
    }

    public sealed class BodySettings
    {
        public string Model = "Natural";
        public float Height = 1.72f, ShoulderWidth = .40f, UpperArm = .31f, Forearm = .27f, Hand = .09f, Torso = .52f;
        public bool SimulatedCamera = true, ShowBody = true, DebugMotionTrace, AutoRestartGoal95 = true;
        public int TrainToAccuracyPercent = 95;
        public bool UseHumanReplayStyle = true;
        public bool AutoLearnOwnReplays = true;
        public bool MultiplayerJoinEnabled;
        public int MultiplayerModel = 1;
        public bool ShowGameplayHud = true, ShowTrainingDetails = true;
        public bool HudOnRight;
        public float HudScale = 1f, HudOpacity = .8f;
        public float ReadinessThreshold = .72f;
        public void Normalize()
        {
            Model = ModelProfile.Find(Model).Name;
            MultiplayerModel = Math.Max(0,Math.Min(2,MultiplayerModel));
            Height = Clamp(Height, 1.35f, 2.1f, 1.72f); ShoulderWidth = Clamp(ShoulderWidth, .30f, .55f, .40f);
            UpperArm = Clamp(UpperArm, .23f, .40f, .31f); Forearm = Clamp(Forearm, .20f, .36f, .27f);
            Hand = Clamp(Hand, .06f, .13f, .09f); Torso = Clamp(Torso, .40f, .68f, .52f);
            ReadinessThreshold = Clamp(ReadinessThreshold,.50f,.95f,.72f);
            HudScale = Clamp(HudScale,.65f,1.5f,1f); HudOpacity = Clamp(HudOpacity,.25f,1f,.8f);
        }
        private static float Clamp(float x, float a, float b, float fallback)
        { return float.IsNaN(x) || float.IsInfinity(x) ? fallback : Math.Max(a, Math.Min(b, x)); }
    }
}
