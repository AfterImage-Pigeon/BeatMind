using System;

namespace SaberMind
{
    public struct MotionAxis
    {
        public double Position, Velocity, Acceleration;
    }
    public static class MotionContinuity
    {
        private static double Limit(double value, double limit) { return Math.Max(-limit, Math.Min(limit, value)); }
        // Exact integration of constant jerk over one substep. Velocity is a
        // soft braking target, never a final clamp that discards momentum.
        public static void Step(ref MotionAxis state, double target, double targetVelocity,
            double dt, double frequency, double speed, double acceleration, double jerk, double targetAcceleration = 0)
        {
            if (dt <= 0) return;
            double desiredVelocity = Limit(targetVelocity + (target - state.Position) * frequency / 3, speed);
            // Triple-pole damping includes the acceleration state itself. Merely
            // slew-limiting a second-order servo's acceleration can oscillate
            // indefinitely on reversals when its jerk budget is saturated.
            double requestedJerk = 3 * frequency * frequency * (desiredVelocity - state.Velocity)
                + 3 * frequency * (Limit(targetAcceleration,acceleration) - state.Acceleration);
            double nextAcceleration = Limit(state.Acceleration + Limit(requestedJerk,jerk)*dt,acceleration);
            double change = nextAcceleration - state.Acceleration;
            double j = change / dt;
            state.Position += state.Velocity * dt + .5 * state.Acceleration * dt * dt + j * dt * dt * dt / 6;
            state.Velocity += state.Acceleration * dt + .5 * j * dt * dt;
            state.Acceleration += change;
        }
        public static void Advance(ref MotionAxis state, double target, double dt, double frequency,
            double speed, double acceleration, double jerk)
        {
            int steps = Math.Max(1, (int)Math.Ceiling(dt / .003));
            for (int i = 0; i < steps; i++) Step(ref state, target, 0, dt / steps, frequency, speed, acceleration, jerk);
        }
        // Bounded elbow flexion without a hard joint-angle projection. Its
        // derivatives stay continuous even while an unreachable target is held.
        public static double Bend(double coordinate) { return 84 + 72 * Math.Tanh(coordinate); }
        public static double BendCoordinate(double degrees)
        {
            double x = Math.Max(-.986, Math.Min(.986, (degrees - 84) / 72));
            return .5 * Math.Log((1 + x) / (1 - x));
        }
    }
}
