using System;
namespace SaberMind
{
    // Planning utilities only. The live sampler never clamps a displayed pose.
    // Side is inclination away from the body's forward/up plane, not yaw:
    // blade = forward*cos(side)*cos(pitch) + right*sin(side)
    //       + up*cos(side)*sin(pitch). This stays regular above straight up.
    public static class WristMotionLimits
    {
        public const double MinimumPitchRadians=-40*Math.PI/180;
        public const double MaximumPitchRadians=100*Math.PI/180;
        public const double MinimumSideRadians=-45*Math.PI/180;
        public const double MaximumSideRadians=45*Math.PI/180;
        private const double Tolerance=2e-12;
        private struct Frame {internal MotionVector Forward,Right,Up,Blade;}
        private static bool Finite(double value){return !double.IsNaN(value) && !double.IsInfinity(value);}
        private static Frame BodyFrame(PhraseGeometry geometry)
        {
            if(geometry==null)throw new ArgumentNullException("geometry");
            var up=new MotionVector(0,1,0);var forward=new MotionVector(geometry.Forward.X,0,geometry.Forward.Z);
            if(!Finite(forward.Length))throw new ArgumentException("Nonfinite body forward.","geometry");
            if(forward.Length<1e-9)forward=new MotionVector(0,0,1);else forward=forward.Unit;
            var blade=geometry.Top-geometry.Bottom;
            if(!Finite(blade.Length) || blade.Length<1e-9)throw new ArgumentException("A nonzero local blade axis is required.","geometry");
            return new Frame{Forward=forward,Right=MotionVector.Cross(up,forward).Unit,Up=up,Blade=blade.Unit};
        }
        private static MotionRotation Unit(MotionRotation rotation)
        {if(!Finite(rotation.Length) || rotation.Length<1e-9)throw new ArgumentException("A finite nonzero rotation is required.","rotation");return rotation.Unit;}
        private static void Margin(double margin)
        {if(!Finite(margin) || margin<0 || margin>(MaximumSideRadians-MinimumSideRadians)*.5)throw new ArgumentOutOfRangeException("marginRad","Margin insets the limits and must be between zero and 45 degrees.");}
        private static void Angles(MotionVector blade,Frame frame,out double pitch,out double side)
        {pitch=Math.Atan2(MotionVector.Dot(blade,frame.Up),MotionVector.Dot(blade,frame.Forward));side=Math.Asin(MotionPhrase.Clamp(MotionVector.Dot(blade,frame.Right),-1,1));}
        private static bool Inside(MotionVector blade,Frame frame,double margin)
        {double pitch,side;Angles(blade,frame,out pitch,out side);return pitch>=MinimumPitchRadians+margin-Tolerance && pitch<=MaximumPitchRadians-margin+Tolerance && side>=MinimumSideRadians+margin-Tolerance && side<=MaximumSideRadians-margin+Tolerance;}
        public static void Angles(MotionRotation q,PhraseGeometry g,out double pitchRad,out double sideRad)
        {var frame=BodyFrame(g);Angles(Unit(q).Rotate(frame.Blade),frame,out pitchRad,out sideRad);}
        public static bool Contains(MotionRotation q,PhraseGeometry g,double marginRad=0)
        {Margin(marginRad);var frame=BodyFrame(g);return Inside(Unit(q).Rotate(frame.Blade),frame,marginRad);}
        public static MotionRotation Fit(MotionRotation q,PhraseGeometry g,double marginRad=0)
        {
            Margin(marginRad);var frame=BodyFrame(g);q=Unit(q);var blade=q.Rotate(frame.Blade);
            if(Inside(blade,frame,marginRad))return q;
            double x=MotionVector.Dot(blade,frame.Right),y=MotionVector.Dot(blade,frame.Up),z=MotionVector.Dot(blade,frame.Forward);
            double low=MinimumPitchRadians+marginRad,high=MaximumPitchRadians-marginRad,pitch=Math.Atan2(y,z);
            // cos(side) stays positive, so the nearest spherical direction
            // first maximizes its forward/up dot product. Comparing endpoints
            // handles periodic pitch: +179 and -179 both choose +100, rather
            // than switching abruptly between opposite ends of the envelope.
            if(pitch<low || pitch>high)
            {double a=z*Math.Cos(low)+y*Math.Sin(low),b=z*Math.Cos(high)+y*Math.Sin(high);pitch=b>a+Tolerance ? high : low;}
            double h=z*Math.Cos(pitch)+y*Math.Sin(pitch),sideLow=MinimumSideRadians+marginRad,sideHigh=MaximumSideRadians-marginRad;
            double side=sideLow,best=x*Math.Sin(sideLow)+h*Math.Cos(sideLow),candidate=x*Math.Sin(sideHigh)+h*Math.Cos(sideHigh);
            if(candidate>best+Tolerance){side=sideHigh;best=candidate;}
            double stationary=Math.Atan2(x,h);
            if(stationary>=sideLow && stationary<=sideHigh && x*Math.Sin(stationary)+h*Math.Cos(stationary)>best+Tolerance)side=stationary;
            var bounded=frame.Forward*(Math.Cos(side)*Math.Cos(pitch))+frame.Right*Math.Sin(side)+frame.Up*(Math.Cos(side)*Math.Sin(pitch));
            // A minimal swing transports the original blade roll intact.
            return (MotionRotation.FromTo(blade,bounded,frame.Right)*q).Unit;
        }
        private static bool InsideAt(MotionRotation q,MotionVector axis,double angle,Frame frame,double margin)
        {var blade=(MotionRotation.Exp(axis*angle)*q).Unit.Rotate(frame.Blade);double pitch,side;Angles(blade,frame,out pitch,out side);return pitch>=MinimumPitchRadians+margin && pitch<=MaximumPitchRadians-margin && side>=MinimumSideRadians+margin && side<=MaximumSideRadians-margin;}
        // Find the first decreasing zero of one linear direction constraint.
        // Rodrigues' actual blade arc gives A*cos(t)+B*sin(t)+C. Considering
        // its roots also catches a narrow exit/re-entry that fixed probes miss.
        private static void Exit(MotionVector normal,double offset,MotionVector parallel,MotionVector radial,MotionVector tangent,ref double first,ref double negativeWidth)
        {
            double a=MotionVector.Dot(normal,radial),b=MotionVector.Dot(normal,tangent),c=MotionVector.Dot(normal,parallel)+offset;
            double radius=Math.Sqrt(a*a+b*b);if(radius<1e-14 || c-radius>=-1e-14)return;
            double root=Math.Atan2(b,a)+Math.Acos(MotionPhrase.Clamp(-c/radius,-1,1));
            root%=2*Math.PI;if(root<0)root+=2*Math.PI;
            if(Math.Abs(a+c)<=1e-14 && (b<-1e-14 || Math.Abs(b)<=1e-14 && a>1e-14))root=0;
            if(root<first){first=root;negativeWidth=2*Math.PI-2*Math.Acos(MotionPhrase.Clamp(-c/radius,-1,1));}
        }
        // Returns signed travel no farther than the requested angle. The start
        // must already be inside: callers fit contacts before planning arcs.
        // The world axis acts on the real local blade, including custom offsets.
        public static double SafeTravel(MotionRotation q,MotionVector axis,double signedAngle,PhraseGeometry g,double marginRad=0)
        {
            Margin(marginRad);if(!Finite(signedAngle) || !Finite(axis.Length))throw new ArgumentException("Finite arc angle and axis are required.");
            var frame=BodyFrame(g);q=Unit(q);var blade=q.Rotate(frame.Blade);
            if(signedAngle==0 || axis.Length<1e-9 || !Inside(blade,frame,marginRad))return 0;
            double sign=signedAngle<0 ? -1 : 1,length=Math.Abs(signedAngle);axis=axis.Unit*sign;
            var parallel=axis*MotionVector.Dot(axis,blade);var radial=blade-parallel;var tangent=MotionVector.Cross(axis,blade);
            double first=double.PositiveInfinity,negativeWidth=0,low=MinimumPitchRadians+marginRad,high=MaximumPitchRadians-marginRad;
            Exit(frame.Up*Math.Cos(low)-frame.Forward*Math.Sin(low),0,parallel,radial,tangent,ref first,ref negativeWidth);
            Exit(frame.Forward*Math.Sin(high)-frame.Up*Math.Cos(high),0,parallel,radial,tangent,ref first,ref negativeWidth);
            Exit(frame.Right,-Math.Sin(MinimumSideRadians+marginRad),parallel,radial,tangent,ref first,ref negativeWidth);
            Exit(-frame.Right,Math.Sin(MaximumSideRadians-marginRad),parallel,radial,tangent,ref first,ref negativeWidth);
            if(first>=length)return signedAngle;if(first<=Tolerance)return 0;
            // Probe/bisect the actual quaternion arc around its earliest exit.
            // The bracket stays inside that constraint's negative interval.
            double probe=Math.Min(.001,negativeWidth*.25),left=Math.Max(0,first-probe),right=Math.Min(length,first+probe);
            if(probe<=Tolerance || InsideAt(q,axis,right,frame,marginRad))return sign*Math.Max(0,first-Tolerance);
            for(int i=0;i<48;i++){double middle=(left+right)*.5;if(InsideAt(q,axis,middle,frame,marginRad))left=middle;else right=middle;}
            return sign*Math.Max(0,left-Tolerance*4);
        }
    }
}
