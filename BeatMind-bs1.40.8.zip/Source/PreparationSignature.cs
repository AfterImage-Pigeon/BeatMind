using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace SaberMind
{
    // The game represents map rotation as Int32. "R" is a floating-point
    // format and throws for integers. Typed overloads also avoid culture
    // dependent Unity Vector3.ToString values in persisted fingerprints.
    public sealed class PreparationSignature
    {
        private readonly StringBuilder text=new StringBuilder();
        public PreparationSignature Add(string value)
        {value=value??"";text.Append(value.Length.ToString(CultureInfo.InvariantCulture)).Append(':').Append(value);return this;}
        public PreparationSignature Add(int value){return Add(value.ToString(CultureInfo.InvariantCulture));}
        public PreparationSignature Add(float value){return Add(value.ToString("R",CultureInfo.InvariantCulture));}
        public PreparationSignature Add(double value){return Add(value.ToString("R",CultureInfo.InvariantCulture));}
        public PreparationSignature Add(bool value){return Add(value ? "1" : "0");}
        public string Digest()
        {using(var sha=SHA256.Create())return System.BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text.ToString()))).Replace("-","").ToLowerInvariant();}
    }
}
