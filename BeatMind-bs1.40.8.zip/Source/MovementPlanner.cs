using System;
using System.Collections.Generic;
using UnityEngine;
namespace SaberMind
{
    internal static class MovementPlanner
    {
        private static int budgetFrame=-1;
        private static double spentMilliseconds;
        internal static MotionVector V(Vector3 p){return new MotionVector(p.x,p.y,p.z);}
        internal static Vector3 V(MotionVector p){return new Vector3((float)p.X,(float)p.Y,(float)p.Z);}
        internal static MotionRotation Q(Quaternion q){return new MotionRotation(q.x,q.y,q.z,q.w);}
        internal static Quaternion Q(MotionRotation q){return new Quaternion((float)q.X,(float)q.Y,(float)q.Z,(float)q.W);}
        internal static bool NeedsPlan(Hand hand,float now,BodyRig rig=null,bool early=false)
        {
            if(hand.PendingPlan!=null)
            {
                if(rig!=null && rig.Motion!=null && hand.PendingRevision!=rig.Motion.Revision){hand.PendingPlan.Dispose();hand.PendingPlan=null;}
                else return false;
            }
            if(hand.Phrase==null || now>=hand.Phrase.RefreshTime-(early ? .35 : 0))return true;
            if(rig!=null && rig.Motion!=null && hand.MotionRevision!=rig.Motion.Revision)return true;
            if(hand.ContactGeometryChanged)return true;
            if(hand.Target!=null)
            {
                var c=hand.Phrase.Contact(hand.Target.MapIndex);
                if(c==null && hand.Target.Time>now+.01 && hand.Target.Time<hand.Phrase.RefreshTime)return true;
                if(c!=null && hand.Target.HasPose && ContactGeometry.Changed(c,hand.Target.HitTime,V(hand.Target.Center),V(hand.Target.Direction),now))return true;
            }
            // Cutting/removing a note isn't a new motion command. The existing
            // release and wrist transition continue along the published curve.
            return false;
        }
        internal static void Plan(Hand hand,BodyRig rig,int color,float now,IList<TrackedNote> future,ModelProfile profile,bool deferred=false)
        {
            long planStart=System.Diagnostics.Stopwatch.GetTimestamp();
            MotionPhrase previous=hand.Phrase;
            bool sourceChanged=rig.Motion!=null && hand.MotionRevision!=rig.Motion.Revision;
            PhraseState seed=previous==null ? new PhraseState{Grip=V(hand.GripPosition),Velocity=V(hand.GripVelocity),Acceleration=V(hand.GripAcceleration),Rotation=Q(hand.LastRotation),AngularVelocity=V(hand.AngularVelocity)*Math.PI/180,AngularAcceleration=V(hand.AngularAcceleration)*Math.PI/180} : previous.Sample(now);
            seed.Time=now;seed.Id=-1;
            var notes=new List<PhraseNote>();
            double previousChartTime=double.NaN;
            foreach(var n in future)
            {
                double hit=n.HitTime;if(hit<=now+.004 || !n.HasPose)continue;
                if(notes.Count>0 && CutSchedule.MergeContact(n.Time,previousChartTime,hit,notes[notes.Count-1].Time,n.Data.gameplayType==NoteData.GameplayType.BurstSliderElement))
                {var centers=new List<MotionVector>(notes[notes.Count-1].OtherCenters);centers.Add(V(n.Center));notes[notes.Count-1].OtherCenters=centers.ToArray();continue;}
                Vector3 direction=n.Direction;if(n.Data.cutDirection==NoteCutDirection.Any && rig.Motion!=null){var observed=rig.Motion.ObservedDotDirection(n.Time,color);if(observed.Length>.5)direction=Quaternion.LookRotation(n.Forward)*V(observed);}
                var note=new PhraseNote{Id=n.MapIndex,Time=hit,Center=V(n.Center),Direction=V(direction),Forward=V(n.Forward),Spacing=n.Spacing,LocalNps=n.LocalNps,Stroke=Policy.Variants[n.Variant].HalfDuration,Curve=n.Behavior.Curve,Anticipation=n.Behavior.Anticipation,Elbow=n.Behavior.Elbow,Lean=n.Behavior.Lean,HeadLead=n.Behavior.HeadLead,Shoulder=n.Behavior.Shoulder,Torso=n.Behavior.Torso,Wrist=n.Behavior.Wrist,Momentum=n.Behavior.Momentum,Recovery=n.Behavior.Recovery,Follow=n.Behavior.Follow,GripPreference=Mathf.Clamp(n.Behavior.Grip+n.Plan.z,-.10f,.10f)};
                var committed=previous==null || sourceChanged && hit>now+ContactGeometry.LockAhead ? null : previous.Contact(n.MapIndex);
                if(CutSafety.ShouldRefit(committed,note,now)){hand.ContactFitChanged=true;committed=null;}note.Committed=committed;notes.Add(note);previousChartTime=n.Time;
            }
            double carry=now;
            if(previous!=null)
            {
                double nextHit=notes.Count==0 ? double.PositiveInfinity : notes[0].Time;
                carry=SwingContinuation.ReleaseUntil(previous,now,hand.LastCutMapIndex,hand.LastCutSongTime,nextHit);
                if(carry>now)
                {seed=previous.Sample(carry);seed.Time=carry;seed.Id=-1;notes.RemoveAll(delegate(PhraseNote n){return n.Time<=carry+.004;});}
            }
            if(deferred && previous!=null)
            {
                double handoff=now+.25;
                if(hand.ContactGeometryChanged && hand.Target!=null)
                {double hit=hand.Target.HitTime;if(hit>now+ContactGeometry.LockAhead)handoff=Math.Min(handoff,hit-.07);}
                handoff=Math.Min(handoff,previous.Knots[previous.Knots.Count-1].Time-.005);
                handoff=Math.Max(carry,handoff);seed=previous.Sample(handoff);seed.Time=handoff;seed.Id=-1;carry=handoff;
                notes.RemoveAll(delegate(PhraseNote n){return n.Time<=handoff+.004;});
            }
            // A prepared, note-free replay interval needs no quarter-second
            // contact rebuilds. Live geometry still invalidates a plan early.
            double horizon=notes.Count==0 ? 3.4 : Math.Min(3.4,Math.Max(1.0,notes[notes.Count-1].Time-seed.Time+.20));
            // Freeze one shared head/left/right source for this published plan.
            // Loading an exact replay or probing an earlier timestamp later
            // cannot mutate the teacher behind an already moving saber.
            var captured=rig.CaptureHuman(seed.Time-.65,seed.Time+horizon+1.50);
            Func<double,PhraseState> teacher=delegate(double t){return captured(t,color+1);};
            var geometry=new PhraseGeometry{Bottom=V(hand.LocalBladeBottom),Top=V(hand.LocalBladeTop),Grip=V(hand.LocalGrip),Shoulder=V(rig.Shoulders[color].position),Reach=rig.Reach,MinimumReach=rig.MinimumReach,Forward=V(rig.Forward),Color=color,
                ScoredHumanSwings=true,StableFastGrip=true,SwingSpeedScale=1,ShoulderAt=delegate(double t){return V(rig.ShoulderAt(t,color,captured));},OtherHandAt=delegate(double t){return captured(t,2-color).Grip;}};
            // The complete map has already conditioned the shared head/hands
            // graph; each hand's contact solver may then inspect every upcoming
            // reachable event in this three-second planning window.
            hand.PendingPlan=ReplayMotor.BeginBuild(seed,notes,geometry,teacher,profile.PlanningSamples,horizon);
            hand.PendingDeferred=deferred && previous!=null;
            hand.PendingStart=now;hand.PendingHandoff=carry;hand.PendingRevision=rig.Motion==null ? 0 : rig.Motion.Revision;
            hand.PendingSetupMilliseconds=(System.Diagnostics.Stopwatch.GetTimestamp()-planStart)*1000.0/System.Diagnostics.Stopwatch.Frequency;
            hand.ContactGeometryChanged=false;
            if(!deferred || previous==null){while(!hand.PendingPlan.Advance(1000)){}Publish(hand,now);}
        }
        internal static void Advance(Hand hand,BodyRig rig,float now)
        {
            var job=hand.PendingPlan;if(job==null)return;
            if(rig.Motion!=null && hand.PendingRevision!=rig.Motion.Revision){job.Dispose();hand.PendingPlan=null;hand.ContactGeometryChanged=true;return;}
            if(budgetFrame!=Time.frameCount){budgetFrame=Time.frameCount;spentMilliseconds=0;}
            double available=Math.Min(.9,Math.Max(0,2-spentMilliseconds));
            if(!job.Done && available>0)
            {double before=job.TotalMilliseconds;job.Advance(available);spentMilliseconds+=job.TotalMilliseconds-before;}
            if(job.Done && now>=hand.PendingHandoff)Publish(hand,now);
        }
        private static void Publish(Hand hand,double now)
        {
            var job=hand.PendingPlan;var previous=hand.Phrase;var next=job.Result;
            if(previous!=null)
            {
                // A note can be cut while the new plan is queued. Ownership
                // must be checked again here, not only when planning began.
                double nextHit=SwingContinuation.NextContactTime(next,now,hand.LastCutMapIndex);
                double handoff=Math.Max(hand.PendingHandoff,SwingContinuation.ReleaseUntil(previous,now,hand.LastCutMapIndex,hand.LastCutSongTime,nextHit));
                bool late=now>hand.PendingHandoff+.008,extended=handoff>hand.PendingHandoff+.000001;
                double joinStart=(late || extended) ? Math.Max(now,handoff) : handoff;
                if(joinStart>hand.PendingStart)next.CarryFrom(previous,hand.PendingStart,joinStart);
                if(late || extended)
                {
                    double end=Math.Min(joinStart+.045,SwingContinuation.NextContactTime(next,joinStart,hand.LastCutMapIndex));
                    if(end>joinStart+.000001)
                    {
                        var original=next.Evaluator;var join=new MotionTransition(previous.Sample(joinStart),next.Sample(end));
                        next.Evaluator=delegate(double t){return t<end ? join.Sample(t) : original(t);};
                    }
                }
            }
            hand.Phrase=next;hand.MotionRevision=hand.PendingRevision;
            hand.ImitationCandidates+=next.CandidateEvaluations;hand.CandidateEvaluations+=next.CandidateEvaluations;hand.PhraseId++;hand.Replans++;hand.RouteChanged=true;
            double milliseconds=job.TotalMilliseconds+hand.PendingSetupMilliseconds;
            hand.PlanMilliseconds+=milliseconds;hand.PeakPlanMilliseconds=Math.Max(hand.PeakPlanMilliseconds,milliseconds);
            if(hand.PendingDeferred)hand.PeakPlanSliceMilliseconds=Math.Max(hand.PeakPlanSliceMilliseconds,job.PeakSliceMilliseconds);
            hand.PendingPlan=null;job.Dispose();
        }
        internal static void Sample(Hand hand,float now,out Vector3 root,out Quaternion rotation)
        {hand.Desired=hand.Phrase.Sample(now);rotation=Q(hand.Desired.Rotation);root=V(hand.Desired.Grip)-rotation*hand.LocalGrip;}
    }
}
