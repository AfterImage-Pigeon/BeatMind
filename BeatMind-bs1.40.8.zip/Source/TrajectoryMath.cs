using System;
using System.Collections.Generic;

namespace SaberMind
{
    // Pure mathematics: the same planner is exercised offline and in Unity.
    public struct MotionVector
    {
        public double X,Y,Z;
        public MotionVector(double x,double y,double z) { X=x;Y=y;Z=z; }
        public double Length { get { return Math.Sqrt(Dot(this,this)); } }
        public MotionVector Unit { get { double n=Length; return n<1e-9 ? new MotionVector() : this/n; } }
        public static MotionVector operator +(MotionVector a,MotionVector b) { return new MotionVector(a.X+b.X,a.Y+b.Y,a.Z+b.Z); }
        public static MotionVector operator -(MotionVector a,MotionVector b) { return new MotionVector(a.X-b.X,a.Y-b.Y,a.Z-b.Z); }
        public static MotionVector operator -(MotionVector a) { return a*-1; }
        public static MotionVector operator *(MotionVector a,double b) { return new MotionVector(a.X*b,a.Y*b,a.Z*b); }
        public static MotionVector operator /(MotionVector a,double b) { return a*(1/b); }
        public static double Dot(MotionVector a,MotionVector b) { return a.X*b.X+a.Y*b.Y+a.Z*b.Z; }
        public static MotionVector Cross(MotionVector a,MotionVector b) { return new MotionVector(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X); }
        public MotionVector Limited(double n) { return Length>n ? Unit*n : this; }
    }
    public struct MotionRotation
    {
        public double X,Y,Z,W;
        public MotionRotation(double x,double y,double z,double w) { X=x;Y=y;Z=z;W=w; }
        public static MotionRotation Identity { get { return new MotionRotation(0,0,0,1); } }
        public double Length { get { return Math.Sqrt(Dot(this,this)); } }
        public MotionRotation Unit { get { double n=Length; return n<1e-9 ? Identity : this*(1/n); } }
        public MotionRotation Inverse { get { return new MotionRotation(-X,-Y,-Z,W); } }
        public MotionVector Vector { get { return new MotionVector(X,Y,Z); } }
        public static MotionRotation operator +(MotionRotation a,MotionRotation b) { return new MotionRotation(a.X+b.X,a.Y+b.Y,a.Z+b.Z,a.W+b.W); }
        public static MotionRotation operator -(MotionRotation a,MotionRotation b) { return a+b*-1; }
        public static MotionRotation operator *(MotionRotation a,double b) { return new MotionRotation(a.X*b,a.Y*b,a.Z*b,a.W*b); }
        public static MotionRotation operator *(MotionRotation a,MotionRotation b)
        { return new MotionRotation(a.W*b.X+a.X*b.W+a.Y*b.Z-a.Z*b.Y,a.W*b.Y-a.X*b.Z+a.Y*b.W+a.Z*b.X,a.W*b.Z+a.X*b.Y-a.Y*b.X+a.Z*b.W,a.W*b.W-a.X*b.X-a.Y*b.Y-a.Z*b.Z); }
        public static double Dot(MotionRotation a,MotionRotation b) { return a.X*b.X+a.Y*b.Y+a.Z*b.Z+a.W*b.W; }
        public MotionVector Rotate(MotionVector p) { return (this*new MotionRotation(p.X,p.Y,p.Z,0)*Inverse).Vector; }
        public static MotionRotation Exp(MotionVector radians)
        { double a=radians.Length; MotionVector v=radians*(a<1e-9 ? .5 : Math.Sin(a/2)/a); return new MotionRotation(v.X,v.Y,v.Z,Math.Cos(a/2)); }
        public static MotionVector Log(MotionRotation q)
        { q=q.Unit; if(q.W<0) q=q*-1; double n=q.Vector.Length; return n<1e-9 ? q.Vector*2 : q.Vector*(2*Math.Atan2(n,q.W)/n); }
        public static MotionRotation FromTo(MotionVector from,MotionVector to,MotionVector priorAxis)
        {
            from=from.Unit;to=to.Unit; double d=MotionVector.Dot(from,to);
            if(d<-.9999) { MotionVector axis=priorAxis-from*MotionVector.Dot(priorAxis,from); if(axis.Length<.001) axis=MotionVector.Cross(from,new MotionVector(1,.3,.1)); return Exp(axis.Unit*Math.PI); }
            MotionVector c=MotionVector.Cross(from,to);return new MotionRotation(c.X,c.Y,c.Z,1+d).Unit;
        }
    }
    public sealed class PhraseState
    {
        public double Time;
        public int Id=-1;public bool LimitedContact,MinimumReachAdjusted;
        public int HumanSource=-1,RepairStage;
        public double HumanGripWeight,HumanWristWeight;
        // An idle-source stroke owns one clock across replans. A late seed
        // continues this window instead of inserting a fresh zero-speed prep.
        public double SwingStart=double.NaN,SwingPeak=double.NaN,SwingEnd=double.NaN;
        public double ScoringReleaseEnd=double.NaN;
        public double ScoringPrepStart=double.NaN;
        // Contact speed ownership survives replans: a published wrist jet must
        // not receive the playback speed multiplier a second time.
        public double WristSpeedScale=1;
        public bool SteadyWristMotion;
        public ContactWristSource WristSource;
        public ContinuousWristBurst WristBurst;
        public ReplayWristRoll WristRoll;
        public ContactWristLink IncomingWrist,OutgoingWrist;
        public MotionVector Grip,Velocity,Acceleration,AngularVelocity,AngularAcceleration,TargetCenter,TargetDirection;
        public MotionRotation Rotation=MotionRotation.Identity;
        public PhraseState Copy() { return (PhraseState)MemberwiseClone(); }
    }
    // An immutable contact-to-contact wrist path. Both notes share the same
    // curve, so a replan inside a dense stream cannot restart preparation or
    // turn a completed stroke into a different independent recovery arc.
    public sealed class ContactWristLink
    {
        public readonly int FromId,ToId;
        public readonly double Start,End;
        private readonly MotionVector[] angle,velocity,acceleration;
        private readonly PhraseState from,to;
        private readonly MotionTransition recovery;
        public bool IsRecovery{get{return recovery!=null;}}
        public ContactWristLink(PhraseState a,PhraseState b) : this(a,b,null){}
        public ContactWristLink(PhraseState a,PhraseState b,MotionVector? recoveryPath)
        {
            from=a.Copy();to=b.Copy();from.IncomingWrist=from.OutgoingWrist=to.IncomingWrist=to.OutgoingWrist=null;FromId=a.Id;ToId=b.Id;Start=a.Time;End=b.Time;
            if(recoveryPath.HasValue){recovery=new MotionTransition(a,b,true,.015,recoveryPath);return;}
            double dt=End-Start;var end=MotionRotation.Log(b.Rotation*a.Rotation.Inverse);
            var ev=PhraseCurve.InverseJacobian(end,b.AngularVelocity);
            var ea=PhraseCurve.InverseJacobian(end,b.AngularAcceleration-PhraseCurve.JacobianDerivative(end,ev,ev));
            var controls=new MotionVector[10];controls[0]=new MotionVector();controls[1]=a.AngularVelocity*(dt/9);controls[2]=controls[1]*2+a.AngularAcceleration*(dt*dt/72);
            controls[9]=end;controls[8]=end-ev*(dt/9);controls[7]=controls[8]*2-end+ea*(dt*dt/72);
            // A degree-five endpoint fit extrapolated the contact jets across
            // the whole beat and overswung behind the player. Shorter C2
            // endpoint support retains the exact peak speed while the middle
            // follows the actual required travel between contact frames.
            for(int i=3;i<=6;i++)controls[i]=controls[2]+(controls[7]-controls[2])*((i-2)/5.0);
            angle=new MotionVector[10];for(int k=0;k<=9;k++)for(int i=0;i<=k;i++)angle[k]+=controls[i]*(Choose(9,k)*Choose(k,i)*((k-i)%2==0 ? 1 : -1));
            velocity=new MotionVector[9];acceleration=new MotionVector[8];
            for(int i=0;i<9;i++)velocity[i]=angle[i+1]*((i+1)/dt);
            for(int i=0;i<8;i++)acceleration[i]=velocity[i+1]*((i+1)/dt);
        }
        private static double Choose(int n,int k){double v=1;for(int i=1;i<=k;i++)v=v*(n-i+1)/i;return v;}
        private static MotionVector Evaluate(MotionVector[] c,double u){var r=c[c.Length-1];for(int i=c.Length-2;i>=0;i--)r=r*u+c[i];return r;}
        public void Inspect(double t,out MotionRotation rotation,out MotionVector angularVelocity)
        {
            if(recovery!=null){var s=recovery.SampleWrist(t);rotation=s.Rotation;angularVelocity=s.AngularVelocity;return;}
            double u=MotionPhrase.Clamp((t-Start)/(End-Start),0,1);var r=Evaluate(angle,u);var v=Evaluate(velocity,u);
            rotation=(MotionRotation.Exp(r)*from.Rotation).Unit;angularVelocity=PhraseCurve.Jacobian(r,v);
        }
        public PhraseState Sample(double t)
        {
            if(recovery!=null)return recovery.SampleWrist(t);
            double u=MotionPhrase.Clamp((t-Start)/(End-Start),0,1);var r=Evaluate(angle,u);var v=Evaluate(velocity,u);var ac=Evaluate(acceleration,u);
            return new PhraseState{Time=t,Rotation=(MotionRotation.Exp(r)*from.Rotation).Unit,AngularVelocity=PhraseCurve.Jacobian(r,v),AngularAcceleration=PhraseCurve.Jacobian(r,ac)+PhraseCurve.JacobianDerivative(r,v,v),WristSpeedScale=Math.Max(from.WristSpeedScale,to.WristSpeedScale)};
        }
        public bool Matches(PhraseState a,bool ending)
        {var b=ending ? to : from;return a.Id==b.Id && Math.Abs(a.Time-b.Time)<1e-8 && MotionRotation.Log(a.Rotation*b.Rotation.Inverse).Length<1e-8 && (a.AngularVelocity-b.AngularVelocity).Length<1e-7 && (a.AngularAcceleration-b.AngularAcceleration).Length<1e-6;}
    }
    // Only scored contacts retain their pre-speed jets. Sharing immutable
    // metadata keeps ordinary replay samples small and makes queued future
    // contacts independent of how often the live planner refreshes.
    public sealed class ContactWristSource
    {
        public readonly MotionVector Velocity,Acceleration;
        public readonly double Start,Peak,End,Preparation;
        public readonly bool Steady;
        public ContactWristSource(PhraseState s){Velocity=s.AngularVelocity;Acceleration=s.AngularAcceleration;Start=s.SwingStart;Peak=s.SwingPeak;End=s.SwingEnd;Preparation=s.ScoringPrepStart;Steady=s.SteadyWristMotion;}
        public void Restore(PhraseState s){s.AngularVelocity=Velocity;s.AngularAcceleration=Acceleration;s.SwingStart=Start;s.SwingPeak=Peak;s.SwingEnd=End;s.WristSpeedScale=1;s.SteadyWristMotion=Steady;}
    }
    public sealed class PhraseNote
    {
        public int Id,ScoringType=1;
        public bool AnyDirection;
        public bool HasPivotHint;
        public MotionVector PivotHint;
        public double Time,Spacing=.5,LocalNps,Stroke=.065,GripPreference,Follow=1,Momentum=1,Wrist=1,Curve=1,Recovery=1;
        public MotionVector Center,Direction,Forward;
        public double Anticipation=1,Elbow,Lean=1,HeadLead=1,Shoulder,Torso=1,WristTwist;
        public MotionVector[] OtherCenters=new MotionVector[0];
        public PhraseState Committed;
        public PhraseNote Next;
        public PhraseState NextPose;
    }
    public sealed class PhraseGeometry
    {
        public MotionVector Bottom,Top,Grip,Shoulder,Forward;
        public double Reach=.65;
        public double MinimumReach;
        public bool StableFastGrip;
        public bool ControlledWrist;
        public bool ScoredHumanSwings;
        public double SwingSpeedScale=1;
        public double PlanningStart;
        public Func<double,MotionVector> ShoulderAt,OtherHandAt;
        // Read only while planning a handoff. It is released before publication.
        public Func<double,PhraseState> PreviousWristAt;
        public int Color;
    }
    public sealed class MotionPhrase
    {
        public readonly List<PhraseState> Knots=new List<PhraseState>();
        public double RefreshTime,Cost;
        public int CandidateEvaluations,StabilityFallbacks;
        public Func<double,PhraseState> Evaluator;
        // Rotation-only evaluation shares the published angular curve while
        // avoiding an unused grip/reach evaluation during wrist retiming.
        // Its returned pose is owned by the caller; grip fields are unused.
        public Func<double,PhraseState> WristEvaluator;
        public PhraseGeometry WristGeometry;
        // Frozen diagnostic stages for this plan, before and after reach fitting.
        // They do not participate in playback or choose a movement target.
        public Func<double,PhraseState> RawTeacher,AdaptedTeacher;
        private int cursor;
        private readonly List<PhraseCurve> curves=new List<PhraseCurve>();
        private readonly List<PhraseCurve> prefix=new List<PhraseCurve>();
        private readonly List<PhraseState> carriedContacts=new List<PhraseState>();
        private sealed class CarriedRange
        {
            internal double Start,End;
            internal Func<double,PhraseState> Pose,Wrist,Raw,Adapted;
        }
        private readonly List<CarriedRange> carriedRanges=new List<CarriedRange>();
        // Retain the actual old curve through an already-cut note's follow-through.
        // Copy segment references, not whole plans, so repeated replans cannot
        // retain an unbounded chain of historical routes.
        public void CarryFrom(MotionPhrase previous,double start,double until)
        {
            // A new plan can be queued while the previous plan is still
            // playing its carried prefix. Copy that active prefix as clipped
            // ranges, not just previous.Evaluator (which starts at its seed).
            // Flatten delegates so no historical MotionPhrase chain is kept.
            carriedRanges.Clear();double edge=start;
            foreach(var range in previous.carriedRanges)
            {
                double a=Math.Max(start,range.Start),b=Math.Min(until,range.End);if(b<=a)continue;
                if(previous.Evaluator!=null && a>edge)carriedRanges.Add(new CarriedRange{Start=edge,End=a,Pose=previous.Evaluator,Wrist=previous.WristEvaluator ?? previous.Evaluator,Raw=previous.RawTeacher,Adapted=previous.AdaptedTeacher});
                carriedRanges.Add(new CarriedRange{Start=a,End=b,Pose=range.Pose,Wrist=range.Wrist,Raw=range.Raw,Adapted=range.Adapted});edge=b;
            }
            if(previous.Evaluator!=null && until>edge)carriedRanges.Add(new CarriedRange{Start=edge,End=until,Pose=previous.Evaluator,Wrist=previous.WristEvaluator ?? previous.Evaluator,Raw=previous.RawTeacher,Adapted=previous.AdaptedTeacher});
            previous.EnsureCurves();
            foreach(PhraseCurve curve in previous.prefix)
                if(curve.End>start && curve.Start<until) prefix.Add(curve);
            foreach(PhraseCurve curve in previous.curves)
                if(curve.End>start && curve.Start<until) prefix.Add(curve);
            foreach(PhraseState contact in previous.Knots)
                if(contact.Id>=0 && contact.Time>=start-.2 && contact.Time<=until) carriedContacts.Add(contact.Copy());
            foreach(PhraseState contact in previous.carriedContacts)
                if(contact.Time>=start-.2 && contact.Time<=until && Contact(contact.Id)==null) carriedContacts.Add(contact.Copy());
        }
        private void EnsureCurves()
        { while(curves.Count<Knots.Count-1) curves.Add(new PhraseCurve(Knots[curves.Count],Knots[curves.Count+1])); }
        public PhraseState Contact(int id)
        { foreach(PhraseState s in Knots) if(s.Id==id) return s;foreach(PhraseState s in carriedContacts) if(s.Id==id) return s; return null; }
        public PhraseState TeacherAt(double time,bool adapted)
        {
            Func<double,PhraseState> sample=adapted ? AdaptedTeacher : RawTeacher;
            foreach(var range in carriedRanges)if(time>=range.Start && time<range.End){var carried=adapted ? range.Adapted : range.Raw;if(carried!=null)sample=carried;break;}
            return sample==null ? null : sample(time);
        }
        public PhraseState Sample(double now)
        {
            if(Knots.Count==0) return new PhraseState {Time=now};
            foreach(var range in carriedRanges)if(now>=range.Start && now<range.End)return range.Pose(now);
            if(now<Knots[0].Time)
                foreach(PhraseCurve curve in prefix) if(now>=curve.Start && now<=curve.End) return curve.Sample(now);
            if(Evaluator!=null)return Evaluator(now);
            if(now<=Knots[0].Time) return Knots[0].Copy();
            if(now<Knots[cursor].Time) cursor=0;
            while(cursor+1<Knots.Count-1 && now>Knots[cursor+1].Time) cursor++;
            if(now>=Knots[Knots.Count-1].Time) return Knots[Knots.Count-1].Copy();
            EnsureCurves();
            return curves[cursor].Sample(now);
        }
        public PhraseState SampleWrist(double now)
        {
            if(Knots.Count==0)return new PhraseState{Time=now};
            foreach(var range in carriedRanges)if(now>=range.Start && now<range.End)return range.Wrist(now);
            if(now<Knots[0].Time)
                foreach(PhraseCurve curve in prefix)if(now>=curve.Start && now<=curve.End)return curve.Sample(now,true);
            if(WristEvaluator!=null)return WristEvaluator(now);
            if(Evaluator!=null)return Evaluator(now);
            if(now<=Knots[0].Time)return Knots[0].Copy();
            if(now<Knots[cursor].Time)cursor=0;
            while(cursor+1<Knots.Count-1 && now>Knots[cursor+1].Time)cursor++;
            if(now>=Knots[Knots.Count-1].Time)return Knots[Knots.Count-1].Copy();
            EnsureCurves();return curves[cursor].Sample(now,true);
        }
        // Quintic position and normalized quaternion curves share exact first
        // and second derivatives at contacts. No finite-difference pose probes.
        public static PhraseState Segment(PhraseState a,PhraseState b,double now)
        {return new PhraseCurve(a,b).Sample(now);}
        public static double Clamp(double x,double min,double max) { return Math.Max(min,Math.Min(max,x)); }
    }
    // Quintic position and Lie-group rotation, with analytic SO(3) jets.
    // Component-wise quaternion polynomials could approach zero norm and
    // amplify a gentle wrist transition into an abrupt multi-turn whip.
    internal struct PhraseCurve
    {
        private readonly double start,duration;
        internal double Start {get{return start;}}
        internal double End {get{return start+duration;}}
        // These six tiny polynomials used to allocate eighteen arrays per
        // curve (controls, derivatives and power conversion). Keep exactly
        // the same arithmetic in value storage: replay probes create many
        // curves, but must not fill the managed heap while a song is playing.
        private struct Polynomial
        {
            internal int Count;
            private MotionVector a,b,c,d,e,f;
            internal MotionVector this[int i]
            {
                get {switch(i){case 0:return a;case 1:return b;case 2:return c;case 3:return d;case 4:return e;case 5:return f;default:throw new ArgumentOutOfRangeException();}}
                set {switch(i){case 0:a=value;break;case 1:b=value;break;case 2:c=value;break;case 3:d=value;break;case 4:e=value;break;case 5:f=value;break;default:throw new ArgumentOutOfRangeException();}}
            }
        }
        private readonly Polynomial p,v,acc,r,rd,rdd;
        private readonly MotionRotation initial;
        private readonly double humanGrip,humanWrist;
        private readonly double wristScale;
        private readonly int source;
        internal PhraseCurve(PhraseState a,PhraseState b) : this(a,b,null){}
        internal PhraseCurve(PhraseState a,PhraseState b,MotionVector? rotationPath)
        {
            humanGrip=Math.Min(a.HumanGripWeight,b.HumanGripWeight);humanWrist=Math.Min(a.HumanWristWeight,b.HumanWristWeight);source=b.HumanSource;
            wristScale=Math.Max(a.WristSpeedScale,b.WristSpeedScale);
            start=a.Time;duration=Math.Max(1e-8,b.Time-a.Time);initial=a.Rotation.Unit;
            p=Controls(a.Grip,a.Velocity,a.Acceleration,b.Grip,b.Velocity,b.Acceleration,duration);
            v=Derivative(p,duration);acc=Derivative(v,duration);p=Power(p);v=Power(v);acc=Power(acc);
            MotionVector end=rotationPath.HasValue ? rotationPath.Value : MotionRotation.Log(b.Rotation*initial.Inverse);
            MotionVector endVelocity=InverseJacobian(end,b.AngularVelocity);
            MotionVector endAcceleration=InverseJacobian(end,b.AngularAcceleration-JacobianDerivative(end,endVelocity,endVelocity));
            r=Controls(new MotionVector(),a.AngularVelocity,a.AngularAcceleration,end,endVelocity,endAcceleration,duration);
            rd=Derivative(r,duration);rdd=Derivative(rd,duration);r=Power(r);rd=Power(rd);rdd=Power(rdd);
        }
        internal PhraseState Sample(double now)
        {return Sample(now,false);}
        internal MotionVector RotationVector(double now)
        {return Blend(r,MotionPhrase.Clamp((now-start)/duration,0,1));}
        internal PhraseState SampleGrip(double now)
        {
            double t=MotionPhrase.Clamp((now-start)/duration,0,1);
            return new PhraseState{Time=now,Grip=Blend(p,t),Velocity=Blend(v,t),Acceleration=Blend(acc,t),
                HumanGripWeight=humanGrip,HumanWristWeight=humanWrist,HumanSource=source,WristSpeedScale=wristScale};
        }
        internal PhraseState Sample(double now,bool wristOnly)
        {
            double t=MotionPhrase.Clamp((now-start)/duration,0,1);
            MotionVector angle=Blend(r,t),velocity=Blend(rd,t),acceleration=Blend(rdd,t);
            return new PhraseState{Time=now,Grip=wristOnly ? new MotionVector() : Blend(p,t),Velocity=wristOnly ? new MotionVector() : Blend(v,t),Acceleration=wristOnly ? new MotionVector() : Blend(acc,t),Rotation=(MotionRotation.Exp(angle)*initial).Unit,
                AngularVelocity=Jacobian(angle,velocity),AngularAcceleration=Jacobian(angle,acceleration)+JacobianDerivative(angle,velocity,velocity),
                HumanGripWeight=humanGrip,HumanWristWeight=humanWrist,HumanSource=source,WristSpeedScale=wristScale};
        }
        internal static MotionVector Jacobian(MotionVector r,MotionVector v)
        {
            double t=r.Length,a,b;
            if(t<.001){double s=t*t;a=.5-s/24+s*s/720;b=1.0/6-s/120+s*s/5040;}
            else{a=(1-Math.Cos(t))/(t*t);b=(t-Math.Sin(t))/(t*t*t);}
            return v+MotionVector.Cross(r,v)*a+MotionVector.Cross(r,MotionVector.Cross(r,v))*b;
        }
        internal static MotionVector InverseJacobian(MotionVector r,MotionVector v)
        {
            double t=r.Length,c=t<.001 ? 1.0/12+t*t/720 : (1-.5*t/Math.Tan(t*.5))/(t*t);
            return v-MotionVector.Cross(r,v)*.5+MotionVector.Cross(r,MotionVector.Cross(r,v))*c;
        }
        internal static MotionVector JacobianDerivative(MotionVector r,MotionVector rate,MotionVector v)
        {
            double t=r.Length,a,b,da,db,dot=MotionVector.Dot(r,rate);
            if(t<.001){double s=t*t;a=.5-s/24+s*s/720;b=1.0/6-s/120+s*s/5040;da=dot*(-1.0/12+s/180);db=dot*(-1.0/60+s/1260);}
            else{double t2=t*t;a=(1-Math.Cos(t))/t2;b=(t-Math.Sin(t))/(t2*t);da=dot*(t*Math.Sin(t)-2*(1-Math.Cos(t)))/(t2*t2);db=dot*(t*(1-Math.Cos(t))-3*(t-Math.Sin(t)))/(t2*t2*t);}
            MotionVector cross=MotionVector.Cross(r,v);
            return cross*da+MotionVector.Cross(rate,v)*a+MotionVector.Cross(r,cross)*db+
                (MotionVector.Cross(rate,cross)+MotionVector.Cross(r,MotionVector.Cross(rate,v)))*b;
        }
        private static Polynomial Controls(MotionVector a,MotionVector av,MotionVector aa,MotionVector b,MotionVector bv,MotionVector ba,double d)
        {var result=new Polynomial{Count=6};result[0]=a;result[1]=a+av*(d/5);result[2]=a+av*(2*d/5)+aa*(d*d/20);result[3]=b-bv*(2*d/5)+ba*(d*d/20);result[4]=b-bv*(d/5);result[5]=b;return result;}
        private static Polynomial Derivative(Polynomial a,double d)
        {int n=a.Count-1;var v=new Polynomial{Count=n};for(int i=0;i<n;i++)v[i]=(a[i+1]-a[i])*(n/d);return v;}
        private static readonly int[][] Binomial={new[]{1},new[]{1,1},new[]{1,2,1},new[]{1,3,3,1},new[]{1,4,6,4,1},new[]{1,5,10,10,5,1}};
        private static Polynomial Power(Polynomial a)
        {int n=a.Count-1;var result=new Polynomial{Count=a.Count};for(int i=0;i<=n;i++)for(int j=0;j<=i;j++)result[i]+=a[j]*(Binomial[n][i]*Binomial[i][j]*((i-j)%2==0 ? 1 : -1));return result;}
        private static MotionVector Blend(Polynomial a,double t)
        {MotionVector value=a[a.Count-1];for(int i=a.Count-2;i>=0;i--)value=value*t+a[i];return value;}
    }
    // Preserve outgoing and incoming jets on short edges. Tracker-scale
    // acceleration must not be extrapolated over the entire phrase handoff.
    public sealed class MotionTransition
    {
        private readonly PhraseCurve first,middle,last;private readonly double splitA,splitB;
        public MotionTransition(PhraseState a,PhraseState b) : this(a,b,false,.015){}
        public MotionTransition(PhraseState a,PhraseState b,bool wristHandoff,double strokeEdge) : this(a,b,wristHandoff,strokeEdge,null){}
        public MotionTransition(PhraseState a,PhraseState b,bool wristHandoff,double strokeEdge,MotionVector? rotationPath)
        {
            // A fast tracker sample is local motion, not permission to carry
            // that speed through a long, nearly stationary handoff. Bound the
            // middle of the join by its actual travel; retain the exact source
            // jets only on the short C2 edges. Dense swings still retain their
            // speed because their angular travel / interval is correspondingly
            // large. This removes spurious loops without retiming the cuts.
            double duration=Math.Max(.001,b.Time-a.Time);
            double linear=Math.Min(12,Math.Max(.35,(b.Grip-a.Grip).Length*3/duration));
            double angular=Math.Min(80,Math.Max(1.5,MotionRotation.Log(b.Rotation*a.Rotation.Inverse).Length*3/duration));
            var ac=a.Copy();var bc=b.Copy();ac.Velocity=ac.Velocity.Limited(linear);bc.Velocity=bc.Velocity.Limited(linear);ac.Acceleration=ac.Acceleration.Limited(Math.Min(100,linear*6/duration));bc.Acceleration=bc.Acceleration.Limited(Math.Min(100,linear*6/duration));
            if(wristHandoff)
            {
            // Endpoint tracker jets belong to the short C2 edges below. Carrying
            // their transverse/opposing angular velocity through the macro
            // polynomial made an almost stationary handoff orbit a whole turn.
            // The macro follows the shortest physical orientation change with
            // monotone scalar progress; both exact endpoint jets are retained.
            MotionVector turn=rotationPath.HasValue ? rotationPath.Value : MotionRotation.Log(b.Rotation*a.Rotation.Inverse),axis=turn.Unit;
            double rate=turn.Length/duration;
            ac.AngularVelocity=axis*MotionPhrase.Clamp(MotionVector.Dot(a.AngularVelocity,axis),0,rate);
            bc.AngularVelocity=axis*MotionPhrase.Clamp(MotionVector.Dot(b.AngularVelocity,axis),0,rate);
            ac.AngularAcceleration=bc.AngularAcceleration=new MotionVector();
            }
            else
            {ac.AngularVelocity=ac.AngularVelocity.Limited(angular);bc.AngularVelocity=bc.AngularVelocity.Limited(angular);ac.AngularAcceleration=ac.AngularAcceleration.Limited(Math.Min(700,angular*6/duration));bc.AngularAcceleration=bc.AngularAcceleration.Limited(Math.Min(700,angular*6/duration));}
            var macro=new PhraseCurve(ac,bc,rotationPath);double edge=Math.Min(strokeEdge,(b.Time-a.Time)*(wristHandoff ? .40 : .20));splitA=a.Time+edge;splitB=b.Time-edge;
            var left=macro.Sample(splitA);var right=macro.Sample(splitB);first=new PhraseCurve(a,left);
            // The recovery macro is a scalar rotation about one fixed axis.
            // Preserve its chosen branch through the middle subdivision;
            // taking another principal quaternion log would restore the loop.
            middle=new PhraseCurve(left,right,rotationPath.HasValue && wristHandoff ? (MotionVector?)(macro.RotationVector(splitB)-macro.RotationVector(splitA)) : null);last=new PhraseCurve(right,b);
        }
        public PhraseState Sample(double time){return time<splitA ? first.Sample(time) : time>splitB ? last.Sample(time) : middle.Sample(time);}
        internal PhraseState SampleGrip(double time){return time<splitA ? first.SampleGrip(time) : time>splitB ? last.SampleGrip(time) : middle.SampleGrip(time);}
        internal PhraseState SampleWrist(double time){return time<splitA ? first.Sample(time,true) : time>splitB ? last.Sample(time,true) : middle.Sample(time,true);}
    }

}
