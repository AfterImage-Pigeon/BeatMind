using System;

namespace SaberMind
{
    // A break is a chart interval, independent of whether walls are present.
    // Leave both ends of the interval free for cut follow-through and approach.
    public static class BreakTiming
    {
        public static double Strength(double now, double previous, double next)
        {
            if (next - previous < 1.35) return 0;
            double since = now - previous, until = next - now;
            if (since <= .28 || until <= .72) return 0;
            return Math.Min(1, Math.Min((since - .28) / .35, (until - .72) / .35));
        }
    }
}
