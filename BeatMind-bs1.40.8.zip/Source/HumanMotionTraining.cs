using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
namespace SaberMind
{
    internal sealed class HumanMotionFile
    {
        public int Format=HumanMotionModel.Version,Cuts;
        public string Key,Rejection,ReplayIdentity;
        public HumanRecording Recording;
        public int[] PhaseCounts=new int[5];
        public List<HumanMotionExample> Examples=new List<HumanMotionExample>();
    }
    public static class HumanMotionTraining
    {
        private struct FitAssignment
        {internal int Bank,Sequence,Count;internal HumanPhase Phase;internal string Recording;internal double Start;}
        internal sealed class CachedSource
        {internal string Path,Identity,Key;internal bool Held;internal int[] Order,Phases,Sequences;internal List<int> Selected;}
        public const double MinimumReplayAccuracy=.93;
        public const int MaximumLearningPoseSamples=250000;
        internal const int LearningBudgetVersion=2;
        private const string Revision="continuous-human-sequences-jets-93-v5";
        public static HumanMotionModel Load(string directory,string cache,Action<string> progress,Action<string> warning)
        {return LoadFiles(Directory.Exists(directory) ? Directory.GetFiles(directory,"*.bsor") : new string[0],cache,progress,warning);}
        public static HumanMotionModel LoadFiles(string[] sourcePaths,string cache,Action<string> progress,Action<string> warning)
        {return LoadFiles(sourcePaths,cache,progress,warning,null);}
        public static HumanMotionModel LoadFiles(string[] sourcePaths,string cache,Action<string> progress,Action<string> warning,Action waitForIdle)
        {return LoadFiles(sourcePaths,cache,progress,warning,waitForIdle,null);}
        public static HumanMotionModel LoadFiles(string[] sourcePaths,string cache,Action<string> progress,Action<string> warning,Action waitForIdle,Action<HumanMotionModel> cachedReady)
        {
            Directory.CreateDirectory(cache);string[] paths=(string[])sourcePaths.Clone();Array.Sort(paths,StringComparer.OrdinalIgnoreCase);
            var keys=new List<string>();foreach(string p in paths){long size,ticks;ReplayFileAccess.Metadata(p,out size,out ticks);keys.Add(Digest(Path.GetFileName(p)+"|"+size+"|"+ticks+"|"+Revision));}
            var ordered=new List<string>(keys);ordered.Sort(StringComparer.Ordinal);string fingerprint=Digest(string.Join(";",ordered.ToArray())+"|whole-sequence-pose-budget-"+MaximumLearningPoseSamples+"-v"+LearningBudgetVersion);
            string modelPath=Path.Combine(cache,"HumanMotionModel.json.gz");HumanMotionModel previous=null;
            foreach(string p in new[]{modelPath,modelPath+".bak"})if(File.Exists(p))try
            {var m=Read<HumanMotionModel>(p,waitForIdle);if(m!=null && m.Valid()){previous=m;RefreshPaths(m,paths);if(cachedReady!=null)cachedReady(m);if(m.Fingerprint==fingerprint){m.CachedFiles=paths.Length;if(progress!=null)progress("Ready: whole-body replay motion (cached).");return m;}}}catch(Exception e){if(warning!=null)warning("Motion cache: "+e.Message);}
            var files=new List<CachedSource>();var seen=new HashSet<string>();var result=new HumanMotionModel{Fingerprint=fingerprint,Examined=paths.Length,OptimizerVersion=4};
            for(int i=0;i<paths.Length;i++)
            {
                if(waitForIdle!=null)waitForIdle();
                string item=Path.Combine(cache,keys[i]+".json.gz");HumanMotionFile f=null;
                try
                {
                    if(File.Exists(item))try{f=Read<HumanMotionFile>(item,waitForIdle);if(f.Key!=keys[i] || f.Format!=HumanMotionModel.Version || !ValidFile(f))f=null;else result.CachedFiles++;}catch{f=null;}
                    if(f==null)
                    {
                        f=new HumanMotionFile{Key=keys[i]};
                        try
                        {
                            var replay=HumanReplayLibrary.Read(paths[i],waitForIdle);RequireEligible(replay,paths[i]);
                            f.ReplayIdentity=Digest(replay.PlayerId+"|"+replay.Timestamp+"|"+replay.Hash+"|"+replay.Difficulty+"|"+replay.Mode+"|"+replay.Score);
                            f.Recording=new HumanRecording{Path=paths[i],Identity=f.ReplayIdentity,Hash=replay.Hash,Difficulty=replay.Difficulty,Mode=replay.Mode,Accuracy=Accuracy(replay),Frames=replay.Frames.Count,Notes=replay.Notes.Count,Start=replay.Frames[0].Time,End=replay.Frames[replay.Frames.Count-1].Time};
                            Extract(replay,f,waitForIdle);
                            if(f.Cuts<2){f.Rejection="Too little continuous human tracking.";f.Examples.Clear();}
                        }
                        catch(Exception e){if(!(e is IOException) && !(e is InvalidDataException) && !(e is UnauthorizedAccessException) && !(e is ArgumentException))throw;f.Rejection=e.Message;f.Examples.Clear();}
                        Write(item,f,waitForIdle);
                    }
                    if(f.Rejection!=null){result.Rejected++;if(warning!=null)warning(Path.GetFileName(paths[i])+": "+f.Rejection);}
                    else if(seen.Add(f.ReplayIdentity))
                    {
                        f.Recording.Path=paths[i];files.Add(IndexSource(item,f,files.Count));
                        result.AvailableSequences+=f.Cuts;result.Recordings.Add(f.Recording);
                    }
                    else result.Duplicates++;
                }
                catch(IOException e){result.Rejected++;if(warning!=null)warning(e.Message);}
                if(progress!=null)progress("Reading complete human motion: "+(i+1)+" / "+paths.Length+" ("+((i+1)*70/Math.Max(1,paths.Length))+"%)");
            }
            result.Files=files.Count;if(files.Count==0)return result;
            ApplyLearningBudget(files,result);
            File.WriteAllLines(Path.Combine(cache,"CacheKeys.txt"),keys.ToArray());
            result.TrainingFingerprint=TrainingFingerprint(files);
            if(previous!=null && previous.TrainingFingerprint==result.TrainingFingerprint)
            {result.Examples=previous.Examples;result.ContextWeight=previous.ContextWeight;result.BoundaryWeight=previous.BoundaryWeight;result.ContextValidationError=previous.ContextValidationError;result.MeanValidationError=previous.MeanValidationError;result.ValidationExamples=previous.ValidationExamples;Write(modelPath,result,waitForIdle);return result;}
            // Read only the selected, capped excerpts once. At most 249,873
            // synchronized timestamps are retained (about 57 MB of floats),
            // rather than every recording's potentially multi-GB arrays.
            // Repeated fitting epochs keep the same ordered input and idle
            // checks without decoding the uncapped caches eighteen times.
            var selected=MaterializeSelected(files,waitForIdle);var heldRecordings=new HashSet<string>();
            if(files.Count>=7)for(int i=6;i<files.Count;i+=7)heldRecordings.Add(files[i].Identity);
            var training=RepeatSelected(selected,delegate(HumanMotionExample e){return !heldRecordings.Contains(e.Recording);},waitForIdle);
            var held=RepeatSelected(selected,delegate(HumanMotionExample e){return heldRecordings.Contains(e.Recording);},waitForIdle);
            var validation=Fit(training,delegate(int p){if(progress!=null)progress("Optimizing coordinated motion / separate-run validation: "+(70+p*3)+"%");});
            Validate(validation,held,result);
            result.Examples=Fit(RepeatSelected(selected,null,waitForIdle),delegate(int p){if(progress!=null)progress("Fitting bounded human replay excerpts: "+(85+p*3)+"%");});
            if(!result.Valid())throw new InvalidDataException("Fitted whole-body model failed validation.");Write(modelPath,result,waitForIdle);
            if(progress!=null)progress("Ready: "+result.LearningPoseSamples+" / "+MaximumLearningPoseSamples+" learned pose samples in "+result.Cuts+" intact coordinated excerpts (100%).");return result;
        }
        internal static CachedSource IndexSource(string path,HumanMotionFile file,int ordinal)
        {
            var groups=new List<int>[5];for(int p=0;p<5;p++)groups[p]=new List<int>();
            var source=new CachedSource{Path=path,Identity=file.ReplayIdentity,Key=file.Key,Phases=new int[file.Examples.Count],Sequences=new int[file.Examples.Count]};
            for(int i=0;i<file.Examples.Count;i++){var e=file.Examples[i];groups[(int)e.Phase].Add(i);source.Phases[i]=(int)e.Phase;source.Sequences[i]=e.Sequence;}
            foreach(var group in groups)group.Sort(delegate(int a,int b){int c=source.Sequences[a].CompareTo(source.Sequences[b]);return c==0 ? a.CompareTo(b) : c;});
            var cursor=new int[5];var order=new List<int>();
            while(order.Count<file.Examples.Count)
            {
                int desired=(ordinal+order.Count)%5;
                for(int offset=0;offset<5;offset++){int phase=(desired+offset)%5;if(cursor[phase]>=groups[phase].Count)continue;order.Add(groups[phase][cursor[phase]++]);break;}
            }
            source.Order=order.ToArray();return source;
        }
        internal static void ApplyLearningBudget(IList<CachedSource> files,HumanMotionModel result)
        {
            int remaining=MaximumLearningPoseSamples/HumanMotionModel.Points;result.Cuts=0;result.PhaseCounts=new int[5];
            foreach(var f in files)f.Selected=new List<int>();
            // Each round gives every recording a turn before any recording
            // receives another excerpt. When a round only partly fits, select
            // evenly across its recordings, rather than retaining a prefix.
            for(int round=0;remaining>0;round++)
            {
                var candidates=new List<CachedSource>();foreach(var f in files)if(f.Order.Length>round)candidates.Add(f);
                if(candidates.Count==0)break;int take=Math.Min(remaining,candidates.Count);
                for(int i=0;i<take;i++){var f=candidates[(int)((long)i*candidates.Count/take)];int index=f.Order[round];f.Selected.Add(index);result.PhaseCounts[f.Phases[index]]++;result.Cuts++;}
                remaining-=take;
            }
            foreach(var f in files)f.Selected.Sort(delegate(int a,int b){int c=f.Sequences[a].CompareTo(f.Sequences[b]);return c==0 ? a.CompareTo(b) : c;});
            result.LearningBudgetVersion=LearningBudgetVersion;result.LearningPoseSamples=result.Cuts*HumanMotionModel.Points;
        }
        private static string TrainingFingerprint(IList<CachedSource> files)
        {
            var identities=new List<string>();foreach(var f in files)identities.Add(f.Identity+"|"+f.Key+"|"+string.Join(",",f.Selected.ConvertAll(delegate(int n){return n.ToString();}).ToArray()));
            identities.Sort(StringComparer.Ordinal);return Digest(string.Join(";",identities.ToArray())+"|continuous-trajectory-metric-v4|pose-budget-v"+LearningBudgetVersion);
        }
        internal static IEnumerable<HumanMotionExample> Examples(IList<CachedSource> files,Predicate<int> include,Action waitForIdle)
        {
            long samples=0;
            for(int i=0;i<files.Count;i++)
            {
                if(include!=null && !include(i) || files[i].Selected!=null && files[i].Selected.Count==0)continue;if(waitForIdle!=null)waitForIdle();
                var source=files[i];var f=Read<HumanMotionFile>(source.Path,waitForIdle);
                if(f.Key!=source.Key || f.ReplayIdentity!=source.Identity || !ValidFile(f))throw new InvalidDataException("Cached demonstration changed during fitting.");
                var indices=source.Selected;if(indices==null){indices=new List<int>();for(int n=0;n<f.Examples.Count;n++)indices.Add(n);}
                foreach(int index in indices)
                {
                    var original=f.Examples[index];var e=source.Selected==null ? original : SelectedExample(original);
                    samples+=(long)e.Count*HumanMotionModel.Points;if(samples>MaximumLearningPoseSamples)throw new InvalidDataException("Continuous learning pose budget exceeded.");
                    if(waitForIdle!=null)waitForIdle();yield return e;
                }
            }
        }
        internal static List<HumanMotionExample> MaterializeSelected(IList<CachedSource> files,Action waitForIdle)
        {
            var result=new List<HumanMotionExample>();foreach(var e in Examples(files,null,waitForIdle))result.Add(e);return result;
        }
        internal static IEnumerable<HumanMotionExample> RepeatSelected(IList<HumanMotionExample> selected,Predicate<HumanMotionExample> include,Action waitForIdle)
        {
            long samples=0;foreach(var e in selected)
            {
                samples+=(long)e.Count*HumanMotionModel.Points;if(samples>MaximumLearningPoseSamples)throw new InvalidDataException("Continuous learning pose budget exceeded.");
                if(include!=null && !include(e))continue;if(waitForIdle!=null)waitForIdle();yield return e;
            }
        }
        private static HumanMotionExample SelectedExample(HumanMotionExample e)
        {
            // A cached representative may previously have counted many omitted
            // demonstrations. Only this retained, complete excerpt contributes
            // to the new fit, so its old cluster weight cannot bypass the cap.
            return new HumanMotionExample{Count=1,Phase=e.Phase,StartTime=e.StartTime,Duration=e.Duration,Score=e.Score,Recording=e.Recording,Sequence=e.Sequence,Context=e.Context,Curve=e.Curve,Kinematics=e.Kinematics,Anchors=e.Anchors};
        }
        private static void RefreshPaths(HumanMotionModel model,string[] paths)
        {var names=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);foreach(var p in paths)names[Path.GetFileName(p)]=p;foreach(var r in model.Recordings){string p;if(names.TryGetValue(Path.GetFileName(r.Path),out p))r.Path=p;}}
        private static bool ValidFile(HumanMotionFile f)
        {if(f==null || f.Examples==null)return false;if(f.Rejection!=null)return f.Examples.Count==0;if(f.Cuts<2 || f.Recording==null || f.PhaseCounts==null || f.PhaseCounts.Length!=5 || f.Examples.Count>48)return false;foreach(var e in f.Examples)if(!HumanMotionModel.ValidExample(e))return false;return true;}
        internal static double Accuracy(HumanReplayLibrary.Replay replay)
        {
            long maximum=0;int count=0;foreach(var n in replay.Notes){int s=n.ScoringType==4 ? 85 : n.ScoringType==5 || n.ScoringType==8 ? 20 : n.ScoringType>=1 && n.ScoringType<=8 || n.ScoringType==-2 ? 115 : 0;if(s==0)continue;count++;maximum+=s*(count>=14 ? 8 : count>=6 ? 4 : count>=2 ? 2 : 1);}return maximum==0 ? double.NaN : (double)replay.Score/maximum;
        }
        internal static void RequireEligible(HumanReplayLibrary.Replay r,string path)
        {
            if(!HumanMotionModel.Finite(r.StartTime) || !HumanMotionModel.Finite(r.FailTime) || r.StartTime!=0 || r.FailTime!=0 || r.PracticeSpeed!=0)throw new InvalidDataException("Only full completed runs without practice/failure may teach movement.");
            string name=Path.GetFileName(path);
            if(System.Text.RegularExpressions.Regex.IsMatch(name,@"^[^-]+-(?:(?:practice|fail|exit)-)+",System.Text.RegularExpressions.RegexOptions.IgnoreCase))throw new InvalidDataException("Quit, failed or practice recording.");
            if(string.IsNullOrEmpty(r.PlayerId) || string.IsNullOrEmpty(r.Timestamp) || !name.StartsWith(r.PlayerId+"-",StringComparison.OrdinalIgnoreCase) || !name.EndsWith("-"+r.Timestamp+".bsor",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Full-level completion cannot be verified from recording provenance.");
            double acc=Accuracy(r);if(!HumanMotionModel.Finite(acc) || acc<MinimumReplayAccuracy || acc>1.0001 || r.Score<=0)throw new InvalidDataException("Human learning requires at least 93% actual raw score / maximum score.");
        }
        private static void Extract(HumanReplayLibrary.Replay replay,HumanMotionFile file,Action waitForIdle)
        {
            HumanTape tape=HumanTape.FromReplay(replay,file.ReplayIdentity,waitForIdle);if(tape.Notes.Length<2)return;
            var regions=HumanMotionRegions.Build(tape.Notes,tape.Times[0],tape.Times[tape.Times.Length-1]);int sequence=0,frameCursor=0;
            foreach(var region in regions)
            {
                double width=region.Phase==HumanPhase.Playing ? 1.25 : 2.5;
                for(double start=region.Start;start<region.End-.10;start+=width*.80)
                {
                    if(waitForIdle!=null)waitForIdle();
                    double end=Math.Min(region.End,start+width),duration=end-start;
                    while(frameCursor+1<tape.Times.Length && tape.Times[frameCursor+1]<start)frameCursor++;
                    bool valid=true;for(int f=frameCursor;f+1<tape.Times.Length && tape.Times[f]<end;f++)if(tape.Times[f+1]-tape.Times[f]>.12){valid=false;break;}
                    // Repaired tracking is safe to display, but generated gap
                    // bridges must not be treated as measured human examples.
                    foreach(double repaired in tape.RepairTimes){if(repaired>end)break;if(repaired>=start){valid=false;break;}}
                    if(!valid)continue;
                    var e=new HumanMotionExample{Phase=region.Phase,StartTime=start,Duration=duration,Score=tape.Accuracy,Recording=file.ReplayIdentity,Sequence=sequence++,Curve=new float[129*21],Kinematics=new float[129*36]};
                    MotionVector[] priorP=new MotionVector[3];MotionRotation[] priorQ=new MotionRotation[3];double energy=0;
                    for(int p=0;p<129 && valid;p++)for(int j=0;j<3;j++)
                    {
                        var s=tape.Sample(start+duration*p/128,j);
                        if(Math.Abs(s.Grip.X)>2 || s.Grip.Y<.1 || s.Grip.Y>3 || Math.Abs(s.Grip.Z)>2 || s.Velocity.Length>(j==0 ? 3 : 14) || s.AngularVelocity.Length>(j==0 ? 6 : 66)){valid=false;break;}
                        if(p>0){double speed=(s.Grip-priorP[j]).Length/(duration/128),angular=MotionRotation.Log(s.Rotation*priorQ[j].Inverse).Length/(duration/128);if(speed>(j==0 ? 3 : 16) || angular>(j==0 ? 6 : 70)){valid=false;break;}if(j>0)energy+=(s.Grip-priorP[j]).Length;}
                        priorP[j]=s.Grip;priorQ[j]=s.Rotation;HumanTape.Put(e.Curve,p*21+j*7,s.Grip,s.Rotation);HumanTape.PutJets(e.Kinematics,p*36+j*12,s);
                    }
                    if(!valid)continue;
                    if(region.Phase==HumanPhase.Ending && energy>.45 && (priorP[1].Y>1.6 || priorP[2].Y>1.6))e.Phase=HumanPhase.Celebration;
                    e.Context=HumanContext.Describe(tape.Notes,start,duration,e.Phase);var anchors=new List<HumanAnchor>();
                    int first=HumanContext.Lower(tape.Notes,start);
                    for(int i=first;i<tape.Notes.Length && tape.Notes[i].Time<=end && anchors.Count<256;i++)
                    {var n=tape.Notes[i];anchors.Add(new HumanAnchor{Phase=(n.Time-start)/duration,Hand=n.Hand,Lane=n.Lane,Layer=n.Layer,Direction=n.Direction,Score=replay.Notes[n.Id].Score});}
                    e.Anchors=anchors.ToArray();file.Cuts++;file.PhaseCounts[(int)e.Phase]++;Accumulate(file.Examples,e,e.Phase==HumanPhase.Playing ? 24 : e.Phase==HumanPhase.Break ? 8 : 4);
                }
            }
        }
        private static HumanMotionExample Copy(HumanMotionExample e)
        {return new HumanMotionExample{Count=e.Count,Phase=e.Phase,StartTime=e.StartTime,Duration=e.Duration,Score=e.Score,Recording=e.Recording,Sequence=e.Sequence,Context=(double[])e.Context.Clone(),Curve=(float[])e.Curve.Clone(),Kinematics=(float[])e.Kinematics.Clone(),Anchors=e.Anchors};}
        private static int Nearest(List<HumanMotionExample> bank,HumanMotionExample e,bool motion,out double cost)
        {
            int best=-1;cost=double.MaxValue;for(int i=0;i<bank.Count;i++){var b=bank[i];if(b.Phase!=e.Phase)continue;double d=HumanMotionModel.Distance(b.Context,e.Context);if(d>=cost)continue;if(motion)d+=HumanMotionModel.CurveDistance(b,e)*.18;if(d<cost){cost=d;best=i;}}return best;
        }
        private static void Accumulate(List<HumanMotionExample> bank,HumanMotionExample e,int maximum)
        {
            double cost;int i=Nearest(bank,e,true,out cost),count=0;foreach(var b in bank)if(b.Phase==e.Phase)count++;
            if(i<0 || count<maximum && cost>.006){bank.Add(Copy(e));return;}
            var a=bank[i];a.Count+=e.Count;
            // Keep a real recording exemplar; don't average opposite wrist arcs.
            if(e.Score>a.Score+.005){int visits=a.Count;bank[i]=Copy(e);bank[i].Count=visits;}
        }
        private static List<HumanMotionExample> Fit(IEnumerable<HumanMotionExample> input,Action<int> progress)
        {
            var bank=new List<HumanMotionExample>();foreach(var e in input)Accumulate(bank,e,e.Phase==HumanPhase.Playing ? 256 : e.Phase==HumanPhase.Break ? 64 : 32);
            for(int epoch=0;epoch<4;epoch++)
            {
                var centers=new double[bank.Count][];var weights=new long[bank.Count];for(int i=0;i<bank.Count;i++)centers[i]=new double[48];
                // The bank stays immutable until the end of this epoch. Reuse
                // its assignments instead of doing the identical expensive
                // trajectory search again in the representative-selection pass.
                var assignments=new List<FitAssignment>();
                foreach(var e in input){double cost;int b=Nearest(bank,e,true,out cost);assignments.Add(new FitAssignment{Bank=b,Sequence=e.Sequence,Count=e.Count,Phase=e.Phase,Recording=e.Recording,Start=e.StartTime});if(b<0)continue;weights[b]+=e.Count;for(int c=0;c<48;c++)centers[b][c]+=e.Context[c]*e.Count;}
                for(int i=0;i<bank.Count;i++)for(int c=0;c<48;c++)centers[i][c]/=Math.Max(1,weights[i]);
                var representatives=new HumanMotionExample[bank.Count];var distances=new double[bank.Count];for(int i=0;i<distances.Length;i++)distances[i]=double.MaxValue;
                int ordinal=0;
                foreach(var e in input){if(ordinal>=assignments.Count)throw new InvalidDataException("Training sequence changed within an epoch.");var a=assignments[ordinal++];if(a.Sequence!=e.Sequence || a.Count!=e.Count || a.Phase!=e.Phase || a.Recording!=e.Recording || a.Start!=e.StartTime)throw new InvalidDataException("Training sequence ordering changed within an epoch.");int b=a.Bank;if(b<0)continue;double d=HumanMotionModel.Distance(centers[b],e.Context)+HumanMotionModel.CurveDistance(bank[b],e)*.08;if(d<distances[b]){representatives[b]=Copy(e);distances[b]=d;}}
                if(ordinal!=assignments.Count)throw new InvalidDataException("Training sequence changed within an epoch.");
                for(int i=0;i<bank.Count;i++)if(representatives[i]!=null){bank[i]=representatives[i];bank[i].Count=(int)Math.Min(int.MaxValue,weights[i]);}
                if(progress!=null)progress(epoch+1);
            }
            return bank;
        }
        private static void Validate(List<HumanMotionExample> fitted,IEnumerable<HumanMotionExample> held,HumanMotionModel result)
        {
            var generic=new HumanMotionExample[5];foreach(var e in fitted)if(generic[(int)e.Phase]==null || e.Count>generic[(int)e.Phase].Count)generic[(int)e.Phase]=e;
            double[] weights={0,.03,.10,.30,1,3,8},contexts={0,.1,.3,1,3,10};int variants=weights.Length*contexts.Length;var errors=new double[variants];
            // Train the retrieval metric on separate recordings, conditioning
            // on the observable starting posture as well as upcoming notes.
            // Never use the future trajectory to choose a runtime prototype.
            foreach(var e in held)
            {
                int[] best=new int[variants];double[] costs=new double[variants];for(int w=0;w<variants;w++){best[w]=-1;costs[w]=double.MaxValue;}
                for(int i=0;i<fitted.Count;i++)
                {var b=fitted[i];if(b.Phase!=e.Phase)continue;double context=HumanMotionModel.Distance(b.Context,e.Context),boundary=HumanMotionModel.BoundaryDistance(b,e);
                    for(int c=0;c<contexts.Length;c++)for(int w=0;w<weights.Length;w++){int v=c*weights.Length+w;double cost=contexts[c]*context+weights[w]*boundary-1e-9*Math.Log(b.Count+1.0);if(cost<costs[v]){costs[v]=cost;best[v]=i;}}}
                if(best[0]<0)continue;
                var losses=new Dictionary<int,double>();for(int w=0;w<variants;w++){double loss;if(!losses.TryGetValue(best[w],out loss)){loss=HumanMotionModel.CurveDistance(fitted[best[w]],e);losses.Add(best[w],loss);}errors[w]+=loss*e.Count;}
                result.MeanValidationError+=HumanMotionModel.CurveDistance(generic[(int)e.Phase],e)*e.Count;result.ValidationExamples+=e.Count;
            }
            int chosen=0;for(int w=1;w<variants;w++)if(errors[w]<errors[chosen])chosen=w;result.ContextWeight=contexts[chosen/weights.Length];result.BoundaryWeight=weights[chosen%weights.Length];result.ContextValidationError=errors[chosen];
            if(result.ValidationExamples>0){result.ContextValidationError/=result.ValidationExamples;result.MeanValidationError/=result.ValidationExamples;}
        }
        // Calibration can be updated without throwing away a completed fit of
        // the selected demonstrations. Its validation bank excludes held-out runs.
        public static void Recalibrate(HumanMotionModel model,string cache,Action<string> progress)
        {
            if(!model.Valid())throw new InvalidDataException("Reload human replays before calibrating a legacy or over-budget model.");
            var files=new List<CachedSource>();
            for(int i=0;i<model.Recordings.Count;i++)
            {
                var r=model.Recordings[i];long size,ticks;ReplayFileAccess.Metadata(r.Path,out size,out ticks);
                string key=Digest(Path.GetFileName(r.Path)+"|"+size+"|"+ticks+"|"+Revision);
                var f=Read<HumanMotionFile>(Path.Combine(cache,key+".json.gz"));
                if(f.Key!=key || !ValidFile(f) || f.ReplayIdentity!=r.Identity)throw new InvalidDataException("Calibration source changed.");
                var source=IndexSource(Path.Combine(cache,key+".json.gz"),f,files.Count);source.Held=i%7==6;files.Add(source);
                if(progress!=null && i%100==0)progress("Loading independent calibration runs: "+i+" / "+model.Files);
            }
            ApplyLearningBudget(files,new HumanMotionModel());
            var training=Examples(files,delegate(int i){return !files[i].Held && i%3==0;},null);var held=Examples(files,delegate(int i){return files[i].Held;},null);
            var bank=Fit(training,delegate(int p){if(progress!=null)progress("Calibrating context / incoming motion: "+p+" / 4");});
            model.ContextValidationError=model.MeanValidationError=0;model.ValidationExamples=0;
            Validate(bank,held,model);model.OptimizerVersion=4;
            model.TrainingFingerprint=TrainingFingerprint(files);
            if(!model.Valid())throw new InvalidDataException("Continuous motion calibration failed.");Write(Path.Combine(cache,"HumanMotionModel.json.gz"),model);
        }
        internal static string Digest(string text)
        {using(var h=SHA256.Create()){byte[] bytes=h.ComputeHash(Encoding.UTF8.GetBytes(text));var s=new StringBuilder();foreach(byte b in bytes)s.Append(b.ToString("x2"));return s.ToString();}}
        internal static T Read<T>(string path)
        {return Read<T>(path,null);}
        internal static T Read<T>(string path,Action waitForIdle)
        {if(new FileInfo(path).Length>64*1024*1024)throw new InvalidDataException("Motion cache bound exceeded.");using(var f=new ReplayFileAccess.IdleStream(File.OpenRead(path),waitForIdle))using(var z=new GZipStream(f,CompressionMode.Decompress))using(var r=new StreamReader(z))using(var j=new JsonTextReader(r))return new JsonSerializer{MaxDepth=32}.Deserialize<T>(j);}
        internal static void Write<T>(string path,T value)
        {Write(path,value,null);}
        internal static void Write<T>(string path,T value,Action waitForIdle)
        {string temp=path+".tmp";using(var f=new ReplayFileAccess.IdleStream(File.Create(temp),waitForIdle))using(var z=new GZipStream(f,CompressionMode.Compress))using(var w=new StreamWriter(z))using(var j=new JsonTextWriter(w))new JsonSerializer().Serialize(j,value);if(File.Exists(path))File.Replace(temp,path,path+".bak");else File.Move(temp,path);}
    }
    public sealed class HumanRegion { public double Start,End;public HumanPhase Phase; }
    public static class HumanMotionRegions
    {
        public static List<HumanRegion> Build(IList<HumanChartNote> notes,double start,double end)
        {
            var regions=new List<HumanRegion>();if(notes.Count==0){regions.Add(new HumanRegion{Start=start,End=end,Phase=HumanPhase.Break});return regions;}
            double cursor=start,opening=Math.Min(end,notes[0].Time-.22);Add(regions,cursor,opening,HumanPhase.Opening);cursor=Math.Max(cursor,opening);
            for(int i=1;i<notes.Count;i++)if(notes[i].Time-notes[i-1].Time>=1.35)
            {double a=Math.Max(cursor,notes[i-1].Time+.28),b=Math.Min(end,notes[i].Time-.65);Add(regions,cursor,a,HumanPhase.Playing);Add(regions,a,b,HumanPhase.Break);cursor=Math.Max(cursor,b);}
            double ending=Math.Min(end,notes[notes.Count-1].Time+.25);Add(regions,cursor,ending,HumanPhase.Playing);Add(regions,Math.Max(cursor,ending),end,HumanPhase.Ending);return regions;
        }
        private static void Add(List<HumanRegion> list,double a,double b,HumanPhase phase){if(b-a>=.08)list.Add(new HumanRegion{Start=a,End=b,Phase=phase});}
    }
}
