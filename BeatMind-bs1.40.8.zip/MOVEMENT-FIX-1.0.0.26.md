# 1.0.0.26 — preparation and contact scheduling

The real 1.0.0.25 run of The Purple Dimension exposed two supported causes of missed/bad cuts.

1. Every pre-song preparation pass stopped with `System.FormatException` in `PreSongTrainer.Signature`. Beat Saber's map rotation is an integer; floating-point `"R"` formatting throws for that type. The fingerprint now uses typed, invariant numeric serialization, including individual vector components. Its revision changed so previous preparation cache entries are revalidated.
2. At song time **76.8629 s**, the blue up note at **76.8526 s** requested a contact at **76.8876 s**, while its next down note at **76.91725 s** requested **76.8823 s**. Independent learned offsets reversed their order. The planner treated any difference below 12 ms, including a negative difference, as one contact and discarded the second arrow's identity/direction. Same-time stacks could also receive conflicting offsets.

`CutSchedule` keeps requested variants and learned rewards intact, but projects applied offsets into chart-relative slots. Consecutive contacts retain at least half their nominal interval for the wrist transition. Same-hand notes at exactly the same chart timestamp share their median requested contact time. The other hand's timing remains independent. Ordinary nearby arrows retain separate contacts; the existing short continuous-chain merge is restricted to explicit chain elements. This changes scheduling rather than imposing a new movement filter or rotation clamp.

Playback planning, contact invalidation, native jump-position prediction, preparation candidates, evaluation and diagnostic traces use `TrackedNote.HitTime`. Chart notes are chosen/scheduled once before playback and rescheduled after preparation changes. Future-contact filtering and preparation follow-through expiry also use that contact clock. Native cube prediction uses the applied offset rather than the unprojected request.

Changed runtime files: `CutSchedule.cs`, `PreparationSignature.cs`, `MovementPlanner.cs`, `PreSongTrainer.cs`, `Session.cs`, `SaberTrace.cs`, `Plugin.cs`.

Validation:

- Release DLL compiled against this machine's Beat Saber 1.40.8 assemblies.
- Full offline suite passed, including the v14 motion reference, hybrid accuracy/acceleration, dense streams, repeated-arrow recovery, replay learning, memory cap, unranked hooks and native planner publication tests.
- 3,942 focused schedule/fingerprint assertions and 121 assertions invoking the shipped native scheduling method passed. Static checks verify the shipped fingerprint's typed integer calls, shared contact clock and all 32 Harmony targets.
- The actual map hash was verified as `6343BBDA0B1C75D52423E6273858C1D80B6F9326`. All **2,275** native timing keys were checked using the saved learning snapshot, with the captured up/down choices explicitly restored for reproduction. In Play & Learn mode, five reversed pairs, ten inappropriate merges and one split stack became zero. The focused 75.85–78.55 s movement proxy retained the previously lost distinct contact; direction errors stayed zero and constrained geometric contacts decreased from three to two. The reproduced up/down pair no longer required a limited contact.
- The proxy still contains existing constrained contacts. It approximates scene geometry and does not execute Unity collision/scoring code. It does not establish perfect map accuracy.

The human motion solver, swing-speed/acceleration profile, replay fitting, three models, 250,000-pose limit, user settings, stored learning, backups, human recordings, existing best replay, F6/F8 and score-submission blocking are preserved. Existing recorded replay playback continues to reproduce the original recording. No VR/in-game run was performed by the assistant.
