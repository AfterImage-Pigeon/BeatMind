# Two-menu startup fix — DLL 1.0.0.5

The installed game's `2026.10.01.16.00.06.log` showed an undefined target for `CompanionAuthenticationPatch` at 16:00:14. This caused `Plugin.Enable` to abort before the runtime and either menu existed.

The old constructor attribute omitted its argument types. Installed Harmony 2.10.2 interprets that as a zero-argument constructor. Beat Saber 1.40.8's actual `PlatformAuthenticationTokenProvider` constructor takes `IPlatformUserModel` and `UserInfo`. The patch now declares both types explicitly. It observes the native instance; authentication behavior is unchanged.

- Solo → Mods → BeatMind is the original learning panel, including all six pages.
- Online → Mods → SaberMind 1v1 is a separate online-only opponent panel.
- Create Server keeps the left-hand 1v1 controls. Each view has its own bound objects and shares the multiplayer settings; changes refresh both views.
- A prediction error no longer permanently disables menu registration. Registration retries transient failures and duplicate names remain suppressed by BSML.
- Failed creation of the server panel clears its partial objects so reopening can retry.
- All motion, scoring, note planning, replay learning and persistence source files remain byte-for-byte unchanged from 1.0.0.4.

Verification: the full offline suite passes, including 32 native hook bindings, per-view BSML value/action/component checks, and distinct Solo/Online registration masks. A new regression uses the installed Harmony resolver to reproduce the old null constructor target, resolve its correction and resolve all 32 shipped hooks. These tests do not execute Unity or prove VR layout/network operation.

The installation scan found one active SaberMind-family DLL (`Plugins/BeatMindHumanBeta.dll`). `ClearMind.dll` is a separate mod and stays untouched. The update replaces only the mod DLL and preserves every file under `UserData/AIPlayAndLearn`. The ZIP contains no UserData or private invitations.
