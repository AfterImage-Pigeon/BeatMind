# 1.0.0.13 — replay swing speed, live planning and dense cuts

The patch targets the reported recurring gameplay hitches, generated swing speed overriding human recordings, and stopped swings in dense sections. No models, learning rules, menus or additional features were added.

## Confirmed causes and changes

- **ReplayMotor.FitContact** previously replaced measured wrist motion with a generated NPS-dependent speed floor and clipped off-axis wrist motion. A valid recorded 7.6557 rad/s wrist became 52.3981 rad/s in the reproduced dense-note fixture. Valid recorded cuts now retain measured angular speed, roll, acceleration and hand velocity, transported into the fitted saber frame. If retargeting makes a cut too slow or points its velocity against the arrow, correct that cut using its actual contact/tip lever and existing minimum speed; do not add handle translation to compensate. The same fixture now stays at 7.6557 rad/s. The existing no-source stroke remains.
- **Session.Move / MovementPlanner** repeatedly rebuilt complete plans synchronously. The captured 12-second dense attempt recorded 89 left and 104 right plans, averaging approximately 12–13 ms, peaking around 17 ms each. New **ReplayPlanJob** advances the same solver incrementally, with up to 0.9 ms requested per hand and a shared 2 ms requested frame budget. Start normal refreshes early and continue the current phrase while planning. Publish from the preserved outgoing pose; cancel stale graph revisions and dispose pending jobs on exit. Initial plans and pre-song practice remain synchronous. An atomic solver step can exceed a requested budget; this is not a hard frame-time guarantee.
- **ConstrainedReplayTrajectory.ContactRepair** previously discarded an entire contact window if one transition was unsafe. It now keeps a feasible subsequence and marks only skipped contacts as limited. The reproduced fixture retains two reachable cuts instead of one when an impossible 5 ms jump is interposed. This avoids losing otherwise usable strokes across the whole repair interval.
- **ReachTransition** and trajectory validation expose incremental work boundaries without changing the underlying reach calculations. Idle strokes, pivots, cut timing, learned data and leaderboard blocking remain.

Changed source: ReplayMotor.cs, ReplayPlanJob.cs, ReachTransition.cs, ConstrainedReplayTrajectory.cs, MovementPlanner.cs, Session.cs and Plugin.cs. ReplayPlaybackTests.cs covers valid recorded cut jets, scored-window preservation, dense partial repair, and exact equivalence between incrementally and synchronously solved motion. Build/test defaults now target the dedicated 1.40.8 (3) instance.

## Verification

- Compiled against the actual 1.40.8 (3) libraries. Full offline regression suite passed, including existing compact pivot, idle-source stroke, event alignment, learning/persistence, replay eligibility, two-menu bindings and all 32 native Harmony targets.
- Dense 40-note solver equivalence: identical grip, orientation and angular velocity at 1,500 sampled timestamps per hand. Solver work spans multiple slices instead of one monolithic call.
- Same 46.23-second $100 Bills Expert proxy: 145 fitted contact probes, zero fitted misses, 141 valid first-collision proxies and three direction errors before and after. This does not execute native collisions or calculate an in-game score.
- Eight actual eligible recordings: 1,337 plans, 5,915 evaluated cuts and 666,649 trajectory samples. Contact-distance proxy failures improved from 494 to 243; direction proxy differences from 33 to 10. Zero unmarked contact-distance failures and zero unreachable contacts. Remaining adapted/limited cuts mean this is not a guarantee of perfect accuracy.
- Measured maximum grip speed 17.1977 m/s; angular speed 125.0267 rad/s. The latter is slightly above the 125 rad/s sampled trajectory certification threshold; this regression did not establish a strict continuous maximum. Angular derivative error was below 0.000009 rad/s.
- A separate full GHOST Expert graph preparation completed offline with retained managed memory below 48 MB. The live game's out-of-memory failure and approximately 15 GB working set were observed, but not reproduced or conclusively attributed to a retention bug. This patch does **not** claim to resolve that crash.

There has been no Unity gameplay, VR, live frame-time or live cut-accuracy test of this build. Time-slicing tests validate the solver and its equivalence, not the runtime scheduling or every mod interaction. Replay speed replication requires an available compatible human recording; fallback intervals cannot imitate an absent recording.

The local installation updates only the SaberMind DLL in the AI instance, verifies retained learning/settings/model data, and backs up/removes its plugin from the old personal instance. Source replays remain untouched. Every bot mode remains unranked with score submission disabled.
