# Global 93% human replay policy — DLL 1.0.0.6

Every human recording used by `HumanMotionTraining` must be a completed, non-practice run with measured raw-score accuracy at or above 93%. This applies to automatic BeatLeader imports, manually supplied files and public downloads. Lower-accuracy originals stay on disk; they no longer contribute to the fitted model.

The eligibility revision is part of per-file cache keys and consequently both model fingerprints. The old 80% caches cannot retain rejected examples or restore the old fitted model without rechecking recordings. Regression coverage seeds an accepted 80% legacy file/model cache and confirms both are bypassed and the recording is rejected. Boundary tests accept the first whole-point score above 93% and reject the point immediately below it. Existing cut, speed, pattern, replay and movement regressions also pass.

The library fingerprint sorts the file identity keys rather than depending on absolute folder ordering. Relocating the verified downloads into the game retains the pre-fitted model. A regression relocates the same recordings across two differently sorted folders and verifies the cached fit is restored.

Public downloads are selected from actual installed map hashes and available difficulties, with top accuracy scores in the ordinary unmodified human leaderboard context. Bot flags, suspect statuses, modifiers and unavailable files are excluded. Each downloaded file is parsed using the same BSOR reader as the mod, matched to the API's player, map, difficulty, mode and raw score, checked for zero failure/practice values and verified to meet 93% using the actual notes/multiplier ramp. The measured and published accuracy must agree.

BeatLeader's public CDN filenames differ from its local recording filenames. The importer preserves the original download under a score-specific archive directory, records the public URL/score metadata and SHA-256, and creates a verified local-format copy containing the real player ID and recording timestamp. It never edits replay bytes. The local copy works with the existing completion/provenance checks. Identity-based deduplication remains unchanged.

The trial successfully fitted 3,380 transitions from eight public recordings, with no rejected files; their accuracy range was 96.949%–97.812%. Offline validation establishes parsing and fitting, not live VR performance or a promised gameplay accuracy increase.
