# SaberMind playback performance and contact repair — 1.0.0.10

Beat Saber PCVR 1.40.8. Public name remains BeatMind Human Beta V1.0.0.

## Evidence and causes

The 2026-10-02 15:49:08 game log reports out-of-memory exceptions in pre-song practice and live movement. The live exception invokes Session.Stop, which explains the observed loss of AI control. This proves allocation failure stopped the bot; it does not independently establish the cause of the entire game exiting.

Replay fitting retained every qualifying recording's cached example arrays, plus training/validation lists, simultaneously. Memory scaled with the entire replay library. The fitted model itself was already bounded. This unnecessary bulk retention created memory pressure; unrelated game/mod allocations can also contribute to process exhaustion.

Fallback graph selection, alignment and handoff validation ran during live saber updates. Repeated samples rebuilt interpolation curves for all three joints even when only one joint was requested. Background replay import/fitting could continue during a song. These create avoidable CPU and garbage-collection work during playback.

The stability repair had an independent accuracy defect: it replaced the interior of an unsafe interval with the human teacher, discarding fitted contacts inside that interval. It then marked those contacts limited. A focused reproduction fails on 1.0.0.9 with `repair discarded its physically feasible fitted contact` and passes on this build.

The saved Quiet Water bot replay also records low pre-swing ratings, early contacts and off-centre cuts. This patch does not claim every scoring issue is resolved or guarantee 100-point cuts.

## Changes

- HumanMotionTraining reads one cached recording at a time on each optimizer pass. Source ordering, four optimization epochs, representative selection, counts, held-out validation and the 93% qualification policy remain the same. Representatives are copied before releasing each file. Recalibration also streams its inputs.
- Plugin cooperatively suspends replay fitting while a song is active. Session publishes the playback flags safely to that worker.
- Session prepares the unchanged solo motion graph before audio starts, including Play Learned. Preparation uses the existing loading view. The trained motor and learned decisions remain unchanged.
- HumanMotionGraph reuses its example tapes. HumanTape caches eight interpolation intervals per joint rather than rebuilding three joints on every probe.
- ReplayMotor has bounded, exact-timestamp pose/geometry caches. Cached pose values are copied before publication; caching does not alter trajectories or their derivatives.
- Normal trace capture is limited to 10 Hz. Detailed debug capture retains its previous frequency. An unnecessary second source evaluation was removed. Actual live planning mean/peak times are logged for follow-up diagnosis.
- ConstrainedReplayTrajectory first tries a continuous reach-aware repair through the existing fitted contacts. It accepts that route only if it satisfies the existing speed/reach checks. Infeasible cases retain the marked fallback. Contact-direction metadata survives repair.

No new AI models, features, swing-speed changes, score submission, or settings changes. The body remains invisible. Off, F8, learning persistence, replay eligibility, no-fail assistance, restart controls and leaderboard blocking remain present.

## Verification

- Release compilation passes; all regression suites and all 32 installed Harmony target/binding checks pass.
- Streaming regression enumerates 2,560 complete demonstrations. Retained peak is about 1.27 MB versus 75.29 MB of pose/derivative arrays if all inputs were retained. Streaming and in-memory fitting produce identical serialized parameters in the deterministic comparison.
- Prepared/unprepared graph comparison preserves selected positions and rotations. Prepared playback performs no additional graph searches in that test.
- Offline KNOCK KNOCK graph harness: the worst capture plus 0.9-second batch of 240 Hz head/hand queries measures about 31.02 ms before versus 2.81 ms with precomputed routes. This is an offline batch timing, not a measured VR frame time.
- Same 32.35-second 100Bills test: 114 contact probes; fitted-contact misses 7 → 0; first swept-collision good results 99 → 102. Wrong-direction collision proxies remain 3; wrong-hand proxies remain 0. Human source coverage is unchanged. Angular derivative error stays below 0.000001 rad/s.
- Eight real human recordings: 1,337 plans, 5,915 contact probes and 666,649 motion samples. Approximate-geometry contact misses 888 → 540; all remaining misses are marked limited. No unmarked contact misses or unreachable contacts. Mean plan cost measures about 5.58 → 4.20 ms in these runs; maxima remain about 53–57 ms. Timing varies with JIT, map and machine load. Individual contact replans remain synchronous.
- Continuous repaired contacts are covered by reach/speed checks and finite-difference wrist-derivative checks. Original contact times and cut-speed policy are preserved.

The collision tests approximate native note volumes and movement. They do not execute Unity collision/scoring. VR rendering, actual cut scores, frame rates and the user's observed lag spikes have **not** been verified in-game on this build. Residual direction/scoring and expensive dense-map replans require an actual game run to assess.
