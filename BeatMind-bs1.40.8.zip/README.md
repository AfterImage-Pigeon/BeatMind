# BeatMind Human Beta V1.0.0 — continuous human motion rebuild

For Beat Saber PCVR 1.40.8. DLL file version **1.0.0.25**. Local AI instance: **1.40.8 (3)**. Solo menu: **Mods → BeatMind**. Private opponent menu: **Online → Mods → SaberMind 1v1**, with the separate options beside Create Server.

The 1.0.0.25 patch makes measured cut score the learning objective. Accurate cuts receive no style penalty; the stroke policy keeps improving toward the chosen accuracy target, and newer measured winners take priority over older replay decisions. Pre-song geometric checks use exact contact time and no longer penalize useful acceleration. Verified preparation can be reused for identical inputs, playback preparation batches work within the existing frame budget, and replay fitting avoids repeated trajectory searches within an epoch. The offline equivalent-fit benchmark was about 40% faster with identical learned output; total loading time still depends on the map, replay library and cache state. See [verification and limitations](MOVEMENT-FIX-1.0.0.25.md).

The 1.0.0.24 patch fixes a full-turn recovery between repeated arrows, including two downslashes at different heights. Their recovery now returns against the cutting direction instead of choosing a shorter forward rotation around the circle. Replanning preserves that exact return. The existing scored contact position, orientation, time and speed remain intact. See [verification and limitations](MOVEMENT-FIX-1.0.0.24.md).

The 1.0.0.23 fast-stream fixes remain: dense patterns use a compact reachable hand pivot and share continuous wrist curves through contacts; grip repairs retain the scored wrist; replay roll comes from measured angular motion. The **250,000 timestamp** learning/cache budget, three models, learned data, invisible body, menus, F6 camera switch and unranked protections remain current. The existing stopped-clock memory safety collection can still cause a brief pause under unusually high allocation growth. This build has not been tested in-game or in VR.

This release replaces the gameplay movement generator with a coordinated replay motion graph and a contact-constrained replay motor. Head and both hands share one ordered human recording clock. A replay is a demonstration of continuous motion: its poses, speed, acceleration, wrist angular velocity, braking, follow-through and transitions stay connected in time.

## Human replay learning

**Auto-learn my replays** reads all eligible `.bsor` files in `UserData/BeatLeader/Replays` and `UserData/AIPlayAndLearn/HumanReplays`. Only verified full completed, non-practice human recordings at **93% accuracy or higher** may teach movement. Failed, quit, bot-labelled and known bot-session recordings are excluded. Originals stay untouched. Previously accepted files are rechecked for the new model format.

On a matching chart, the best qualifying human run supplies its full simultaneous head and saber trajectory, including the intro, note-free breaks and recorded post-song gestures. On other charts, the graph fits and selects whole ordered sequences conditioned on both hands' upcoming notes, cadence, outgoing motion and source sequence. It never selects independent pose targets.

Each retained sequence stores 129 synchronized samples and 57 channels: head/left/right position and rotation, linear velocity and acceleration, and angular velocity and acceleration. Timestamps and source sequence identities are preserved. The derivatives come from the original timestamped tracking, with analytic continuous curves; BSOR does not directly record acceleration or elbow joints. Training compares ordered trajectories and their derivatives, and calibrates boundary matching on separate held-out recordings. The representation is an exemplar motion graph, not a neural network.

The 250,000-sample limit counts one simultaneous head/left/right state at one timestamp. The largest full-excerpt budget is **1,937 excerpts / 249,873 timestamps**. Selection is deterministic and balanced across recordings and motion phases; it never truncates an excerpt or counts omitted recordings as retained demonstrations. All eligible source recordings stay indexed for matching-map playback, and original replay files remain untouched. Selected excerpts are decoded once and reused during fitting; exact-run caches also have a combined 250,000-frame retention limit. The cache budget revision rejects old 500,000-pose models, including backups, before making them available for playback.

The three models remain **Rapid, Natural and Human Simulation**. Existing timing/stroke data and contact controls are preserved. Human replay fitting supplies a motion prior; actual cut score drives stroke learning without an aesthetic reward. The models evaluate different numbers of motion candidates and contact fits. Source sequences are cached, and exact recordings load in the background.

## Movement

The motor jointly fits hand position, saber orientation and contact distance to the actual notes. It retains existing learned hit timing. Recorded poses guide contact fitting. Near a cut, the v14 progressive analytic stroke uses the 0.9.9 speed bands and reaches its maximum at contact, with extra cadence speed only where required to fit the available interval. Human replay roll and hand movement shape the blade's visible motion. Dot notes keep a valid measured swing direction instead of being tested against an arrow. Dense cuts share continuous contact-to-contact wrist paths with exact contact velocity and acceleration; the hand repositions only as required by the upcoming pattern and physical reach. Openings and breaks retain ordered recorded gestures. There is no universal upright return or per-frame random rotation. Analytic curves carry velocity and acceleration through handoffs. Reaching farther notes can still require legitimate hand movement.

The fallback graph plays one opening sequence once, then prepares for the first note. Each contiguous break gets one unused break sequence, cropped when necessary and followed by a smooth settle. These gestures never loop or stack. Playing sequences match their ordered hand/cut events to the current chart using one continuous source clock for head and both hands. Unmatched intervening source cuts are excluded, and shared prefixes of adjacent training windows are not replayed. An incompatible source clock or handoff is rejected using the same motion range accepted during training; the existing contact motor supplies the interval when a compatible demonstration is unavailable. Published plans freeze the coordinated human motion. See **MOVEMENT-FIX-1.0.0.9.md** for event-alignment evidence and **MOVEMENT-FIX-1.0.0.10.md** for contact repair and performance checks.

The invisible articulated rig follows the resulting head, shoulders, arms, elbows, wrists and hands with configured proportions and reach constraints. No body meshes are created. Head motion follows the recording, with bounded obstacle avoidance where required. Elbows and torso are inferred because ordinary BSOR replays do not track them.

Human recordings can contain a celebration only if the game captured that motion. The system learns available gestures and plays an ending once, then settles; it cannot recover unrecorded post-results movements. It adds no per-frame random jitter.

Incompatible contact targets can still require adaptation. Local stability checks prefer a continuous recorded stroke over a physically impossible jump, and mark these contacts in diagnostics so they can be refitted. This is an explicit limitation, not a guarantee of perfect hits or scores.

## Preserved controls

- Play & learn / Play learned / Watch best replay / Off.
- F8 manual takeover; current bot gameplay stays unranked.
- F7 gameplay HUD toggle; customizable HUD preferences.
- F6 switches AI head and mouse camera in FPFC during live Play & learn, Play learned and replay watching; WASD/QE moves the free camera. The switch affects only the view. F8 still returns gameplay to manual control.
- Pre-song learning screen and measured practice progress.
- Training accuracy dropdown and three consecutive qualifying runs before auto-restart stops.
- Measured cut feedback, note timing/stroke evidence, best replay replacement, persistence and backups.
- Separate learning and private 1v1 menus. Private multiplayer still requires a second authenticated client/account; see PRIVATE-MULTIPLAYER.md.
- All AI, training, watching and opponent gameplay remains unranked. Score submission remains blocked. Predictions use measured runs; unreliable PP remains N/A.

## Install and verify

Close Beat Saber and copy the ZIP's **Plugins** folder into your 1.40.8 instance. Replace `BeatMindHumanBeta.dll`. Keep one active copy of this mod; archive old BeatGPT/SaberMind/AIPlayAndLearn DLLs outside Plugins. Keep BSIPA, BSML and BS Utils installed.

The ZIP contains no user recordings or UserData. Keep your existing learning, settings and replays. On another installation, the new movement model will fit from that installation's eligible recordings in the background. The prepared model can be installed locally without modifying source replays.

`Build.ps1 -GamePath <instance>` compiles against the installed game. `Tests/Run.ps1 -GamePath <instance>` runs the offline regression suite and checks the native hooks and both menu bindings. `Tests/TrainHumanMotion.cs` and `Tests/RealMotionValidation.cs` provide offline training and measured trajectory validation.

See **MOVEMENT-FIX-1.0.0.8.md**, **MOVEMENT-REBUILD.md**, **TrainingReport-continuous.json**, and **MovementFixValidation-1.0.0.8.json** for the implementation and verification. The continuous-training report describes the retained model; the new movement validation report describes this patch. Offline tests do not execute Unity and do not prove live VR accuracy, visual realism or compatibility with every mod. This release has **not been tested in VR**.
