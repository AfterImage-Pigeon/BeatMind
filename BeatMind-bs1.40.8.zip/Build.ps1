param([string]$GamePath = 'C:\Users\comma\BSManager\BSInstances\1.40.8 (3)')
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'The Windows .NET Framework C# compiler was not found.' }
$managed = Join-Path $GamePath 'Beat Saber_Data\Managed'
$source = Join-Path $PSScriptRoot 'Source'
$destination = Join-Path $PSScriptRoot 'Plugins'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$references = @(
    "$managed\mscorlib.dll", "$managed\System.dll", "$managed\System.Core.dll", "$managed\netstandard.dll",
    "$managed\System.Xml.dll", "$managed\System.Xml.Linq.dll",
    "$managed\UnityEngine.CoreModule.dll", "$managed\UnityEngine.InputLegacyModule.dll", "$managed\UnityEngine.PhysicsModule.dll",
    "$managed\UnityEngine.UIModule.dll", "$managed\UnityEngine.TextRenderingModule.dll", "$managed\UnityEngine.XRModule.dll",
    "$managed\Main.dll", "$managed\GameplayCore.dll", "$managed\BeatmapCore.dll", "$managed\DataModels.dll",
    "$managed\BGNetCore.dll", "$managed\Networking.dll", "$managed\PlatformUserModel.dll",
    "$managed\HMLib.dll", "$managed\HMUI.dll", "$managed\BeatSaber.ViewSystem.dll", "$managed\Core.dll", "$managed\IPA.Loader.dll",
    "$managed\Zenject.dll", "$managed\Zenject-usage.dll", "$managed\BGLib.AppFlow.dll", "$managed\BGLib.UnityExtension.dll", "$managed\LiteNetLib.dll", "$managed\UnityEngine.UI.dll", "$managed\Unity.TextMeshPro.dll",
    "$GamePath\Libs\0Harmony.dll", "$GamePath\Libs\Newtonsoft.Json.dll",
    "$GamePath\Plugins\BSML.dll", "$GamePath\Plugins\BS_Utils.dll"
)
$arguments = @('/nologo', '/noconfig', '/target:library', '/nostdlib+', '/optimize+', '/warn:4', "/out:$destination\BeatMindHumanBeta.dll")
$arguments += $references | ForEach-Object { "/reference:$_" }
$arguments += "/resource:$source\manifest.json,SaberMind.manifest.json"
$arguments += "/resource:$source\Menu.bsml,SaberMind.Menu.bsml"
$arguments += "/resource:$source\MultiplayerMenu.bsml,SaberMind.MultiplayerMenu.bsml"
$arguments += (Get-ChildItem -LiteralPath $source -Filter '*.cs').FullName
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw "Build failed: compiler exit code $LASTEXITCODE" }
Write-Output "Built $destination\BeatMindHumanBeta.dll"



