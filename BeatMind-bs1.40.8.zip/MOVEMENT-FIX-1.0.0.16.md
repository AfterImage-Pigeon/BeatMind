# 1.0.0.16: playback and replay-import stalls

The user's 1.0.0.15 logs record playback planning slices of 120–162 ms, rising to 205–222 ms in the later dense map. A 0.9 ms scheduler budget was not a bound: individual work items evaluated an entire scoring window before yielding. Separately, the replay learner checked whether a song was playing only between files. Decoding an already-open cache, extracting a recording, or writing a model could continue during playback. Automatic garbage collection was enabled to prevent the earlier memory exhaustion, but no incremental playback schedule was owned by the AI.

Changes:

- Scoring-window probes now yield individually. The same scoring arithmetic, sample timestamps, contact constraints and protected release times are retained.
- Curve coefficients live in value storage instead of eighteen small temporary arrays per construction. Arithmetic order, derivatives and rotations are unchanged.
- In-flight compressed cache reads/writes, replay decoding, registration preparation and tracking/excerpt extraction honor the playback idle gate. Learning resumes during preparation, pauses and menus. A completed, validated cached model is made available before a changed replay inventory finishes refreshing; completed learning is retained if the refresh has no usable sources.
- When the actual Unity player reports incremental collection support, active playback and menu replay imports use manual incremental collection steps with a 500,000 ns request, once per frame. Incomplete cycles continue; stable heaps start a new cycle at most every two seconds, or earlier after 8 MiB growth. Preparation retains automatic collection. Unsupported players retain automatic collection, never disabled GC. Mode ownership is restored when the session/import scope ends. The log records runtime support and peak native collection-step time. Native time budgets are requests, not a guaranteed maximum pause; actual player behavior requires in-game verification.

Validation:

- Release build and full offline suite passed, including 32 installed Harmony target bindings, native swing-rating formula comparisons, continuation, angles, learning limits, caching, results and unranked policy checks.
- 290,472 focused assertions: old/new polynomials are bit-for-bit equal; scoring yields at most one pose probe per work item; in-flight cache decoding pauses/resumes and preserves all values; valid completed learning is available before refresh completion. 20 GC mode/lifecycle assertions use a controlled native-API substitute, not Unity execution.
- Same capped model and 46.23-second map: the serialized movement samples have identical SHA256 `7C797DA9E38E80E90A1C14C00832CE1606CCC4C9734B17D83FDD72E641788212`. Nominal contact/direction misses remain zero; swept collision proxies remain 141 good / 2 direction errors.
- Eight real recording checks: both builds produce 1,337 plans / 5,915 contacts, identical 191 limited contact proxies / 5 direction differences, zero unmarked contact misses and zero unreachable contacts. These are offline proxies, not actual Beat Saber cuts.
- Curve construction allocations: 37,280,000 → 20,000,000 bytes for 20,000 curves (46.35% lower). Same-map planning allocations: 269,975,768 → 244,233,848 bytes (9.53% lower). Observed standalone planning maximum slice: 27.44 → 18.29 ms, with the remaining >5 ms slices at initial JIT startup. Timing is machine-dependent and not a live FPS result.

No movement policy, timing/stroke learning, model selection, replay eligibility threshold, body proportions, camera behavior or leaderboard blocking was changed. Maximum learned pose budget remains 500,000. Source recordings, settings and trained model files are not replaced by installation. No Unity gameplay or VR test was performed. Other installed mods, driver/GPU stalls and players without incremental support remain possible sources of frame spikes.
